# Reale Beobachtung, Dauerbetrieb und externe Gates

Keine kostenpflichtigen Dienste oder Deployments. Die lokale Datenbank `nexus` enthält ausschließlich Abrufe öffentlicher Provider; Browser-/Chaosfixtures liegen in eigenen `_test`-Datenbanken. Die Laufzeit dieses Arbeitsauftrags ersetzt keinen 24-Stunden-Nachweis. Ein einminütiger Instrumentierungstest steht in `reports/final-soak.json` und ist ausdrücklich kein Soak-Abnahmetest.

## Wiederholbarer Betrieb

Node 24, PostgreSQL 17, `.env.example` nach `.env`, dann `npm ci`, `npm run db:migrate`, `npm run worker` und in separatem Terminal `npm run build` / `npm start`. Für Beobachtung muss der Worker durchlaufen und der Browser Discovery oder Command anzeigen. Es werden keine Schlüssel benötigt; öffentliche 429 und Coverage-Gaps bleiben möglich. Keine Budgets zurücksetzen, um Backoff zu umgehen.

```bash
# Mindestens zwei Stunden bei unverändertem Build:
SOAK_SECONDS=7200 SOAK_REPORT=reports/final-observation-2h.json npx tsx --env-file-if-exists=.env scripts/final-soak.ts
# Separater 24-Stunden-Lauf:
SOAK_SECONDS=86400 SOAK_REPORT=reports/final-soak-24h.json npx tsx --env-file-if-exists=.env scripts/final-soak.ts
# Nach dem jeweiligen Lauf:
npm run test:chain-summary
```

`status=COMPLETED` bezeichnet nur abgelaufene Beobachtungsdauer. Jeden Sample auf Workerheartbeat, DEGRADED, Datenbankfehler, Queue-Alter, ausstehende Retries, Dead-letter, kumulative Drops/Gaps und Alert-Zustellung prüfen. Observer-RSS ist getrennt von Worker-RSS. Worker/App-Prozesse zusätzlich mit `pidstat -r -u -p <PID> 30` überwachen; bei fehlendem pidstat `/proc/<PID>/status` und `/proc/<PID>/stat` alle 30s archivieren. Periodisch `/api/health` und `/api/quality` mit Abrufzeit archivieren. Keine Credentials in Logs.

## Zeitkorrelation und Interpretation

Signatur ist die stabile Transaktions-Event-ID. Ein Transaktionsereignis kann mehrere Pools/Pair-Assets enthalten. Die Queue liefert beobachtet, aufgenommen, RPC-Versuch, fetched, decoded, processed. `processed_at` entsteht innerhalb der Completion-Transaktion; die tatsächliche Sichtbarkeit liegt nach COMMIT (Commit-Netzwerkzeit nicht separat vermessen). Ein HTTP-Discovery-Envelope trägt `publishedAt`. Sichtbare Eventkarten senden nach zwei rAFs eine sitzungsgebundene `chain_ui_receipts`-Quittung; Offscreen-Karten und versteckte Dokumente zählen nicht. Das ist eine DOM/Frame-Näherung mit Browser-Selbstbericht, kein physikalischer Bildschirmnachweis.

BlockTime: Auflösung 1s, Uhrversatz und Bestätigungsdelay unbekannt. Event→UI nur für korrelierte, decodierte Nicht-Replay-Signaturen mit bekannter BlockTime auswerten. Pending-Karten sind ausdrücklich Kandidaten und keine bestätigten Pools. Erste Pending-Quittung nicht als Decode→UI verwenden: ein zweiter, nach Completion beobachteter Render wird separat unter rendered_state=decoded gespeichert. Legacy-/Kandidatenquittungen zählen dafür nicht. Neue Mints werden nicht behauptet.

Pro Stufe SQL `percentile_cont(.5/.95/.99)` in Millisekunden, N und vollständige Missing-/Negative-Clock-Zähler ausweisen. Bei N=0 NULL, bei N=1 keine Tail-/SLA-Aussage. Provider-Scope, rollierende Budgets, upstream 429 versus lokale Budgetablehnungen, WS-Unterbrechungen und Gaps separat berichten. API-Kosten ohne Abrechnungsquelle UNKNOWN.

## Chaos und Mehrclient-Abnahme

`npm run test:integration`: DB-Trigger-Rollback bei Admission und Completion, konkurrierende Claims, Lease-Verfall/Fencing, doppelte Signaturen, Burst, Queue-Limit, Retry-After, Null/unsupported TX; 1/5/20 unabhängige SSE-Sitzungen samt Reconnect und finaler Revision. Lokaler Prozess-/DB-Ausfall zusätzlich mit `npm run test:chaos` gegen laufende App+Worker, niemals parallel zu DB-abhängigen Tests ausführen. Dieser Befehl stoppt ausschließlich den lokalen Compose-Postgres und startet ihn im finally-Block wieder. Worker-Kill benötigt einen expliziten Prozessneustart/Supervisor; nacktes `npm run worker` ist kein Betriebssystem-Supervisor.

WAN: `bench:elite` testet 4× CPU, 150ms, 1.6Mbps down/750kbps up mit echten paginierten API-Requests für 1k/5k/10k. Mehrclient-SSE-Integration ist Loopback und KEIN 20-Browser-WAN-Dauernachweis. Für 1/5/20 Browser je eigenem Kontext CDP-Profil setzen, gleichzeitig 500 Änderungen/Minute einspielen, mindestens 30 Minuten, dann getrennt Reconnect, Pause/Resume und Offline je Client auslösen. Revision des Endzustands, DOM-Messung, Server-RSS/CPU und Long Tasks persistieren. Dieser breite Lauf bleibt NOT VERIFIED bis ausgeführt.

## Externe Gates

Zusätzliche Decoder erst nach offiziell belegten Program-IDs/Layouts und echten positiven sowie negativen Transaktionsfixtures freischalten. Keine generischen Programmsignaturen als neue Pools zählen. Unabhängige historische Risikolabels fehlen (`tests/fixtures/risk-evaluation/v1.json`); daher keine Precision/Recall/FPR behaupten. Reale Zielnutzer-Aufgabenstudie, VoiceOver/NVDA, Zoom, reale iOS/Safari-Geräte, Hosting-Zugriffsprüfung und externer Penetrationstest bleiben separate NOT VERIFIED-Gates. ZIP enthält keine Remote-Rechte; private Repository-Sichtbarkeit ist hier nicht prüfbar.
