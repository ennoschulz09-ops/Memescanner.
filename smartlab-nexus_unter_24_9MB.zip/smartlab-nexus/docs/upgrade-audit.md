# Upgrade-Audit – 23.10.2026

Basis: Commit `f9b348c`, bestehender Next.js-/PostgreSQL-/Worker-Pfad. Auftrag: [Upgrade-Masterprompt](upgrade-masterprompt.txt). Vorhandene Reports sind historische Hinweise; neue Belege erhalten eigene Dateien.

## Verifizierter Codepfad

```mermaid
flowchart LR
  G[GeckoTerminal REST] --> Q[Gemeinsame Zyklusqueue]
  D[DexScreener REST] --> Q
  S[Solana Read-only RPC] --> Q
  Q --> V[Schema und Normalisierung]
  V --> DB[(PostgreSQL: Beobachtungen, Audits, Alerts)]
  DB --> N[pg_notify: bisher ohne Listener]
  DB --> P[Versionsscan alle 2,5 Sekunden]
  P --> SSE[SSE-Hinweise]
  SSE --> F[Delta-Abfrage / vollständiger Resync]
  F --> UI[Virtualisierte React-Tabelle]
```

## Priorisierte Defizite

1. **P0: Commit-Push nicht angeschlossen.** Ingestion sendet bereits transaktionales `pg_notify('nexus_update', ...)`; `lib/stream.ts` hört nicht zu. Die UI wartet auf 2,5-Sekunden-Scans; das Subsekunden-Ziel ist damit nicht belegt.
2. **P0: Discovery/Hydration gekoppelt.** Profile warten im selben Task auf Marktanreicherung, bevor eine Mint sichtbar ist. Risk-Aufgaben verzögern den nächsten gesamten Workerzyklus.
3. **P1: Globaler Mindesttakt.** `Math.max(60000, ...)` gilt für alle Aufgaben. Für gecachte kostenlose Poolfeeds sinnvoll, für unabhängige Hydration/Alerts unnötig. Ohne Providerprüfung darf die Feedfrequenz nicht pauschal erhöht werden.
4. **P1: Unbeschränkte Queue.** Parallelität und Deduplizierung existieren, aber kein harter Aufnahmegrenzwert oder dokumentierter Backpressure-Zustand.
5. **P1: Voller Scannerbestand.** Erste Abfrage bis 10.000 vollständige Poolobjekte mit Quellen und Risiko-Evidenz; bisheriger synthetischer 10k-Payload 55,18 MB. Serverseitige Seiten/Filter fehlen.
6. **P1: Frische nicht getrennt konfigurierbar.** Marktfrische 180 Sekunden und Onchain-Gültigkeit eine Stunde stehen im Code; nicht jede einzelne dargestellte Zahl trägt einen maschinenprüfbaren Herkunftsvertrag.
7. **P1: Stream-Wiederaufnahme.** Reconnect erzwingt vollständigen Abgleich. Zeilenrevisionen verhindern Commit-Reihenfolgefehler; ein begrenztes Replay und Protokoll-/Checkpoint-Version fehlen.
8. **P2: Test-/Messlücken.** Tablet, 500 Updates/Minute, Publish→DOM und Konfidenzintervalle sind nicht in den bisherigen Belegen enthalten. CPU/RSS/Netzwerk/DB-Last sind nur teilweise erfasst.
9. **P2: Alert-Arten.** Neue Tokens, Liquidität, Risiko und Watchlist-Aktivität existieren. Neue Pools, Konzentrationsanstieg und Quellausfall brauchen eigene konkrete Ereignisse.
10. **Externe Grenze:** Öffentliche RPC-Methoden werden teils gedrosselt. Universelle Poolinitialisierungs-Erkennung, Holder-Owner-Zuordnung und Cluster sind nicht nachgewiesen. Kein bestehender Report ersetzt diese fehlenden Daten.

## Erhaltene Stärken

Lesende RPC-Allowlist, serverseitige Providerziele, Origin-/Eingabe-/Sitzungsprüfung, gemeinsame rollierende DB-Budgets, Retry-After, idempotente Beobachtungen, konservative Unknown-Scores, unveränderliche Audits, Alert-Outbox, virtuelle Zeilen und getrennte Testdatenbank sind tatsächlich implementiert. Sie werden durch Regressionstests erhalten.

## Arbeitsannahmen

Keine neuen kostenpflichtigen Dienste oder Schlüssel. PostgreSQL bleibt die gemeinsame Infrastruktur. HTTP-Marktdaten bleiben als Polling/Cache gekennzeichnet. WebSocket-Logs allein identifizieren keinen neuen Pool; ein programmspezifisch geprüfter Decoder wäre zusätzliche Evidenz. GitHub-Upload bleibt an die bereits gewählte private Sichtbarkeit gebunden; das Zielrepository war beim erneuten Abruf weiterhin öffentlich und leer.
