# SMARTLAB NEXUS Elite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Bestehendes Research-Terminal sichtbar und messbar veredeln, Backlog diagnostizieren und reale Grenzen beweisen.
**Architecture:** Next.js/React und separater Worker behalten PostgreSQL als einzige gemeinsame Infrastruktur. Unabhängige Bereiche Queue, Datenvertrag und QA-Werkzeuge können getrennt implementiert und danach gemeinsam geprüft werden.
**Tech Stack:** TypeScript, Next.js 16.4.2, React 19, PostgreSQL 17, Playwright/Vitest.
**Spec:** docs/superpowers/specs/2026-10-23-elite-design.md und docs/elite-masterprompt.txt.

## Global Constraints

Read-only RPC, keine Wallet-/Trade-/Signaturfunktionen. Keine kostenpflichtigen Dienste. Testdaten nur isoliert. Realtime p95 <250 ms lokal, kontrollierte Standardfilter p95 <200 ms; drei getrennte Läufe. Keine erfundenen Scores oder Live-Erfolge. Netzwerkproxy und CA-Vertrauen erhalten. AGENTS.md/mitgelieferte Next-Dokumentation beachten.

## Review Focus

- Dauerhaft fehlerhafter Kandidat darf neue Kandidaten nicht blockieren: Queue-Fairness/Dead-letter/Restart-Test.
- Fehlende Werte und widersprüchliche Quellen dürfen durch Transportkompression keine 0/grünen Werte werden: Wire-Roundtrip-/Property-Tests.
- Mobile Sheet/Frieren dürfen Fokus und jüngsten Zustand nicht verlieren: E2E Escape/Resume/Navigation.
- Leerer eigener Bestand muss in CI und beim Erststart verständlich funktionieren: dedizierter Testmodus ohne Fixtures in Live-Datenbank.
- Quoten/Offline dürfen keine Kosten-/Abdeckungsversprechen erzeugen: Quality-/Provider-Fehlertests und reale Beobachtung.

### Task A: Baseline und Designprototypen
**Files:** docs/elite-masterprompt.txt, docs/elite-audit.md, reports/elite-baseline-*, docs/design-variants/*.
- [x] Bestehende 47 Unit-/33 Integrations-/39 Browserprüfungen und aktuellen Realtime-/Listenbenchmark reproduzieren, Rohdaten erhalten.
- [x] Drei funktional gleiche visuelle Varianten mit echten Browseraufnahmen prototypisieren; Rubrik dokumentieren und eine wählen.
- [x] Bestandsbefund und Entscheidungen committen.

### Task B: Queue-Diagnose und persistierte Zustände
**Files:** worker/chain-feed.ts, worker/index.ts, lib/providers/solana.ts, db/003_*.sql, neue queuebezogene Module/Tests.
**Interfaces:** getChainQueueHealth() liefert pending/deadLetter/dequeueRate/oldestAge/retryReasons/lastDiscovery/cursor; persistente Kandidaten behalten tatsächliche Ereignis-/Beobachtungszeiten.
- [x] Backlog/Retry/Crash-/Restart-Tests schreiben und erwartetes Scheitern protokollieren.
- [x] Ursache gegen echte budgetierte RPC-Antworten untersuchen; versionierte Gründe, Dead-letter und bounded Replay einbauen.
- [x] Unit-/Integrationstests grün, echte Langzeitbeobachtung protokollieren, ohne Vollständigkeitsbehauptung.

### Task C: Kompakter Scanner und Data Quality
**Files:** lib/scanner-wire.ts, lib/api.ts, lib/client.ts, lib/data-quality.ts, lib/risk.ts, lib/domain.ts, Tests.
**Interfaces:** optionaler kompakter Pool-Vertrag wird in api() zu PoolRow rekonstruiert; API quality liefert dokumentierten DTO für UI. Risikoreports enthalten Modellversion.
- [x] Wire-Roundtrip für null/extreme Werte/Quellenkonflikte sowie Abdeckungsquoten als fehlschlagende Tests schreiben.
- [x] Überflüssige Wiederholungen reduzieren; genaue Herkunft/Missing-State erhalten und Details weiterhin vollständig abrufen.
- [x] SQL-Qualitätsaggregation, Quellenfehler und unbekannte Kosten sowie Modellversion umsetzen; Tests/Query-Pläne prüfen.

### Task D: Gewählte UI-Richtung
**Files:** app/globals.css, components/nexus-shell.tsx, scanner.tsx, token-detail.tsx, neue Command-/Quality-Komponenten, E2E.
- [x] E2E für mobile Bottom-Navigation, Analyse-Sheet, Update-Freeze/Resume und Quality-Drilldown schreiben und Rot prüfen.
- [x] Design-Tokens, Hierarchie, Command Dashboard, mobile Karten/Targets/Sheet, deutliche Quellen-/Unknown-Zustände und Risiko-Evidenzpfade umsetzen.
- [x] Standardfilter-Debounce/Renderpfad nach Baseline gezielt optimieren; bestehende E2E grün erhalten.

### Task E: Browser/Accessibility/Performance/CI
**Files:** playwright.config.ts, .github/workflows/ci.yml, scripts/elite-*.ts, tests/e2e/*, package scripts.
- [x] Browser- und Accessibility-Tests für Tastatur, Kontrast und Touchziele vorbereiten; verfügbare Browser wirklich testen.
- [x] CI vollständig und ohne Live-Providerabhängigkeit mit getrenntem Testbestand ausführen können.
- [x] Drei getrennte 500/min-Läufe, 1k/5k/10k, Desktop-/Mobile-Interaktionen/Drosselung und Query-Pläne erfassen; fehlschlagende Gates reparieren.
- [x] Abschließende Unit-/Integration-/Browser-/Security-/Build- und geordnete Chaos-/Worker-Crash-Prüfung durchführen.

### Task F: Lieferung und unabhängige Prüfung
**Files:** CHANGELOG.md, DESIGN_SYSTEM.md, DESIGN_AUDIT.md, QA_REPORT.md, PERFORMANCE.md, SOURCE_COVERAGE.md, RISK_MODEL.md, SECURITY.md, README.md, reports/elite-*.
- [x] Mindestens fünf Desktop- und fünf Mobile-Screenshots visuell prüfen, Vorher/Nachher dokumentieren.
- [x] Zehn Kategorien mit gleicher expliziter 0–10-Rubrik, Tests, Status und Blockern ausweisen; Ungeprüftes verliert Punkte.
- [x] Code-/Designreview gegen den PDF-Auftrag; gefundene Fehler beheben, passende Tests wiederholen.
- [x] Sinnvolle Commits und vollständiges ZIP ohne Secrets/Runtime prüfen.
- [ ] GitHub hochladen und tatsächlichen Actions-/Codespaces-Start prüfen: Nutzer hat privat gesetzt; verbundene Zugänge haben derzeit keinen Repositoryzugriff (HTTP404).
