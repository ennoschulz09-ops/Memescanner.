# SMARTLAB NEXUS Elite — Design und technische Entscheidungen

Auftrag: docs/elite-masterprompt.txt, bestehender Stand 7af10c6. Der Nutzer hat die unmittelbare eigenständige Umsetzung beauftragt; die bestehende Next.js-/PostgreSQL-Architektur und der reine Lesemodus bleiben verbindlich. Keine zusätzlichen Freigabeschleifen für bereits autorisierte lokale Umsetzung. Keine gebuchten Dienste und kein Upload in das weiterhin öffentliche Zielrepository.

## Ansätze und Entscheidung

1. Nur kosmetische Überarbeitung: geringes Risiko, behebt weder mobile Abläufe noch Backlog/Transportlast; nicht ausreichend.
2. Bestehendes Terminal gezielt veredeln: Design-Tokens, eigenständiges Command Dashboard, mobile Navigation/Analyse-Sheet, Herkunft und Queue-Drilldowns, kompakter Scannertransport und belastbare Gates. Gewählt, weil Module und bewiesene Datenisolation erhalten bleiben.
3. Neue Plattform/Queue-Infrastruktur: unbelegter Nutzen, zusätzliche Betriebs-/Kostenrisiken; ausgeschlossen.

Drei funktional gleiche visuelle Browserprototypen werden mit echten App-Daten aufgenommen: Atlas (ruhiger Rasterterminal), Vector (kompakte Kontur-/Datenstreifen), Folio (typografischer Research-Workspace). Eine dokumentierte Rubrik gewichtet Lesbarkeit, Hierarchie, Dichte, Zustände und mobile Nutzbarkeit. Genau eine Richtung wird fertig umgesetzt, ohne Nutzerstudien oder objektive Geschmacksnoten zu erfinden.

## Schnittstellen und Zuständigkeiten

- UI: NexusShell/Scanner/TokenDetail, neue Command-/Quality-Ansichten und Design-Tokens; Standard-Scannerflow erhalten, zusätzliche Command-Navigation. Mobile Bottom-Navigation und fokussiertes Analyse-Sheet; Einfrieren puffert Hinweise, Resume synchronisiert serverseitig.
- Queue: persistierte Retry-/Dequeue-/Dead-letter-Evidenz, begrenzte Verarbeitung und Restart-Sicherheit, Diagnose des tatsächlichen RPC-Fehlers, keine aggressiveren Providerabrufe. Ein bekannter Decoder wird versioniert; Erweiterung nur bei verifiziertem Format.
- Daten: kompakter optionaler Wire-Vertrag mit vollständiger Rekonstruktion der UI-Provenienz; große Detail-/Quellenbeobachtungen erst bei Detailabruf. Quality-API liefert Feldabdeckung, Frische, Fehlerraten und explizit unbekannte API-Kosten; Risikomodell erhält Version.
- QA: verfügbare Browser installieren/prüfen, isolierter CI-Browserbestand, drei getrennte Realtime-Läufe mit <250-ms-Ziel, kontrollierte Filterinteraktion <200 ms, mobile Drosselung, Query-Pläne, Kontrast/Keyboard, reale Langzeitbeobachtung. Kein DB-Chaos gleichzeitig mit anderen DB-Tests.

## Akzeptanz und Grenzen

Alle bisherigen Funktionen bleiben geprüft. Jede neue Verhaltensänderung bekommt einen reproduzierenden Test vor der Implementierung. Zehn Kategorien werden anhand expliziter Teilkriterien bewertet; unbekannte Nachweise geben keinen Punkt und 9,5 wird nicht behauptet. Mindestens je fünf Desktop-/Mobile-Aufnahmen aus der gebauten App, CHANGELOG/DESIGN_SYSTEM/DESIGN_AUDIT und vorhandene Berichte aktualisieren. Öffentlicher RPC oder fehlender WebKit darf als NOT VERIFIED enden; lokal reparierbare Gate-Fehler werden behoben.
