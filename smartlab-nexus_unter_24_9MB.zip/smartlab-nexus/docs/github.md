# GitHub und Codespaces

Ziel: Das neue private Repository `ennoschulz09-ops/smartlab-nexus` direkt im Browser starten. Die technische Wahl Codespaces folgt dem Wunsch nach einem Start über GitHub. Ein reines Pages-Deployment eignet sich wegen API, PostgreSQL und dauerhaftem Worker nicht; ein externes Hosting wäre eine zusätzliche Betreiberentscheidung.

## Umsetzung und Prüfung

- [x] Devcontainer mit offiziell verfügbarem Node-22-Image und PostgreSQL 17; DB nur im privaten Compose-Netz, Port 3000 weiterleiten.
- [x] Vorhandene Umgebungsdatei erhalten, Container-Datenbank verwenden, Abhängigkeiten installieren und App/Worker beim Start des Codespace starten.
- [x] Den exakten Codespaces-HTTPS-Ursprung aus der Plattformkonfiguration ableiten; Origin-Prüfungen und Development-Assets auf diese Adresse begrenzen.
- [x] GitHub Actions mit separater Testdatenbank, Unit-/Integrationstests, Typecheck, Sicherheitscheck und Build ergänzen.
- [x] Containerstart, Wiederholungsstart und Mutationen unter einem simulierten Codespaces-Ursprung prüfen; Konfiguration und bestehende Tests ausführen.
- [ ] Privates Zielrepository prüfen, Commit hochladen und Remote-/CI-Ergebnis dokumentieren.

## Start, Daten und Grenzen

In der Repositoryansicht **Code → Codespaces → Create codespace on main** wählen. Nach der Einrichtung unter **PORTS** Port **3000** im Browser öffnen. Der Codespace darf mit seinen Standardeinstellungen privat bleiben. Der tatsächlich nach außen sichtbare App-Link lautet `https://<codespace-name>-3000.app.github.dev`; er wird beim Start ausgegeben.

Der App-Container nutzt `postgres:5432`, nicht `localhost:5432`. PostgreSQL hat ein eigenes persistentes Compose-Volume. Lokale Daten aus der ursprünglichen Entwicklungsumgebung werden nicht hochgeladen. Ein neuer Codespace beginnt mit einem eigenen Bestand. GitHub-Codespace-Löschen kann diesen Bestand entfernen; wichtige Daten separat sichern.

`.env` bleibt ignoriert. Codespaces-Secrets wie ein eigener `SOLANA_RPC_URL` oder `ACCESS_TOKEN` können serverseitig konfiguriert werden. Die Compose-Datenbankwerte sind lokale Entwicklungswerte; sie sind keine Zugangsdaten zu einem veröffentlichten Server. Ein konfigurierter `APP_ORIGIN` wird im Codespaces-Startprozess durch die genaue Codespaces-Adresse ersetzt. Dadurch wird keine allgemeine Wildcard-Freigabe für Mutationen eingeführt.

Zum Prüfen der Verbindung dient `/api/health`. Ein eingeschränkter öffentlicher Provider kann einen degradierten Modus verursachen, obwohl Datenbank, App und Worker laufen. Anbieterbudgets und Backoff werden auch in Codespaces beachtet. Während der Codespace gestoppt ist, werden keine Daten erfasst. Die Nutzung kann abhängig von GitHub-Kontingent und Budget kostenpflichtig sein; es wird kein Codespace automatisch gebucht.

Logs: `.runtime/codespace.log`. `npm run codespace:stop` beendet ausschließlich den von diesem Startskript verwalteten Prozessbaum. `npm run codespace:start` startet ihn erneut; ein laufender Startprozess wird erkannt. Der eigentliche Start verwendet weiterhin `npm run dev:all` mit Schema-Migration und den getrennten App-/Workerprozessen.

## Offizielle Referenzen

- [Devcontainer-Konfiguration und Lifecycle](https://containers.dev/implementors/json_reference/)
- [GitHub Codespaces Portweiterleitung und private Zugriffe](https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace)
- Next.js-Versiondokumentation `node_modules/next/dist/docs/01-app/03-api-reference/05-config/01-next-config-js/allowedDevOrigins.md`

## Upload-Status

Der erste Versuch, das private Repository mit dem verbundenen GitHub-Zugang anzulegen, wurde mit fehlender `CreateRepository`-Berechtigung abgelehnt. Der Nutzer legte das leere Repository an. Die Prüfung meldet jedoch `visibility: public`, obwohl ein privates Repository ausgewählt wurde. Auch die Umstellung ist für die verbundene Integration mit HTTP 403 gesperrt. Der Nutzer wurde gebeten, unter Repository Settings → General → Danger Zone die Sichtbarkeit auf privat zu setzen. Es wurde deshalb noch kein Projektcode hochgeladen. Eine sichtbare Admin-Rolle des Nutzers bedeutet nicht, dass die GitHub-App alle Verwaltungsberechtigungen besitzt.

## Lokale Prüfung der GitHub-Konfiguration

Das veröffentlichte Devcontainer-Basisimage `mcr.microsoft.com/devcontainers/javascript-node:1-22-bookworm` wurde tatsächlich heruntergeladen. In einer isolierten Compose-Instanz mit eigenem DB-Volume und frisch installiertem `node_modules` wurden Node **22.16.0**, PostgreSQL 17, `codespace:setup`, `codespace:start`, Wiederholungsstart, Stop und erneuter Start geprüft. Eine fehlende `.env` wird angelegt; eine vorhandene Datei wird erhalten. Datenbank-Verbindung über den Compose-Hostnamen und echte öffentliche Daten funktionierten; beim ersten Check waren **64 echte Pools** erfasst.

**35 Unit- und 26 Integrationstests**, Typecheck, statischer Sicherheitscheck und Produktionsbuild bestanden auch in diesem Container. Die API erlaubte eine Watchlist-Mutation mit der simulierten Codespaces-Origin (`HTTP 200`) und lehnte eine fremde Origin ab (`HTTP 403`). Belege: [github-codespace.json](../reports/github-codespace.json). Die ursprünglichen umfassenden Browser-/Chaos-/Performanceprüfungen stehen im [Abnahmebericht](../reports/acceptance.md).

Zusätzlich bestand ein Browserablauf gegen den Container mit lokal konfiguriertem Ursprung: echte Scannerzeilen, Watchlist-Speicherung über ein Neuladen hinweg und Öffnen der Token-Analyse, ohne Browser-Laufzeitfehler. Der dynamische Codespaces-Ursprung wurde separat auf API-Ebene geprüft; diese lokale Browserprüfung beansprucht keine Verifikation der tatsächlichen GitHub-Portweiterleitung.

Diese Prüfung lief lokal gegen die ausgelieferte Containerkonfiguration mit simuliertem Codespaces-Namen. Es wurde noch kein echter GitHub-Codespace gebucht oder gestartet; GitHubs tatsächliche TLS-/Portweiterleitung und der neue Actions-Workflow sind deshalb noch nicht als remote erfolgreich geprüft ausgewiesen. Der private Port ist GitHubs dokumentierte Standardeinstellung. CI-Erfolg kann erst nach dem Upload auf GitHub verifiziert werden.


## Elite-Status —24.10.2026

Der Nutzer hat das Repository inzwischen auf privat umgestellt. Seitdem melden sowohl die GitHub-App als auch der als `ennoschulz09-ops` authentifizierte CLI-Zugang HTTP404; die geprüften OAuth-Scopes sind leer, und es wird keine zugängliche GitHub-App-Installation zurückgegeben. Die private Sichtbarkeit kann mit diesem Zugang nicht unabhängig ausgelesen werden. Das ist eine neue Zugriffsgrenze, keine Aufforderung, das Repository wieder öffentlich zu machen.

Erforderlich ist die Freigabe von `smartlab-nexus` für die ChatGPT/Codex-GitHub-Verbindung (GitHub Settings → Applications → Installed GitHub Apps beziehungsweise GitHub-Verbindung in ChatGPT/Codex neu konfigurieren). Keine Tokens in den Chat kopieren. Code, ZIP und lokale CI-/Browsernachweise werden vollständig vorbereitet; Upload, tatsächlicher Actions-Lauf und echter Codespace-Start bleiben bis zur Freigabe NOT VERIFIED. [Aktueller Statusbeleg](../reports/elite-github-status.json).
