# Dokumentierte Quellen und konservative Budgets

Geprüft am 23.10.2026; öffentliche APIs können sich ändern. Keine Zugangsgebühren im Standardbetrieb, kein SLA. Kostenpflichtige Anbieter werden nicht automatisch aktiviert.

| Quelle | Offizielle Dokumentation | Dokumentiertes Limit | Eigenes gemeinsames Budget |
|---|---|---|---|
| DexScreener | https://docs.dexscreener.com/api/reference | Profile 60/min; Suche/Paare/Tokens 300/min; Batch bis 30 Mint-Adressen | Profile 6/min, Markt 30/min |
| GeckoTerminal | https://www.geckoterminal.com/dex-api und https://api.geckoterminal.com/docs/v2/swagger.json | aktuell ungefähr 10/min, fluktuierend; Endpunkte 1 Minute gecacht | 8/min |
| Solana RPC | https://solana.com/docs/references/clusters und https://solana.com/docs/rpc/http | 100/10s/IP, 40/10s/Methode, 40 gleichzeitige Verbindungen; 100 MB/30s; öffentliche Nodes nicht für Produktion vorgesehen | 30/min, maximal 2 gleichzeitige Requests |

GeckoTerminal: `GET /networks/solana/new_pools`, `trending_pools`, `pools/multi/{addresses}`, OHLCV `.../ohlcv/{minute|hour|day}` mit `include_empty_intervals=false`. `Accept: application/json;version=20230203`. Kein API-Streaming verwendet. Die alte Guide-Domain leitet inzwischen auf CoinGecko um; deshalb aktuelle offizielle DEX-API-Seite und OpenAPI-Definition herangezogen.

DexScreener: `GET /token-profiles/latest/v1` ist ein Profil-Feed, keine vollständige Liste aller neuen Mints; dieser Selektionsbias wird angezeigt. `GET /tokens/v1/solana/{mints}` aktualisiert bekannte Pools; `GET /latest/dex/search?q=...` für aktive Suche. Nur Solana-Ergebnisse werden übernommen.

RPC: ausschließlich `getHealth`, `getAccountInfo` (jsonParsed), `getTokenLargestAccounts`, `getBalance`, `getTokenAccountsByOwner`, `getSignaturesForAddress`. Bestätigungsstufe `confirmed`. Keine WebSocket-Subscription standardmäßig: öffentliches Pool-Discovery über RPC bräuchte programmspezifische vollständige Decodierung und belastbare Kapazität. Adapter können erweitert werden; gegenwärtige Datenabdeckung wird nicht als vollständig dargestellt.

HTTP-Date/Age beschreibt HTTP-Response-Frische, keinen garantierten Zeitpunkt der Marktbeobachtung. `measuredAt` bleibt null, wenn der Anbieter keinen echten Messzeitpunkt liefert. 429 berücksichtigt Retry-After; Netzwerkfehler verursachen exponentiellen Backoff mit Jitter, kein Umgehen von Limits. Gemeinsame PostgreSQL-Budgets begrenzen Worker und UI-Anfragen zusammen.
