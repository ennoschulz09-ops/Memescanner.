# SMARTLAB NEXUS – verbindlicher Entwurf

Grundlage: vollständiger Masterprompt aus der vom Nutzer angehängten PDF, archiviert als `docs/masterprompt.txt`. Auftrag: vollständiger lokaler Neubau, technische Entscheidungen ausdrücklich delegiert. Keine zusätzlichen Freigabegates.

## Ansatz
Next.js/React/TypeScript mit getrenntem TypeScript-Worker und PostgreSQL. Öffentliche dokumentierte REST-Endpunkte von GeckoTerminal und DexScreener liefern Pool-Discovery und Marktbeobachtungen, Solana JSON RPC ausschließlich lesende Contract- und öffentliche Kontodaten. Keine bezahlten Anbieter nötig. Provider-Streaming wird nicht behauptet; SSE transportiert unsere budgetiert abgefragten Beobachtungen.

Alternativen: Browser-direkte API-Aufrufe würden Schlüssel, Budgets und Auditierbarkeit schwächen; ein alleiniger Next.js-Timer ist für dauerhafte Erfassung ungeeignet. Deshalb eigenständiger Worker und zentraler Datenbankzustand. Redis ist für den lokalen Einprozess-Worker nicht nötig. PostgreSQL-Advisory-Lock verhindert konkurrierende Workerbudgets.

## Datenvertrag
Poolschlüssel Mint + Pooladresse, Provider-Beobachtungen separat. Abrufzeit, HTTP-Date/Age und daraus abgeleitete Quellzeit separat. Anbieter veröffentlicht häufig keinen Messzeitpunkt; Quellzeit ist dann eine offen gekennzeichnete HTTP-Cache-Näherung, keine Blockzeit. RPC-Slot als Evidenz. Pools beider Provider werden nie für dieselbe Pooladresse doppelt addiert. Tokenalter ist ohne Mint-Entstehung unbekannt; Poolalter wird ausdrücklich als solches bezeichnet.

## Oberfläche
Deutschsprachiges Terminal, tiefes Schwarzblau, Cyan/Violett, linke Navigation, zentrale virtualisierte Tabelle, rechte Analyseansicht; mobil gestapelt. Discovery, Live Scanner, Token Detail, Risk Lab, Wallet Explorer, Watchlists, Alerts, Analytics, System Health, Settings. Echte leere Zustände. Keine erfundene Historie, Scores oder Wallet-Zuordnungen.

## Risikologik
Getrennte Datenqualität, Liquidität, Konzentration, Aktivität, Contract-Kontrollen und Momentum. Formeln und Beobachtungen auditieren. Unbekannte Pflichtprüfungen verhindern aggregierten Risikoscore. Größte Tokenkonten sind keine eindeutigen Wallet-Holder; Poolverwahrung kann enthalten sein. LP-Lock, Eigentümerkonzentration und Cluster bleiben ohne belegbare Quelle unbekannt.

## Lokalbetrieb und Schutz
Sessiongebundene Watchlists, Alerts, Presets und Einstellungen in PostgreSQL; gleichursprüngliche Mutationen, HttpOnly-Session, Body- und Rate-Limits, sichere Metadaten-Ausgabe, keine frei wählbaren externen Fetch-URLs. Keine Credentials in API-Antworten/Exporten. Optionaler Zugangstoken für nichtlokale Nutzung. Keine Handels-/Signatur-/Ausführungsfunktionen.

## Verifikation
Unit-, Integrations-, Browser-, Live-Read-only-, Chaos-, Security- und 1k/10k-Performanceprüfungen. Synthetische Lastdaten nur in Tests, niemals in der produktiven DB. Einschränkungen und Messwerte werden dokumentiert. Keine Behauptung von Produktionsreife.
