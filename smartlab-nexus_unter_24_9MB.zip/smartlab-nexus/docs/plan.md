# SMARTLAB NEXUS Implementation Plan

> Umsetzung direkt in dieser Sitzung mit `superpowers:executing-plans`; Testfälle vor der jeweiligen Kernlogik.

**Ziel:** Vollständige lokale Solana-Research-Plattform gemäß `masterprompt.txt`.
**Architektur:** Next.js UI/API, separater dauerhafter Worker, PostgreSQL; Provider hinter austauschbaren Adaptern.
**Tech Stack:** TypeScript, Next.js, React, Tailwind, PostgreSQL, Zod, Vitest, Playwright.
**Spec:** `docs/design.md`, `docs/masterprompt.txt`.

## Globale Vorgaben
Nur öffentliche lesende Daten. Keine Ausführung, keine Wallet-Verbindung, keine erfundenen Werte. Quellen, Cache, Frische und Abdeckung sichtbar. Fehlende Prüfungen bleiben unbekannt.

## Review-Fokus
- Nullwerte/Null-Liquidität und ungültige Zahlen dürfen keine Freigabe ergeben.
- Quellausfall und verzögerte Ereignisse dürfen aktuelle Daten nicht vortäuschen/überschreiben.
- Gleicher Pool in zwei Quellen darf Volumen nicht verdoppeln.
- Alert-Ruhezeiten, Quoten und Sessiongrenzen müssen erhalten bleiben.
- DB-Ausfall und SSE-Abbruch müssen sichtbare degradierte Zustände auslösen.

## Aufgaben
- [x] 1. Provider: `lib/providers/{http,dex,gecko,solana}.ts`, `lib/domain.ts`, `tests/unit/providers.test.ts`. Schnittstelle `Observation`, `fetchJson`, `DexProvider`, `GeckoProvider`, `SolanaProvider`. Erst Tests für Normalisierung, ungültige Metadaten, Nullwerte, 429/Retry-After, Cache-Alter und RPC; dann Adapter; `npm test` und echte Read-only-Probe.
- [x] 2. Datenpfad: `lib/db.ts`, `db/001_init.sql`, `lib/ingestion.ts`, `worker/index.ts`, `tests/integration/pipeline.test.ts`. Schnittstellen `ingest(observations)`, `getPools`, `getHealth`; atomare Persistenz, Queues, Audits, Aktualität, deduplizierte Ereignisse. Erst Integrationsfälle, dann Worker. PostgreSQL-Ausfall, verspätete/duplizierte Beobachtung und Wiederanlauf prüfen.
- [x] 3. Analyse: `lib/{risk,filters,alerts}.ts`, `lib/services.ts`, Tests für fehlende Daten, Gewichte, Filter, neue Risiken, Liquiditätsveränderung, Cooldown/Quota/Ruhezeiten. Risikotraces und öffentliche Wallet-Daten ohne Identitätsannahmen persistieren.
- [x] 4. API und Echtzeit: `app/api/[...path]/route.ts`, `app/api/stream/route.ts`, `lib/api.ts`, Tests für Session, Validierung, Export und Ausfall. Kein frei wählbares Fetchziel. Streaming nur eigener persistierter Beobachtungen. Änderungen inkrementell ausliefern.
- [x] 5. Terminal: `app/`, `components/`, `lib/client.ts`, Browser-Spezifikation `tests/e2e/app.spec.ts`. Alle zehn Ansichten, Filter/Spalten/Presets, Watchlists, Alert-Regeln, Zeitreihen und Quellenvergleich, Mobilansicht und Fehlerzustände.
- [x] 6. Abnahme: `scripts/{live-check,benchmark,security-check}.ts`, `README.md`, `reports/acceptance.md`. Build, Typecheck, alle Suiten, echte Providerprobe, Chaos und Lastmessungen ausführen; keine künstlichen Daten in Produktivmodus.

## Fortschrittsprotokoll
Initial: leeres Workspace, keine alten SmartLab-Dateien mitgeliefert. PDF als vollständige Anforderung verwendet. Live-Verbindungen zu drei Quellen am 23.10.2026 erfolgreich geprüft.


23.10.2026, Abschluss: Alle sechs Phasen implementiert und lokal ausgeführt. Produktionsbuild, 35 Unit-, 26 Integrations- und 20 Desktop-/Mobil-Browsertests bestanden. Echte Read-only-Anbindung zuerst umgesetzt; Providerlimits und fehlende Onchain-Abdeckung offen dargestellt. Reale DB-Unterbrechung samt Wiederanlauf, 1k/10k-Browserbenchmark und Live-Latenzmessung ausgeführt. Ein unabhängiges Schlussreview identifizierte Nebenläufigkeits-/Zustellungsfehler; alle wurden mit Regressionstests behoben. Vollständige Ergebnisse und offene Daten-/Betriebsgrenzen: `reports/acceptance.md`.

Entscheidungen: PostgreSQL übernimmt gemeinsame Budgets/Queuezustände statt zusätzlichem Redis; eigener dauerhafter Worker statt Serverless-Timer; öffentliche kostenlose Standardanbieter statt gebuchter Tarife; sitzungsgebundene lokale Nutzung statt unangefordertem Kontensystem. Keine alten Referenzdateien vorhanden. Unbelegte Owner-/LP-/Clusterprüfungen bleiben unbekannt. Kostenlose Anbieterkapazität beschränkt Abdeckung und Frische; ein dedizierter RPC ist konfigurierbar, aber nicht eingerichtet. Keine Veröffentlichung oder bezahlte Buchung vorgenommen.
