# Scanner transport and data quality contract

Task C, 2026-10-23. No additional service, provider subscription or trading capability.

## Optional compact scanner transport

The default response remains unchanged. Opt in with `format=compact` on either `GET /api/pools` (including paginated/filter queries) or `POST /api/pools/query`. Authentication, origin checks, pagination and row limits are unchanged. The generic browser `api()` expands the compact response into ordinary `PoolRow` objects before returning it; scanner cells retain their existing value, freshness, confidence, missing, conflict and risk inputs.

The JSON discriminator is `format: "nexus-pools/1"`. Pagination, `at`, totals and other response metadata remain at the top level. The transport contains:

- `rows`: identity, metadata, list values and dictionary references.
- `provenance`: complete shared `Provenance` records. Each row references its selected provenance and all source provenance summaries.
- `timestamps`: exact timestamp strings shared by evidence, signal times and sparkline points.
- `evidenceFields`: the field names used by per-row evidence arrays; absent entries are `null`, distinct from an evidence entry describing a missing value.
- `evidence`: tuples `[source, sourceTimestampIndex|null, sourceResponseAtIndex, fetchedAtIndex, computedAtIndex, freshness, confidenceLevel, missing, conflicts]`.
- `signalDefinitions`: shared risk signal metadata (`key`, label, unit, threshold, formula, weight and source).
- `explanations`: shared risk explanation strings.

Each row's `values` array follows the versioned order `priceUsd, liquidityUsd, volume5m, volume1h, volume24h, buys5m, sells5m, change5m, change1h, change24h, fdvUsd, marketCapUsd`. A missing measurement remains JSON `null`; observed zero remains `0`. Risk signal tuples are `[definitionIndex, value|null, state, updatedAtIndex|null, coverage, explanationIndex]`. Sparklines are `[timestampIndex, value]` tuples. The client expands every tuple; it does not recompute evidence from today's clock or infer safety from missing data. JSON canonicalizes negative zero to zero, as on the unchanged full API.

Complete alternate source observations are intentionally deferred: expanded list rows have `sources: []`, `sourceDetail: "deferred"` and `sourceSummaries: Provenance[]`. These summaries retain provider, endpoint, timestamps, timestamp type, cache age, latency and the freshness budget. No synthetic source observations or manufactured numeric fields are created. `GET /api/tokens/:mint?pool=:poolId` retains complete `selected.sources`, all pool observations, the conflict details, history and audit trail. Components that compare alternate numeric source values must use this detail endpoint. The selected list evidence already retains all field-specific conflict provider names.

The codec round-trips optional evidence records, custom field provenance, missing values, extreme finite numbers, large revision strings, risk reports and response metadata. It also round-trips its own expanded output. This contract is internal and versioned; arbitrary third-party compact JSON is not a validated import format.

## Data quality

`GET /api/quality` calls `getDataQuality()` and returns `DataQualityReport` from `lib/data-quality.ts`. It reads PostgreSQL aggregates only and never calls a provider. Ratios are percentages from 0 to 100, rounded to two decimals; an empty denominator returns `null`, never an implied 100% or 0% success rate.

```ts
{
  version: 1,
  at: string,
  window: { from: string, to: string, hours: 24 },
  pools: number,
  fields: Array<{
    field: string, present: number, missing: number,
    total: number, coveragePct: number | null
  }>,
  freshness: {
    current: number, stale: number, unknown: number, total: number,
    stalePct: number | null, unknownPct: number | null,
    budgetsSeconds: { discovery: number, market: number, onchain: number }
  },
  providers: Array<{
    provider: "dex" | "gecko" | "solana",
    status: "ok" | "error" | "limited" | "unknown",
    auditEvents24h: number, failedAuditEvents24h: number, rateLimitedAuditEvents24h: number,
    failedAuditEventPct: number | null, failedAuditRuns24h: number,
    lastSuccess: string | null, lastError: string | null, retryAt: string | null
  }>,
  cache: {
    scope: "retained-service-counters",
    requests: number, hits: number, staleFallbacks: number,
    hitRatePct: number | null
  },
  requestBudgets: Array<{
    channel: string, limit: number, used: number,
    remaining: number, windowSeconds: 60
  }>,
  costs: { status: "unknown", totalUsd: null, reason: string },
  limits: string[]
}
```

Coverage counts selected numeric provider fields over locally stored pools. Zero is present; JSON null or a missing field is absent. Coverage is not a correctness score and does not measure all Solana pools. There is no proxy value for supply, FDV or market cap.

Freshness uses the same per-observation or configured market budget and 60-second future-clock tolerance as the domain helper. Retrieval-only timestamps and absent source times are unknown, rather than fresh or stale. The stale denominator includes all local pools; `unknownPct` is reported separately. These are current database aggregates, distinct from the 24-hour audit-event window. Queries execute concurrently with one shared timestamp; concurrent worker commits can cause a small difference between independently aggregated counts.

Provider counters refer exclusively to retained `source_audits` **events** inside `[window.from, window.to]`. `auditEvents24h` counts those events, `failedAuditEvents24h` counts `ok=false`, and `rateLimitedAuditEvents24h` counts HTTP-429 audit events. `failedAuditEventPct` is the percentage of failed **audit events**, never a transport request error rate. A single HTTP200 response followed by a JSON-RPC/application/schema error produces one successful transport audit and one failed validation audit. The correct report is therefore two audit events, one failed event and 50% failed audit events for that single failed request. The DTO deliberately exposes no `requests24h` or `failurePct` fields and the UI must label these values as audit events.

`failedAuditRuns24h` counts observed transitions into a failing audit run within the window, including a failing first observation. It is not a count of proven provider outages, measured uptime or a guarantee that the failure began during that window. Correlated transport request counts are unavailable because the retained schema has no request correlation key. Budget/backoff checks that prevent transport are excluded. No audit events means `failedAuditEventPct: null`; current provider state is reported separately. These events cannot establish billable request counts or API costs.

Cache counters have their explicitly named retention scope, not the 24-hour audit-event scope. Cache hit rate excludes stale fallbacks, matching the existing service counters. Request budgets show all configured channels and actual claims in the trailing 60 seconds; the limit is read from the same `budgetLimits` used to enforce requests. Unknown tariffs and absent billing data yield `costs.status: "unknown"` and `totalUsd: null`, even when no audit events were observed.

## Risk model version

New reports and new persisted audit reports contain `modelVersion: "nexus-risk/2"`. Historical reports without a version remain historical and must be displayed as legacy/unknown version; their model is not guessed.

Version 2 retains independent controls, token-account concentration, liquidity, activity and data-quality signals. Unknown LP ownership, owner-wallet mapping and transaction clusters remain unknown. A total is available only when all weighted inputs exist and selected market freshness is current. Failed, excessively future-dated or expired chain checks cannot verify controls; zero/invalid mint supply cannot verify controls or concentration. Invalid numeric inputs become unknown within risk evaluation. This does not convert or invent stored provider values.

Source disagreements compare like mint/pool pairs from different providers. For nonnegative finite values the relative difference is `100 * abs(a-b) / max(a,b)`, bounded from 0 to 100. Equal values, including two zeros, do not conflict; zero versus positive is 100%. Thresholds remain above 10% for price and above 20% for liquidity/FDV. This detects depeg and zero-liquidity disagreements without infinity/JSON-null overflow. It is a source disagreement, not a claim about a peg, scam or trading outcome.

## Reproducible evidence and limits

- `tests/unit/elite-data.test.ts`: actual serialized DTO round-trip, independent field overrides/conflicts, generic API expansion, a deterministic 100-row × 32-point payload budget, 150 generated finite/null DTO cases, 100 generated extreme source comparisons and conservative-risk regression cases. Fixed fast-check seed: `20261023`.
- `tests/unit/elite-quality.test.ts`: DTO percentages, empty denominators, failed audit events, cache scope and request-budget claims.
- `tests/integration/elite-data.test.ts`: real PostgreSQL field/stale/unknown aggregation, 24-hour audits and 60-second claims, persisted model versions, full default API, compact GET/POST and complete token-detail observations.
- Tracked raw red/green output bundle: `reports/elite-data-test-evidence.txt` (65/65 full unit checks, 3/3 Task C integration checks, and successful TypeScript check). Individual work logs: `reports/elite-data-red.log`, `elite-wire-size-red.log`, `elite-risk-red.log`, `elite-quality-red.log`, `elite-data-green.log`, `elite-data-integration.log`. The provider-state-without-recent-audits regression is also included in the tracked bundle.
- `reports/elite-data-wire-quality.json` records a read-only local-public-data sample and the full `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` plans. At the recorded 3,358-pool snapshot, 100 rows shrank from 1,623,897 to 153,889 raw JSON bytes (90.52%). No gzip/brotli credit is included. Field/freshness aggregates took 65.939/21.966 ms in this one local plan sample; these are not p95 or production latency guarantees.

Payload sizes vary with metadata, explanations, timestamp diversity and retained sparkline points. The under-200 kB result is this measured 100-row sample and the named deterministic fixture, not a maximum for every possible page. Full detail intentionally remains larger. Query plans include normal sequential scans for whole-inventory aggregates; no index can avoid counting all stored coverage. The implementation reduces repeated JSONB decompression and keeps large source payloads out of the transport; it does not claim to eliminate server-side detail construction in `getPools()`.

## Review correction: audit-event semantics

The pre-release provider DTO was renamed from request/failure labels to the explicit audit-event fields above after reproducing HTTP200 plus application-error double auditing. Historical measurement files such as `reports/elite-data-wire-quality.json` retain their original payload and field names as raw evidence; their provider `requests24h`/`failurePct` values must be interpreted as audit-event counts/shares, not actual requests. This documentation change does not rewrite those samples. `tests/integration/elite-data.test.ts` executes one injected HTTP200 JSON-RPC failure through the real `HttpClient`/`SolanaProvider` and PostgreSQL audit hook, then verifies the two-event report and absence of request-error-rate fields. No live provider call is needed.

Review verification: targeted data/quality units 12/12 and Task C PostgreSQL integrations 4/4 passed. The single injected-request regression confirms two audit events, one failed event and absence of request/error-rate fields. Raw red/green and integration output: `reports/elite-quality-audit-review.txt`. Historical full-suite results in the earlier bundle remain dated evidence; the review change does not claim a new full-suite run.
