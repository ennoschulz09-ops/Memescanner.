# SMARTLAB NEXUS Upgrade – Umsetzungsplan

Ziel: vorhandene funktionierende Bereiche erhalten und die Latenz-/Datenqualitäts-/UX-Grenzen mit reproduzierbaren Belegen verbessern. Spezifikation: `upgrade-masterprompt.txt`, Befund: `upgrade-audit.md`.

- [x] A: Bestehende Unit-/Integrations-/Typecheck-Prüfungen und Browserbenchmark erneut ausführen; Baseline und Quellen dokumentieren.
- [x] B: Begrenzte Quellenscheduler mit getrennten Discovery-/Hydration-/Risk-Aufgaben, persistierte frühe Entdeckung, Token-Bucket/Circuit-Breaker/Backpressure. Tests zuerst für Aufnahmegrenzen, Scheduling und frühe Sichtbarkeit.
- [x] B: Vorhandenes PostgreSQL-NOTIFY an SSE anbinden, coalescte Revisionen, versionierte Checkpoints und begrenztes Replay, Polling-Abgleich als Ausfallpfad. Regression: verspätete Commits, Reconnect und 500 Updates/Minute.
- [x] C: Konfigurierbare Frischebudgets, Herkunft pro Marktfeld, Missing-State und konservative Onchain-Gültigkeit. Quellenkonflikte und Risk-Traces erhalten. Neue konkrete Alert-Ereignisse ergänzen.
- [x] D: Serverseitige Scannerseiten/Filter/Sortierung, bounded UI-Deltas, mobile Filter-Sheet, Tastatur/Fokus, Watchlist-Suche und Tablet-Prüfung.
- [x] E: Produktionsbuild und gesamte Testmatrix, echte Providerprobe, Chaos, 5k/10k-UI-/Streamingmessung mit Lastdefinition, Ressourcen und Unsicherheiten; Screenshots erneuern.
- [x] E: `PERFORMANCE.md`, `SOURCE_COVERAGE.md`, `RISK_MODEL.md`, `SECURITY.md`, `QA_REPORT.md` und ein evidenzgebundenes Scoreboard für acht Kategorien. Ungeprüftes bleibt NOT VERIFIED; kein pauschales 9/10.

Kein Architektur-Neubau und kein zusätzlicher Redis-Dienst. Keine Handels-/Wallet-/Signaturfunktionen. Eigenständige Umsetzung ist im PDF ausdrücklich beauftragt; Rückfragen nur bei tatsächlich zwingender externer Konfiguration.

Abgeschlossen mit expliziten Teilnachweisen: aktuelle Gate-/Kategorie-Matrix in `../QA_REPORT.md`. Öffentliche Chain-Discovery, universelle Marktdarstellungsabdeckung, Query-Telemetrie und Remote-CI bleiben dort als PARTIAL/NOT VERIFIED ausgewiesen. GitHub-Upload wartet auf private Sichtbarkeit.
