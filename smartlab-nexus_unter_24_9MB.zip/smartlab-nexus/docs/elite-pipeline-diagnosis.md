# Chain-Pipeline: Diagnose und belastbarer Nachweis

Stand: 23.10.2026. Scope: ausschließlich lesende Raydium-CPMM-Initialisierungen. Kein Handel, keine neue Programmcoverage, keine neuen Anbieter oder Abonnements.

## Tatsächliche Ursachen

1. **Nicht unterstützte Transaktionsversion.** Ein einziger budgetierter `getTransaction`-Abruf des ältesten offenen Kandidaten am 23.10.2026 um 18:42 UTC lieferte JSON-RPC `-32015`: Die Transaktion hat Version 1, der bisherige Worker fordert `maxSupportedTransactionVersion: 0`. Der Originalbefund steht in `reports/elite-chain-rpc-probe.json`. Die bisherige Schemafehlerbehandlung verwandelte diesen konkreten Fehler in ein generisches HTTP-502-Signal. Der Kandidat blieb ohne Versuchszähler, Abbruchgrund oder Dead-letter dauerhaft offen.
2. **Fehler eines Kandidaten stoppten den gesamten Decoderjob.** Der Scheduler öffnete nach wiederholten RPC-Fehlern seinen Circuit für alle Signaturen. `next_attempt_at + 60s` war keine Lösung für nicht unterstützte Versionen. Unbegrenzte Vorrangbehandlung von Live-Kandidaten konnte Replay verdrängen; zwei gleichzeitig aufgerufene Decoder konnten dieselbe Zeile bearbeiten.
3. **Risikoanreicherung verbarg Providerfehler.** `inspect()` gab nach einem fehlgeschlagenen Teilabruf unvollständige Evidenz zurück. Der Worker speicherte sie und meldete alle zehn Sekunden einen erfolgreichen Job. Historische `getTokenLargestAccounts`-Audits enthielten 252 echte HTTP 429; im neuen Pilotlauf trat dieser Fehler weiterhin auf und aktivierte den gemeinsamen Providerbackoff. Der Riskjob erhält jetzt nach der Speicherung der Unknown-Evidenz denselben typisierten Fehler mit Retry-After; sein eigener Scheduler wartet entsprechend. Der gemeinsame Providerbackoff bleibt erhalten.
4. **Im Pilotlauf gefundene Fehler der ersten Überarbeitung wurden vor der finalen Fassung behoben.** Eine Cursorpersistierung für jede Programmmeldung konkurrierte zunächst mit den vier Kandidatenschreibplätzen. Ein reproduzierter Burst von 100 normalen Meldungen ergab 89–90 irreführende Drops und einen alten Cursor. Die finale Fassung koalesziert ausschließlich den jüngsten Cursor mit einem einzelnen Writer; Initialisierungskandidaten haben weiterhin eigene vier Aufnahmeplätze. Ein gezielter Test fand außerdem einen zusätzlichen Replay-RPC-Parameter der Zwischenfassung. Der finale Replayaufruf hat genau die dokumentierten zwei Parameter. Alte Pilotzähler werden nicht rückwirkend gelöscht.

Vor dem neuen Lauf war der Worker tatsächlich beendet: Heartbeat zuletzt 17:21 UTC, elf offene Kandidaten, ältester von 16:20 UTC. Ein ruhender Worker ist ein zusätzlicher Betriebsbefund; ein größerer Pollingtakt hätte keine dieser Ursachen repariert.

## Geprüfter Vertrag und Umsetzung

Die am 23.10.2026 gelesene [offizielle Solana-Dokumentation](https://solana.com/developers/guides/advanced/versions) nennt `legacy`, `0` und `1` und verlangt ausdrücklich `maxSupportedTransactionVersion: 1`, wenn alle derzeitigen Formate akzeptiert werden sollen. [getTransaction](https://solana.com/docs/rpc/http/gettransaction) beschreibt den gemeinsamen bestätigten JSON-Vertrag und die Encoding-Option. Der Worker fordert `jsonParsed`, akzeptiert ausschließlich diese drei Versionen und validiert weiterhin das Instruction-DTO. Eine unbekannte zukünftige Version wird nicht geraten.

Der Decoder `raydium-cpmm-initialize-v1` deckt ausschließlich das bereits bekannte [offizielle CPMM-Programm](https://github.com/raydium-io/raydium-cp-swap/blob/master/programs/cp-swap/src/lib.rs) und dessen [Initialize-Layout](https://github.com/raydium-io/raydium-cp-swap/blob/master/programs/cp-swap/src/instructions/initialize.rs) ab: mindestens 20 Pflichtkonten, Pool an Index 3, Assets an Index 4/5, genau 32 Bytes aus Anchor-Discriminator und drei u64-Argumenten. Zusätzliche verbleibende Konten sind im offiziellen Context vorgesehen. Andere Programme, Discriminatoren, verkürzte Kontenlisten und fehlgeschlagene Transaktionen werden nicht als Pool akzeptiert. Beide Pair-Assets sind beobachtete Assets; insbesondere ist WSOL kein neu erzeugter Mint.

Migration `003_chain_queue.sql` ergänzt bestehende Tabellen, ohne historische Beobachtungen oder Decoderresultate zu löschen. Kandidaten speichern Zustand, Claim-Token, 90-Sekunden-Lease, Versuche, Fehlversuche, RPC-Code, Retry-/Terminalgrund, Decoder-Version sowie Ereignis-, Beobachtungs-, Abruf-, Decode- und Publikationszeit. `FOR UPDATE SKIP LOCKED` macht Claims atomar; ein alter Claim kann einen neuen Abschluss nicht überschreiben. Neue und Replay-Kandidaten werden nach Fälligkeit und Beobachtung gemeinsam abgearbeitet. Der nächste Retry verschiebt einen fehlerhaften Kandidaten hinter andere fällige Zeilen.

Bekannte permanente RPC-Fehler werden unmittelbar in Dead-letter verschoben. Null-Transaktionen und sonstige vorübergehende Fehler haben höchstens fünf Fehlversuche über Neustarts hinweg. HTTP 429 und ein aktives gemeinsames Anbieterbudget verbrauchen keine dieser fünf Fehlversuche und behalten mindestens den echten Retry-After. Ein Kandidatenfehler öffnet nicht den gesamten Decoder-Circuit. DB-Fehler beim Claim oder Speichern bleiben sichtbare Jobfehler.

Die Aufnahmegrenze bleibt 256 offene Kandidaten; Duplikate zählen auch bei voller Queue nicht als Drop. Überlauf und Admission-Backpressure werden persistent gezählt; Burstzähler werden über einen einzelnen Writer zusammengefasst. Die Signatur-/Programmcursor werden unabhängig vom 15-Sekunden-Heartbeat persistiert. Reconnect prüft höchstens 20 Signaturen; ausgeschöpfte Replaygrenzen und Verbindungsabbrüche bleiben Coverage-Gaps. Eine vollständige Chain-Historie wird nicht behauptet.

`recordDiscoveries` erhält optional die ursprüngliche Beobachtungszeit. RPC-Abrufzeit und `blockTime` bleiben davon getrennt. Erneute Publikation nach einem Crash bleibt über den bestehenden `(mint, provider)`-Schlüssel idempotent. Ein fehlender Marktpreis erzeugt weiterhin keinen erfundenen Scanner-Pool. Die RPC-Latenz wird gemessen und nicht mit einem künstlichen Nullwert belegt.

## Health-JSON

`getChainQueueHealth()` aus `lib/chain-queue.ts` liefert JSON-Version 1:

| Feld | Bedeutung |
| --- | --- |
| `pending` | Offene Kandidaten inklusive aktiver Leases und geplanter Retries |
| `deadLetter` | Persistierte terminal abgebrochene Kandidaten |
| `dequeueRate` | `windowSeconds: 300`, Claim-Anzahl und Claims pro Minute; dies sind keine erfolgreichen RPCs oder Discoveries |
| `oldestAgeSeconds` | Alter der ältesten offenen Beobachtung in Sekunden; null bei leerer Queue |
| `retryReasons` | Aktuelle offene Kandidaten je versioniertem maschinenlesbarem Grund |
| `dropped` | Persistierte Aufnahmeverluste seit Einführung dieser Instrumentierung; Pilotwerte bleiben erhalten |
| `lastRealDiscovery` | Letzter erfolgreich persistierter, versionierter CPMM-Decode mit Signatur, Slot und separaten Zeiten; ältere unversionierte Ergebnisse werden konservativ ausgeschlossen |
| `cursor` | Programmadresse, letzte persistierte Signatur/Slot/Beobachtungszeit, Replaystatus und kumulative Coverage-Gaps |

Terminale Gründe stehen zusätzlich in `chain_candidates.terminal_reason`; vollständige Versuchsverläufe in `chain_candidate_attempts`. Diese Versuchszeilen haben eine eigene Aufbewahrung nach der vorhandenen konfigurierbaren Retention. Alte, vor dieser Migration nicht instrumentierte Versuche werden nicht nachträglich erfunden.

## Tests und reale Beobachtung

Die erste Rotphase reproduzierte den verschluckten RPC-Code, fehlende Decoder-Version, Replay-Starvation, unbegrenzte Null-Retries und fehlende persistente Claim-Zustände. Spätere Rotphasen reproduzierten Cursorburst-Verluste, fehlerhafte Replayparameter, verlorenen Risk-Retry-After, einen fälschlich erfolgreichen Risk-Schedulerjob und künstliche RPC-Latenz 0. Die finalen Befehle und Ergebnisse stehen in `reports/elite-chain-tests.json`.

`worker/observe-chain.ts` führt keine RPC-Anfragen aus. Es liest alle 30 Sekunden den laufenden Hauptworker, Queue, tatsächliche Provider-Audits und persistierte Decoderresultate. Der erste elfminütige Pilot steht in `reports/elite-chain-observation.json`; er enthält bewusst Vorherzustand und Zwischenfassungen. Der getrennte finale Lauf steht in `reports/elite-chain-final-observation.json`. Der Hauptworker wurde ausschließlich vom Root-Agent geordnet neu gestartet. Ein durch aktiven Providerbackoff abgewiesener Diagnoseaufruf wurde nicht über einen anderen Anbieter oder ein zurückgesetztes Budget erneut erzwungen.

Im Pilot wurde eine echte CPMM-Transaktion mit zwei Pair-Assets durch den bisherigen Worker am 18:49:16 UTC persistiert. Dieses historische Resultat hat keine Decoder-Version und bleibt deshalb aus `lastRealDiscovery` ausgeschlossen. Das ist ein realer begrenzter Decoderbeleg, kein Nachweis durchgängiger Erfassung. Der abgeschlossene finale Lauf wird im folgenden Abschnitt und in `reports/elite-chain-live-summary.json` separat ausgewertet.

## Ergebnis des abgeschlossenen finalen Laufs

Der Hauptworker lief im ausgewerteten Fenster von **18:59:53.642 bis 19:11:26.430 UTC**, also **692,788 Sekunden** mit 24 Snapshots nach seinem Start. `reports/elite-chain-live-summary.json` enthält die nach dem finalen Start abgegrenzten SQL-Audits, Kandidaten, Zeitpunkte und Perzentile; vorherige Pilotfehler werden nicht in einen grünen finalen Lauf umetikettiert.

- 40 versionierte Transaktionen wurden abgeschlossen: 39 Replay-/Programmsignaturen waren keine unterstützte Initialisierung und wurden korrekt verworfen; ein tatsächliches, per WebSocket beobachtetes CPMM-Initialize wurde decodiert. Eine Signatur aus Replay ist allein kein Poolereignis.
- Der erste Snapshot enthielt 22 offene Kandidaten mit einem ältesten Alter von 9.594,345 Sekunden. Um 19:05:26 UTC war der alte Rückstau leer. Danach kamen neue Replay-Signaturen hinzu; am Ende waren acht Kandidaten offen, ältester 55,192 Sekunden. Das ist eine beobachtete Reparatur des alten Dauerrückstaus, keine Garantie einer dauerhaft leeren Queue.
- Der Aufnahmeverlustzähler blieb im gesamten finalen Fenster bei **885**, also **null neue Drops**. Die 885 stammen aus der Zwischenfassung, die normale Logs mitzählte; die Zahl ist deshalb kein verifizierter Zähler verlorener Initialize-Ereignisse. Sie wurde bewusst nicht gelöscht.
- Der Cursor ging weiter, aber es kamen **17 Coverage-Gap-Ereignisse** hinzu. Im Fenster lieferten sieben tatsächliche Largest-Accounts-Abrufe HTTP 429. Der gemeinsame Anbieterbackoff und der nun funktionierende Riskjob-Backoff blieben aktiv. Öffentliche WebSocket-Abbrüche und nur begrenzter Replay sind weiterhin reale Abdeckungsgrenzen.

Der neue reale Pool ist `FP7LDmBjF7RH2Aevda2Q8LvFv6j4zWbKwop9eeXVRBYe`, Signatur `5sMpE9RJ4jAfUQvQqwV9HTcNVcJvSZryDAfXgjKPEbY2FtLTjgSgX2ES7SYicxiioSNB34kFrDby59yxretEcYfh`, Slot 460555832, Decoder `raydium-cpmm-initialize-v1`, **kein Replay**. Das Pair enthält WSOL und `CAoRoYSjqc2shxvFyGMtzb84UzLwydhxVFBQPoNGChJQ`. WSOL war bereits bekannt; es entstand genau eine neue Discovery-Zeile für einen Provider/Asset-Schlüssel, kein Nachweis der Erzeugung eines neuen Mints.

| Stufe | Gemessene Zeit |
| --- | --- |
| Chain-`blockTime` | 19:06:29.000 UTC |
| Eigene WS-Beobachtung | 19:06:30.274 UTC |
| Erfolgreicher Dequeue-Versuch | 19:08:22.954 UTC |
| RPC-Ergebnis erhalten | 19:08:23.153 UTC |
| Decode abgeschlossen | 19:08:23.157 UTC |
| Kandidat/publizierte Discovery abgeschlossen | 19:08:23.161 UTC |

Event→Beobachtung waren 1.274 ms; Event→Persistenz 114.161 ms. Davon entfielen 112.680 ms auf die Wartezeit bis zum erfolgreichen Dequeue und 199 ms auf Dequeue→RPC-Ergebnis. Die gespeicherte Adapter-Provenienz misst 198,228 ms. Fetch→Decode und Decode→Abschluss betrugen je vier Millisekunden. Für diese einzelne Beobachtung sind empirisches p50/p95/p99 identisch; **N=1 schätzt keine Tailverteilung und belegt keine SLA**. Der Sekunden-Zeitstempel der Chain und unbekannter Uhrversatz begrenzen die Genauigkeit zusätzlich. DB→SSE und SSE→sichtbare UI wurden für diese Signatur nicht getraced.

Die reine `discovery_persist`-Messkorrektur und der zusätzliche Shutdown-Guard wurden nach dem Start dieses Workers getestet. Der weiterlaufende Prozess hat diese beiden kleinen Abschlusskorrekturen noch nicht geladen. Daher verwendet die Liveauswertung ausschließlich die separat persistierten Stufenzeiten und RPC-Provenienz, nicht die ältere, irreführend benannte Persistiermetrik. Alle Queue-, Cursor-, Decoder- und Risk-Backoff-Korrekturen waren im beobachteten Worker aktiv.

Lokale Endverifikation: **66/66 Unit**, **50/50 PostgreSQL-Integration**, Typecheck und Formatprüfung grün. Darin enthalten sind 13 spezielle Queueintegrationstests und sieben neue Unitprüfungen gegenüber der Basis. Die Messregression scheiterte zunächst mit 3.540.043 ms scheinbarer Persistierdauer und wurde anschließend durch einen separaten monotonic Start behoben. Beide rein lesenden Beobachter sind beendet und ihre DB-Verbindungen geschlossen.

## Ausdrücklich offen

Universelle Solana-/Raydium-Abdeckung, lückenloser Replay, ein Provider-SLA und belastbare neue Chain-Event→sichtbare-UI-Perzentile bleiben **NOT VERIFIED**. `blockTime` ist sekundengenau; Synchronisierung und Fehler der Provideruhr sind nicht vermessen. Ein kurzer lokaler Lauf und Fixturetests können diese Grenzen nicht aufheben. Die öffentlichen Largest-Accounts-Limits können weiterhin Unknown-Evidenz und Rückstau erzeugen; diese Grenzen werden eingehalten und sichtbar gemacht. Keine DB wurde gestoppt und keine synthetische Transaktion in Live-Tabellen eingespeist.

## Nachträglicher Crashreview am 23.10.2026, 23:46 UTC

Ein unabhängiger Review fand nach dem oben beschriebenen Livefenster eine weitere wichtige Crashlücke: Der koaleszierte Cursor konnte vor der Initialisierungskandidatenaufnahme committen. Ein Rollback oder Crash dazwischen hätte den fehlenden Kandidaten hinter den Replay-`until`-Cursor verschoben. Ein echter PostgreSQL-`BEFORE INSERT`-Fehler mit anschließender normaler Programmmeldung reproduzierte genau dieses Verhalten.

Der Cursorwriter wartet nun auf alle bereits gestarteten Kandidatenaufnahmen und auf die dauerhafte Evidenz etwaiger Admission-Drops. Initialize-Aufnahme wird vor dem Cursorfortschritt registriert. Bei einem Aufnahme- oder Drop-Persistenzfehler bleibt der Cursor bis zum nächsten Feedneustart blockiert. Der Fehlergrund `candidate_admission_database_error` wird bestmöglich sofort persistiert; bei vollständigem DB-Ausfall bleibt stattdessen der alte sichere Cursor erhalten. Auch die für Heartbeat und Reconnect verwendete `lastSignature` wird erst nach erfolgreichem Cursor-Commit aktualisiert. Ein Prozessabbruch kann dadurch zusätzliche Replay-Duplikate auslösen, aber keinen ungesicherten Kandidaten durch einen voreiligen eigenen Cursor überspringen. Die bestehende begrenzte Replay-Coverage bleibt ausdrücklich unverändert.

Regression Rot→Grün; gezielt der gesamte Queueintegrationstestfile **14/14 grün**, Lauf 23:46:10 UTC, 1,39 Sekunden Gesamtdauer. Keine Providerprobe, kein Workerrestart und keine Main-DB-Manipulation durch diesen Test. Die frühere 692,788-Sekunden-Beobachtung liegt zeitlich vor diesem zusätzlichen Crashfix und gilt nicht als sein Live-Nachweis. Die umfassende Repository-Abnahme nach diesem Review übernimmt die koordinierte finale QA.
