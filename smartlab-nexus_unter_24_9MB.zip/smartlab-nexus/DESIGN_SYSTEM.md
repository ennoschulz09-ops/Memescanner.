# ATLAS — SMARTLAB NEXUS Designsystem

Stand: 23.10.2026, Elite-Upgrade. Die Tokens und States stehen in `app/globals.css` im Abschnitt „ATLAS / Elite“. Die Oberfläche dient ausschließlich der Recherche.

## Grundlagen

| Token                       | Wert / Verwendung                                                                               |
| --------------------------- | ----------------------------------------------------------------------------------------------- |
| Hintergrund                 | `--bg: #090e11`, Tinte                                                                          |
| Fläche / angehobene Fläche  | `--surface: #11191f`, `--surface-raised: #19252d`                                               |
| Text / sekundär / ergänzend | `#ecf3f3` / `#a8bac2` / `#91a8b2`                                                               |
| Kontur                      | `--border: #334650`; Bedienelemente `#607e8b`                                                   |
| Akzent                      | `--cyan: #79e4d3`; Navigation, Auswahl, Quellenpfade                                            |
| Semantik                    | Rot `#ffa3b1`, Amber `#f2ce90`, Violett `#b8b3f4`; immer mit Text/Label                         |
| Radius                      | Panel 7 px, Controls 5 px, Badge 4 px                                                           |
| Abstände                    | 4 / 8 / 12 / 16 / 24 / 32 px                                                                    |
| Schrift                     | Lokaler System-Sans-Stack; Daten/Indizes `ui-monospace, SFMono-Regular, Consolas, monospace`    |
| Zahlen                      | `font-variant-numeric: tabular-nums`; keine animierten Zahlenrollen                             |
| Hierarchie                  | Seitentitel 34 px, mobil 30 px; Command-Einstieg 42/36 px; Fließtext und Datentext nach Dichte  |
| Fokus                       | 2 px Cyan, 3 px Offset und transparenter Ring                                                   |
| Bewegung                    | 120 ms für einfache Zustandswechsel; `prefers-reduced-motion` schaltet Übergänge/Animationen ab |
| Schatten                    | Sparsam; Panels ohne dekorativen Glow, mobile Dialoge mit abgegrenztem Hintergrund              |

Historische Komponentenregeln bleiben erhalten, soweit sie nicht vom Elite-System ersetzt werden. Der Code enthält daher noch einzelne ältere fest gesetzte Werte; die Tokenisierung ist kein Beleg einer vollständig automatisierten Designbibliothek.

## Layout und Interaktion

Desktop besitzt eine feste 200-px-Navigation, Status-/Suchleiste und ein Hauptfenster mit optionalem Analysepanel. Unter 1.240 px wechselt der Scanner auf eine Hauptspalte. Bis 800 px gibt es eine feste Bottom-Navigation für Command, Radar, Analyse, Watchlists und Status. Die Kompakteinstellung reduziert Tabellenzeilen auf56 px; mobile Touch-Karten behalten ihre128 px Höhe. Bis 600 px verwendet der Scanner 128-px-Karten mit Token, Quelle/Frische, Preis und Liquidität. Die virtuelle Zeilengruppe übernimmt dabei keine Desktop-Mindestbreite.

Die Scannerseite lädt standardmäßig 100 Einträge. Spaltenwahl, Sortierung, Filter, Presets und Suche bleiben serverseitig. „Updates pausieren“ hält automatische Tabellenänderungen an; Filter und Systemstatus bleiben bedienbar. Fortsetzen lädt den aktuellen Seitenstand. Auf Mobilgeräten öffnet eine Karte eine Schnellanalyse als Bottom Sheet; Escape schließt sie, Tab bleibt im Dialog und der Fokus kehrt zur Zeile zurück. Die vollständige Analyse bleibt ein eigener Bildschirm.

## Komponenten und States

| Komponente         | Verhalten                                                                                                                  |
| ------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| Navigation         | Sichtbare Auswahl, `aria-current`, beschriftete mobile Symbole, Skiplink zum Hauptinhalt                                   |
| Button / Eingabe   | Default, Hover, Fokus, Disabled; mobile Hauptbedienung mindestens 44 px, überprüfte AA-Mindestziele 24 px                  |
| Scanner            | Skeleton beim Laden, erste Inbetriebnahme bei leerem Bestand, Zero Results mit Filteraktion, Fehlerbanner mit Wiederholung |
| Datenwert          | Herkunft und Abruf-/Messzeit im Tooltip, Freshness und Missing-State; Null bleibt „Unbekannt“, echte Null bleibt 0         |
| Quelle / Transport | Teilabdeckung, Stale, HTTP-Fallback, Offline und Wiederverbindung mit Text; keine bloße Farbcodierung                      |
| Risiko             | Getrennte Signale, Modellversion, aufklappbare Evidenz; fehlende Pflichtprüfung erzeugt keinen Gesamtscore                 |
| Quality            | Feldabdeckung, unbekannte Zeitstände, Providerfehler, Budgets; unbekannte Kosten bleiben unbekannt                         |
| Diagramm           | Preis Cyan, Liquidität Amber; Achsen, Zeitzone und Herkunft; fehlende Intervalle werden nicht erfunden                     |
| Lange Metadaten    | Begrenzte Zeile mit vollständigem Text im Titel, Adressen kopierbar; Token-Metadaten sind untrusted Text                   |

Farben für Marktveränderungen beschreiben gemeldete Vergangenheit. Sie sind keine Kauf-/Verkaufsempfehlung. Positive Farbe ersetzt niemals eine unbekannte Sicherheitsprüfung.

## Belege

Drei funktionale Varianten und die Auswahlrubrik: [DESIGN_AUDIT.md](DESIGN_AUDIT.md). Gebaute Hauptansichten: [Screenshot-Manifest](reports/elite-screens/manifest.json). Browser-/Axe-/Tastaturprüfungen und verbleibende Grenzen: [QA_REPORT.md](QA_REPORT.md).

## Final Precision – operative Ergänzungen

Der Command-Bereich verwendet eine verkleinerte Introfläche und einen Research-Blotter vor den sekundären Quellenkarten. Desktopzeilen kombinieren Token/Pool, Fundalter mit exaktem UTC-Tooltip, Preis, Liquidität, Risiko und Frische; mobil eigenständige Karten. Die Scanner-Dichteprofile und gespeicherten Spalten/Filter bleiben erhalten. Zahlenformatierer werden pro Format wiederverwendet.

Zeitreihen sortieren/deduplizieren Zeitstempel; fehlende Werte und Beobachtungslücken trennen Segmente. Kein Nullwert wird in einen Kurs umgedeutet. Chart ist per Tab und Pfeiltasten/Home/End erreichbar; Quelle und Zeit stehen im Readout. Visuelle Regression prüft die erste vollständige Blotter-Zeile/Karte in fünf Browser-/Geräteprojekten. Variable Zeit/Risiko-Bereiche sind maskiert; deren Semantik wird separat getestet. Neue Baselines sind initiale, lokal geprüfte Referenzen, keine unabhängige Designzertifizierung.
