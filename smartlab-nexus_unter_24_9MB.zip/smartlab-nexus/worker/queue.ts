interface Task {
  key: string;
  priority: number;
  createdAt: number;
  run: () => Promise<unknown>;
}
export class PriorityQueue {
  private tasks: Task[] = [];
  private keys = new Set<string>();
  rejected = 0;
  constructor(private capacity = 256) {}
  get size() {
    return this.tasks.length;
  }
  get lagMs() {
    return this.tasks.length
      ? Date.now() - Math.min(...this.tasks.map((x) => x.createdAt))
      : 0;
  }
  add(key: string, priority: number, run: () => Promise<unknown>) {
    if (this.keys.has(key)) return false;
    if (this.keys.size >= this.capacity) {
      this.rejected++;
      return false;
    }
    this.keys.add(key);
    this.tasks.push({ key, priority, run, createdAt: Date.now() });
    return true;
  }
  async drain(concurrency = 2) {
    const results: { key: string; ok: boolean; error?: unknown }[] = [];
    const consume = async () => {
      while (this.tasks.length) {
        this.tasks.sort(
          (a, b) => a.priority - b.priority || a.createdAt - b.createdAt,
        );
        const t = this.tasks.shift()!;
        try {
          await t.run();
          results.push({ key: t.key, ok: true });
        } catch (error) {
          results.push({ key: t.key, ok: false, error });
        } finally {
          this.keys.delete(t.key);
        }
      }
    };
    await Promise.all(
      Array.from({ length: Math.max(1, Math.min(4, concurrency)) }, consume),
    );
    return results;
  }
}
