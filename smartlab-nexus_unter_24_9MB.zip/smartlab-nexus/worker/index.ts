import type { PoolClient } from "pg";
import { runRiskEnrichment } from "./risk-enrichment";
import { db, migrate, claimBudget, auditRequest } from "../lib/db";
import {
  ingest,
  saveEvidence,
  processPendingAlerts,
  rescorePools,
} from "../lib/ingestion";
import { HttpClient, ProviderError } from "../lib/providers/http";
import { DexProvider } from "../lib/providers/dex";
import { GeckoProvider } from "../lib/providers/gecko";
import { SolanaProvider } from "../lib/providers/solana";
import { SourceScheduler } from "./scheduler";
import { recordDiscoveries } from "../lib/discovery";
import { ProgramFeed } from "./chain-feed";
import { freshnessBudgets } from "../lib/freshness-config";
import { rotatingBatch } from "./refresh";
const http = new HttpClient(undefined, {
  claim: claimBudget,
  audit: auditRequest,
});
const dex = new DexProvider(http),
  gecko = new GeckoProvider(http),
  solana = new SolanaProvider(http);
const interval = Math.max(60000, Number(process.env.POLL_INTERVAL_MS) || 60000); // Cached pool discovery retains its documented one-minute floor. Other jobs are independent.
const once = process.argv.includes("--once");
let stop = false,
  cycle = 0,
  rotation = 0,
  lockLost = false,
  lock: PoolClient | null = null;
let state: Record<string, unknown> = {
  status: "starting",
  queueDepth: 0,
  queueLagMs: 0,
  lastCycle: null,
  pollIntervalMs: interval,
};
let scheduler: SourceScheduler | null = null;
let chainFeed: ProgramFeed | null = null;
function log(event: string, data: Record<string, unknown> = {}) {
  console.log(JSON.stringify({ at: new Date().toISOString(), event, ...data }));
}
async function heartbeat() {
  if (!lock || lockLost) return;
  await db.query(
    "INSERT INTO worker_state(id,data) VALUES(1,$1) ON CONFLICT(id) DO UPDATE SET heartbeat=clock_timestamp(),data=$1",
    [
      {
        ...state,
        chainFeed: chainFeed?.snapshot() ??
          state.chainFeed ?? { status: "disabled" },
        status:
          state.status === "stopped"
            ? "stopped"
            : scheduler?.snapshot().some((j) => j.failures > 0)
              ? "degraded"
              : state.status,
        jobs: scheduler?.snapshot() ?? [],
        queueDepth:
          scheduler
            ?.snapshot()
            .filter((j) => !j.running && j.nextAt <= Date.now()).length ?? 0,
        queueLagMs: Math.max(
          0,
          ...(scheduler?.snapshot().map((j) => j.lagMs) ?? []),
        ),
      },
    ],
  );
}
async function wait(ms: number) {
  const until = Date.now() + ms;
  while (!stop && !lockLost && Date.now() < until)
    await new Promise((r) =>
      setTimeout(r, Math.min(1000, Math.max(1, until - Date.now()))),
    );
}
process.on("SIGTERM", () => {
  stop = true;
});
process.on("SIGINT", () => {
  stop = true;
});
async function acquire() {
  if (lock && !lockLost) return true;
  if (lock) {
    lock.release(true);
    lock = null;
  }
  lockLost = false;
  await migrate();
  const candidate = await db.connect();
  if (
    !(await candidate.query("SELECT pg_try_advisory_lock(7864321) as acquired"))
      .rows[0].acquired
  ) {
    candidate.release();
    log("worker_lock_busy");
    return false;
  }
  lock = candidate;
  candidate.on("error", () => {
    lockLost = true;
    state = { ...state, status: "error" };
    log("worker_lock_connection_lost");
  });
  return true;
}
async function releaseLock(unlock = false) {
  const current = lock;
  lock = null;
  if (current) {
    if (unlock)
      await current.query("SELECT pg_advisory_unlock(7864321)").catch(() => {});
    current.release(true);
  }
}
function createScheduler() {
  const jobs = new SourceScheduler(4);
  if (process.env.SOLANA_WS_DISCOVERY !== "false") {
    chainFeed = new ProgramFeed(solana, () => {
      jobs.wake("pool-init-decoder");
    });
    void chainFeed.start().catch(() => log("chain_feed_unavailable"));
  }
  const add = (
    key: string,
    intervalMs: number,
    priority: number,
    run: () => Promise<unknown>,
  ) =>
    jobs.add({
      key,
      intervalMs,
      priority,
      run: async () => {
        const start = performance.now();
        try {
          const result = await run();
          state = {
            ...state,
            status: "waiting",
            lastCycle: new Date().toISOString(),
            cycle: ++cycle,
          };
          log("job_complete", {
            key,
            durationMs: Math.round(performance.now() - start),
          });
          return result;
        } catch (error) {
          log("task_failed", {
            task: key,
            status: error instanceof ProviderError ? error.status : "internal",
            retryAfterMs:
              error instanceof ProviderError ? error.retryAfterMs : null,
          });
          throw error;
        }
      },
    });
  add("new-pools", interval, 0, async () => {
    const rows = await gecko.discover();
    if (rows.length)
      await recordDiscoveries(
        rows.map((r) => ({ mint: r.mint, eventAt: r.createdAt })),
        rows[0].provenance,
      );
    await ingest(rows);
  });
  add("profiles", 30000, 0, async () => {
    const feed = await dex.profileFeed();
    await recordDiscoveries(
      feed.mints.map((mint) => ({ mint })),
      feed.provenance,
    );
  });
  add("hydration", 2000, 1, async () => {
    const mints = (
      await db.query(
        "SELECT mint,min(first_seen_at) as first FROM discoveries WHERE hydrated_at IS NULL AND next_attempt_at<=clock_timestamp() GROUP BY mint ORDER BY first LIMIT 30",
      )
    ).rows.map((r) => r.mint as string);
    if (!mints.length) return;
    await db.query(
      "UPDATE discoveries SET attempted_at=clock_timestamp(),next_attempt_at=clock_timestamp()+interval '60 seconds' WHERE mint=ANY($1::text[])",
      [mints],
    );
    try {
      await ingest(await dex.tokens(mints));
    } catch (error) {
      await db.query(
        "UPDATE discoveries SET error='Marktdaten nicht verfügbar; budgetierter Wiederholungsversuch folgt' WHERE mint=ANY($1::text[]) AND hydrated_at IS NULL",
        [mints],
      );
      throw error;
    }
  });
  add("watchlist", 15000, 1, async () => {
    const mints = (
      await db.query(
        "SELECT DISTINCT mint FROM watchlist_items ORDER BY mint LIMIT 30",
      )
    ).rows.map((r) => r.mint as string);
    if (mints.length) await ingest(await dex.tokens(mints));
  });
  add("regular-market", 15000, 3, async () => {
    const known = (
      await db.query(
        "SELECT mint FROM tokens ORDER BY first_seen_at DESC LIMIT 10000",
      )
    ).rows.map((r) => r.mint as string);
    const batch = rotatingBatch(known, rotation, 30);
    rotation = batch.next;
    if (batch.items.length) await ingest(await dex.tokens(batch.items));
  });
  add("pool-refresh", 20000, 3, async () => {
    const batch = (
      await db.query(
        "SELECT pool_id FROM pools ORDER BY last_refresh_attempt_at ASC NULLS FIRST,updated_at ASC LIMIT 20",
      )
    ).rows.map((r) => r.pool_id as string);
    if (!batch.length) return;
    await db.query(
      "UPDATE pools SET last_refresh_attempt_at=clock_timestamp() WHERE pool_id=ANY($1::text[])",
      [batch],
    );
    await ingest(await gecko.pools(batch));
  });
  add("trending-pools", 300000, 3, async () => {
    await ingest(await gecko.discover("trending_pools"));
  });
  add("risk-enrichment", 10000, 4, async () => {
    const mint = (
      await db.query(
        "SELECT t.mint FROM tokens t LEFT JOIN chain_evidence c ON c.mint=t.mint WHERE c.checked_at IS NULL OR c.checked_at<now()-($1*interval '1 second') ORDER BY EXISTS(SELECT 1 FROM watchlist_items w WHERE w.mint=t.mint) DESC,t.first_seen_at DESC LIMIT 1",
        [freshnessBudgets().onchain],
      )
    ).rows[0]?.mint;
    if (mint) await runRiskEnrichment(mint, solana, saveEvidence);
  });
  add("rpc-health", 60000, 4, () => solana.health());
  add("pool-init-decoder", 5000, 0, async () => {
    await chainFeed?.processCandidate();
  });
  add("alerts", 2000, 2, () => processPendingAlerts());
  let maintenance = 0;
  add("maintenance", 60000, 5, async () => {
    await rescorePools();
    if (maintenance++ % 60 === 0) {
      const days = Math.max(
        1,
        Math.min(365, Number(process.env.RETENTION_DAYS) || 30),
      );
      for (const [table, column] of [
        ["samples", "source_at"],
        ["source_audits", "at"],
        ["risk_audits", "at"],
        ["events", "at"],
        ["metrics", "at"],
        ["chain_candidate_attempts", "started_at"],
        ["chain_ui_receipts", "received_at"],
      ])
        await db.query(
          `DELETE FROM ${table} WHERE ${column}<now()-($1*interval '1 day')`,
          [days],
        );
      await db.query(
        "DELETE FROM discoveries WHERE first_seen_at<now()-($1*interval '1 day')",
        [days],
      );
      await db.query(
        "DELETE FROM chain_candidates WHERE processed_at<now()-($1*interval '1 day')",
        [days],
      );
      await db.query(
        "DELETE FROM source_cache WHERE updated_at<now()-interval '1 day'",
      );
    }
  });
  return jobs;
}
const pulse = setInterval(() => {
  heartbeat().catch(() => log("heartbeat_database_unavailable"));
}, 15000);
async function stopChainFeed() {
  const current = chainFeed;
  chainFeed = null;
  await current?.stop();
  if (current) state = { ...state, chainFeed: current.snapshot() };
}
try {
  do {
    try {
      if (!(await acquire())) {
        if (once) {
          process.exitCode = 1;
          break;
        }
        await wait(5000);
        continue;
      }
      if (!scheduler) scheduler = createScheduler();
      scheduler.tick();
      if (once) {
        while (scheduler.snapshot().some((j) => j.running || j.nextAt === 0)) {
          await wait(100);
          scheduler.tick();
        }
        await scheduler.stop();
        break;
      }
      await wait(250);
      if (lockLost) {
        await scheduler.stop();
        scheduler = null;
        await stopChainFeed();
      }
    } catch {
      state = { ...state, status: "error" };
      log("worker_cycle_failed");
      await heartbeat().catch(() => {});
      if (once) {
        process.exitCode = 1;
        break;
      }
      if (scheduler) {
        await scheduler.stop();
        scheduler = null;
      }
      await stopChainFeed();
      lockLost = false;
      await releaseLock();
      await wait(5000 + Math.random() * 3000);
    }
  } while (!stop);
} finally {
  clearInterval(pulse);
  await scheduler?.stop();
  await stopChainFeed();
  state = { ...state, status: "stopped" };
  await heartbeat().catch(() => {});
  await releaseLock(true);
  await db.end();
}
