export class TokenBucket {
  private tokens: number;
  private at: number;
  constructor(
    readonly capacity: number,
    readonly perMinute: number,
    private clock = Date.now,
  ) {
    if (!(capacity > 0 && perMinute > 0)) throw new Error("Ungültiges Budget");
    this.tokens = capacity;
    this.at = clock();
  }
  private refill() {
    const now = this.clock();
    this.tokens = Math.min(
      this.capacity,
      this.tokens + (Math.max(0, now - this.at) * this.perMinute) / 60000,
    );
    this.at = now;
  }
  take(cost = 1) {
    if (!(cost > 0 && cost <= this.capacity))
      throw new Error("Ungültige Kosten");
    this.refill();
    if (this.tokens < cost) return false;
    this.tokens -= cost;
    return true;
  }
  retryAfterMs(cost = 1) {
    this.refill();
    return Math.max(
      0,
      Math.ceil(((cost - this.tokens) * 60000) / this.perMinute),
    );
  }
}
interface Job {
  key: string;
  intervalMs: number;
  priority: number;
  run: () => Promise<unknown>;
}
interface State extends Job {
  wakeRequested?: boolean;
  nextAt: number;
  running: boolean;
  failures: number;
  lastSuccess: string | null;
  lastError: string | null;
  circuit: "closed" | "open" | "half-open";
  durationMs: number | null;
}
export class SourceScheduler {
  private jobs: State[] = [];
  private running = new Set<Promise<void>>();
  private stopped = false;
  constructor(
    private concurrency = 4,
    private clock = Date.now,
    private random = Math.random,
  ) {}
  add(job: Job) {
    if (
      this.jobs.length >= 64 ||
      this.jobs.some((x) => x.key === job.key) ||
      job.intervalMs < 250
    )
      return false;
    this.jobs.push({
      ...job,
      nextAt: 0,
      running: false,
      failures: 0,
      lastSuccess: null,
      lastError: null,
      circuit: "closed",
      durationMs: null,
    });
    return true;
  }
  /** Wake successful work on durable input; never bypass a failure circuit or Retry-After. */
  wake(key: string) {
    const job = this.jobs.find((j) => j.key === key);
    if (!job || job.failures || job.circuit !== "closed" || this.stopped)
      return false;
    if (job.running) job.wakeRequested = true;
    else job.nextAt = this.clock();
    return true;
  }
  tick() {
    if (this.stopped) return;
    for (const job of [...this.jobs].sort(
      (a, b) => a.priority - b.priority || a.nextAt - b.nextAt,
    )) {
      if (this.running.size >= this.concurrency) break;
      if (job.running || job.nextAt > this.clock()) continue;
      job.running = true;
      if (job.circuit === "open") job.circuit = "half-open";
      const start = this.clock();
      const promise = Promise.resolve()
        .then(job.run)
        .then(
          () => {
            job.failures = 0;
            job.lastError = null;
            job.lastSuccess = new Date(this.clock()).toISOString();
            job.circuit = "closed";
            job.nextAt =
              this.clock() +
              (job.wakeRequested
                ? 0
                : job.intervalMs +
                  this.random() * Math.min(3000, job.intervalMs * 0.05));
            job.wakeRequested = false;
          },
          (error: unknown) => {
            job.wakeRequested = false;
            job.failures++;
            job.lastError = "Quelle/Aufgabe eingeschränkt";
            const retry =
              Number((error as { retryAfterMs?: number })?.retryAfterMs) || 0;
            const backoff = Math.min(
              120000,
              job.intervalMs * 2 ** Math.min(job.failures, 6),
            );
            if (job.failures >= 3) job.circuit = "open";
            job.nextAt =
              this.clock() +
              Math.max(retry, backoff, job.circuit === "open" ? 30000 : 0);
          },
        )
        .finally(() => {
          job.running = false;
          job.durationMs = this.clock() - start;
          this.running.delete(promise);
        });
      this.running.add(promise);
    }
  }
  snapshot() {
    return this.jobs.map(({ run, ...job }) => ({
      ...job,
      lagMs: job.running ? 0 : Math.max(0, this.clock() - job.nextAt),
    }));
  }
  async stop() {
    this.stopped = true;
    await Promise.allSettled([...this.running]);
  }
}
