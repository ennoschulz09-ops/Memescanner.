import { WebSocket, EnvHttpProxyAgent } from "undici";
import { z } from "zod";
import bs58 from "bs58";
import { db, metric } from "../lib/db";
import {
  SolanaProvider,
  MAX_SUPPORTED_TRANSACTION_VERSION,
} from "../lib/providers/solana";
import {
  claimChainCandidate,
  failChainCandidate,
  observeChainLog,
  recordChainGap,
} from "../lib/chain-queue";
import {
  CPMM_PROGRAM,
  CPMM_DECODER_VERSION,
  isOwnInitializeLog,
  decodePoolInitializations,
} from "../lib/providers/pool-init";
import { recordDiscoveries } from "../lib/discovery";
const signature = z.string().refine((v) => {
  try {
    return bs58.decode(v).length === 64;
  } catch {
    return false;
  }
});
const notification = z.object({
  method: z.literal("logsNotification"),
  params: z.object({
    result: z.object({
      context: z.object({ slot: z.number().int().nonnegative() }),
      value: z.object({
        signature,
        err: z.unknown().nullable(),
        logs: z.array(z.string()).max(2000),
      }),
    }),
  }),
});
export class ProgramFeed {
  private socket: WebSocket | null = null;
  private dispatcher = new EnvHttpProxyAgent();
  private timer: ReturnType<typeof setTimeout> | undefined;
  private stopped = false;
  private admissionTail: Promise<unknown> = Promise.resolve();
  private pending = new Set<Promise<unknown>>();
  private cursorTask: Promise<void> | null = null;
  private latestCursor: { signature: string; slot: number; at: string } | null =
    null;
  private dropTask: Promise<void> | null = null;
  private unpersistedDrops = 0;
  private cursorBlocked = false;
  private data = {
    status: "starting",
    scope: "Raydium CPMM initialize only",
    lastSignature: null as string | null,
    lastSlot: null as number | null,
    lastLogAt: null as string | null,
    disconnects: 0,
    coverageGaps: 0,
    backpressure: 0,
    replay: "not-needed",
    decoded: 0,
  };
  constructor(
    private solana: SolanaProvider,
    private onCandidate: () => void = () => {},
  ) {}
  snapshot() {
    return {
      ...this.data,
      status: this.cursorBlocked ? "degraded" : this.data.status,
      cursorBlocked: this.cursorBlocked,
      admissionsInFlight: this.pending.size,
      unpersistedDrops: this.unpersistedDrops,
    };
  }
  async start() {
    const old = (
      await db.query(
        "SELECT data->'chainFeed' as feed FROM worker_state WHERE id=1",
      )
    ).rows[0]?.feed;
    if (old?.lastSignature) {
      this.data.lastSignature = old.lastSignature;
      this.data.lastSlot = old.lastSlot;
      this.data.disconnects = Number(old.disconnects) || 0;
      this.data.coverageGaps = Number(old.coverageGaps) || 0;
      this.data.backpressure = Number(old.backpressure) || 0;
      this.data.decoded = Number(old.decoded) || 0;
    }
    const persisted = (
      await db.query("SELECT * FROM chain_feed_cursors WHERE program_id=$1", [
        CPMM_PROGRAM,
      ])
    ).rows[0];
    if (persisted?.signature) {
      this.data.lastSignature = persisted.signature;
      this.data.lastSlot = Number(persisted.slot);
    } else if (this.data.lastSignature && this.data.lastSlot != null) {
      await observeChainLog(
        this.data.lastSignature,
        this.data.lastSlot,
        old?.lastLogAt ?? new Date().toISOString(),
        false,
      );
    }
    this.connect();
  }
  private connect() {
    if (this.stopped) return;
    const url = process.env.SOLANA_WS_URL || "wss://api.mainnet.solana.com";
    if (new URL(url).protocol !== "wss:") {
      this.data.status = "unavailable";
      return;
    }
    const socket = new WebSocket(url, { dispatcher: this.dispatcher });
    this.socket = socket;
    socket.addEventListener("open", () => {
      if (this.stopped) return;
      socket.send(
        JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "logsSubscribe",
          params: [{ mentions: [CPMM_PROGRAM] }, { commitment: "confirmed" }],
        }),
      );
    });
    socket.addEventListener("message", (event) => {
      let input: unknown;
      try {
        input = JSON.parse(String(event.data));
      } catch {
        return;
      }
      const ack = z
        .object({ id: z.literal(1), result: z.number() })
        .safeParse(input);
      if (ack.success) {
        this.data.status = "connected";
        void db
          .query(
            "INSERT INTO provider_states(provider,status,last_success) VALUES('solana-ws','ok',clock_timestamp()) ON CONFLICT(provider) DO UPDATE SET status='ok',last_success=clock_timestamp(),error=NULL",
          )
          .catch(() => {});
        if (this.data.lastSignature)
          void this.replay().catch(() => {
            this.data.replay = "unavailable";
            this.data.coverageGaps++;
            void recordChainGap("replay_unavailable").catch(() => {});
          });
        return;
      }
      this.observe(input);
    });
    const reconnect = () => {
      if (this.socket !== socket || this.stopped) return;
      this.socket = null;
      this.data.status = "disconnected";
      this.data.disconnects++;
      this.data.coverageGaps++;
      void recordChainGap("websocket_disconnected").catch(() => {});
      void db
        .query(
          "INSERT INTO provider_states(provider,status,last_error,error) VALUES('solana-ws','error',clock_timestamp(),'Programmlog-Verbindung unterbrochen') ON CONFLICT(provider) DO UPDATE SET status='error',last_error=clock_timestamp(),error='Programmlog-Verbindung unterbrochen'",
        )
        .catch(() => {});
      try {
        socket.close();
      } catch {}
      this.timer = setTimeout(
        () => this.connect(),
        Math.min(60000, 5000 * 2 ** Math.min(4, this.data.disconnects)) +
          Math.random() * 2000,
      );
    };
    socket.addEventListener("error", reconnect);
    socket.addEventListener("close", reconnect);
  }
  observe(input: unknown) {
    if (this.stopped) return;
    const parsed = notification.safeParse(input);
    if (!parsed.success) return;
    const value = parsed.data.params.result;
    this.data.lastLogAt = new Date().toISOString();
    if (value.value.err === null && isOwnInitializeLog(value.value.logs))
      this.admit(
        value.value.signature,
        value.context.slot,
        false,
        true,
        this.data.lastLogAt,
      );
    this.checkpoint(
      value.value.signature,
      value.context.slot,
      this.data.lastLogAt,
    );
  }
  private checkpoint(signature: string, slot: number, at: string) {
    this.latestCursor = { signature, slot, at };
    if (this.cursorTask) return;
    this.cursorTask = (async () => {
      while (this.latestCursor) {
        const cursor = this.latestCursor;
        this.latestCursor = null;
        // A later ordinary log must not put an uncommitted initialize behind
        // the replay cursor. Admission rollback freezes this cursor until restart.
        await Promise.all([...this.pending]);
        if (this.dropTask) await this.dropTask;
        if (this.cursorBlocked) return;
        await observeChainLog(cursor.signature, cursor.slot, cursor.at, false);
        // Heartbeat/reconnect may only reuse a durably secured checkpoint.
        this.data.lastSignature = cursor.signature;
        this.data.lastSlot = cursor.slot;
      }
    })();
    void this.cursorTask
      .catch(() => {
        this.data.coverageGaps++;
      })
      .finally(() => {
        this.cursorTask = null;
      });
  }
  private recordDroppedAdmission() {
    this.unpersistedDrops++;
    if (this.dropTask) return;
    this.dropTask = (async () => {
      while (this.unpersistedDrops) {
        const count = this.unpersistedDrops;
        this.unpersistedDrops = 0;
        try {
          await recordChainGap("admission_concurrency_limit", count);
        } catch (error) {
          this.unpersistedDrops += count;
          throw error;
        }
      }
    })();
    void this.dropTask
      .catch(() => {
        this.cursorBlocked = true;
      })
      .finally(() => {
        this.dropTask = null;
      });
  }
  private admit(
    sig: string,
    slot: number,
    replay: boolean,
    candidate = true,
    observedAt = new Date().toISOString(),
  ) {
    if (this.pending.size >= 256) {
      this.data.backpressure++;
      this.data.coverageGaps++;
      this.recordDroppedAdmission();
      return;
    }
    const task = this.admissionTail
      .catch(() => {})
      .then(() =>
        observeChainLog(sig, slot, observedAt, candidate, replay, false),
      )
      .then((admitted) => {
        if (admitted) this.onCandidate();
        if (!admitted) {
          this.data.backpressure++;
          this.data.coverageGaps++;
        }
      })
      .catch(async (error) => {
        this.cursorBlocked = true;
        this.data.coverageGaps++;
        await recordChainGap("candidate_admission_database_error").catch(
          () => {},
        );
        throw error;
      });
    this.admissionTail = task;
    this.pending.add(task);
    void task.catch(() => {}).finally(() => this.pending.delete(task));
  }
  private async replay() {
    this.data.replay = "bounded-20-signatures; gaps may remain";
    const rows = z
      .array(
        z.object({
          signature,
          slot: z.number().int().nonnegative(),
          err: z.unknown().nullable(),
        }),
      )
      .parse(
        await this.solana.rpc("getSignaturesForAddress", [
          CPMM_PROGRAM,
          {
            commitment: "confirmed",
            limit: 20,
            until: this.data.lastSignature,
          },
        ]),
      );
    if (rows.length === 20) {
      this.data.coverageGaps++;
      await recordChainGap("bounded_replay_limit_20");
    } else
      await db.query(
        "UPDATE chain_feed_cursors SET replay_status='bounded_replay_complete',updated_at=clock_timestamp() WHERE program_id=$1",
        [CPMM_PROGRAM],
      );
    for (const row of rows.filter((r) => r.err === null)) {
      while (this.pending.size >= 256)
        await Promise.race([...this.pending]).catch(() => {});
      if (this.stopped) break;
      this.admit(row.signature, row.slot, true);
      await Promise.resolve();
    }
  }
  async processCandidate() {
    const row = await claimChainCandidate();
    if (!row) return;
    try {
      const rpcStarted = performance.now();
      const tx = await this.solana.rpc("getTransaction", [
        row.signature,
        {
          encoding: "jsonParsed",
          commitment: "confirmed",
          maxSupportedTransactionVersion: MAX_SUPPORTED_TRANSACTION_VERSION,
        },
      ]);
      if (!tx) {
        // A null confirmed transaction is retryable but bounded across restarts.
        await failChainCandidate(row, {
          chainReason: "transaction_not_available",
        });
        return;
      }
      const fetchedAt = new Date().toISOString();
      const rpcLatency = performance.now() - rpcStarted;
      await db.query(
        "UPDATE chain_candidates SET fetched_at=$3 WHERE signature=$1 AND lease_token=$2",
        [row.signature, row.lease_token, fetchedAt],
      );
      const pools = decodePoolInitializations(tx);
      const decodedAt = new Date().toISOString();
      const c = await db.connect();
      let added = 0;
      try {
        await c.query("BEGIN");
        // Lock and fence inside the SAME transaction as discovery publication.
        const owner = await c.query(
          "SELECT 1 FROM chain_candidates WHERE signature=$1 AND lease_token=$2 AND lease_until>clock_timestamp() FOR UPDATE",
          [row.signature, row.lease_token],
        );
        if (!owner.rowCount) {
          await c.query("ROLLBACK");
          return;
        }
        for (const pool of pools) {
          added += await recordDiscoveries(
            pool.mints.map((mint) => ({ mint, eventAt: pool.eventAt })),
            {
              provider: "solana",
              endpoint: "raydium-cpmm-initialize",
              fetchedAt,
              sourceAt: pool.eventAt ?? fetchedAt,
              measuredAt: pool.eventAt,
              timestampKind: "rpc-slot",
              cacheAgeSeconds: 0,
              latencyMs: rpcLatency,
            },
            new Date(row.observed_at).toISOString(),
            c,
          );
        }
        const updated = await c.query(
          "UPDATE chain_candidates SET processed_at=clock_timestamp(),status=$3,decoded=$4,decoder_version=$5,event_at=$6,decoded_at=$7,discovered_at=CASE WHEN $8 THEN clock_timestamp() ELSE NULL END,terminal_reason=$9,lease_until=NULL,lease_token=NULL WHERE signature=$1 AND lease_token=$2",
          [
            row.signature,
            row.lease_token,
            pools.length ? "decoded" : "rejected",
            JSON.stringify(pools),
            CPMM_DECODER_VERSION,
            pools[0]?.eventAt ?? null,
            decodedAt,
            pools.length > 0,
            pools.length
              ? null
              : tx.meta.err !== null
                ? "transaction_failed"
                : "no_supported_initialization",
          ],
        );
        if (updated.rowCount)
          await c.query(
            "UPDATE chain_candidate_attempts SET completed_at=clock_timestamp(),outcome=$2,reason=$3 WHERE token=$1",
            [
              row.lease_token,
              pools.length ? "decoded" : "rejected",
              pools.length ? null : "no_supported_initialization",
            ],
          );
        await c.query("COMMIT");
      } catch (error) {
        await c.query("ROLLBACK");
        throw error;
      } finally {
        c.release();
      }
      if (added) {
        await metric(
          "discovery_persist",
          performance.now() - rpcStarted - rpcLatency,
        ).catch(() => {});
        if (pools[0]?.eventAt)
          await metric(
            "chain_event_to_first_seen",
            Math.max(0, Date.now() - Date.parse(pools[0].eventAt)),
          ).catch(() => {});
      }
      this.data.decoded += pools.length;
    } catch (error) {
      // Candidate faults must not open the scheduler circuit for every other signature.
      // Provider-wide Retry-After remains enforced by the shared RPC budget.
      await failChainCandidate(row, error);
    } finally {
      this.onCandidate();
    }
  }
  async stop() {
    this.stopped = true;
    clearTimeout(this.timer);
    try {
      this.socket?.close();
    } catch {}
    await this.dispatcher.destroy();
    await Promise.allSettled([...this.pending]);
    await Promise.allSettled(
      [this.cursorTask, this.dropTask].filter(
        (p): p is Promise<void> => p !== null,
      ),
    );
    this.data.status = "stopped";
  }
}
