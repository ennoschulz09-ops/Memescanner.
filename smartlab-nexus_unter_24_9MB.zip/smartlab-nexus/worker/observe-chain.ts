/** Read-only, no RPC requests: observe the existing main worker and persist honest samples. */
import { writeFile } from "node:fs/promises";
import { db } from "../lib/db";
import { getChainQueueHealth } from "../lib/chain-queue";
const durationSeconds = Math.max(
  600,
  Number(process.env.CHAIN_OBSERVE_SECONDS) || 660,
);
const startedAt = new Date().toISOString();
const reportPath =
  process.env.CHAIN_OBSERVATION_REPORT ||
  "reports/elite-chain-observation.json";
const samples: unknown[] = [];
const until = Date.now() + durationSeconds * 1000;
try {
  do {
    const at = new Date().toISOString();
    let queue: unknown;
    try {
      queue = await getChainQueueHealth();
    } catch {
      queue = { status: "migration_not_available" };
    }
    const worker = (
      await db.query(
        "SELECT heartbeat,data->>'status' AS status,data->'chainFeed' AS feed,data->'jobs' AS jobs FROM worker_state WHERE id=1",
      )
    ).rows[0];
    const rpc = (
      await db.query(
        "SELECT endpoint,ok,status,error,count(*)::int AS n,max(at) AS last_at FROM source_audits WHERE provider='solana' AND at>=$1 GROUP BY endpoint,ok,status,error ORDER BY endpoint,ok",
        [startedAt],
      )
    ).rows;
    const decoded = (
      await db.query(
        "SELECT signature,slot,from_replay,observed_at,processed_at,event_at,fetched_at,decoded_at,discovered_at,decoder_version,decoded FROM chain_candidates WHERE processed_at>=$1 AND decoder_version IS NOT NULL AND jsonb_typeof(decoded)='array' AND jsonb_array_length(decoded)>0 ORDER BY processed_at DESC LIMIT 30",
        [startedAt],
      )
    ).rows;
    const liveDiscoveries = (
      await db.query(
        "SELECT mint,first_seen_at,observed_at,event_at FROM discoveries WHERE provider='solana' AND first_seen_at>=$1 ORDER BY first_seen_at DESC LIMIT 100",
        [startedAt],
      )
    ).rows;
    samples.push({ at, queue, worker, rpc, decoded, liveDiscoveries });
    await writeFile(
      reportPath,
      JSON.stringify(
        {
          startedAt,
          updatedAt: at,
          plannedSeconds: durationSeconds,
          elapsedSeconds: (Date.now() - Date.parse(startedAt)) / 1000,
          status: Date.now() < until ? "RUNNING" : "PARTIAL",
          method:
            "Read-only PostgreSQL samples every30s; no additional RPC; main worker shares existing budgets. Historical backlog and replay are not new live events.",
          clock:
            "Single-host UTC/Date.now; Solana blockTime precision1s; provider clock uncertainty unmeasured.",
          samples,
          limits:
            "Only Raydium CPMM initialize. Sample cannot establish full coverage or SLA; new event-to-UI timing remains NOT VERIFIED without matching browser trace.",
        },
        null,
        2,
      ),
    );
    console.log(
      JSON.stringify({
        at,
        samples: samples.length,
        decoded: decoded.length,
        discoveredAssets: liveDiscoveries.length,
      }),
    );
    if (Date.now() >= until) break;
    await new Promise((resolve) =>
      setTimeout(resolve, Math.min(30000, until - Date.now())),
    );
  } while (true);
} finally {
  await db.end();
}
