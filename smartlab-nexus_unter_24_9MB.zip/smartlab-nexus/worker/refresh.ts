export function rotatingBatch<T>(
  items: T[],
  offset: number,
  capacity: number,
): { items: T[]; next: number } {
  if (!items.length) return { items: [], next: 0 };
  const size = Math.min(items.length, capacity);
  return {
    items: Array.from(
      { length: size },
      (_, i) => items[(offset + i) % items.length],
    ),
    next: (offset + size) % items.length,
  };
}
