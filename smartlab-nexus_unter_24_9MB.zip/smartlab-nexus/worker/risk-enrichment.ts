import type { ChainEvidence } from "../lib/domain";
import { SolanaProvider } from "../lib/providers/solana";
import { ProviderError } from "../lib/providers/http";
export async function runRiskEnrichment(
  mint: string,
  solana: SolanaProvider,
  persist: (mint: string, evidence: ChainEvidence) => Promise<void>,
) {
  const evidence = await solana.inspect(mint);
  await persist(mint, evidence);
  if (evidence.error)
    throw new ProviderError(
      "solana",
      evidence.requestFailure?.status ?? 503,
      evidence.requestFailure?.retryAfterMs ?? 60000,
      "Onchain-Risikoanreicherung unvollständig; Evidenz gespeichert",
    );
}
