import { defineConfig, devices } from "@playwright/test";

const baseURL = process.env.E2E_BASE_URL || "http://localhost:3000";
const managedServer = process.env.PLAYWRIGHT_START_SERVER === "true";
if (managedServer) {
  const url = process.env.CI_TEST_DATABASE_URL;
  if (
    process.env.NEXUS_TEST_MODE !== "true" ||
    !url ||
    !/^[a-zA-Z0-9_]+_test$/.test(new URL(url).pathname.slice(1))
  )
    throw new Error(
      "Managed E2E requires CI_TEST_DATABASE_URL ending in _test and NEXUS_TEST_MODE=true.",
    );
}
const chromiumLaunch = {
  ...(process.env.CHROMIUM_PATH
    ? { executablePath: process.env.CHROMIUM_PATH }
    : {}),
  args: ["--no-sandbox"],
};
export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 30000,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  webServer: managedServer
    ? {
        command: "npm run start -- --port 3000",
        url: `${baseURL}/api/health`,
        reuseExistingServer: false,
        timeout: 60000,
        env: {
          DATABASE_URL: process.env.CI_TEST_DATABASE_URL!,
          NEXUS_TEST_MODE: "true",
          APP_ORIGIN: baseURL,
          SOLANA_WS_DISCOVERY: "false",
          CI_NETWORK_ISOLATION: "true",
        },
      }
    : undefined,
  reporter: [["list"], ["html", { open: "never" }]],
  projects: [
    {
      name: "tablet",
      use: {
        ...devices["Desktop Chrome"],
        launchOptions: chromiumLaunch,
        viewport: { width: 834, height: 1194 },
        hasTouch: true,
      },
    },
    {
      name: "desktop",
      use: {
        ...devices["Desktop Chrome"],
        launchOptions: chromiumLaunch,
        viewport: { width: 1512, height: 982 },
      },
    },
    {
      name: "mobile",
      use: {
        ...devices["iPhone 13"],
        defaultBrowserType: "chromium",
        launchOptions: chromiumLaunch,
      },
    },
    {
      name: "firefox",
      use: {
        ...devices["Desktop Firefox"],
        viewport: { width: 1512, height: 982 },
      },
    },
    {
      name: "webkit",
      use: {
        ...devices["Desktop Safari"],
        viewport: { width: 1512, height: 982 },
        ...(process.env.WEBKIT_PATH
          ? { launchOptions: { executablePath: process.env.WEBKIT_PATH } }
          : {}),
      },
    },
  ],
});
