# SMARTLAB NEXUS – Abnahme vom 23.10.2026

Der Neubau ist lokal unter **http://localhost:3000** gestartet: Next.js im Produktionsmodus, separater Erfassungsworker und PostgreSQL 17. Der persistierte Bestand besteht aus echten öffentlichen Anbieterantworten. Im Live-Messfenster waren 1.357 Pools und 1.227 Mints gespeichert. Es wurden keine Demo-Tokens in die Anwendungsdatenbank geschrieben.

Grundlage ist der vollständige [Masterprompt](../docs/masterprompt.txt). Die erwähnten zwei alten SmartLab-Dateien waren nicht beigefügt. Architektur und Annahmen sind im [Entwurf](../docs/design.md) und in der [Startanleitung](../README.md) dokumentiert. Dieser Bericht belegt die lokale Umsetzung und ihre Grenzen; er ist keine allgemeine Freigabe für Produktionsbetrieb.

## Tatsächlich implementiert

| Bereich | Ergebnis |
|---|---|
| Echte Discovery | GeckoTerminal New/Trending Pools, DexScreener Profile/Suche/Token-Paare; dokumentierte austauschbare Adapter; öffentliche lesende Solana-RPC-Methoden |
| Erfassung | Schema-Prüfung, Mint/Pool-Deduplizierung, getrennte Quellbeobachtungen, atomare Persistenz, Audit, Scoring, Alert-Outbox und SSE-Änderungshinweise |
| Zuverlässigkeit | Gemeinsame rollierende DB-Budgets, Retry-After/Backoff/Jitter, Queue-Parallelität 2, Worker-Sperre, Wiederverbindung nach DB-Verlust, priorisierte und rotierende Aktualisierung |
| Oberfläche | Alle zehn Ansichten; Desktop-Terminal und mobile Navigation; Lade-, Fehler-, Empty-, Offline-, Stale- und Reconnect-Zustände |
| Scanner | Virtualisierung, Spaltenwahl, Sortierung, lokale/Anbietersuche, Schnellfilter, kombinierte Filter, Presets, Watchlist-Stern, letzte betrachtete Tokens, Detail-Sidebar |
| Filter | Poolalter, Liquidität, relative Volumenänderung, Aktivitätsanstieg aus zwei eigenen Samples, Konzentration, Risiko-/Datenstatus, Datenqualität, DEX |
| Token-Analyse | Preis-/Volumen-/Liquiditäts-/Trade-Charts für 1h/24h/7d soweit vorhanden, Poolwahl, Kopieren, Quellenkonflikte, Risiko-/Ereignis-Audit und persönliche Alert-Historie |
| Risk Lab | Getrennte transparente Komponenten für Datenqualität, Liquidität, Tokenkonto-Konzentration, Contract-Kontrollen, aggregierte Aktivität und Momentum; Formeln, Gewichte, Quellen und Nullwertbehandlung |
| Wallet Explorer | Öffentlich lesbarer SOL-Saldo, SPL-/Token-2022-Konten, Signaturen und Aktivitätsverteilung mit Abdeckungsanzeige; keine behauptete Personenzuordnung |
| Watchlists/Alerts | Sitzungsgebundene persistente Listen, Regeln, Deduplizierung, Cooldown, Quota, UTC-Ruhezeiten, Wiederholungen nach DB-Fehlern und getrennte Auslösung/Zustellbestätigung |
| Historie/Analytics | Ereignissuche, UTC/lokale Zeit, CSV/JSON-Export, Quellen- und Score-Audits, aggregierte Bestandsauswertung |
| Betrieb | System Health, Provider-/Queue-/Cache-/SSE-Metriken, p50/p95/p99, Einstellungen, Migration, Compose, Umgebungsbeispiel und Produktionsstart-Anleitung |
| Schutz | Serverkonfiguration, optionale Zugangssperre, HttpOnly-Sitzungen, Origin-/Schema-/Body-/Rate-Prüfungen, feste Providerziele, lesende RPC-Allowlist, sichere Textausgabe und CSV-Formelschutz |

Es gibt keine Handels-, Swap-, Order-, Signatur-, Wallet-Verbindungs- oder Transaktionsausführungsfunktion.

## Ausgeführte Verifikation

Geprüft mit Node.js 24.19.0, PostgreSQL 17 und Chromium 154.0.8037.57 in dieser Linux-Umgebung.

| Prüfung | Tatsächliches Ergebnis |
|---|---|
| `npm test` | **35/35 bestanden**, fünf Dateien, zuletzt 11:30 UTC |
| `npm run test:integration` | **26/26 bestanden**, echte separate PostgreSQL-Testdatenbank, zuletzt 11:30 UTC |
| `npm run test:e2e` | **20/20 bestanden** gegen den Produktionsserver: zehn Desktop-, zehn mobile Prüfungen |
| `npm run typecheck` | Bestanden |
| `npm run build` | Produktionsbuild erfolgreich; anschließend genau diesen Build gestartet |
| `npm run test:security` | 31 Produktdateien geprüft, keine Treffer; lesende RPC-Allowlist vorhanden; [JSON](security.json) |
| `npm audit --omit=dev --json` | Keine gemeldeten Schwachstellen zum Prüfzeitpunkt; [JSON](dependency-audit.json) |
| `npm run test:chaos` | Tatsächlicher Compose-DB-Stopp/-Neustart bestanden; [JSON](chaos-db.json) |
| `npm run bench` | 1.000/10.000 Zeilen im isolierten Produktions-Testbrowser gemessen; [JSON](performance.json) |
| `npm run test:runtime` | Echte Provider/Worker/UI beobachtet, keine Browserfehler; [JSON](runtime-metrics.json) |
| `npm run test:live` | GeckoTerminal und DexScreener erfolgreich; Solana eingeschränkt. Erwarteter Fehlercode wegen `partial`/`blocked`; [Einzelergebnisse](live-check.json) |

Die automatisierten Fälle prüfen Normalisierung, ungültige/fehlende Werte, Scoring, Filter, Alerts, Sessiongrenzen, Origin-/Eingabevalidierung, Export, Cache-Frische, Providerfehler und gemeinsame rollierende Limits. Ausfälle, verspätete Beobachtungen, Dubletten, Transaktionsabbruch, SSE-Abbruch und ein fehlgeschlagener Delta-Abruf sind gezielt abgedeckt. Browserprüfungen umfassen alle Ansichten, echte Pool-Herkunft, Detailöffnung, persistente Watchlist/Presets/Einstellungen, Alert-Regelverwaltung, Fehlerzustände, Mobilansicht und fehlende Hydration-/Laufzeitfehler.

Beim echten DB-Ausfall lieferte die API **HTTP 503 / offline**. Nach dem Start war der Worker nach **3.308 ms** wieder verbunden; alle zuvor gespeicherten **1.263 Pools** waren erhalten. Ein zweiter Worker erhielt keine Erfassungssperre und überschrieb den Zustand des aktiven Workers nicht.

### Unabhängiges Code-Review und Korrekturen

Die abschließende unabhängige Prüfung fand mehrere Nebenläufigkeits- und Zustellungsprobleme. Sie wurden vor der Abnahme behoben und durch Regressionstests abgesichert:

- Zeilenrevisionen ersetzen einen reinen Zeitstempel-Cursor; eine später committende Transaktion mit älterem Zeitstempel geht nicht verloren.
- Fehlgeschlagene Delta-Abrufe bleiben vorgemerkt und werden auch ohne weiteres SSE-Ereignis wiederholt.
- Bereits laufende erfolgreiche/fehlgeschlagene Anfragen können einen neueren Provider-Backoff nicht verkürzen.
- Eine verspätete Token-Antwort kann die inzwischen ausgewählte andere Mint-Analyse nicht ersetzen.
- Zustellbestätigungen beziehen sich ausschließlich auf tatsächlich angezeigte Ereignis-IDs.
- Ruhezeiten prüfen auch den Ereigniszeitpunkt; nach einem Ausfall werden unterdrückte Ereignisse nicht verspätet zugestellt.
- Standby-Worker überschreiben keine aktive Health-Meldung; Token-Details reagieren auf Revisionen; Altersfilter altern mit der Uhr.

## Performance-Messwerte

### Echter laufender Datenpfad

Messfenster **11:27:57–11:30:06 UTC**, Produktionsserver, 1.357 Pools/1.227 Tokens, Pollintervall mindestens 60 Sekunden, Queue-Parallelität 2, regulär bis 180 Mints und 60 Pools pro Durchlauf.

| Gemessene Strecke | n | p50 | p95 | p99 |
|---|---:|---:|---:|---:|
| Normalisierter Eingang → DB-Commit | 26 | 137,7 ms | 263,9 ms | 282,2 ms |
| Frischer Antwort-Eingang → UI | 3 | 455 ms | 578,3 ms | 589,3 ms |
| Gespeichertes Update → UI | 5 | 498 ms | 2.213 ms | 2.453 ms |

Provider-HTTP-Latenz separat: DexScreener p95 **97,2 ms** (20/20 erfolgreiche Anfragen), GeckoTerminal **511,7 ms** (8/8), Solana **165,8 ms** (6/9). Die Solana-Verteilung enthält auch fehlgeschlagene Antworten. Die erste bedienbare echte Datenansicht wurde einmal mit **1.793,6 ms** gemessen.

Das sind kleine, unterschiedlich zusammengesetzte Stichproben und interpolierte Perzentile, keine belastbaren Latenzgarantien. Sie messen eigene beobachtete Eingänge, keine echte Onchain-Ereigniszeit. Diese ist ohne veröffentlichten Messzeitpunkt unbekannt. Polling, Anbieter-Caches und ungleichmäßige Aktualisierung bleiben zusätzliche Verzögerungen; Browser-/Server-Uhren müssen hinreichend übereinstimmen.

### Isolierter Tabellenbenchmark

Produktionsbuild, Desktop 1512 × 982, Headless Chromium; synthetische Antworten ausschließlich im Testbrowser, keine Einträge in PostgreSQL.

| Messung | 1.000 Zeilen | 10.000 Zeilen |
|---|---:|---:|
| Erste bedienbare Datenansicht, TTI-Näherung | 920 ms | 2.606 ms |
| Suche bis Darstellung inkl. 180-ms-Debounce | 213 ms | 231 ms |
| Filterberechnung im Browser | 0,7 ms | 7,1 ms |
| Berechnungs-p50/p95/p99 | 0,38 / 2,25 / 21,98 ms | 4,55 / 14,86 / 15,05 ms |
| Skript-Scroll-FPS | 56,0 | 51,4 |
| p95 Framezeit | 33,3 ms | 33,3 ms |
| Gemountete Tabellenzeilen | 17 | 17 |
| JS-Heap, Momentaufnahme | 23,8 MiB | 77,3 MiB |
| Unkomprimiertes Test-JSON | 5,53 MB | 55,18 MB |

Die TTI-Näherung ist kein offizieller Web-Vitals-Wert. Suchzeit enthält Playwright-Aufwand. FPS stammt aus 1,5 Sekunden gesteuertem Scrollen, Speicher ist kein Spitzen-RSS. Der Test belegt die Browserdarstellung, keinen 10.000-Pool-Backend-Dauerdurchsatz oder Mehrbenutzer-Lasttest. Die große 10k-Startantwort ist eine bekannte Grenze; vor deutlich größerem Betrieb wären kompaktere Projektionen und serverseitige Seiten/Filter sinnvoll. Auch 51 FPS sind keine 60-FPS-Garantie.

## Blockierte Daten, API-Kosten und Betriebsgrenzen

- **Echte Marktanbindung funktioniert.** Die letzte separate Live-Probe lieferte 20 GeckoTerminal-Pools und ein DexScreener-Paar mit Abrufzeit, geschätzter HTTP-Cache-Frische und ausdrücklich unbekanntem Markt-Messzeitpunkt.
- **Öffentlicher Solana-RPC ist eingeschränkt.** Im laufenden Messfenster gelangen sechs Anfragen; die letzte Probe traf einen bereits aktiven Backoff. Controls, Konzentration und Wallet-Daten dieser Probe waren deshalb teilweise/nicht verfügbar. Das UI zeigt unbekannte Komponenten und einen degradierten Gesamtstatus. Kein Limit wurde umgangen. Ein geeigneter dedizierter RPC kann serverseitig konfiguriert werden.
- **Keine Kostenpflicht eingerichtet.** Die verwendeten Standardendpunkte benötigen keinen bezahlten Schlüssel; es wurde nichts gebucht. Sie haben kein SLA. Hosting, PostgreSQL und ein späterer dedizierter RPC/optionaler Birdeye-/Helius-Tarif sind Betreiberentscheidungen. Offizielle Quellen und konservative Budgets stehen in [providers.md](../docs/providers.md).
- **Begrenzte Abdeckung.** Discovery umfasst verfügbare New-/Trend-/Profil-Feeds und keinen vollständigen Solana-Index. Bis 30 Watchlist-Mints werden je Durchlauf bevorzugt; reguläre Aktualisierungen rotieren. Kostenlose Budgets reichen bei größerem Bestand nicht zur Aktualisierung aller Pools binnen 180 Sekunden. Veraltete Werte bleiben gekennzeichnet.
- **Unbelegte Prüfungen bleiben unbekannt.** Verifizierte LP-Locks, eindeutige Holder-/Owner-Konzentration, vollständige Transaktionsgraphen, individuelle Großflüsse und belastbare Cluster sind mit den verfügbaren Quellen nicht umgesetzt. Größte Tokenkonten werden ausdrücklich als Konten behandelt. Aggregierte Aktivitätsheuristiken ersetzen keine Einzeltransaktionsanalyse.
- **Historie wächst ab Erfassung.** Externe OHLCV sind nur soweit erhältlich nutzbar; eigene Liquiditäts-/Trade-Samples beginnen beim ersten Abruf. Es gibt keine rückwirkend erfundene Historie oder interpolierten leeren Intervalle.
- **Benachrichtigungen ausschließlich in der App.** Kein E-Mail-/Messenger-Versand. Zufällige Sitzungen ersetzen kein vollständiges Konten-/Rollen-/Wiederherstellungssystem. Cookieverlust trennt den Zugriff auf bisherige persönliche Listen.
- **Lokaler Betrieb, kein veröffentlichtes Deployment.** Für gemeinsamen Betrieb: Zugangsschutz, TLS/Reverse Proxy mit SSE-Konfiguration, passende Origin, gesicherte DB-Werte, Backups, Monitoring und Kapazitätsplanung. CSP erlaubt den notwendigen lokalen Next.js-Inline-Bootstrap; keine noncebasierte Strict-CSP. Statischer Check und Dependency-Audit ersetzen keinen externen Sicherheitstest.

## Prüfen und weiterbetreiben

Start- und Prüfkommandos stehen vollständig in der [README](../README.md). PostgreSQL hält seine Daten im Compose-Volume; App und Worker laufen als getrennte Prozesse. Testdatenbanken mit Suffix `_test` bleiben vom Anwendungsbestand getrennt. Der Chaos-Test stoppt bewusst die lokale Compose-Datenbank.

Aktuelle echte Oberfläche: [Desktop](desktop.png), [Mobil](mobile.png). Die Screenshots zeigen den sichtbaren degradierten Zustand und konservative unbekannte Risikoprüfungen.
