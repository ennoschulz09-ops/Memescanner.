# Reproducible QA tooling

CI runs Node 24, PostgreSQL 17, unit/integration tests, typecheck, the existing security scan, a production build and the complete Chromium desktop/tablet/mobile, Firefox desktop and WebKit desktop browser suite. It uploads browser reports, traces on failure and accessibility attachments. Automated checks support the WCAG 2.2 AA target; they are not a complete accessibility certification or screen-reader audit.

## CI commands

```sh
npm ci
npx playwright install --with-deps chromium firefox webkit
npm run test:browsers
npm run db:migrate
npm run db:test
npm test
npm run test:integration
npm run typecheck
npm run test:security
npm run build
NEXUS_TEST_MODE=true CI_NETWORK_ISOLATION=true npm run test:ci-fixtures
NEXUS_TEST_MODE=true CI_NETWORK_ISOLATION=true PLAYWRIGHT_START_SERVER=true npm run test:e2e
```

The workflow provides `DATABASE_URL` and `CI_TEST_DATABASE_URL` pointing at `nexus_ci_test`, and a separate `TEST_DATABASE_URL` pointing at `nexus_test`. `NEXUS_TEST_MODE=true` and `CI_NETWORK_ISOLATION=true` are explicit only for fixture/E2E steps and the managed browser server. They are deliberately absent from unit/integration steps, whose injected fixture transports must remain executable. The fixture command requires `CI_TEST_DATABASE_URL`, validates the `_test` suffix before connecting, verifies `current_database()` again before truncating, seeds 240 deterministic test rows and no real provider data. It never falls back to `DATABASE_URL`. The browser server requires the same test-mode guard and displays an isolated-test-data banner. No worker is started by CI. The app scanner remains the default route.

`CI_NETWORK_ISOLATION` blocks provider transport in conjunction with test mode; provider unit/integration steps exercise injected deterministic transports with those two flags unset. The isolated candle cache contains explicitly empty QA data; no market candles are fabricated. Expired cache requests can report a blocked provider and use stale fallback without requiring external access.

## Interaction benchmark

```sh
npm run build
npm run bench:elite
```

Run the benchmark alone after the production build. It creates/seeds only a distinct `nexus_elite_performance_test` database, starts an isolated production server on port 3200 and measures real paginated requests with 1k/5k/10k total rows, a bounded 100-row server page and at most 50 mounted scanner rows. Set `ELITE_DATABASE_URL` to another `_performance_test` database, `ELITE_PORT` to 3100–3999 or `ELITE_REPORT` to retain independent runs. The script rejects the normal app database. It leaves the isolated database available for inspecting evidence.

The default seven initial loads and twenty samples each for filter/sort/search/detail produce raw samples and nearest-rank p50/p95/p99. The actual DOM input/change/click begins interaction timing; the first animation frame after a corresponding server response and expected DOM result ends it. No automation polling time is included in interaction timing. Initial load is a task-specific navigation-to-populated-scanner proxy with automation overhead. The first navigation is cold for each profile, later loads use warm caches. Small-sample p99 equals the maximum and does not establish a tail SLA.

Desktop uses 1512×982 without throttling. Mobile uses the iPhone 13 Chromium device profile, 4× CPU slowdown, 150 ms added latency, 1.6 Mbps down and 750 kbps up. Only the controlled desktop standard liquidity-filter p95 <200 ms is an acceptance gate. Throttled mobile results are diagnostics. Long Tasks API durations, scripted 1.5-second scroll FPS and one point-in-time JS heap sample are retained; they do not prove peak RAM, sustained real-device frame rate or provider performance. Run independently from realtime benchmarks or other browser suites.

`ELITE_COUNTS=1000 ELITE_SAMPLES=5 ELITE_LOAD_SAMPLES=3 npm run bench:elite` is a tooling smoke run, not the full acceptance measurement. The existing realtime benchmark remains separate.

## Browser availability in this workspace

Playwright downloaded Chromium 156, Firefox 157 and WebKit 27.2 with the existing proxy and CA configuration. Chromium and Firefox launched directly. `playwright install-deps` could not elevate (`su: Authentication failure`). For WebKit, matching signed Debian 13 packages were downloaded and extracted under ignored `.runtime/webkit-libs`; no system package files changed. Required packages: `libgtk-4-1`, `libgraphene-1.0-0`, `libharfbuzz-icu0`, `libmanette-0.2-0`, `libhyphen0`, `libgles2`, `libcairo-script-interpreter2`, `libhidapi-hidraw0`, `libglvnd0`.

The local `.runtime/webkit-libs/launch-webkit.sh` wrapper sets the bundle's WPE executable/resource paths and an `LD_LIBRARY_PATH` combining extracted libraries with Playwright's bundled libraries, then executes MiniBrowser. `WEBKIT_PATH` points Playwright at that wrapper; it does not disable TLS, proxy settings or a security check. The actual browser launch and DOM interaction verify that the extracted ABI works. CI uses the normal `install --with-deps` route and needs no wrapper.

```sh
WEBKIT_PATH="$PWD/.runtime/webkit-libs/launch-webkit.sh" npm run test:browsers
WEBKIT_PATH="$PWD/.runtime/webkit-libs/launch-webkit.sh" npm run test:e2e
BROWSER_PROBE_URL=http://localhost:3000 WEBKIT_PATH="$PWD/.runtime/webkit-libs/launch-webkit.sh" npm run test:browsers
```

The availability report distinguishes runtime capability from an optional application smoke check; complete browser regressions are separate evidence. Desktop WebKit is not a physical Safari/iPhone test.
