# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app.spec.ts >> saves a filter preset and persists a compact terminal preference
- Location: tests/e2e/app.spec.ts:102:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 56
Received: 128
```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - generic [ref=f2e2]:
    - link "Zum Research-Inhalt" [ref=f2e3] [cursor=pointer]:
      - /url: "#research-main"
    - complementary [ref=f2e4]:
      - generic [ref=f2e10]:
        - strong [ref=f2e11]: SMARTLAB
        - generic [ref=f2e12]: NEXUS / 01
      - button "S Research Workspace Solana Mainnet" [ref=f2e13] [cursor=pointer]:
        - generic [ref=f2e14]: S
        - generic [ref=f2e15]:
          - strong [ref=f2e16]: Research Workspace
          - generic [ref=f2e17]: Solana Mainnet
      - generic [ref=f2e20]: ENTDECKEN & ANALYSIEREN
      - navigation "Hauptnavigation" [ref=f2e21]:
        - button "Command Dashboard" [ref=f2e22] [cursor=pointer]
        - button "Discovery" [ref=f2e29] [cursor=pointer]
        - button "Live Scanner" [ref=f2e34] [cursor=pointer]
        - button "Token-Analyse" [ref=f2e43] [cursor=pointer]
        - button "Risk Lab" [ref=f2e50] [cursor=pointer]
        - button "Wallet Explorer" [ref=f2e55] [cursor=pointer]
        - generic [ref=f2e60]: DEIN RESEARCH
        - button "Watchlists" [ref=f2e61] [cursor=pointer]
        - button "Alerts" [ref=f2e65] [cursor=pointer]
        - button "Analytics" [ref=f2e70] [cursor=pointer]
        - button "Datenqualität" [ref=f2e74] [cursor=pointer]
      - generic [ref=f2e80]:
        - generic [ref=f2e81]:
          - generic [ref=f2e82]: WATCHLISTS
          - button "Watchlist erstellen" [ref=f2e83] [cursor=pointer]
        - paragraph [ref=f2e85]: Dein nächster Fundbeginnt im Scanner.
      - generic [ref=f2e86]:
        - generic [ref=f2e87]:
          - button "System Health" [ref=f2e88] [cursor=pointer]
          - button "Einstellungen" [ref=f2e93] [cursor=pointer]
        - generic [ref=f2e101]:
          - strong [ref=f2e102]: Research. Mit Klarheit.
          - generic [ref=f2e103]: Öffentliche Daten.Nachvollziehbare Evidenz.
        - generic [ref=f2e104]:
          - generic [ref=f2e105]: SMARTLAB NEXUS
          - generic [ref=f2e106]: v1.0
    - generic [ref=f2e107]:
      - banner [ref=f2e108]:
        - generic [ref=f2e109]:
          - button "Navigation öffnen" [ref=f2e110] [cursor=pointer]
          - strong [ref=f2e112]: Live Scanner
        - generic [ref=f2e113]:
          - textbox "Token, Symbol oder Mint-Adresse suchen" [ref=f2e117]
          - generic [ref=f2e118]: ⌘ K
        - generic [ref=f2e119]:
          - generic [ref=f2e120]:
            - generic [ref=f2e121]: ≋
            - text: Solana
          - button "Alert-Posteingang" [ref=f2e122] [cursor=pointer]
          - generic [ref=f2e126]: R
      - main [ref=f2e127]:
        - generic [ref=f2e128]:
          - generic [ref=f2e129]:
            - generic [ref=f2e130]: SOLANA TOKEN INTELLIGENCE
            - heading "Live Scanner" [level=1] [ref=f2e133]: Live Scanner.
            - paragraph [ref=f2e134]: Öffentliche Solana-Pools entdecken. Daten einordnen. Risiken verstehen.
          - generic [ref=f2e135]:
            - generic [ref=f2e136]: Degradierter Modus
            - generic [ref=f2e138]: Update 1m
        - status [ref=f2e144]:
          - strong [ref=f2e145]: ISOLIERTE TESTDATEN · keine aktuellen Marktdaten
        - generic [ref=f2e146]:
          - generic [ref=f2e147]: TOKEN RADAR öffentliche Beobachtungen
          - button "Live-Updates pausieren" [ref=f2e148] [cursor=pointer]: Updates pausieren
        - generic [ref=f2e152]:
          - generic [ref=f2e153]:
            - generic [ref=f2e154]: Erfasste Pools
            - strong [ref=f2e161]: "240"
            - generic [ref=f2e162]: Öffentlicher Marktausschnitt
          - generic [ref=f2e164]:
            - generic [ref=f2e165]: Neu erkannt · 5 Min.
            - strong [ref=f2e171]: "211"
            - generic [ref=f2e172]:
              - generic [ref=f2e173]: "0"
              - text: in 1m
              - generic [ref=f2e174]: /
              - text: 240 in 15m
          - generic [ref=f2e175]:
            - generic [ref=f2e176]: Liquidität · Auswahl
            - strong [ref=f2e181]: $595K
            - generic [ref=f2e182]: 100 Pools mit verfügbarem Wert
          - generic [ref=f2e183]:
            - generic [ref=f2e184]: Ø Datenqualität · Auswahl
            - strong [ref=f2e190]: 60/100
            - generic [ref=f2e191]:
              - generic [ref=f2e192]: "3"
              - text: Quellen-/Frischehinweise
        - generic [ref=f2e194]:
          - generic [ref=f2e195]:
            - button "Alle Pools 240" [ref=f2e196] [cursor=pointer]:
              - text: Alle Pools
              - generic [ref=f2e197]: "240"
            - button "Neue Listings" [ref=f2e198] [cursor=pointer]
            - button "Steigendes Volumen" [ref=f2e200] [cursor=pointer]
            - button "Hohe Liquidität" [ref=f2e201] [cursor=pointer]
            - group [ref=f2e202]:
              - generic "Weitere Schnellfilter" [ref=f2e203] [cursor=pointer]
          - generic [ref=f2e205]:
            - generic [ref=f2e206]:
              - generic [ref=f2e207]:
                - heading "Token-Radar" [level=2] [ref=f2e214]
                - generic [ref=f2e215]: 100 Pools
              - generic [ref=f2e216]:
                - generic [ref=f2e217]:
                  - generic [ref=f2e218]: Sortierung
                  - combobox "Scanner-Sortierung" [ref=f2e219]:
                    - option "Neueste Funde" [selected]
                    - option "Liquidität ↓"
                    - option "Preis ↓"
                    - option "Name A–Z"
                - button "Filter" [ref=f2e220] [cursor=pointer]
                - group [ref=f2e222]:
                  - generic "Spalten auswählen" [ref=f2e223] [cursor=pointer]
                - link "Scanner als CSV exportieren" [ref=f2e226] [cursor=pointer]:
                  - /url: /api/export?format=csv
            - generic [ref=f2e231]:
              - button "Mein Recherchefilter" [ref=f2e232] [cursor=pointer]
              - button "Mein Recherchefilter löschen" [ref=f2e233] [cursor=pointer]
            - table "Solana Token Scanner" [ref=f2e237]:
              - row [ref=f2e238]:
                - columnheader [ref=f2e239]:
                  - button "Token / Pool" [ref=f2e240] [cursor=pointer]
                - columnheader [ref=f2e241]:
                  - button "Poolalter" [ref=f2e242] [cursor=pointer]
                - columnheader [ref=f2e243]:
                  - button "Preis" [ref=f2e244] [cursor=pointer]
                - columnheader [ref=f2e245]:
                  - button "Liquidität" [ref=f2e246] [cursor=pointer]
                - columnheader [ref=f2e247]:
                  - button "Vol. 5m" [ref=f2e248] [cursor=pointer]
                - columnheader [ref=f2e249]:
                  - button "Δ Preis 5m" [ref=f2e250] [cursor=pointer]
                - columnheader [ref=f2e251]:
                  - button "Risiko" [ref=f2e252] [cursor=pointer]
                - columnheader [ref=f2e253]:
                  - button "Datenqualität" [ref=f2e254] [cursor=pointer]
              - rowgroup [ref=f2e255]:
                - row [selected] [ref=f2e256] [cursor=pointer]:
                  - cell "QA0 Zur Watchlist hinzufügen QA0 Isolierter QA Token 00000 1113…Nm22 · HTTP-Cache 1m" [ref=f2e257]:
                    - button "QA0 Zur Watchlist hinzufügen" [ref=f2e258]
                    - generic [aria-hidden] [ref=f2e261]: QA
                    - generic [ref=f2e262]:
                      - generic [ref=f2e263]:
                        - strong [ref=f2e264]: QA0
                        - generic "Isolierter QA Token 00000" [ref=f2e265]
                      - generic [ref=f2e266]:
                        - generic "1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22" [ref=f2e267]: 1113…Nm22
                        - generic [ref=f2e268]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e269]: HTTP-Cache 1m
                  - cell "Preis $1" [ref=f2e270]:
                    - text: Preis
                    - generic "1" [ref=f2e271]: $1
                  - cell "Liq. $1,000" [ref=f2e272]:
                    - text: Liq.
                    - generic "1000" [ref=f2e273]: $1,000
                - row [ref=f2e274] [cursor=pointer]:
                  - cell "QA1 Zur Watchlist hinzufügen QA1 Isolierter QA Token 00001 1116…uAqY · HTTP-Cache 1m" [ref=f2e275]:
                    - button "QA1 Zur Watchlist hinzufügen" [ref=f2e276]
                    - generic [aria-hidden] [ref=f2e279]: QA
                    - generic [ref=f2e280]:
                      - generic [ref=f2e281]:
                        - strong [ref=f2e282]: QA1
                        - generic "Isolierter QA Token 00001" [ref=f2e283]
                      - generic [ref=f2e284]:
                        - generic "1116ToyYDUkenKtmMGSxDN8xKwLDH7nX8H4JDxuAqY" [ref=f2e285]: 1116…uAqY
                        - generic [ref=f2e286]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e287]: HTTP-Cache 1m
                  - cell "Preis $1.001" [ref=f2e288]:
                    - text: Preis
                    - generic "1.001" [ref=f2e289]: $1.001
                  - cell "Liq. $1,100" [ref=f2e290]:
                    - text: Liq.
                    - generic "1100" [ref=f2e291]: $1,100
                - row [ref=f2e292] [cursor=pointer]:
                  - cell "QA2 Zur Watchlist hinzufügen QA2 Isolierter QA Token 00002 1119…Raf4 · HTTP-Cache 1m" [ref=f2e293]:
                    - button "QA2 Zur Watchlist hinzufügen" [ref=f2e294]
                    - generic [aria-hidden] [ref=f2e297]: QA
                    - generic [ref=f2e298]:
                      - generic [ref=f2e299]:
                        - strong [ref=f2e300]: QA2
                        - generic "Isolierter QA Token 00002" [ref=f2e301]
                      - generic [ref=f2e302]:
                        - generic "11196XUf3GUXSx5gdiyLLK4TQgQYF8RbLmxYLYRaf4" [ref=f2e303]: 1119…Raf4
                        - generic [ref=f2e304]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e305]: HTTP-Cache 1m
                  - cell "Preis $1.002" [ref=f2e306]:
                    - text: Preis
                    - generic "1.002" [ref=f2e307]: $1.002
                  - cell "Liq. $1,200" [ref=f2e308]:
                    - text: Liq.
                    - generic "1200" [ref=f2e309]: $1,200
                - row [ref=f2e310] [cursor=pointer]:
                  - cell "QA3 Zur Watchlist hinzufügen QA3 Isolierter QA Token 00003 111B…wzUa · HTTP-Cache 1m" [ref=f2e311]:
                    - button "QA3 Zur Watchlist hinzufügen" [ref=f2e312]
                    - generic [aria-hidden] [ref=f2e315]: QA
                    - generic [ref=f2e316]:
                      - generic [ref=f2e317]:
                        - strong [ref=f2e318]: QA3
                        - generic "Isolierter QA Token 00003" [ref=f2e319]
                      - generic [ref=f2e320]:
                        - generic "111BjEyms4CQ7aGbvBViTFyxVRUsD94fZGrnT7wzUa" [ref=f2e321]: 111B…wzUa
                        - generic [ref=f2e322]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e323]: HTTP-Cache 1m
                  - cell "Preis $1.003" [ref=f2e324]:
                    - text: Preis
                    - generic "1.003" [ref=f2e325]: $1.003
                  - cell "Liq. $1,300" [ref=f2e326]:
                    - text: Liq.
                    - generic "1300" [ref=f2e327]: $1,300
                - row [ref=f2e328] [cursor=pointer]:
                  - cell "QA4 Zur Watchlist hinzufügen QA4 Isolierter QA Token 00004 111E…UQJ6 · HTTP-Cache 1m" [ref=f2e329]:
                    - button "QA4 Zur Watchlist hinzufügen" [ref=f2e330]
                    - generic [aria-hidden] [ref=f2e333]: QA
                    - generic [ref=f2e334]:
                      - generic [ref=f2e335]:
                        - strong [ref=f2e336]: QA4
                        - generic "Isolierter QA Token 00004" [ref=f2e337]
                      - generic [ref=f2e338]:
                        - generic "111EMxUtgqvGnCTXCe26aCuTaAZCB9hjmmm2ZhUQJ6" [ref=f2e339]: 111E…UQJ6
                        - generic [ref=f2e340]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e341]: HTTP-Cache 1m
                  - cell "Preis $1.004" [ref=f2e342]:
                    - text: Preis
                    - generic "1.004" [ref=f2e343]: $1.004
                  - cell "Liq. $1,400" [ref=f2e344]:
                    - text: Liq.
                    - generic "1400" [ref=f2e345]: $1,400
                - row [ref=f2e346] [cursor=pointer]:
                  - cell "QA5 Zur Watchlist hinzufügen QA5 Isolierter QA Token 00005 111G…zp7c · HTTP-Cache 1m" [ref=f2e347]:
                    - button "QA5 Zur Watchlist hinzufügen" [ref=f2e348]
                    - generic [aria-hidden] [ref=f2e351]: QA
                    - generic [ref=f2e352]:
                      - generic [ref=f2e353]:
                        - strong [ref=f2e354]: QA5
                        - generic "Isolierter QA Token 00005" [ref=f2e355]
                      - generic [ref=f2e356]:
                        - generic "111Gzfz1Wde9SpeSV6YUh9pxeudX9ALozGfGgGzp7c" [ref=f2e357]: 111G…zp7c
                        - generic [ref=f2e358]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e359]: HTTP-Cache 1m
                  - cell "Preis $1.005" [ref=f2e360]:
                    - text: Preis
                    - generic "1.005" [ref=f2e361]: $1.005
                  - cell "Liq. $1,500" [ref=f2e362]:
                    - text: Liq.
                    - generic "1500" [ref=f2e363]: $1,500
                - row [ref=f2e364] [cursor=pointer]:
                  - cell "QA6 Zur Watchlist hinzufügen QA6 Isolierter QA Token 00006 111K…XDw8 · HTTP-Cache 1m" [ref=f2e365]:
                    - button "QA6 Zur Watchlist hinzufügen" [ref=f2e366]
                    - generic [aria-hidden] [ref=f2e369]: QA
                    - generic [ref=f2e370]:
                      - generic [ref=f2e371]:
                        - strong [ref=f2e372]: QA6
                        - generic "Isolierter QA Token 00006" [ref=f2e373]
                      - generic [ref=f2e374]:
                        - generic "111KdPV8LRN27SqMmZ4rp6kTjehr7AytCmZWnrXDw8" [ref=f2e375]: 111K…XDw8
                        - generic [ref=f2e376]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e377]: HTTP-Cache 1m
                  - cell "Preis $1.006" [ref=f2e378]:
                    - text: Preis
                    - generic "1.006" [ref=f2e379]: $1.006
                  - cell "Liq. $1,600" [ref=f2e380]:
                    - text: Liq.
                    - generic "1600" [ref=f2e381]: $1,600
                - row [ref=f2e382] [cursor=pointer]:
                  - cell "QA7 Zur Watchlist hinzufügen QA7 Isolierter QA Token 00007 111N…3dke · HTTP-Cache 1m" [ref=f2e383]:
                    - button "QA7 Zur Watchlist hinzufügen" [ref=f2e384]
                    - generic [aria-hidden] [ref=f2e387]: QA
                    - generic [ref=f2e388]:
                      - generic [ref=f2e389]:
                        - strong [ref=f2e390]: QA7
                        - generic "Isolierter QA Token 00007" [ref=f2e391]
                      - generic [ref=f2e392]:
                        - generic "111NG6zFAD5tn52H41bEw3fxpPnB5BcxRGTkuS3dke" [ref=f2e393]: 111N…3dke
                        - generic [ref=f2e394]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e395]: HTTP-Cache 1m
                  - cell "Preis $1.007" [ref=f2e396]:
                    - text: Preis
                    - generic "1.007" [ref=f2e397]: $1.007
                  - cell "Liq. $1,700" [ref=f2e398]:
                    - text: Liq.
                    - generic "1700" [ref=f2e399]: $1,700
                - row [ref=f2e400] [cursor=pointer]:
                  - cell "QA8 Zur Watchlist hinzufügen QA8 Isolierter QA Token 00008 111Q…a3aA · HTTP-Cache 1m" [ref=f2e401]:
                    - button "QA8 Zur Watchlist hinzufügen" [ref=f2e402]
                    - generic [aria-hidden] [ref=f2e405]: QA
                    - generic [ref=f2e406]:
                      - generic [ref=f2e407]:
                        - strong [ref=f2e408]: QA8
                        - generic "Isolierter QA Token 00008" [ref=f2e409]
                      - generic [ref=f2e410]:
                        - generic "111QtpVMyzomShDCLU7d3zbTu8rW3CG2dmN121a3aA" [ref=f2e411]: 111Q…a3aA
                        - generic [ref=f2e412]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e413]: HTTP-Cache 1m
                  - cell "Preis $1.008" [ref=f2e414]:
                    - text: Preis
                    - generic "1.008" [ref=f2e415]: $1.008
                  - cell "Liq. $1,800" [ref=f2e416]:
                    - text: Liq.
                    - generic "1800" [ref=f2e417]: $1,800
                - row [ref=f2e418] [cursor=pointer]:
                  - cell "QA9 Zur Watchlist hinzufügen QA9 Isolierter QA Token 00009 111T…6TPg · HTTP-Cache 1m" [ref=f2e419]:
                    - button "QA9 Zur Watchlist hinzufügen" [ref=f2e420]
                    - generic [aria-hidden] [ref=f2e423]: QA
                    - generic [ref=f2e424]:
                      - generic [ref=f2e425]:
                        - strong [ref=f2e426]: QA9
                        - generic "Isolierter QA Token 00009" [ref=f2e427]
                      - generic [ref=f2e428]:
                        - generic "111TXXzUonXe7KQ7cve1AwWxysvq1Cu6rGGF8b6TPg" [ref=f2e429]: 111T…6TPg
                        - generic [ref=f2e430]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e431]: HTTP-Cache 1m
                  - cell "Preis $1.009" [ref=f2e432]:
                    - text: Preis
                    - generic "1.009" [ref=f2e433]: $1.009
                  - cell "Liq. $1,900" [ref=f2e434]:
                    - text: Liq.
                    - generic "1900" [ref=f2e435]: $1,900
                - row [ref=f2e436] [cursor=pointer]:
                  - cell "QA10 Zur Watchlist hinzufügen QA10 Isolierter QA Token 00010 111W…csDC · HTTP-Cache 1m" [ref=f2e437]:
                    - button "QA10 Zur Watchlist hinzufügen" [ref=f2e438]
                    - generic [aria-hidden] [ref=f2e441]: QA
                    - generic [ref=f2e442]:
                      - generic [ref=f2e443]:
                        - strong [ref=f2e444]: QA10
                        - generic "Isolierter QA Token 00010" [ref=f2e445]
                      - generic [ref=f2e446]:
                        - generic "111WAFVbdaFWmwb2uPAPHtSU4d19yDYB4mAVFAcsDC" [ref=f2e447]: 111W…csDC
                        - generic [ref=f2e448]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e449]: HTTP-Cache 1m
                  - cell "Preis $1.01" [ref=f2e450]:
                    - text: Preis
                    - generic "1.01" [ref=f2e451]: $1.01
                  - cell "Liq. $2,000" [ref=f2e452]:
                    - text: Liq.
                    - generic "2000" [ref=f2e453]: $2,000
                - row [ref=f2e454] [cursor=pointer]:
                  - cell "QA11 Zur Watchlist hinzufügen QA11 Isolierter QA Token 00011 111Y…9H2i · HTTP-Cache 1m" [ref=f2e455]:
                    - button "QA11 Zur Watchlist hinzufügen" [ref=f2e456]
                    - generic [aria-hidden] [ref=f2e459]: QA
                    - generic [ref=f2e460]:
                      - generic [ref=f2e461]:
                        - strong [ref=f2e462]: QA11
                        - generic "Isolierter QA Token 00011" [ref=f2e463]
                      - generic [ref=f2e464]:
                        - generic "111YnxziTMyPSZmxBqgmQqMy9N5UwEBFHG4jMk9H2i" [ref=f2e465]: 111Y…9H2i
                        - generic [ref=f2e466]: ·
                        - generic "GeckoTerminal · 2026-10-24T00:00:15.946Z · http-cache-estimate" [ref=f2e467]: HTTP-Cache 1m
                  - cell "Preis $1.011" [ref=f2e468]:
                    - text: Preis
                    - generic "1.011" [ref=f2e469]: $1.011
                  - cell "Liq. $2,100" [ref=f2e470]:
                    - text: Liq.
                    - generic "2100" [ref=f2e471]: $2,100
            - generic [ref=f2e472]:
              - generic [ref=f2e473]: GeckoTerminal + DexScreener · budgetiertes Polling
              - generic [ref=f2e475]:
                - button "Vorherige Scanner-Seite" [disabled] [ref=f2e476]: ‹
                - generic [ref=f2e477]: Seite 1 / 3 · 240 Treffer
                - button "Nächste Scanner-Seite" [ref=f2e478] [cursor=pointer]: ›
          - generic [ref=f2e479]: Recherche beginnt mit Daten. Ein Score ist keine Empfehlung. Fehlende Prüfungen bleiben unbekannt.
        - generic [ref=f2e483]:
          - generic [ref=f2e484]:
            - text: READ-ONLY RESEARCH
            - generic [ref=f2e489]: /
            - text: Datenqualität ist kein Sicherheitsnachweis.
          - generic [ref=f2e490]:
            - text: 24.10., 00:01:45 UTC
            - generic [ref=f2e491]: ·
            - text: Quellenstand je Wert sichtbar
    - navigation "Mobile Research-Navigation" [ref=f2e492]:
      - button "Command" [ref=f2e493] [cursor=pointer]
      - button "Radar" [ref=f2e500] [cursor=pointer]
      - button "Analyse" [ref=f2e508] [cursor=pointer]
      - button "Watchlists" [ref=f2e515] [cursor=pointer]
      - button "Status" [ref=f2e519] [cursor=pointer]
  - alert [ref=f2e524]
```

# Test source

```ts
  33  |   await expect(
  34  |     page.getByText("Meine Watchlist", { exact: true }).last(),
  35  |   ).toBeVisible();
  36  |   await page
  37  |     .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
  38  |     .fill("no-watchlist-match-92371");
  39  |   await expect(
  40  |     page.getByText("Keine Treffer in dieser Watchlist"),
  41  |   ).toBeVisible();
  42  |   await expect(page.getByTestId("watchlist-token")).toHaveCount(0);
  43  |   await page
  44  |     .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
  45  |     .fill("");
  46  |   await page.getByTestId("watchlist-token").first().click();
  47  |   await expect(
  48  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  49  |   ).toBeVisible();
  50  |   await expect(page.getByText("Datenherkunft", { exact: true })).toBeVisible();
  51  | });
  52  | test("filters, column selection and empty states work", async ({ page }) => {
  53  |   await page.goto("/");
  54  |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  55  |   await page
  56  |     .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
  57  |     .fill("unfindable-token-xyz-293");
  58  |   await expect(page.getByText("Keine passenden Pools")).toBeVisible();
  59  |   await page
  60  |     .getByRole("main")
  61  |     .getByRole("button", { name: "Suche zurücksetzen" })
  62  |     .click();
  63  |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  64  |   await page.locator('summary[aria-label="Spalten auswählen"]').click();
  65  |   await page.getByLabel("FDV", { exact: true }).check();
  66  |   await expect(
  67  |     page.getByRole("columnheader", { name: "FDV", exact: true }),
  68  |   ).toHaveCount(1);
  69  |   await page.getByLabel("FDV", { exact: true }).uncheck();
  70  |   await page.locator('summary[aria-label="Spalten auswählen"]').click();
  71  |   await expect(
  72  |     page.getByRole("columnheader", { name: "FDV", exact: true }),
  73  |   ).toHaveCount(0);
  74  | });
  75  | test("all research views render and fit their viewport", async ({
  76  |   page,
  77  | }, info) => {
  78  |   for (const [view, heading] of [
  79  |     ["discovery", "Discovery"],
  80  |     ["risk", "Risk Lab"],
  81  |     ["wallet", "Wallet Explorer"],
  82  |     ["watchlists", "Watchlists"],
  83  |     ["alerts", "Alerts"],
  84  |     ["analytics", "Analytics"],
  85  |     ["health", "System Health"],
  86  |     ["settings", "Einstellungen"],
  87  |   ]) {
  88  |     await page.goto("/?view=" + view);
  89  |     await expect(
  90  |       page.getByRole("heading", { name: heading, exact: true }),
  91  |     ).toBeVisible();
  92  |     await expect(page.getByTestId("virtual-table")).toHaveCount(0);
  93  |     if (info.project.name === "mobile")
  94  |       expect(
  95  |         await page.evaluate(
  96  |           () => document.documentElement.scrollWidth <= innerWidth,
  97  |         ),
  98  |         view,
  99  |       ).toBe(true);
  100 |   }
  101 | });
  102 | test("saves a filter preset and persists a compact terminal preference", async ({
  103 |   page,
  104 | }) => {
  105 |   await page.goto("/");
  106 |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  107 |   await page.getByRole("button", { name: "Filter", exact: true }).click();
  108 |   await page.getByLabel("Min. Liquidität (USD)", { exact: true }).fill("100");
  109 |   await page.getByRole("button", { name: "Als Preset speichern" }).click();
  110 |   await page
  111 |     .getByRole("textbox", { name: "Preset-Name" })
  112 |     .fill("Mein Recherchefilter");
  113 |   await page.getByRole("button", { name: "Speichern", exact: true }).click();
  114 |   await expect(
  115 |     page.getByRole("button", { name: "Mein Recherchefilter", exact: true }),
  116 |   ).toBeVisible();
  117 |   await page.goto("/?view=settings");
  118 |   await expect(
  119 |     page.getByRole("switch", { name: "Kompakte Tabelle" }),
  120 |   ).toBeVisible();
  121 |   await page.getByRole("switch", { name: "Kompakte Tabelle" }).click();
  122 |   await page.getByRole("button", { name: "Einstellungen speichern" }).click();
  123 |   await expect(
  124 |     page.getByRole("button", { name: "Gespeichert", exact: true }),
  125 |   ).toBeVisible();
  126 |   await page.goto("/");
  127 |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  128 |   expect(
  129 |     await page
  130 |       .getByTestId("pool-row")
  131 |       .first()
  132 |       .evaluate((e) => e.getBoundingClientRect().height),
> 133 |   ).toBe(56);
      |     ^ Error: expect(received).toBe(expected) // Object.is equality
  134 | });
  135 | test("creates, pauses and removes an in-app alert rule", async ({ page }) => {
  136 |   await page.goto("/?view=alerts");
  137 |   await page.getByRole("button", { name: "Neue Alert-Regel" }).click();
  138 |   await page
  139 |     .getByLabel("Name", { exact: true })
  140 |     .fill("E2E Liquiditätsbeobachtung");
  141 |   await page.getByRole("button", { name: "Regel speichern" }).click();
  142 |   const toggle = page.getByRole("switch", {
  143 |     name: "E2E Liquiditätsbeobachtung aktiv",
  144 |   });
  145 |   await expect(toggle).toBeChecked();
  146 |   await toggle.click();
  147 |   await expect(toggle).not.toBeChecked();
  148 |   await page
  149 |     .locator(".alert-rule")
  150 |     .filter({ hasText: "E2E Liquiditätsbeobachtung" })
  151 |     .getByRole("button", { name: "Entfernen" })
  152 |     .click();
  153 |   await expect(toggle).toHaveCount(0);
  154 | });
  155 | test("database and provider failures produce an explicit error state", async ({
  156 |   page,
  157 | }) => {
  158 |   await page.route("**/api/pools**", (route) =>
  159 |     route.fulfill({
  160 |       status: 503,
  161 |       contentType: "application/json",
  162 |       body: JSON.stringify({
  163 |         error: "Datenbank nicht verfügbar.",
  164 |         mode: "offline",
  165 |       }),
  166 |     }),
  167 |   );
  168 |   await page.goto("/");
  169 |   await expect(
  170 |     page.getByRole("alert").filter({ hasText: "Datenbank nicht verfügbar." }),
  171 |   ).toBeVisible();
  172 |   await expect(page.getByTestId("pool-row")).toHaveCount(0);
  173 | });
  174 | test("wallet validation is local and mobile layout has no page overflow", async ({
  175 |   page,
  176 | }, info) => {
  177 |   await page.goto("/?view=wallet");
  178 |   await expect(
  179 |     page.getByRole("heading", { name: "Wallet Explorer", exact: true }),
  180 |   ).toBeVisible();
  181 |   await page.getByLabel("Öffentliche Solana-Adresse").fill("invalid");
  182 |   await page.getByRole("button", { name: "Adresse analysieren" }).click();
  183 |   await expect(
  184 |     page.getByText("Bitte eine gültige öffentliche Solana-Adresse eingeben."),
  185 |   ).toBeVisible();
  186 |   if (info.project.name === "mobile")
  187 |     expect(
  188 |       await page.evaluate(
  189 |         () => document.documentElement.scrollWidth <= window.innerWidth,
  190 |       ),
  191 |     ).toBe(true);
  192 | });
  193 |
```
