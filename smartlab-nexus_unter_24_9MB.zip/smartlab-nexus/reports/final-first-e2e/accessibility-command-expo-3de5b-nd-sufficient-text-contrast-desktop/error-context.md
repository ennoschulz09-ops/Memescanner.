# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> command exposes labels, landmarks and sufficient text contrast
- Location: tests/e2e/accessibility.spec.ts:11:3

# Error details

```
Error: command

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 25

- Array []
+ Array [
+   Object {
+     "id": "label-content-name-mismatch",
+     "targets": Array [
+       Array [
+         "button[aria-label=\"QA0 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA1 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA2 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA3 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA4 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA5 analysieren\"]",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Zum Research-Inhalt" [ref=e3] [cursor=pointer]:
      - /url: "#research-main"
    - complementary [ref=e4]:
      - generic [ref=e10]:
        - strong [ref=e11]: SMARTLAB
        - generic [ref=e12]: NEXUS / 01
      - button "S Research Workspace Solana Mainnet" [ref=e13] [cursor=pointer]:
        - generic [ref=e14]: S
        - generic [ref=e15]:
          - strong [ref=e16]: Research Workspace
          - generic [ref=e17]: Solana Mainnet
      - generic [ref=e20]: ENTDECKEN & ANALYSIEREN
      - navigation "Hauptnavigation" [ref=e21]:
        - button "Command Dashboard" [ref=e22] [cursor=pointer]
        - button "Discovery" [ref=e29] [cursor=pointer]
        - button "Live Scanner" [ref=e34] [cursor=pointer]
        - button "Token-Analyse" [ref=e43] [cursor=pointer]
        - button "Risk Lab" [ref=e50] [cursor=pointer]
        - button "Wallet Explorer" [ref=e55] [cursor=pointer]
        - generic [ref=e60]: DEIN RESEARCH
        - button "Watchlists" [ref=e61] [cursor=pointer]
        - button "Alerts" [ref=e65] [cursor=pointer]
        - button "Analytics" [ref=e70] [cursor=pointer]
        - button "Datenqualität" [ref=e74] [cursor=pointer]
      - generic [ref=e80]:
        - generic [ref=e81]:
          - generic [ref=e82]: WATCHLISTS
          - button "Watchlist erstellen" [ref=e83] [cursor=pointer]
        - paragraph [ref=e85]: Dein nächster Fundbeginnt im Scanner.
      - generic [ref=e86]:
        - generic [ref=e87]:
          - button "System Health" [ref=e88] [cursor=pointer]
          - button "Einstellungen" [ref=e93] [cursor=pointer]
        - generic [ref=e101]:
          - strong [ref=e102]: Research. Mit Klarheit.
          - generic [ref=e103]: Öffentliche Daten.Nachvollziehbare Evidenz.
        - generic [ref=e104]:
          - generic [ref=e105]: SMARTLAB NEXUS
          - generic [ref=e106]: v1.0
    - generic [ref=e107]:
      - banner [ref=e108]:
        - generic [ref=e109]:
          - generic [ref=e110]: Workspace
          - strong [ref=e113]: Command Dashboard
        - generic [ref=e114]:
          - textbox "Token, Symbol oder Mint-Adresse suchen" [ref=e118]
          - generic [ref=e119]: ⌘ K
        - generic [ref=e120]:
          - generic [ref=e121]:
            - generic [ref=e122]: ≋
            - text: Solana
            - generic [ref=e123]: Mainnet
          - button "Alert-Posteingang" [ref=e124] [cursor=pointer]
          - generic [ref=e128]: R
      - main [ref=e129]:
        - generic [ref=e130]:
          - generic [ref=e131]:
            - generic [ref=e132]: SOLANA TOKEN INTELLIGENCE
            - heading "Command Dashboard" [level=1] [ref=e135]: Command Dashboard.
            - paragraph [ref=e136]: Quellen verstehen. Neue Funde prüfen. Den Datenstand einordnen.
          - generic [ref=e137]:
            - generic [ref=e138]: Degradierter Modus
            - generic [ref=e140]: Update 12m
        - status [ref=e146]:
          - strong [ref=e147]: ISOLIERTE TESTDATEN · keine aktuellen Marktdaten
        - generic [ref=e148]:
          - generic [ref=e149]:
            - generic [ref=e150]:
              - text: 01 / RESEARCH OPERATIONS
              - heading "Erfassen. Prüfen. Einordnen." [level=2] [ref=e151]
              - paragraph [ref=e152]: Solana Research Workspace · Read-onlyQuellen, Frische und Risiko gemeinsam im Blick.
              - button "Token Radar öffnen" [ref=e153] [cursor=pointer]
            - generic [ref=e157]:
              - generic [ref=e158]:
                - generic [ref=e165]: ERFASSUNG IM BLICK
                - generic [ref=e166]: Teilabdeckung
              - generic [ref=e167]:
                - text: "240"
                - generic [ref=e168]: beobachtete Pools
              - generic [ref=e169]:
                - generic [ref=e170]:
                  - strong [ref=e171]: 0.0 %
                  - text: frisch · geladene Auswahl
                - generic "Gemessener Server-Publish bis UI; kein Markt-SLA" [ref=e172]:
                  - strong [ref=e173]: Unbekannt
                  - generic [ref=e174]: UI-Latenz p95 · 0 Proben
          - generic [ref=e175]:
            - generic "Offene Onchain-Kandidaten" [ref=e176]:
              - generic [ref=e177]: "01"
              - generic [ref=e178]:
                - generic [ref=e179]: In Prüfung
                - strong [ref=e180]: "0"
            - generic "Wartealter des ältesten offenen Kandidaten" [ref=e183]:
              - generic [ref=e184]: "02"
              - generic [ref=e185]:
                - generic [ref=e186]: Ältester Fund
                - strong [ref=e187]: Unbekannt
            - generic "Dauerhaft fehlerhafte Kandidaten mit Diagnose" [ref=e190]:
              - generic [ref=e191]: "03"
              - generic [ref=e192]:
                - generic [ref=e193]: Ausgesetzt
                - strong [ref=e194]: "0"
            - generic "Versuche im letzten 5-Minuten-Fenster" [ref=e197]:
              - generic [ref=e198]: "04"
              - generic [ref=e199]:
                - generic [ref=e200]: Prüfungen / Min.
                - strong [ref=e201]: "0.0"
          - generic [ref=e202]:
            - generic [ref=e203]:
              - heading "Research-Blotter" [level=3] [ref=e204]
              - button "Alle Pools im Radar" [ref=e205] [cursor=pointer]
            - generic [aria-hidden] [ref=e209]:
              - generic [ref=e210]: Token / Pool
              - generic [ref=e211]: Entdeckt
              - generic [ref=e212]: Preis
              - generic [ref=e213]: Liquidität
              - generic [ref=e214]: Risiko / Frische
            - generic [ref=e215]:
              - button "QA0 analysieren" [ref=e216] [cursor=pointer]:
                - generic [ref=e217]:
                  - generic [aria-hidden] [ref=e218]: QA
                  - generic [ref=e219]:
                    - strong [ref=e220]: QA0
                    - generic "Isolierter QA Token 00000" [ref=e221]
                    - generic [ref=e222]: 1113kJ…xJusn2 · GeckoTerminal
                - generic "2026-10-24T08:29:25.183Z" [ref=e223]: 12m
                - generic [ref=e224]: $1
                - generic [ref=e225]: $1,000
                - generic [ref=e226]:
                  - generic [ref=e227]: Unbekannt
                  - generic [ref=e228]: Veraltet · 12m
              - button "QA1 analysieren" [ref=e229] [cursor=pointer]:
                - generic [ref=e230]:
                  - generic [aria-hidden] [ref=e231]: QA
                  - generic [ref=e232]:
                    - strong [ref=e233]: QA1
                    - generic "Isolierter QA Token 00001" [ref=e234]
                    - generic [ref=e235]: 1116P2…4tSHbY · GeckoTerminal
                - generic "2026-10-24T08:29:24.183Z" [ref=e236]: 12m
                - generic [ref=e237]: $1
                - generic [ref=e238]: $1,100
                - generic [ref=e239]:
                  - generic [ref=e240]: Unbekannt
                  - generic [ref=e241]: Veraltet · 12m
              - button "QA2 analysieren" [ref=e242] [cursor=pointer]:
                - generic [ref=e243]:
                  - generic [aria-hidden] [ref=e244]: QA
                  - generic [ref=e245]:
                    - strong [ref=e246]: QA2
                    - generic "Isolierter QA Token 00002" [ref=e247]
                    - generic [ref=e248]: 11191j…BTxhR4 · GeckoTerminal
                - generic "2026-10-24T08:29:23.183Z" [ref=e249]: 12m
                - generic [ref=e250]: $1
                - generic [ref=e251]: $1,200
                - generic [ref=e252]:
                  - generic [ref=e253]: Unbekannt
                  - generic [ref=e254]: Veraltet · 12m
              - button "QA3 analysieren" [ref=e255] [cursor=pointer]:
                - generic [ref=e256]:
                  - generic [aria-hidden] [ref=e257]: QA
                  - generic [ref=e258]:
                    - strong [ref=e259]: QA3
                    - generic "Isolierter QA Token 00003" [ref=e260]
                    - generic [ref=e261]: 111BeT…J3V7Ea · GeckoTerminal
                - generic "2026-10-24T08:29:22.183Z" [ref=e262]: 12m
                - generic [ref=e263]: $1
                - generic [ref=e264]: $1,300
                - generic [ref=e265]:
                  - generic [ref=e266]: Unbekannt
                  - generic [ref=e267]: Veraltet · 12m
              - button "QA4 analysieren" [ref=e268] [cursor=pointer]:
                - generic [ref=e269]:
                  - generic [aria-hidden] [ref=e270]: QA
                  - generic [ref=e271]:
                    - strong [ref=e272]: QA4
                    - generic "Isolierter QA Token 00004" [ref=e273]
                    - generic [ref=e274]: 111EHA…Qd1X46 · GeckoTerminal
                - generic "2026-10-24T08:29:21.183Z" [ref=e275]: 12m
                - generic [ref=e276]: $1
                - generic [ref=e277]: $1,400
                - generic [ref=e278]:
                  - generic [ref=e279]: Unbekannt
                  - generic [ref=e280]: Veraltet · 12m
              - button "QA5 analysieren" [ref=e281] [cursor=pointer]:
                - generic [ref=e282]:
                  - generic [aria-hidden] [ref=e283]: QA
                  - generic [ref=e284]:
                    - strong [ref=e285]: QA5
                    - generic "Isolierter QA Token 00005" [ref=e286]
                    - generic [ref=e287]: 111Gut…XCXvsc · GeckoTerminal
                - generic "2026-10-24T08:29:20.183Z" [ref=e288]: 12m
                - generic [ref=e289]: $1.01
                - generic [ref=e290]: $1,500
                - generic [ref=e291]:
                  - generic [ref=e292]: Unbekannt
                  - generic [ref=e293]: Veraltet · 12m
          - generic [ref=e294]:
            - generic [ref=e295]:
              - generic [ref=e296]:
                - heading "Quellenlage" [level=3] [ref=e297]
                - button "Diagnose" [ref=e298] [cursor=pointer]
              - generic [ref=e302]:
                - generic [ref=e303]:
                  - generic [ref=e304]: G
                  - generic [ref=e305]:
                    - strong [ref=e306]: GeckoTerminal
                    - generic [ref=e307]: Noch keine bestätigte Antwort
                  - generic [ref=e308]: Eingeschränkt
                - generic [ref=e309]:
                  - generic [ref=e310]: D
                  - generic [ref=e311]:
                    - strong [ref=e312]: DexScreener
                    - generic [ref=e313]: Noch keine bestätigte Antwort
                  - generic [ref=e314]: Eingeschränkt
                - generic [ref=e315]:
                  - generic [ref=e316]: S
                  - generic [ref=e317]:
                    - strong [ref=e318]: Solana RPC
                    - generic [ref=e319]: Noch keine bestätigte Antwort
                  - generic [ref=e320]: Eingeschränkt
              - paragraph [ref=e321]: HTTP-Stand ist keine bestätigte Markt-Messzeit. Quellen können abweichen oder verzögert sein.
            - generic [ref=e322]:
              - heading "Daten vor Interpretation" [level=3] [ref=e324]
              - generic [ref=e328]:
                - text: QUALITY FIRST
                - heading "Was wissen wir wirklich?" [level=3] [ref=e329]
                - paragraph [ref=e330]: Feldabdeckung, veraltete Daten und Quellenstörungen bilden die Grundlage jeder Analyse. Fehlende Evidenz bleibt unbekannt.
                - button "Datenqualität öffnen" [ref=e331] [cursor=pointer]
          - generic [ref=e335]:
            - generic [ref=e336]:
              - heading "Beobachtete Marktänderungen" [level=3] [ref=e337]
              - generic [ref=e338]: 5m · geladene Auswahl
            - paragraph [ref=e339]: Gemeldete Preisbewegungen der aktuellen Scannerseite. Reihenfolge nach absoluter Änderung, ohne Prognose.
            - generic [ref=e340]:
              - button "QA0 1113…Nm22 -43,65% GeckoTerminal · 12m Unbekannt" [ref=e341] [cursor=pointer]:
                - generic [ref=e342]:
                  - generic [aria-hidden] [ref=e343]: QA
                  - generic [ref=e344]:
                    - strong [ref=e345]: QA0
                    - generic [ref=e346]: 1113…Nm22
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e350]': "-43,65%"
                - generic [ref=e351]: GeckoTerminal · 12m
                - generic [ref=e352]: Unbekannt
              - button "QA1 1116…uAqY -43,65% GeckoTerminal · 12m Unbekannt" [ref=e353] [cursor=pointer]:
                - generic [ref=e354]:
                  - generic [aria-hidden] [ref=e355]: QA
                  - generic [ref=e356]:
                    - strong [ref=e357]: QA1
                    - generic [ref=e358]: 1116…uAqY
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e362]': "-43,65%"
                - generic [ref=e363]: GeckoTerminal · 12m
                - generic [ref=e364]: Unbekannt
              - button "QA2 1119…Raf4 -43,65% GeckoTerminal · 12m Unbekannt" [ref=e365] [cursor=pointer]:
                - generic [ref=e366]:
                  - generic [aria-hidden] [ref=e367]: QA
                  - generic [ref=e368]:
                    - strong [ref=e369]: QA2
                    - generic [ref=e370]: 1119…Raf4
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e374]': "-43,65%"
                - generic [ref=e375]: GeckoTerminal · 12m
                - generic [ref=e376]: Unbekannt
              - button "QA3 111B…wzUa -43,65% GeckoTerminal · 12m Unbekannt" [ref=e377] [cursor=pointer]:
                - generic [ref=e378]:
                  - generic [aria-hidden] [ref=e379]: QA
                  - generic [ref=e380]:
                    - strong [ref=e381]: QA3
                    - generic [ref=e382]: 111B…wzUa
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e386]': "-43,65%"
                - generic [ref=e387]: GeckoTerminal · 12m
                - generic [ref=e388]: Unbekannt
          - generic [ref=e389]:
            - heading "Zuerst entdeckt · anschließend angereichert" [level=3] [ref=e391]
            - paragraph [ref=e392]: Öffentliche Profil-/Poolfeeds. „Entdeckt“ bezeichnet unsere erste Beobachtung, keine bestätigte Mint-Erstellung.
            - paragraph [ref=e393]: Noch keine unabhängigen Entdeckungen in diesem Bestand.
        - generic [ref=e394]:
          - generic [ref=e395]:
            - text: READ-ONLY RESEARCH
            - generic [ref=e400]: /
            - text: Datenqualität ist kein Sicherheitsnachweis.
          - generic [ref=e401]:
            - text: 24.10., 08:41:37 UTC
            - generic [ref=e402]: ·
            - text: Quellenstand je Wert sichtbar
  - alert [ref=e403]
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { expect, test } from "@playwright/test";
  3   | 
  4   | for (const [view, heading] of [
  5   |   ["scanner", "Live Scanner"],
  6   |   ["command", /Command/],
  7   |   ["watchlists", "Watchlists"],
  8   |   ["health", "System Health"],
  9   |   ["quality", "Datenqualität"],
  10  | ] as const) {
  11  |   test(`${view} exposes labels, landmarks and sufficient text contrast`, async ({
  12  |     page,
  13  |   }, info) => {
  14  |     await page.goto(view === "scanner" ? "/" : `/?view=${view}`);
  15  |     await expect(page.getByRole("main")).toBeVisible();
  16  |     await expect(
  17  |       page.getByRole("heading", {
  18  |         name: heading,
  19  |         exact: typeof heading === "string",
  20  |       }),
  21  |     ).toBeVisible();
  22  |     if (view === "scanner")
  23  |       await page.getByTestId("pool-row").first().waitFor();
  24  |     if (view === "quality")
  25  |       await expect(
  26  |         page.getByText("Feldabdeckung", { exact: true }),
  27  |       ).toBeVisible();
  28  |     const report = await new AxeBuilder({ page })
  29  |       .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  30  |       .analyze();
  31  |     await info.attach(`axe-${view}`, {
  32  |       body: JSON.stringify(report, null, 2),
  33  |       contentType: "application/json",
  34  |     });
  35  |     expect(
  36  |       report.violations.map(({ id, nodes }) => ({
  37  |         id,
  38  |         targets: nodes.map(({ target }) => target),
  39  |       })),
  40  |       view,
> 41  |     ).toEqual([]);
      |       ^ Error: command
  42  |   });
  43  | }
  44  | 
  45  | test("token intelligence exposes labels, landmarks and sufficient text contrast", async ({
  46  |   page,
  47  | }, info) => {
  48  |   const response = await page.request.get("/api/pools?page=1&pageSize=1");
  49  |   expect(response.ok()).toBe(true);
  50  |   const { rows } = await response.json();
  51  |   expect(rows).toHaveLength(1);
  52  |   const chosen = rows[0];
  53  |   await Promise.all([
  54  |     page.waitForResponse(
  55  |       (result) =>
  56  |         result.url().includes(`/api/candles/${chosen.poolId}/`) && result.ok(),
  57  |     ),
  58  |     page.goto(
  59  |       "/?" +
  60  |         new URLSearchParams({
  61  |           view: "token",
  62  |           mint: chosen.mint,
  63  |           pool: chosen.poolId,
  64  |         }),
  65  |     ),
  66  |   ]);
  67  |   await expect(
  68  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  69  |   ).toBeVisible();
  70  |   await expect(page.locator(".detail-token h2")).toHaveText(chosen.name);
  71  |   const report = await new AxeBuilder({ page })
  72  |     .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  73  |     .analyze();
  74  |   await info.attach("axe-token-intelligence", {
  75  |     body: JSON.stringify(report, null, 2),
  76  |     contentType: "application/json",
  77  |   });
  78  |   expect(
  79  |     report.violations.map(({ id, nodes }) => ({
  80  |       id,
  81  |       targets: nodes.map(({ target }) => target),
  82  |     })),
  83  |   ).toEqual([]);
  84  | });
  85  | 
  86  | test("scanner filters support keyboard focus, Escape and reduced motion", async ({
  87  |   page,
  88  | }) => {
  89  |   await page.emulateMedia({ reducedMotion: "reduce" });
  90  |   await page.goto("/");
  91  |   await page.getByTestId("pool-row").first().waitFor();
  92  |   if (process.env.NEXUS_TEST_MODE === "true")
  93  |     await expect(page.getByTestId("test-mode-banner")).toBeVisible();
  94  |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  95  |   await trigger.focus();
  96  |   await page.keyboard.press("Enter");
  97  |   const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  98  |   await expect(dialog).toBeVisible();
  99  |   await expect(dialog.locator(":focus")).toHaveCount(1);
  100 |   await page.keyboard.press("Tab");
  101 |   expect(
  102 |     await page.evaluate(
  103 |       () => document.activeElement?.closest('[role="dialog"]') !== null,
  104 |     ),
  105 |   ).toBe(true);
  106 |   await page.keyboard.press("Escape");
  107 |   await expect(dialog).toHaveCount(0);
  108 |   await expect(trigger).toBeFocused();
  109 |   expect(
  110 |     await page.evaluate(
  111 |       () => matchMedia("(prefers-reduced-motion: reduce)").matches,
  112 |     ),
  113 |   ).toBe(true);
  114 | });
  115 | 
  116 | test("mobile research controls meet WCAG 2.2 minimum target size", async ({
  117 |   page,
  118 | }, info) => {
  119 |   test.skip(
  120 |     info.project.name !== "mobile",
  121 |     "Touch target check uses the mobile project viewport.",
  122 |   );
  123 |   await page.goto("/");
  124 |   await page.getByTestId("pool-row").first().waitFor();
  125 |   await expect(
  126 |     page.getByRole("button", { name: "Navigation öffnen", exact: true }),
  127 |   ).toBeVisible();
  128 |   await expect(
  129 |     page.getByRole("navigation", { name: "Mobile Research-Navigation" }),
  130 |   ).toBeVisible();
  131 |   const targets: {
  132 |     name: string | null | undefined;
  133 |     width: number;
  134 |     height: number;
  135 |     stage: string;
  136 |   }[] = [];
  137 |   const sample = async (stage: string) =>
  138 |     targets.push(
  139 |       ...(
  140 |         await page
  141 |           .locator('button,a[href],input,select,summary,[role="button"]')
```