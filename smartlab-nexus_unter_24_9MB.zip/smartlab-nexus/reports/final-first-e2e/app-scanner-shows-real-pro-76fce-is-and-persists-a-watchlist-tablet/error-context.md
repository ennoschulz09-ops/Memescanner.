# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app.spec.ts >> scanner shows real provenance, opens analysis and persists a watchlist
- Location: tests/e2e/app.spec.ts:9:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('pool-row').first()
Expected pattern: /HTTP|Abruf|Cache/
Received string:  "QAQA0Isolierter QA Token 000001113…Nm22·Veraltet 11m22h$1$1,000$0-43,65%Unbekannt30/100"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByTestId('pool-row').first() with timeout 5000ms
  - waiting for getByTestId('pool-row').first()
    14 × locator resolved to <div role="row" tabindex="0" data-revision="1" aria-selected="true" data-testid="pool-row" class="pool-row selected stale-row" data-pool-id="1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22:1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2">…</div>
       - unexpected value "QAQA0Isolierter QA Token 000001113…Nm22·Veraltet 11m22h$1$1,000$0-43,65%Unbekannt30/100"

```

```yaml
- row "QA0 Zur Watchlist hinzufügen QA0 Isolierter QA Token 00000 1113…Nm22 · Veraltet 11m 22h $1 $1,000 $0 -43,65% Unbekannt 30/100" [selected]:
  - cell "QA0 Zur Watchlist hinzufügen QA0 Isolierter QA Token 00000 1113…Nm22 · Veraltet 11m":
    - button "QA0 Zur Watchlist hinzufügen":
      - img
    - strong: QA0
    - text: Isolierter QA Token 00000 1113…Nm22 · Veraltet 11m
  - cell "22h"
  - cell "$1"
  - cell "$1,000"
  - cell "$0"
  - cell "-43,65%"
  - cell "Unbekannt"
  - cell "30/100"
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | test("has no browser runtime or hydration errors", async ({ page }) => {
  3   |   const errors: string[] = [];
  4   |   page.on("pageerror", (e) => errors.push(e.message));
  5   |   await page.goto("/");
  6   |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  7   |   expect(errors).toEqual([]);
  8   | });
  9   | test("scanner shows real provenance, opens analysis and persists a watchlist", async ({
  10  |   page,
  11  | }, info) => {
  12  |   await page.goto("/");
  13  |   await expect(
  14  |     page.getByRole("heading", { name: "Live Scanner", exact: true }),
  15  |   ).toBeVisible();
  16  |   await expect(page.getByTestId("pool-row").first()).toBeVisible({
  17  |     timeout: 20000,
  18  |   });
  19  |   const row = page.getByTestId("pool-row").first();
> 20  |   await expect(row).toContainText(/HTTP|Abruf|Cache/);
      |                     ^ Error: expect(locator).toContainText(expected) failed
  21  |   await row.getByRole("button", { name: /Zur Watchlist/ }).click();
  22  |   await page.reload();
  23  |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  24  |   if (info.project.name === "mobile")
  25  |     await page.getByRole("button", { name: "Navigation öffnen" }).click();
  26  |   await page
  27  |     .getByRole("button", { name: "Watchlists", exact: true })
  28  |     .first()
  29  |     .click();
  30  |   await expect(
  31  |     page.getByRole("heading", { name: "Watchlists", exact: true }),
  32  |   ).toBeVisible();
  33  |   await expect(
  34  |     page.getByText("Meine Watchlist", { exact: true }).last(),
  35  |   ).toBeVisible();
  36  |   await page
  37  |     .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
  38  |     .fill("no-watchlist-match-92371");
  39  |   await expect(
  40  |     page.getByText("Keine Treffer in dieser Watchlist"),
  41  |   ).toBeVisible();
  42  |   await expect(page.getByTestId("watchlist-token")).toHaveCount(0);
  43  |   await page
  44  |     .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
  45  |     .fill("");
  46  |   await page.getByTestId("watchlist-token").first().click();
  47  |   await expect(
  48  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  49  |   ).toBeVisible();
  50  |   await expect(page.getByText("Datenherkunft", { exact: true })).toBeVisible();
  51  | });
  52  | test("filters, column selection and empty states work", async ({ page }) => {
  53  |   await page.goto("/");
  54  |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  55  |   await page
  56  |     .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
  57  |     .fill("unfindable-token-xyz-293");
  58  |   await expect(page.getByText("Keine passenden Pools")).toBeVisible();
  59  |   await page
  60  |     .getByRole("main")
  61  |     .getByRole("button", { name: "Suche zurücksetzen" })
  62  |     .click();
  63  |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  64  |   await page.locator('summary[aria-label="Spalten auswählen"]').click();
  65  |   await page.getByLabel("FDV", { exact: true }).check();
  66  |   await expect(
  67  |     page.getByRole("columnheader", { name: "FDV", exact: true }),
  68  |   ).toHaveCount(1);
  69  |   await page.getByLabel("FDV", { exact: true }).uncheck();
  70  |   await page.locator('summary[aria-label="Spalten auswählen"]').click();
  71  |   await expect(
  72  |     page.getByRole("columnheader", { name: "FDV", exact: true }),
  73  |   ).toHaveCount(0);
  74  | });
  75  | test("all research views render and fit their viewport", async ({
  76  |   page,
  77  | }, info) => {
  78  |   for (const [view, heading] of [
  79  |     ["discovery", "Discovery"],
  80  |     ["risk", "Risk Lab"],
  81  |     ["wallet", "Wallet Explorer"],
  82  |     ["watchlists", "Watchlists"],
  83  |     ["alerts", "Alerts"],
  84  |     ["analytics", "Analytics"],
  85  |     ["health", "System Health"],
  86  |     ["settings", "Einstellungen"],
  87  |   ]) {
  88  |     await page.goto("/?view=" + view);
  89  |     await expect(
  90  |       page.getByRole("heading", { name: heading, exact: true }),
  91  |     ).toBeVisible();
  92  |     await expect(page.getByTestId("virtual-table")).toHaveCount(0);
  93  |     if (info.project.name === "mobile")
  94  |       expect(
  95  |         await page.evaluate(
  96  |           () => document.documentElement.scrollWidth <= innerWidth,
  97  |         ),
  98  |         view,
  99  |       ).toBe(true);
  100 |   }
  101 | });
  102 | test("saves a filter preset and persists a compact terminal preference", async ({
  103 |   page,
  104 | }) => {
  105 |   await page.goto("/");
  106 |   await expect(page.getByTestId("pool-row").first()).toBeVisible();
  107 |   await page.getByRole("button", { name: "Filter", exact: true }).click();
  108 |   await page.getByLabel("Min. Liquidität (USD)", { exact: true }).fill("100");
  109 |   await page.getByRole("button", { name: "Als Preset speichern" }).click();
  110 |   await page
  111 |     .getByRole("textbox", { name: "Preset-Name" })
  112 |     .fill("Mein Recherchefilter");
  113 |   await page.getByRole("button", { name: "Speichern", exact: true }).click();
  114 |   await expect(
  115 |     page.getByRole("button", { name: "Mein Recherchefilter", exact: true }),
  116 |   ).toBeVisible();
  117 |   await page.goto("/?view=settings");
  118 |   await expect(
  119 |     page.getByRole("switch", { name: "Kompakte Tabelle" }),
  120 |   ).toBeVisible();
```