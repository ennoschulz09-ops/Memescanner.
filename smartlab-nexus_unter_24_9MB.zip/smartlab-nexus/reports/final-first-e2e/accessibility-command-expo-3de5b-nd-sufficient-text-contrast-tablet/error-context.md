# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> command exposes labels, landmarks and sufficient text contrast
- Location: tests/e2e/accessibility.spec.ts:11:3

# Error details

```
Error: command

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 25

- Array []
+ Array [
+   Object {
+     "id": "label-content-name-mismatch",
+     "targets": Array [
+       Array [
+         "button[aria-label=\"QA0 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA1 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA2 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA3 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA4 analysieren\"]",
+       ],
+       Array [
+         "button[aria-label=\"QA5 analysieren\"]",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Zum Research-Inhalt" [ref=e3] [cursor=pointer]:
      - /url: "#research-main"
    - complementary [ref=e4]:
      - generic [ref=e10]:
        - strong [ref=e11]: SMARTLAB
        - generic [ref=e12]: NEXUS / 01
      - button "S Research Workspace Solana Mainnet" [ref=e13] [cursor=pointer]:
        - generic [ref=e14]: S
        - generic [ref=e15]:
          - strong [ref=e16]: Research Workspace
          - generic [ref=e17]: Solana Mainnet
      - generic [ref=e20]: ENTDECKEN & ANALYSIEREN
      - navigation "Hauptnavigation" [ref=e21]:
        - button "Command Dashboard" [ref=e22] [cursor=pointer]
        - button "Discovery" [ref=e29] [cursor=pointer]
        - button "Live Scanner" [ref=e34] [cursor=pointer]
        - button "Token-Analyse" [ref=e43] [cursor=pointer]
        - button "Risk Lab" [ref=e50] [cursor=pointer]
        - button "Wallet Explorer" [ref=e55] [cursor=pointer]
        - generic [ref=e60]: DEIN RESEARCH
        - button "Watchlists" [ref=e61] [cursor=pointer]
        - button "Alerts" [ref=e65] [cursor=pointer]
        - button "Analytics" [ref=e70] [cursor=pointer]
        - button "Datenqualität" [ref=e74] [cursor=pointer]
      - generic [ref=e80]:
        - generic [ref=e81]:
          - generic [ref=e82]: WATCHLISTS
          - button "Watchlist erstellen" [ref=e83] [cursor=pointer]
        - paragraph [ref=e85]: Dein nächster Fundbeginnt im Scanner.
      - generic [ref=e86]:
        - generic [ref=e87]:
          - button "System Health" [ref=e88] [cursor=pointer]
          - button "Einstellungen" [ref=e93] [cursor=pointer]
        - generic [ref=e101]:
          - strong [ref=e102]: Research. Mit Klarheit.
          - generic [ref=e103]: Öffentliche Daten.Nachvollziehbare Evidenz.
        - generic [ref=e104]:
          - generic [ref=e105]: SMARTLAB NEXUS
          - generic [ref=e106]: v1.0
    - generic [ref=e107]:
      - banner [ref=e108]:
        - strong [ref=e110]: Command Dashboard
        - textbox "Token, Symbol oder Mint-Adresse suchen" [ref=e115]
        - generic [ref=e116]:
          - generic [ref=e117]:
            - generic [ref=e118]: ≋
            - text: Solana
          - button "Alert-Posteingang" [ref=e119] [cursor=pointer]
          - generic [ref=e123]: R
      - main [ref=e124]:
        - generic [ref=e125]:
          - generic [ref=e126]:
            - generic [ref=e127]: SOLANA TOKEN INTELLIGENCE
            - heading "Command Dashboard" [level=1] [ref=e130]: Command Dashboard.
            - paragraph [ref=e131]: Quellen verstehen. Neue Funde prüfen. Den Datenstand einordnen.
          - generic [ref=e132]:
            - generic [ref=e133]: Degradierter Modus
            - generic [ref=e135]: Update 10m
        - status [ref=e141]:
          - strong [ref=e142]: ISOLIERTE TESTDATEN · keine aktuellen Marktdaten
        - generic [ref=e143]:
          - generic [ref=e144]:
            - generic [ref=e145]:
              - text: 01 / RESEARCH OPERATIONS
              - heading "Erfassen. Prüfen. Einordnen." [level=2] [ref=e146]
              - paragraph [ref=e147]: Solana Research Workspace · Read-onlyQuellen, Frische und Risiko gemeinsam im Blick.
              - button "Token Radar öffnen" [ref=e148] [cursor=pointer]
            - generic [ref=e152]:
              - generic [ref=e153]:
                - generic [ref=e160]: ERFASSUNG IM BLICK
                - generic [ref=e161]: Teilabdeckung
              - generic [ref=e162]:
                - text: "240"
                - generic [ref=e163]: beobachtete Pools
              - generic [ref=e164]:
                - generic [ref=e165]:
                  - strong [ref=e166]: 0.0 %
                  - text: frisch · geladene Auswahl
                - generic "Gemessener Server-Publish bis UI; kein Markt-SLA" [ref=e167]:
                  - strong [ref=e168]: Unbekannt
                  - generic [ref=e169]: UI-Latenz p95 · 0 Proben
          - generic [ref=e170]:
            - generic "Offene Onchain-Kandidaten" [ref=e171]:
              - generic [ref=e172]: "01"
              - generic [ref=e173]:
                - generic [ref=e174]: In Prüfung
                - strong [ref=e175]: "0"
            - generic "Wartealter des ältesten offenen Kandidaten" [ref=e176]:
              - generic [ref=e177]: "02"
              - generic [ref=e178]:
                - generic [ref=e179]: Ältester Fund
                - strong [ref=e180]: Unbekannt
            - generic "Dauerhaft fehlerhafte Kandidaten mit Diagnose" [ref=e181]:
              - generic [ref=e182]: "03"
              - generic [ref=e183]:
                - generic [ref=e184]: Ausgesetzt
                - strong [ref=e185]: "0"
            - generic "Versuche im letzten 5-Minuten-Fenster" [ref=e186]:
              - generic [ref=e187]: "04"
              - generic [ref=e188]:
                - generic [ref=e189]: Prüfungen / Min.
                - strong [ref=e190]: "0.0"
          - generic [ref=e191]:
            - generic [ref=e192]:
              - heading "Research-Blotter" [level=3] [ref=e193]
              - button "Alle Pools im Radar" [ref=e194] [cursor=pointer]
            - generic [aria-hidden] [ref=e198]:
              - generic [ref=e199]: Token / Pool
              - generic [ref=e200]: Entdeckt
              - generic [ref=e201]: Preis
              - generic [ref=e202]: Liquidität
              - generic [ref=e203]: Risiko / Frische
            - generic [ref=e204]:
              - button "QA0 analysieren" [ref=e205] [cursor=pointer]:
                - generic [ref=e206]:
                  - generic [aria-hidden] [ref=e207]: QA
                  - generic [ref=e208]:
                    - strong [ref=e209]: QA0
                    - generic "Isolierter QA Token 00000" [ref=e210]
                    - generic [ref=e211]: 1113kJ…xJusn2 · GeckoTerminal
                - generic "2026-10-24T08:29:25.183Z" [ref=e212]: 10m
                - generic [ref=e213]: $1
                - generic [ref=e214]: $1,000
                - generic [ref=e215]:
                  - generic [ref=e216]: Unbekannt
                  - generic [ref=e217]: Veraltet · 10m
              - button "QA1 analysieren" [ref=e218] [cursor=pointer]:
                - generic [ref=e219]:
                  - generic [aria-hidden] [ref=e220]: QA
                  - generic [ref=e221]:
                    - strong [ref=e222]: QA1
                    - generic "Isolierter QA Token 00001" [ref=e223]
                    - generic [ref=e224]: 1116P2…4tSHbY · GeckoTerminal
                - generic "2026-10-24T08:29:24.183Z" [ref=e225]: 10m
                - generic [ref=e226]: $1
                - generic [ref=e227]: $1,100
                - generic [ref=e228]:
                  - generic [ref=e229]: Unbekannt
                  - generic [ref=e230]: Veraltet · 10m
              - button "QA2 analysieren" [ref=e231] [cursor=pointer]:
                - generic [ref=e232]:
                  - generic [aria-hidden] [ref=e233]: QA
                  - generic [ref=e234]:
                    - strong [ref=e235]: QA2
                    - generic "Isolierter QA Token 00002" [ref=e236]
                    - generic [ref=e237]: 11191j…BTxhR4 · GeckoTerminal
                - generic "2026-10-24T08:29:23.183Z" [ref=e238]: 11m
                - generic [ref=e239]: $1
                - generic [ref=e240]: $1,200
                - generic [ref=e241]:
                  - generic [ref=e242]: Unbekannt
                  - generic [ref=e243]: Veraltet · 10m
              - button "QA3 analysieren" [ref=e244] [cursor=pointer]:
                - generic [ref=e245]:
                  - generic [aria-hidden] [ref=e246]: QA
                  - generic [ref=e247]:
                    - strong [ref=e248]: QA3
                    - generic "Isolierter QA Token 00003" [ref=e249]
                    - generic [ref=e250]: 111BeT…J3V7Ea · GeckoTerminal
                - generic "2026-10-24T08:29:22.183Z" [ref=e251]: 11m
                - generic [ref=e252]: $1
                - generic [ref=e253]: $1,300
                - generic [ref=e254]:
                  - generic [ref=e255]: Unbekannt
                  - generic [ref=e256]: Veraltet · 10m
              - button "QA4 analysieren" [ref=e257] [cursor=pointer]:
                - generic [ref=e258]:
                  - generic [aria-hidden] [ref=e259]: QA
                  - generic [ref=e260]:
                    - strong [ref=e261]: QA4
                    - generic "Isolierter QA Token 00004" [ref=e262]
                    - generic [ref=e263]: 111EHA…Qd1X46 · GeckoTerminal
                - generic "2026-10-24T08:29:21.183Z" [ref=e264]: 11m
                - generic [ref=e265]: $1
                - generic [ref=e266]: $1,400
                - generic [ref=e267]:
                  - generic [ref=e268]: Unbekannt
                  - generic [ref=e269]: Veraltet · 10m
              - button "QA5 analysieren" [ref=e270] [cursor=pointer]:
                - generic [ref=e271]:
                  - generic [aria-hidden] [ref=e272]: QA
                  - generic [ref=e273]:
                    - strong [ref=e274]: QA5
                    - generic "Isolierter QA Token 00005" [ref=e275]
                    - generic [ref=e276]: 111Gut…XCXvsc · GeckoTerminal
                - generic "2026-10-24T08:29:20.183Z" [ref=e277]: 11m
                - generic [ref=e278]: $1.01
                - generic [ref=e279]: $1,500
                - generic [ref=e280]:
                  - generic [ref=e281]: Unbekannt
                  - generic [ref=e282]: Veraltet · 10m
          - generic [ref=e283]:
            - generic [ref=e284]:
              - generic [ref=e285]:
                - heading "Quellenlage" [level=3] [ref=e286]
                - button "Diagnose" [ref=e287] [cursor=pointer]
              - generic [ref=e291]:
                - generic [ref=e292]:
                  - generic [ref=e293]: G
                  - generic [ref=e294]:
                    - strong [ref=e295]: GeckoTerminal
                    - generic [ref=e296]: Noch keine bestätigte Antwort
                  - generic [ref=e297]: Eingeschränkt
                - generic [ref=e298]:
                  - generic [ref=e299]: D
                  - generic [ref=e300]:
                    - strong [ref=e301]: DexScreener
                    - generic [ref=e302]: Noch keine bestätigte Antwort
                  - generic [ref=e303]: Eingeschränkt
                - generic [ref=e304]:
                  - generic [ref=e305]: S
                  - generic [ref=e306]:
                    - strong [ref=e307]: Solana RPC
                    - generic [ref=e308]: Noch keine bestätigte Antwort
                  - generic [ref=e309]: Eingeschränkt
              - paragraph [ref=e310]: HTTP-Stand ist keine bestätigte Markt-Messzeit. Quellen können abweichen oder verzögert sein.
            - generic [ref=e311]:
              - heading "Daten vor Interpretation" [level=3] [ref=e313]
              - generic [ref=e317]:
                - text: QUALITY FIRST
                - heading "Was wissen wir wirklich?" [level=3] [ref=e318]
                - paragraph [ref=e319]: Feldabdeckung, veraltete Daten und Quellenstörungen bilden die Grundlage jeder Analyse. Fehlende Evidenz bleibt unbekannt.
                - button "Datenqualität öffnen" [ref=e320] [cursor=pointer]
          - generic [ref=e324]:
            - generic [ref=e325]:
              - heading "Beobachtete Marktänderungen" [level=3] [ref=e326]
              - generic [ref=e327]: 5m · geladene Auswahl
            - paragraph [ref=e328]: Gemeldete Preisbewegungen der aktuellen Scannerseite. Reihenfolge nach absoluter Änderung, ohne Prognose.
            - generic [ref=e329]:
              - button "QA0 1113…Nm22 -43,65% GeckoTerminal · 10m Unbekannt" [ref=e330] [cursor=pointer]:
                - generic [ref=e331]:
                  - generic [aria-hidden] [ref=e332]: QA
                  - generic [ref=e333]:
                    - strong [ref=e334]: QA0
                    - generic [ref=e335]: 1113…Nm22
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e339]': "-43,65%"
                - generic [ref=e340]: GeckoTerminal · 10m
                - generic [ref=e341]: Unbekannt
              - button "QA1 1116…uAqY -43,65% GeckoTerminal · 10m Unbekannt" [ref=e342] [cursor=pointer]:
                - generic [ref=e343]:
                  - generic [aria-hidden] [ref=e344]: QA
                  - generic [ref=e345]:
                    - strong [ref=e346]: QA1
                    - generic [ref=e347]: 1116…uAqY
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e351]': "-43,65%"
                - generic [ref=e352]: GeckoTerminal · 10m
                - generic [ref=e353]: Unbekannt
              - button "QA2 1119…Raf4 -43,65% GeckoTerminal · 10m Unbekannt" [ref=e354] [cursor=pointer]:
                - generic [ref=e355]:
                  - generic [aria-hidden] [ref=e356]: QA
                  - generic [ref=e357]:
                    - strong [ref=e358]: QA2
                    - generic [ref=e359]: 1119…Raf4
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e363]': "-43,65%"
                - generic [ref=e364]: GeckoTerminal · 10m
                - generic [ref=e365]: Unbekannt
              - button "QA3 111B…wzUa -43,65% GeckoTerminal · 10m Unbekannt" [ref=e366] [cursor=pointer]:
                - generic [ref=e367]:
                  - generic [aria-hidden] [ref=e368]: QA
                  - generic [ref=e369]:
                    - strong [ref=e370]: QA3
                    - generic [ref=e371]: 111B…wzUa
                - 'generic "STALE · Quelle: gecko · Messzeit: unbekannt · HTTP-Stand: 2026-10-24T08:29:25.183Z · Abruf: 2026-10-24T08:29:25.183Z · Abdeckung: partial" [ref=e375]': "-43,65%"
                - generic [ref=e376]: GeckoTerminal · 10m
                - generic [ref=e377]: Unbekannt
          - generic [ref=e378]:
            - heading "Zuerst entdeckt · anschließend angereichert" [level=3] [ref=e380]
            - paragraph [ref=e381]: Öffentliche Profil-/Poolfeeds. „Entdeckt“ bezeichnet unsere erste Beobachtung, keine bestätigte Mint-Erstellung.
            - paragraph [ref=e382]: Noch keine unabhängigen Entdeckungen in diesem Bestand.
        - generic [ref=e384]:
          - text: READ-ONLY RESEARCH
          - generic [ref=e389]: /
          - text: Datenqualität ist kein Sicherheitsnachweis.
  - alert [ref=e390]
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { expect, test } from "@playwright/test";
  3   | 
  4   | for (const [view, heading] of [
  5   |   ["scanner", "Live Scanner"],
  6   |   ["command", /Command/],
  7   |   ["watchlists", "Watchlists"],
  8   |   ["health", "System Health"],
  9   |   ["quality", "Datenqualität"],
  10  | ] as const) {
  11  |   test(`${view} exposes labels, landmarks and sufficient text contrast`, async ({
  12  |     page,
  13  |   }, info) => {
  14  |     await page.goto(view === "scanner" ? "/" : `/?view=${view}`);
  15  |     await expect(page.getByRole("main")).toBeVisible();
  16  |     await expect(
  17  |       page.getByRole("heading", {
  18  |         name: heading,
  19  |         exact: typeof heading === "string",
  20  |       }),
  21  |     ).toBeVisible();
  22  |     if (view === "scanner")
  23  |       await page.getByTestId("pool-row").first().waitFor();
  24  |     if (view === "quality")
  25  |       await expect(
  26  |         page.getByText("Feldabdeckung", { exact: true }),
  27  |       ).toBeVisible();
  28  |     const report = await new AxeBuilder({ page })
  29  |       .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  30  |       .analyze();
  31  |     await info.attach(`axe-${view}`, {
  32  |       body: JSON.stringify(report, null, 2),
  33  |       contentType: "application/json",
  34  |     });
  35  |     expect(
  36  |       report.violations.map(({ id, nodes }) => ({
  37  |         id,
  38  |         targets: nodes.map(({ target }) => target),
  39  |       })),
  40  |       view,
> 41  |     ).toEqual([]);
      |       ^ Error: command
  42  |   });
  43  | }
  44  | 
  45  | test("token intelligence exposes labels, landmarks and sufficient text contrast", async ({
  46  |   page,
  47  | }, info) => {
  48  |   const response = await page.request.get("/api/pools?page=1&pageSize=1");
  49  |   expect(response.ok()).toBe(true);
  50  |   const { rows } = await response.json();
  51  |   expect(rows).toHaveLength(1);
  52  |   const chosen = rows[0];
  53  |   await Promise.all([
  54  |     page.waitForResponse(
  55  |       (result) =>
  56  |         result.url().includes(`/api/candles/${chosen.poolId}/`) && result.ok(),
  57  |     ),
  58  |     page.goto(
  59  |       "/?" +
  60  |         new URLSearchParams({
  61  |           view: "token",
  62  |           mint: chosen.mint,
  63  |           pool: chosen.poolId,
  64  |         }),
  65  |     ),
  66  |   ]);
  67  |   await expect(
  68  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  69  |   ).toBeVisible();
  70  |   await expect(page.locator(".detail-token h2")).toHaveText(chosen.name);
  71  |   const report = await new AxeBuilder({ page })
  72  |     .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  73  |     .analyze();
  74  |   await info.attach("axe-token-intelligence", {
  75  |     body: JSON.stringify(report, null, 2),
  76  |     contentType: "application/json",
  77  |   });
  78  |   expect(
  79  |     report.violations.map(({ id, nodes }) => ({
  80  |       id,
  81  |       targets: nodes.map(({ target }) => target),
  82  |     })),
  83  |   ).toEqual([]);
  84  | });
  85  | 
  86  | test("scanner filters support keyboard focus, Escape and reduced motion", async ({
  87  |   page,
  88  | }) => {
  89  |   await page.emulateMedia({ reducedMotion: "reduce" });
  90  |   await page.goto("/");
  91  |   await page.getByTestId("pool-row").first().waitFor();
  92  |   if (process.env.NEXUS_TEST_MODE === "true")
  93  |     await expect(page.getByTestId("test-mode-banner")).toBeVisible();
  94  |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  95  |   await trigger.focus();
  96  |   await page.keyboard.press("Enter");
  97  |   const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  98  |   await expect(dialog).toBeVisible();
  99  |   await expect(dialog.locator(":focus")).toHaveCount(1);
  100 |   await page.keyboard.press("Tab");
  101 |   expect(
  102 |     await page.evaluate(
  103 |       () => document.activeElement?.closest('[role="dialog"]') !== null,
  104 |     ),
  105 |   ).toBe(true);
  106 |   await page.keyboard.press("Escape");
  107 |   await expect(dialog).toHaveCount(0);
  108 |   await expect(trigger).toBeFocused();
  109 |   expect(
  110 |     await page.evaluate(
  111 |       () => matchMedia("(prefers-reduced-motion: reduce)").matches,
  112 |     ),
  113 |   ).toBe(true);
  114 | });
  115 | 
  116 | test("mobile research controls meet WCAG 2.2 minimum target size", async ({
  117 |   page,
  118 | }, info) => {
  119 |   test.skip(
  120 |     info.project.name !== "mobile",
  121 |     "Touch target check uses the mobile project viewport.",
  122 |   );
  123 |   await page.goto("/");
  124 |   await page.getByTestId("pool-row").first().waitFor();
  125 |   await expect(
  126 |     page.getByRole("button", { name: "Navigation öffnen", exact: true }),
  127 |   ).toBeVisible();
  128 |   await expect(
  129 |     page.getByRole("navigation", { name: "Mobile Research-Navigation" }),
  130 |   ).toBeVisible();
  131 |   const targets: {
  132 |     name: string | null | undefined;
  133 |     width: number;
  134 |     height: number;
  135 |     stage: string;
  136 |   }[] = [];
  137 |   const sample = async (stage: string) =>
  138 |     targets.push(
  139 |       ...(
  140 |         await page
  141 |           .locator('button,a[href],input,select,summary,[role="button"]')
```