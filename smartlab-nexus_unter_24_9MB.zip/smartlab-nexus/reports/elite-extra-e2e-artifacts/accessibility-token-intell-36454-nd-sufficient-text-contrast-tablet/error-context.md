# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> token intelligence exposes labels, landmarks and sufficient text contrast
- Location: tests/e2e/accessibility.spec.ts:45:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   Object {
+     "id": "scrollable-region-focusable",
+     "targets": Array [
+       Array [
+         ".horizontal-scroll",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Zum Research-Inhalt" [ref=e3] [cursor=pointer]:
      - /url: "#research-main"
    - complementary [ref=e4]:
      - generic [ref=e10]:
        - strong [ref=e11]: SMARTLAB
        - generic [ref=e12]: NEXUS / 01
      - button "S Research Workspace Solana Mainnet" [ref=e13] [cursor=pointer]:
        - generic [ref=e14]: S
        - generic [ref=e15]:
          - strong [ref=e16]: Research Workspace
          - generic [ref=e17]: Solana Mainnet
      - generic [ref=e20]: ENTDECKEN & ANALYSIEREN
      - navigation "Hauptnavigation" [ref=e21]:
        - button "Command Dashboard" [ref=e22] [cursor=pointer]
        - button "Discovery" [ref=e29] [cursor=pointer]
        - button "Live Scanner" [ref=e34] [cursor=pointer]
        - button "Token-Analyse" [ref=e43] [cursor=pointer]
        - button "Risk Lab" [ref=e50] [cursor=pointer]
        - button "Wallet Explorer" [ref=e55] [cursor=pointer]
        - generic [ref=e60]: DEIN RESEARCH
        - button "Watchlists" [ref=e61] [cursor=pointer]
        - button "Alerts" [ref=e65] [cursor=pointer]
        - button "Analytics" [ref=e70] [cursor=pointer]
        - button "Datenqualität" [ref=e74] [cursor=pointer]
      - generic [ref=e80]:
        - generic [ref=e81]:
          - generic [ref=e82]: WATCHLISTS
          - button "Watchlist erstellen" [ref=e83] [cursor=pointer]
        - paragraph [ref=e85]: Dein nächster Fundbeginnt im Scanner.
      - generic [ref=e86]:
        - generic [ref=e87]:
          - button "System Health" [ref=e88] [cursor=pointer]
          - button "Einstellungen" [ref=e93] [cursor=pointer]
        - generic [ref=e101]:
          - strong [ref=e102]: Research. Mit Klarheit.
          - generic [ref=e103]: Öffentliche Daten.Nachvollziehbare Evidenz.
        - generic [ref=e104]:
          - generic [ref=e105]: SMARTLAB NEXUS
          - generic [ref=e106]: v1.0
    - generic [ref=e107]:
      - banner [ref=e108]:
        - strong [ref=e110]: Token-Analyse
        - textbox "Token, Symbol oder Mint-Adresse suchen" [ref=e115]
        - generic [ref=e116]:
          - generic [ref=e117]:
            - generic [ref=e118]: ≋
            - text: Solana
          - button "Alert-Posteingang" [ref=e119] [cursor=pointer]
          - generic [ref=e123]: R
      - main [ref=e124]:
        - generic [ref=e125]:
          - generic [ref=e126]:
            - generic [ref=e127]: SOLANA TOKEN INTELLIGENCE
            - heading "Token-Analyse" [level=1] [ref=e130]: Token-Analyse.
            - paragraph [ref=e131]: Marktdaten, öffentliche Evidenzen und nachvollziehbare Risikoindikatoren.
          - generic [ref=e132]:
            - generic [ref=e133]: Degradierter Modus
            - generic [ref=e135]: Update 10s
        - status [ref=e141]:
          - strong [ref=e142]: ISOLIERTE TESTDATEN · keine aktuellen Marktdaten
        - generic [ref=e143]:
          - generic [ref=e144]:
            - button "Zurück zum Scanner" [ref=e145] [cursor=pointer]
            - generic [ref=e148]: Solana / pump-fun / 1113…usn2
          - generic [ref=e149]:
            - generic [ref=e150]:
              - generic [aria-hidden] [ref=e151]: QA
              - generic [ref=e152]:
                - generic [ref=e153]:
                  - heading "Isolierter QA Token 00000" [level=2] [ref=e154]
                  - generic [ref=e155]: QA0
                - button "1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22 — Contract-Adresse kopieren" [ref=e156] [cursor=pointer]:
                  - generic [ref=e157]: 1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22
            - generic [ref=e161]:
              - strong [ref=e162]: $1
              - generic [ref=e163]: "-43,65% · 5m"
            - generic [ref=e164]:
              - button "Beobachten" [ref=e165] [cursor=pointer]
              - button "Analyse aktualisieren" [ref=e168] [cursor=pointer]
          - generic [ref=e174]:
            - generic [ref=e175]:
              - generic [ref=e176]: Liquidität
              - strong [ref=e177]: $1,000
            - generic [ref=e178]:
              - generic [ref=e179]: Volumen · 24h
              - strong [ref=e180]: $119.6
            - generic [ref=e181]:
              - generic [ref=e182]: Market Cap
              - strong [ref=e183]: Unbekannt
            - generic [ref=e184]:
              - generic [ref=e185]: FDV
              - strong [ref=e186]: $3,544.97
            - generic [ref=e187]:
              - generic [ref=e188]: Poolalter
              - strong [ref=e189]: 21h
          - generic [ref=e191]:
            - generic [ref=e192]:
              - generic [ref=e193]:
                - button "Preis" [ref=e194] [cursor=pointer]
                - button "Volumen" [ref=e195] [cursor=pointer]
                - button "Liquidität" [ref=e196] [cursor=pointer]
                - button "Trades" [ref=e197] [cursor=pointer]
              - generic [ref=e198]:
                - button "1h" [ref=e199] [cursor=pointer]
                - button "24h" [ref=e200] [cursor=pointer]
                - button "7d" [ref=e201] [cursor=pointer]
            - generic [ref=e202]:
              - heading "Noch keine Zeitreihe" [level=3] [ref=e208]
              - paragraph [ref=e209]: Es werden ausschließlich verfügbare Quellenwerte und eigene gespeicherte Beobachtungen dargestellt.
          - generic [ref=e210]:
            - generic [ref=e211]:
              - heading "Risk Lab · nachvollziehbare Signale" [level=3] [ref=e213]
              - generic [ref=e217]:
                - paragraph [ref=e218]: "Risikomodell: nexus-risk/2 · Fehlende Evidenz ist kein niedriges Risiko."
                - group [ref=e219]:
                  - generic "Datenqualität 60 / 100 +" [ref=e220] [cursor=pointer]:
                    - generic [ref=e222]: Datenqualität
                    - strong [ref=e223]: 60 / 100
                    - generic [ref=e224]: +
                - group [ref=e225]:
                  - generic "Liquiditätsrisiko 100 / 100 +" [ref=e226] [cursor=pointer]:
                    - generic [ref=e228]: Liquiditätsrisiko
                    - strong [ref=e229]: 100 / 100
                    - generic [ref=e230]: +
                - group [ref=e231]:
                  - generic "Konzentrationsrisiko Unbekannt +" [ref=e232] [cursor=pointer]:
                    - generic [ref=e234]: Konzentrationsrisiko
                    - strong [ref=e235]: Unbekannt
                    - generic [ref=e236]: +
                - group [ref=e237]:
                  - generic "Contract-Kontrollen Unbekannt +" [ref=e238] [cursor=pointer]:
                    - generic [ref=e240]: Contract-Kontrollen
                    - strong [ref=e241]: Unbekannt
                    - generic [ref=e242]: +
                - group [ref=e243]:
                  - generic "Auffällige Aktivität 10 / 100 +" [ref=e244] [cursor=pointer]:
                    - generic [ref=e246]: Auffällige Aktivität
                    - strong [ref=e247]: 10 / 100
                    - generic [ref=e248]: +
                - group [ref=e249]:
                  - generic "Momentum-Kontext -43,648 % +" [ref=e250] [cursor=pointer]:
                    - generic [ref=e252]: Momentum-Kontext
                    - strong [ref=e253]: "-43,648 %"
                    - generic [ref=e254]: +
                - group [ref=e255]:
                  - generic "LP-Lock / LP-Eigentümer Unbekannt +" [ref=e256] [cursor=pointer]:
                    - generic [ref=e258]: LP-Lock / LP-Eigentümer
                    - strong [ref=e259]: Unbekannt
                    - generic [ref=e260]: +
                - group [ref=e261]:
                  - generic "Transaktionscluster Unbekannt +" [ref=e262] [cursor=pointer]:
                    - generic [ref=e264]: Transaktionscluster
                    - strong [ref=e265]: Unbekannt
                    - generic [ref=e266]: +
            - generic [ref=e267]:
              - generic [ref=e268]:
                - heading "Contract & Datenabdeckung" [level=3] [ref=e270]
                - generic [ref=e271]:
                  - generic [ref=e272]: Tokenprogramm
                  - strong [ref=e273]: Unbekannt
                - generic [ref=e274]:
                  - generic [ref=e275]: Mint-Authority
                  - strong [ref=e276]:
                    - generic [ref=e277]: Unbekannt
                - generic [ref=e278]:
                  - generic [ref=e279]: Freeze-Authority
                  - strong [ref=e280]:
                    - generic [ref=e281]: Unbekannt
                - generic [ref=e282]:
                  - generic [ref=e283]: RPC-Slot
                  - strong [ref=e284]: Unbekannt
                - generic [ref=e285]:
                  - generic [ref=e286]: Prüfzeit
                  - strong [ref=e287]: Unbekannt
                - generic [ref=e288]:
                  - generic [ref=e289]: Tokenalter (Mint)
                  - strong [ref=e290]: Unbekannt
                - generic [ref=e291]:
                  - generic [ref=e292]: LP-Lock
                  - strong [ref=e293]: Unbekannt
                - paragraph [ref=e294]: Contract-Kontrollen gelten nach einer Stunde als erneut prüfungsbedürftig. Kein externer Sicherheitsbericht angebunden.
              - generic [ref=e295]:
                - heading "Größte öffentliche Tokenkonten" [level=3] [ref=e297]
                - generic [ref=e298]:
                  - heading "Kontoverteilung unbekannt" [level=3] [ref=e304]
                  - paragraph [ref=e305]: Die größten Tokenkonten wurden noch nicht erfolgreich abgefragt.
                - paragraph [ref=e306]: Tokenkonten sind keine eindeutigen Wallet-Holder. Pool- und Verwahrkonten können enthalten sein. Owner-Konzentration und Personenbezug bleiben unbekannt.
          - generic [ref=e307]:
            - heading "Datenherkunft" [level=3] [ref=e309]
            - generic [ref=e314]:
              - paragraph [ref=e315]: Jeder Wert stammt aus einer konkreten Provider-Beobachtung. Der Messzeitpunkt der Marktwerte wird von den Anbietern nicht veröffentlicht. HTTP-Zeit und Cache-Alter sind Näherungen der Antwortfrische.
              - generic [ref=e316]:
                - text: Pool wählen
                - combobox "Pool wählen" [ref=e317]:
                  - option "pump-fun · 1113…usn2 · $1,000" [selected]
            - table [ref=e319]:
              - rowgroup [ref=e320]:
                - row [ref=e321]:
                  - columnheader "Quelle" [ref=e322]
                  - columnheader "Preis" [ref=e323]
                  - columnheader "Liquidität" [ref=e324]
                  - columnheader "FDV" [ref=e325]
                  - columnheader "Market Cap" [ref=e326]
                  - columnheader "HTTP-Stand" [ref=e327]
                  - columnheader "Abrufzeit" [ref=e328]
                  - columnheader "Zeittyp" [ref=e329]
              - rowgroup [ref=e330]:
                - row [ref=e331]:
                  - cell "GeckoTerminal" [ref=e332]
                  - cell "$1" [ref=e333]
                  - cell "$1,000" [ref=e334]
                  - cell "$3,544.97" [ref=e335]
                  - cell "Unbekannt" [ref=e336]
                  - cell "24.10., 07:00:23" [ref=e337]
                  - cell "24.10., 07:00:23" [ref=e338]
                  - cell "HTTP-Cache-Näherung" [ref=e339]
            - generic [ref=e340]:
              - generic [ref=e341]: Pooladresse
              - button "1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2 — Contract-Adresse kopieren" [ref=e342] [cursor=pointer]:
                - generic [ref=e343]: 1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2
              - link "Öffentlicher Explorer" [ref=e347] [cursor=pointer]:
                - /url: https://explorer.solana.com/address/1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2
          - generic [ref=e352]:
            - generic [ref=e353]:
              - heading "Audit-Trail · Score-Veränderungen" [level=3] [ref=e355]
              - heading "Noch kein Audit-Trail" [level=3] [ref=e363]
            - generic [ref=e364]:
              - heading "Token-Ereignisse" [level=3] [ref=e366]
              - heading "Noch keine Ereignisse" [level=3] [ref=e374]
              - paragraph [ref=e375]: Öffentlich beobachtete Ereignisse; persönliche Benachrichtigungen im Alert-Posteingang.
        - generic [ref=e377]:
          - text: READ-ONLY RESEARCH
          - generic [ref=e382]: /
          - text: Datenqualität ist kein Sicherheitsnachweis.
  - alert [ref=e383]
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { expect, test } from "@playwright/test";
  3   |
  4   | for (const [view, heading] of [
  5   |   ["scanner", "Live Scanner"],
  6   |   ["command", /Command/],
  7   |   ["watchlists", "Watchlists"],
  8   |   ["health", "System Health"],
  9   |   ["quality", "Datenqualität"],
  10  | ] as const) {
  11  |   test(`${view} exposes labels, landmarks and sufficient text contrast`, async ({
  12  |     page,
  13  |   }, info) => {
  14  |     await page.goto(view === "scanner" ? "/" : `/?view=${view}`);
  15  |     await expect(page.getByRole("main")).toBeVisible();
  16  |     await expect(
  17  |       page.getByRole("heading", {
  18  |         name: heading,
  19  |         exact: typeof heading === "string",
  20  |       }),
  21  |     ).toBeVisible();
  22  |     if (view === "scanner")
  23  |       await page.getByTestId("pool-row").first().waitFor();
  24  |     if (view === "quality")
  25  |       await expect(
  26  |         page.getByText("Feldabdeckung", { exact: true }),
  27  |       ).toBeVisible();
  28  |     const report = await new AxeBuilder({ page })
  29  |       .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  30  |       .analyze();
  31  |     await info.attach(`axe-${view}`, {
  32  |       body: JSON.stringify(report, null, 2),
  33  |       contentType: "application/json",
  34  |     });
  35  |     expect(
  36  |       report.violations.map(({ id, nodes }) => ({
  37  |         id,
  38  |         targets: nodes.map(({ target }) => target),
  39  |       })),
  40  |       view,
  41  |     ).toEqual([]);
  42  |   });
  43  | }
  44  |
  45  | test("token intelligence exposes labels, landmarks and sufficient text contrast", async ({
  46  |   page,
  47  | }, info) => {
  48  |   const response = await page.request.get("/api/pools?page=1&pageSize=1");
  49  |   expect(response.ok()).toBe(true);
  50  |   const { rows } = await response.json();
  51  |   expect(rows).toHaveLength(1);
  52  |   const chosen = rows[0];
  53  |   await Promise.all([
  54  |     page.waitForResponse(
  55  |       (result) =>
  56  |         result.url().includes(`/api/candles/${chosen.poolId}/`) && result.ok(),
  57  |     ),
  58  |     page.goto(
  59  |       "/?" +
  60  |         new URLSearchParams({
  61  |           view: "token",
  62  |           mint: chosen.mint,
  63  |           pool: chosen.poolId,
  64  |         }),
  65  |     ),
  66  |   ]);
  67  |   await expect(
  68  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  69  |   ).toBeVisible();
  70  |   await expect(page.locator(".detail-token h2")).toHaveText(chosen.name);
  71  |   const report = await new AxeBuilder({ page })
  72  |     .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  73  |     .analyze();
  74  |   await info.attach("axe-token-intelligence", {
  75  |     body: JSON.stringify(report, null, 2),
  76  |     contentType: "application/json",
  77  |   });
  78  |   expect(
  79  |     report.violations.map(({ id, nodes }) => ({
  80  |       id,
  81  |       targets: nodes.map(({ target }) => target),
  82  |     })),
> 83  |   ).toEqual([]);
      |     ^ Error: expect(received).toEqual(expected) // deep equality
  84  | });
  85  |
  86  | test("scanner filters support keyboard focus, Escape and reduced motion", async ({
  87  |   page,
  88  | }) => {
  89  |   await page.emulateMedia({ reducedMotion: "reduce" });
  90  |   await page.goto("/");
  91  |   await page.getByTestId("pool-row").first().waitFor();
  92  |   if (process.env.NEXUS_TEST_MODE === "true")
  93  |     await expect(page.getByTestId("test-mode-banner")).toBeVisible();
  94  |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  95  |   await trigger.focus();
  96  |   await page.keyboard.press("Enter");
  97  |   const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  98  |   await expect(dialog).toBeVisible();
  99  |   await expect(dialog.locator(":focus")).toHaveCount(1);
  100 |   await page.keyboard.press("Tab");
  101 |   expect(
  102 |     await page.evaluate(
  103 |       () => document.activeElement?.closest('[role="dialog"]') !== null,
  104 |     ),
  105 |   ).toBe(true);
  106 |   await page.keyboard.press("Escape");
  107 |   await expect(dialog).toHaveCount(0);
  108 |   await expect(trigger).toBeFocused();
  109 |   expect(
  110 |     await page.evaluate(
  111 |       () => matchMedia("(prefers-reduced-motion: reduce)").matches,
  112 |     ),
  113 |   ).toBe(true);
  114 | });
  115 |
  116 | test("mobile research controls meet WCAG 2.2 minimum target size", async ({
  117 |   page,
  118 | }, info) => {
  119 |   test.skip(
  120 |     info.project.name !== "mobile",
  121 |     "Touch target check uses the mobile project viewport.",
  122 |   );
  123 |   await page.goto("/");
  124 |   await page.getByTestId("pool-row").first().waitFor();
  125 |   await expect(
  126 |     page.getByRole("button", { name: "Navigation öffnen", exact: true }),
  127 |   ).toBeVisible();
  128 |   await expect(
  129 |     page.getByRole("navigation", { name: "Mobile Research-Navigation" }),
  130 |   ).toBeVisible();
  131 |   const targets: {
  132 |     name: string | null | undefined;
  133 |     width: number;
  134 |     height: number;
  135 |     stage: string;
  136 |   }[] = [];
  137 |   const sample = async (stage: string) =>
  138 |     targets.push(
  139 |       ...(
  140 |         await page
  141 |           .locator('button,a[href],input,select,summary,[role="button"]')
  142 |           .evaluateAll((nodes) =>
  143 |             nodes.flatMap((node) => {
  144 |               const element = node as HTMLElement;
  145 |               const rect = element.getBoundingClientRect();
  146 |               const style = getComputedStyle(element);
  147 |               // Offscreen/hidden/disabled elements are not available pointer targets.
  148 |               if (
  149 |                 !rect.width ||
  150 |                 !rect.height ||
  151 |                 rect.right <= 0 ||
  152 |                 rect.left >= innerWidth ||
  153 |                 rect.bottom <= 0 ||
  154 |                 rect.top >= innerHeight ||
  155 |                 style.visibility === "hidden" ||
  156 |                 element.matches(":disabled")
  157 |               )
  158 |                 return [];
  159 |               return [
  160 |                 {
  161 |                   name:
  162 |                     element.getAttribute("aria-label") ||
  163 |                     element.textContent?.trim().slice(0, 80),
  164 |                   width: rect.width,
  165 |                   height: rect.height,
  166 |                 },
  167 |               ];
  168 |             }),
  169 |           )
  170 |       ).map((target) => ({ ...target, stage })),
  171 |     );
  172 |   await sample("page-top");
  173 |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  174 |   await trigger.scrollIntoViewIfNeeded();
  175 |   await expect(
  176 |     page.getByLabel("Scanner-Sortierung", { exact: true }),
  177 |   ).toBeVisible();
  178 |   await sample("scanner-toolbar");
  179 |   await page.getByTestId("pool-row").first().scrollIntoViewIfNeeded();
  180 |   await sample("scanner-rows");
  181 |   await trigger.click();
  182 |   await expect(
  183 |     page.getByRole("dialog", { name: "Scanner-Filter" }),
```
