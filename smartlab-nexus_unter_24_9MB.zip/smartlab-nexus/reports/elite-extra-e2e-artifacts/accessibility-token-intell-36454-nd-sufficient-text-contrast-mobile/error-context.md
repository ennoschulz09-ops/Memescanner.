# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> token intelligence exposes labels, landmarks and sufficient text contrast
- Location: tests/e2e/accessibility.spec.ts:45:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   Object {
+     "id": "scrollable-region-focusable",
+     "targets": Array [
+       Array [
+         ".horizontal-scroll",
+       ],
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Zum Research-Inhalt" [ref=e3] [cursor=pointer]:
      - /url: "#research-main"
    - complementary [ref=e4]:
      - generic [ref=e10]:
        - strong [ref=e11]: SMARTLAB
        - generic [ref=e12]: NEXUS / 01
      - button "S Research Workspace Solana Mainnet" [ref=e13] [cursor=pointer]:
        - generic [ref=e14]: S
        - generic [ref=e15]:
          - strong [ref=e16]: Research Workspace
          - generic [ref=e17]: Solana Mainnet
      - generic [ref=e20]: ENTDECKEN & ANALYSIEREN
      - navigation "Hauptnavigation" [ref=e21]:
        - button "Command Dashboard" [ref=e22] [cursor=pointer]
        - button "Discovery" [ref=e29] [cursor=pointer]
        - button "Live Scanner" [ref=e34] [cursor=pointer]
        - button "Token-Analyse" [ref=e43] [cursor=pointer]
        - button "Risk Lab" [ref=e50] [cursor=pointer]
        - button "Wallet Explorer" [ref=e55] [cursor=pointer]
        - generic [ref=e60]: DEIN RESEARCH
        - button "Watchlists" [ref=e61] [cursor=pointer]
        - button "Alerts" [ref=e65] [cursor=pointer]
        - button "Analytics" [ref=e70] [cursor=pointer]
        - button "Datenqualität" [ref=e74] [cursor=pointer]
      - generic [ref=e80]:
        - generic [ref=e81]:
          - generic [ref=e82]: WATCHLISTS
          - button "Watchlist erstellen" [ref=e83] [cursor=pointer]
        - paragraph [ref=e85]: Dein nächster Fundbeginnt im Scanner.
      - generic [ref=e86]:
        - generic [ref=e87]:
          - button "System Health" [ref=e88] [cursor=pointer]
          - button "Einstellungen" [ref=e93] [cursor=pointer]
        - generic [ref=e101]:
          - strong [ref=e102]: Research. Mit Klarheit.
          - generic [ref=e103]: Öffentliche Daten.Nachvollziehbare Evidenz.
        - generic [ref=e104]:
          - generic [ref=e105]: SMARTLAB NEXUS
          - generic [ref=e106]: v1.0
    - generic [ref=e107]:
      - banner [ref=e108]:
        - generic [ref=e109]:
          - button "Navigation öffnen" [ref=e110] [cursor=pointer]
          - strong [ref=e112]: Token-Analyse
        - generic [ref=e113]:
          - textbox "Token, Symbol oder Mint-Adresse suchen" [ref=e117]
          - generic [ref=e118]: ⌘ K
        - generic [ref=e119]:
          - generic [ref=e120]:
            - generic [ref=e121]: ≋
            - text: Solana
          - button "Alert-Posteingang" [ref=e122] [cursor=pointer]
          - generic [ref=e126]: R
      - main [ref=e127]:
        - generic [ref=e128]:
          - generic [ref=e129]:
            - generic [ref=e130]: SOLANA TOKEN INTELLIGENCE
            - heading "Token-Analyse" [level=1] [ref=e133]: Token-Analyse.
            - paragraph [ref=e134]: Marktdaten, öffentliche Evidenzen und nachvollziehbare Risikoindikatoren.
          - generic [ref=e135]:
            - generic [ref=e136]: Degradierter Modus
            - generic [ref=e138]: Update 21s
        - status [ref=e144]:
          - strong [ref=e145]: ISOLIERTE TESTDATEN · keine aktuellen Marktdaten
        - generic [ref=e146]:
          - generic [ref=e147]:
            - button "Zurück zum Scanner" [ref=e148] [cursor=pointer]
            - generic [ref=e151]: Solana / pump-fun / 1113…usn2
          - generic [ref=e152]:
            - generic [ref=e153]:
              - generic [aria-hidden] [ref=e154]: QA
              - generic [ref=e155]:
                - generic [ref=e156]:
                  - heading "Isolierter QA Token 00000" [level=2] [ref=e157]
                  - generic [ref=e158]: QA0
                - button "1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22 — Contract-Adresse kopieren" [ref=e159] [cursor=pointer]:
                  - generic [ref=e160]: 1113q6URPh2n7hhr4ova6RDTFCFtK79SunA47PNm22
            - generic [ref=e164]:
              - strong [ref=e165]: $1
              - generic [ref=e166]: "-43,65% · 5m"
            - generic [ref=e167]:
              - button "Beobachten" [ref=e168] [cursor=pointer]
              - button "Analyse aktualisieren" [ref=e171] [cursor=pointer]
          - generic [ref=e177]:
            - generic [ref=e178]:
              - generic [ref=e179]: Liquidität
              - strong [ref=e180]: $1,000
            - generic [ref=e181]:
              - generic [ref=e182]: Volumen · 24h
              - strong [ref=e183]: $119.6
            - generic [ref=e184]:
              - generic [ref=e185]: Market Cap
              - strong [ref=e186]: Unbekannt
            - generic [ref=e187]:
              - generic [ref=e188]: FDV
              - strong [ref=e189]: $3,544.97
            - generic [ref=e190]:
              - generic [ref=e191]: Poolalter
              - strong [ref=e192]: 21h
          - generic [ref=e193]:
            - generic [ref=e194]:
              - generic [ref=e195]:
                - generic [ref=e196]:
                  - button "Preis" [ref=e197] [cursor=pointer]
                  - button "Volumen" [ref=e198] [cursor=pointer]
                  - button "Liquidität" [ref=e199] [cursor=pointer]
                  - button "Trades" [ref=e200] [cursor=pointer]
                - generic [ref=e201]:
                  - button "1h" [ref=e202] [cursor=pointer]
                  - button "24h" [ref=e203] [cursor=pointer]
                  - button "7d" [ref=e204] [cursor=pointer]
              - generic [ref=e205]:
                - heading "Noch keine Zeitreihe" [level=3] [ref=e211]
                - paragraph [ref=e212]: Es werden ausschließlich verfügbare Quellenwerte und eigene gespeicherte Beobachtungen dargestellt.
            - generic [ref=e213]:
              - heading "Rechercheprofil" [level=3] [ref=e215]
              - generic [ref=e216]: Kritisches Risiko
              - generic [ref=e217]:
                - strong [ref=e218]: —
                - generic [ref=e219]: / 100 Risikoindikator
              - paragraph [ref=e220]: Nicht ausreichend Daten. Fehlende Pflichtprüfungen verhindern einen Gesamtscore.
              - generic [ref=e221]:
                - generic [ref=e222]: Abdeckung Pflichtprüfungen
                - strong [ref=e223]: 45 %
              - generic [ref=e224]:
                - generic [ref=e225]: Datenqualität
                - strong [ref=e226]:
                  - generic "Vollständigkeit, Quellenabdeckung und Frische; kein Sicherheitsnachweis" [ref=e227]: 60/100
              - button "Onchain-Daten prüfen" [ref=e231] [cursor=pointer]
              - generic [ref=e237]: Solana RPC · mindestens 60s Cache · begrenztes Budget
          - generic [ref=e238]:
            - generic [ref=e239]:
              - heading "Risk Lab · nachvollziehbare Signale" [level=3] [ref=e241]
              - generic [ref=e245]:
                - paragraph [ref=e246]: "Risikomodell: nexus-risk/2 · Fehlende Evidenz ist kein niedriges Risiko."
                - group [ref=e247]:
                  - generic "Datenqualität 60 / 100 +" [ref=e248] [cursor=pointer]:
                    - generic [ref=e250]: Datenqualität
                    - strong [ref=e251]: 60 / 100
                    - generic [ref=e252]: +
                - group [ref=e253]:
                  - generic "Liquiditätsrisiko 100 / 100 +" [ref=e254] [cursor=pointer]:
                    - generic [ref=e256]: Liquiditätsrisiko
                    - strong [ref=e257]: 100 / 100
                    - generic [ref=e258]: +
                - group [ref=e259]:
                  - generic "Konzentrationsrisiko Unbekannt +" [ref=e260] [cursor=pointer]:
                    - generic [ref=e262]: Konzentrationsrisiko
                    - strong [ref=e263]: Unbekannt
                    - generic [ref=e264]: +
                - group [ref=e265]:
                  - generic "Contract-Kontrollen Unbekannt +" [ref=e266] [cursor=pointer]:
                    - generic [ref=e268]: Contract-Kontrollen
                    - strong [ref=e269]: Unbekannt
                    - generic [ref=e270]: +
                - group [ref=e271]:
                  - generic "Auffällige Aktivität 10 / 100 +" [ref=e272] [cursor=pointer]:
                    - generic [ref=e274]: Auffällige Aktivität
                    - strong [ref=e275]: 10 / 100
                    - generic [ref=e276]: +
                - group [ref=e277]:
                  - generic "Momentum-Kontext -43,648 % +" [ref=e278] [cursor=pointer]:
                    - generic [ref=e280]: Momentum-Kontext
                    - strong [ref=e281]: "-43,648 %"
                    - generic [ref=e282]: +
                - group [ref=e283]:
                  - generic "LP-Lock / LP-Eigentümer Unbekannt +" [ref=e284] [cursor=pointer]:
                    - generic [ref=e286]: LP-Lock / LP-Eigentümer
                    - strong [ref=e287]: Unbekannt
                    - generic [ref=e288]: +
                - group [ref=e289]:
                  - generic "Transaktionscluster Unbekannt +" [ref=e290] [cursor=pointer]:
                    - generic [ref=e292]: Transaktionscluster
                    - strong [ref=e293]: Unbekannt
                    - generic [ref=e294]: +
            - generic [ref=e295]:
              - generic [ref=e296]:
                - heading "Contract & Datenabdeckung" [level=3] [ref=e298]
                - generic [ref=e299]:
                  - generic [ref=e300]: Tokenprogramm
                  - strong [ref=e301]: Unbekannt
                - generic [ref=e302]:
                  - generic [ref=e303]: Mint-Authority
                  - strong [ref=e304]:
                    - generic [ref=e305]: Unbekannt
                - generic [ref=e306]:
                  - generic [ref=e307]: Freeze-Authority
                  - strong [ref=e308]:
                    - generic [ref=e309]: Unbekannt
                - generic [ref=e310]:
                  - generic [ref=e311]: RPC-Slot
                  - strong [ref=e312]: Unbekannt
                - generic [ref=e313]:
                  - generic [ref=e314]: Prüfzeit
                  - strong [ref=e315]: Unbekannt
                - generic [ref=e316]:
                  - generic [ref=e317]: Tokenalter (Mint)
                  - strong [ref=e318]: Unbekannt
                - generic [ref=e319]:
                  - generic [ref=e320]: LP-Lock
                  - strong [ref=e321]: Unbekannt
                - paragraph [ref=e322]: Contract-Kontrollen gelten nach einer Stunde als erneut prüfungsbedürftig. Kein externer Sicherheitsbericht angebunden.
              - generic [ref=e323]:
                - heading "Größte öffentliche Tokenkonten" [level=3] [ref=e325]
                - generic [ref=e326]:
                  - heading "Kontoverteilung unbekannt" [level=3] [ref=e332]
                  - paragraph [ref=e333]: Die größten Tokenkonten wurden noch nicht erfolgreich abgefragt.
                - paragraph [ref=e334]: Tokenkonten sind keine eindeutigen Wallet-Holder. Pool- und Verwahrkonten können enthalten sein. Owner-Konzentration und Personenbezug bleiben unbekannt.
          - generic [ref=e335]:
            - heading "Datenherkunft" [level=3] [ref=e337]
            - generic [ref=e342]:
              - paragraph [ref=e343]: Jeder Wert stammt aus einer konkreten Provider-Beobachtung. Der Messzeitpunkt der Marktwerte wird von den Anbietern nicht veröffentlicht. HTTP-Zeit und Cache-Alter sind Näherungen der Antwortfrische.
              - generic [ref=e344]:
                - text: Pool wählen
                - combobox "Pool wählen" [ref=e345]:
                  - option "pump-fun · 1113…usn2 · $1,000" [selected]
            - table [ref=e347]:
              - rowgroup [ref=e348]:
                - row [ref=e349]:
                  - columnheader "Quelle" [ref=e350]
                  - columnheader "Preis" [ref=e351]
                  - columnheader "Liquidität" [ref=e352]
                  - columnheader "FDV" [ref=e353]
                  - columnheader "Market Cap" [ref=e354]
                  - columnheader "HTTP-Stand" [ref=e355]
                  - columnheader "Abrufzeit" [ref=e356]
                  - columnheader "Zeittyp" [ref=e357]
              - rowgroup [ref=e358]:
                - row [ref=e359]:
                  - cell "GeckoTerminal" [ref=e360]
                  - cell "$1" [ref=e361]
                  - cell "$1,000" [ref=e362]
                  - cell "$3,544.97" [ref=e363]
                  - cell "Unbekannt" [ref=e364]
                  - cell "24.10., 07:00:23" [ref=e365]
                  - cell "24.10., 07:00:23" [ref=e366]
                  - cell "HTTP-Cache-Näherung" [ref=e367]
            - generic [ref=e368]:
              - generic [ref=e369]: Pooladresse
              - button "1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2 — Contract-Adresse kopieren" [ref=e370] [cursor=pointer]:
                - generic [ref=e371]: 1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2
              - link "Öffentlicher Explorer" [ref=e375] [cursor=pointer]:
                - /url: https://explorer.solana.com/address/1113kJbEwdKfJ6Dywvbedb6KHKYorL6EivaLxJusn2
          - generic [ref=e380]:
            - generic [ref=e381]:
              - heading "Audit-Trail · Score-Veränderungen" [level=3] [ref=e383]
              - heading "Noch kein Audit-Trail" [level=3] [ref=e391]
            - generic [ref=e392]:
              - heading "Token-Ereignisse" [level=3] [ref=e394]
              - heading "Noch keine Ereignisse" [level=3] [ref=e402]
              - paragraph [ref=e403]: Öffentlich beobachtete Ereignisse; persönliche Benachrichtigungen im Alert-Posteingang.
        - generic [ref=e404]:
          - generic [ref=e405]:
            - text: READ-ONLY RESEARCH
            - generic [ref=e410]: /
            - text: Datenqualität ist kein Sicherheitsnachweis.
          - generic [ref=e411]:
            - text: 24.10., 07:00:44 UTC
            - generic [ref=e412]: ·
            - text: Quellenstand je Wert sichtbar
    - navigation "Mobile Research-Navigation" [ref=e413]:
      - button "Command" [ref=e414] [cursor=pointer]
      - button "Radar" [ref=e421] [cursor=pointer]
      - button "Analyse" [ref=e429] [cursor=pointer]
      - button "Watchlists" [ref=e436] [cursor=pointer]
      - button "Status" [ref=e440] [cursor=pointer]
  - alert [ref=e445]
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { expect, test } from "@playwright/test";
  3   |
  4   | for (const [view, heading] of [
  5   |   ["scanner", "Live Scanner"],
  6   |   ["command", /Command/],
  7   |   ["watchlists", "Watchlists"],
  8   |   ["health", "System Health"],
  9   |   ["quality", "Datenqualität"],
  10  | ] as const) {
  11  |   test(`${view} exposes labels, landmarks and sufficient text contrast`, async ({
  12  |     page,
  13  |   }, info) => {
  14  |     await page.goto(view === "scanner" ? "/" : `/?view=${view}`);
  15  |     await expect(page.getByRole("main")).toBeVisible();
  16  |     await expect(
  17  |       page.getByRole("heading", {
  18  |         name: heading,
  19  |         exact: typeof heading === "string",
  20  |       }),
  21  |     ).toBeVisible();
  22  |     if (view === "scanner")
  23  |       await page.getByTestId("pool-row").first().waitFor();
  24  |     if (view === "quality")
  25  |       await expect(
  26  |         page.getByText("Feldabdeckung", { exact: true }),
  27  |       ).toBeVisible();
  28  |     const report = await new AxeBuilder({ page })
  29  |       .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  30  |       .analyze();
  31  |     await info.attach(`axe-${view}`, {
  32  |       body: JSON.stringify(report, null, 2),
  33  |       contentType: "application/json",
  34  |     });
  35  |     expect(
  36  |       report.violations.map(({ id, nodes }) => ({
  37  |         id,
  38  |         targets: nodes.map(({ target }) => target),
  39  |       })),
  40  |       view,
  41  |     ).toEqual([]);
  42  |   });
  43  | }
  44  |
  45  | test("token intelligence exposes labels, landmarks and sufficient text contrast", async ({
  46  |   page,
  47  | }, info) => {
  48  |   const response = await page.request.get("/api/pools?page=1&pageSize=1");
  49  |   expect(response.ok()).toBe(true);
  50  |   const { rows } = await response.json();
  51  |   expect(rows).toHaveLength(1);
  52  |   const chosen = rows[0];
  53  |   await Promise.all([
  54  |     page.waitForResponse(
  55  |       (result) =>
  56  |         result.url().includes(`/api/candles/${chosen.poolId}/`) && result.ok(),
  57  |     ),
  58  |     page.goto(
  59  |       "/?" +
  60  |         new URLSearchParams({
  61  |           view: "token",
  62  |           mint: chosen.mint,
  63  |           pool: chosen.poolId,
  64  |         }),
  65  |     ),
  66  |   ]);
  67  |   await expect(
  68  |     page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  69  |   ).toBeVisible();
  70  |   await expect(page.locator(".detail-token h2")).toHaveText(chosen.name);
  71  |   const report = await new AxeBuilder({ page })
  72  |     .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
  73  |     .analyze();
  74  |   await info.attach("axe-token-intelligence", {
  75  |     body: JSON.stringify(report, null, 2),
  76  |     contentType: "application/json",
  77  |   });
  78  |   expect(
  79  |     report.violations.map(({ id, nodes }) => ({
  80  |       id,
  81  |       targets: nodes.map(({ target }) => target),
  82  |     })),
> 83  |   ).toEqual([]);
      |     ^ Error: expect(received).toEqual(expected) // deep equality
  84  | });
  85  |
  86  | test("scanner filters support keyboard focus, Escape and reduced motion", async ({
  87  |   page,
  88  | }) => {
  89  |   await page.emulateMedia({ reducedMotion: "reduce" });
  90  |   await page.goto("/");
  91  |   await page.getByTestId("pool-row").first().waitFor();
  92  |   if (process.env.NEXUS_TEST_MODE === "true")
  93  |     await expect(page.getByTestId("test-mode-banner")).toBeVisible();
  94  |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  95  |   await trigger.focus();
  96  |   await page.keyboard.press("Enter");
  97  |   const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  98  |   await expect(dialog).toBeVisible();
  99  |   await expect(dialog.locator(":focus")).toHaveCount(1);
  100 |   await page.keyboard.press("Tab");
  101 |   expect(
  102 |     await page.evaluate(
  103 |       () => document.activeElement?.closest('[role="dialog"]') !== null,
  104 |     ),
  105 |   ).toBe(true);
  106 |   await page.keyboard.press("Escape");
  107 |   await expect(dialog).toHaveCount(0);
  108 |   await expect(trigger).toBeFocused();
  109 |   expect(
  110 |     await page.evaluate(
  111 |       () => matchMedia("(prefers-reduced-motion: reduce)").matches,
  112 |     ),
  113 |   ).toBe(true);
  114 | });
  115 |
  116 | test("mobile research controls meet WCAG 2.2 minimum target size", async ({
  117 |   page,
  118 | }, info) => {
  119 |   test.skip(
  120 |     info.project.name !== "mobile",
  121 |     "Touch target check uses the mobile project viewport.",
  122 |   );
  123 |   await page.goto("/");
  124 |   await page.getByTestId("pool-row").first().waitFor();
  125 |   await expect(
  126 |     page.getByRole("button", { name: "Navigation öffnen", exact: true }),
  127 |   ).toBeVisible();
  128 |   await expect(
  129 |     page.getByRole("navigation", { name: "Mobile Research-Navigation" }),
  130 |   ).toBeVisible();
  131 |   const targets: {
  132 |     name: string | null | undefined;
  133 |     width: number;
  134 |     height: number;
  135 |     stage: string;
  136 |   }[] = [];
  137 |   const sample = async (stage: string) =>
  138 |     targets.push(
  139 |       ...(
  140 |         await page
  141 |           .locator('button,a[href],input,select,summary,[role="button"]')
  142 |           .evaluateAll((nodes) =>
  143 |             nodes.flatMap((node) => {
  144 |               const element = node as HTMLElement;
  145 |               const rect = element.getBoundingClientRect();
  146 |               const style = getComputedStyle(element);
  147 |               // Offscreen/hidden/disabled elements are not available pointer targets.
  148 |               if (
  149 |                 !rect.width ||
  150 |                 !rect.height ||
  151 |                 rect.right <= 0 ||
  152 |                 rect.left >= innerWidth ||
  153 |                 rect.bottom <= 0 ||
  154 |                 rect.top >= innerHeight ||
  155 |                 style.visibility === "hidden" ||
  156 |                 element.matches(":disabled")
  157 |               )
  158 |                 return [];
  159 |               return [
  160 |                 {
  161 |                   name:
  162 |                     element.getAttribute("aria-label") ||
  163 |                     element.textContent?.trim().slice(0, 80),
  164 |                   width: rect.width,
  165 |                   height: rect.height,
  166 |                 },
  167 |               ];
  168 |             }),
  169 |           )
  170 |       ).map((target) => ({ ...target, stage })),
  171 |     );
  172 |   await sample("page-top");
  173 |   const trigger = page.getByRole("button", { name: "Filter", exact: true });
  174 |   await trigger.scrollIntoViewIfNeeded();
  175 |   await expect(
  176 |     page.getByLabel("Scanner-Sortierung", { exact: true }),
  177 |   ).toBeVisible();
  178 |   await sample("scanner-toolbar");
  179 |   await page.getByTestId("pool-row").first().scrollIntoViewIfNeeded();
  180 |   await sample("scanner-rows");
  181 |   await trigger.click();
  182 |   await expect(
  183 |     page.getByRole("dialog", { name: "Scanner-Filter" }),
```
