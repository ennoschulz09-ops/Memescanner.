# Änderungsprotokoll

## Elite — 23.10.2026

- Eigenes ATLAS-System mit dunklen Tintenflächen, Cyan-Fokus, ruhiger Datenhierarchie, Command Dashboard und Data Quality Dashboard.
- Mobile Bottom-Navigation, virtuelle Tokenkarten, Schnellanalyse-Sheet mit Fokusführung und explizites Pausieren/Fortsetzen der Tabellenupdates. Ein im visuellen Review entdeckter Desktop-Mindestbreitenüberlauf wurde mit einer Browserregression abgesichert.
- Optionaler kompakter Scannervertrag: wiederholte Evidenz-/Risikodefinitionen werden zusammengefasst, vollständige Quellenbeobachtungen bleiben im Detailabruf. Kein 10k-Payload für Standardseiten.
- Persistierte, begrenzte Chain-Queue mit Lease/Fencing, Versuchen, Retry-Gründen, terminalen Fehlern, Dead-letter, Durchsatz, Alter und unabhängigem Replay-Cursor.
- Tatsächliche Solana-Transaktionsversion 1 wird nach aktueller offizieller Dokumentation unterstützt. Der enge Raydium-CPMM-Initialize-Decoder bleibt versioniert und fixture-geprüft. Öffentliche 429 und Coverage-Lücken bleiben sichtbar.
- Fehlgeschlagene Risk-Anreicherung berücksichtigt Provider-Backoff. Beobachtungszeit und Abrufzeit bleiben getrennt; Persistenzdauer verwendet eine monotone lokale Uhr.
- Risikomodell `nexus-risk/2`, Methodenversion im Audit und erneute Prüfung bei Modellwechsel; fehlerhafte, zukünftige oder veraltete Evidenz erzeugt keine Scheinsicherheit. Null-/Extremwert- und Konfliktregressionen einschließlich Property-Tests.
- Isolierte CI-Browserfixtures, blockierter externer Providerzugriff im kombinierten Test-/Isolationsmodus, Chromium/Firefox/WebKit-Projekte und Axe-Prüfungen.
- Neue reproduzierbare Leistungs-, Live-Beobachtungs-, Design- und Abnahmeberichte. Die genaue Gate-Matrix und offene Nachweise stehen in QA_REPORT.md; der Zielwert 9,5 wird nicht pauschal behauptet.

## Vorheriges Upgrade — 23.10.2026

Frühe Discovery vor Markt-Hydration, getrennte Scheduler, Read-only-RPC, NOTIFY/SSE v2, serverseitige Scannerseiten, Feld-Provenienz und GitHub-Codespaces-Konfiguration. Historische Abnahme: `reports/upgrade-verification.json`, Basis des Elite-Upgrades `7af10c6`.

## Final Precision · 24.10.2026

- Atomare, gefencete Chain-Discovery-Completion und begrenzte serielle Burst-Admission.
- Decoder-Wakeup nach dauerhafter Admission; kein Umgehen von Retry-After.
- Signaturkorrelierte frühe Kandidaten und getrennte Pending-/Decode-DOM-Quittungen mit Retention.
- Risiko v3: komponentenweise Teilfehler, Slot-/Authority-/Account-Validierung, konservative Stale-Signale.
- Operativer ATLAS-Blotter, mobile Server-Pages25, gecachte Formatierer, schlankere Evidenzpfade und Query-Race-Schutz.
- Echte Chartsegmente bei Null-/Zeitlücken, Tastatur/Quellenreadout und Overflow-sichere Extremwertgeometrie.
- Vitest5 behebt Auditbefunde; Lockfile-/Secret-/RPC-Guards und CI-Gates erweitert.
- Numerisches Inventar, 50-Kriterien-Scorecard, Live-/Chaos-/Performancebelege und ausführbarer Soak-Observer.
- Keine Handels- oder Wallet-Ausführungsfunktion hinzugefügt.
