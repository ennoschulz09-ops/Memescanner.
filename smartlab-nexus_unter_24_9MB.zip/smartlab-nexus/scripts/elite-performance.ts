import { spawn } from "node:child_process";
import { mkdir, open, writeFile } from "node:fs/promises";
import os from "node:os";
import { performance } from "node:perf_hooks";
import pg from "pg";
import { chromium, devices, type Page } from "@playwright/test";
import { isolatedDatabase, seedEliteFixtures } from "./elite-fixtures";

process.env.NEXUS_TEST_MODE = "true";
const appUrl = new URL(
  process.env.DATABASE_URL ||
    "postgresql://nexus:nexus_local_only@localhost:5432/nexus",
);
const selectedUrl = new URL(process.env.ELITE_DATABASE_URL || appUrl);
if (!process.env.ELITE_DATABASE_URL)
  selectedUrl.pathname = "/nexus_elite_performance_test";
const { url, name } = isolatedDatabase(
  selectedUrl.toString(),
  "Elite performance",
);
if (url.pathname === appUrl.pathname && url.host === appUrl.host)
  throw new Error("Performance database must differ from the app database.");
if (!name.endsWith("_performance_test"))
  throw new Error("Performance database must end in _performance_test.");
const port = Number(process.env.ELITE_PORT || 3200);
if (!Number.isInteger(port) || port < 3100 || port > 3999)
  throw new Error("Invalid isolated performance port.");
const samples = Number(process.env.ELITE_SAMPLES || 20);
const loadSamples = Number(process.env.ELITE_LOAD_SAMPLES || 7);
if (
  !Number.isInteger(samples) ||
  samples < 5 ||
  samples > 100 ||
  !Number.isInteger(loadSamples) ||
  loadSamples < 3 ||
  loadSamples > 30
)
  throw new Error("Use 5–100 interaction samples and 3–30 load samples.");
const counts = (process.env.ELITE_COUNTS || "1000,5000,10000")
  .split(",")
  .map(Number);
if (counts.some((count) => ![1000, 5000, 10000].includes(count)))
  throw new Error("Counts must be 1000,5000,10000.");
const adminUrl = new URL(url);
adminUrl.pathname = "/postgres";
const admin = new pg.Pool({ connectionString: adminUrl.toString() });
try {
  if (
    !(await admin.query("SELECT 1 FROM pg_database WHERE datname=$1", [name]))
      .rowCount
  )
    await admin.query(`CREATE DATABASE "${name}"`);
} finally {
  await admin.end();
}
process.env.DATABASE_URL = url.toString();
const { db, migrate } = await import("../lib/db");
await migrate();
await mkdir("reports", { recursive: true });
const logfile = await open("reports/elite-performance-server.log", "w");
const server = spawn(
  process.execPath,
  [
    "node_modules/next/dist/bin/next",
    "start",
    "--hostname",
    "127.0.0.1",
    "--port",
    String(port),
  ],
  {
    env: {
      ...process.env,
      DATABASE_URL: url.toString(),
      APP_ORIGIN: `http://localhost:${port}`,
      NEXUS_TEST_MODE: "true",
      CI_NETWORK_ISOLATION: "true",
      SOLANA_WS_DISCOVERY: "false",
    },
    stdio: ["ignore", logfile.fd, logfile.fd],
  },
);
await logfile.close();
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const baseURL = `http://localhost:${port}`;
function summarize(raw: number[]) {
  const sorted = raw.filter(Number.isFinite).sort((a, b) => a - b);
  const percentile = (p: number) =>
    sorted.length ? sorted[Math.ceil(sorted.length * p) - 1] : null;
  return {
    n: sorted.length,
    p50Ms: percentile(0.5),
    p95Ms: percentile(0.95),
    p99Ms: percentile(0.99),
    maxMs: sorted.at(-1) ?? null,
    rawMs: raw,
  };
}
async function paint(page: Page) {
  await page.evaluate(
    "new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))",
  );
}
// The browser records the actual DOM input/click event and checks the outcome on rAF.
// Automation polling is outside this duration. A completed matching API response is mandatory.
async function arm(page: Page, kind: string, expected: string) {
  await page.evaluate(
    ({ kind, expected }) => {
      const state = (window as any).__elite;
      state.measure = {
        kind,
        expected,
        started: 0,
        requestDone: false,
        elapsed: null,
      };
    },
    { kind, expected },
  );
}
async function finish(page: Page) {
  await page.waitForFunction(
    () => (window as any).__elite.measure?.elapsed !== null,
    undefined,
    { timeout: 15000 },
  );
  return page.evaluate<number>(() => (window as any).__elite.measure.elapsed);
}
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const results: Record<string, any>[] = [];
try {
  let ready = false;
  for (let attempt = 0; attempt < 120; attempt++) {
    if (server.exitCode !== null)
      throw new Error("Isolated performance server exited.");
    try {
      if ((await fetch(`${baseURL}/api/health`)).ok) {
        ready = true;
        break;
      }
    } catch {}
    await wait(500);
  }
  if (!ready)
    throw new Error(
      "Isolated performance server not ready; inspect report log.",
    );
  browser = await chromium.launch({
    ...(process.env.CHROMIUM_PATH
      ? { executablePath: process.env.CHROMIUM_PATH }
      : {}),
    args: ["--no-sandbox", "--enable-precise-memory-info"],
  });
  for (const count of counts) {
    await seedEliteFixtures(db, count);
    for (const profile of ["desktop", "mobile-throttled"] as const) {
      const { defaultBrowserType: _mobileBrowserType, ...mobileDevice } =
        devices["iPhone 13"];
      const context = await browser.newContext(
        profile === "desktop"
          ? { viewport: { width: 1512, height: 982 } }
          : mobileDevice,
      );
      const page = await context.newPage();
      const errors: string[] = [];
      page.on("pageerror", (error) => errors.push(error.message));
      const cdp = await context.newCDPSession(page);
      await cdp.send("Network.enable");
      await cdp.send("Performance.enable");
      if (profile === "mobile-throttled") {
        await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
        await cdp.send("Network.emulateNetworkConditions", {
          offline: false,
          latency: 150,
          downloadThroughput: 1_600_000 / 8,
          uploadThroughput: 750_000 / 8,
        });
      }
      let bytes = 0;
      cdp.on("Network.loadingFinished", ({ encodedDataLength }) => {
        bytes += encodedDataLength;
      });
      await page.addInitScript({
        content: `(() => {
        const state=window.__elite={longTasks:[],measure:null};
        try {new PerformanceObserver(list=>state.longTasks.push(...list.getEntries().map(e=>e.duration))).observe({type:'longtask',buffered:true});}catch{}
        for(const type of ['input','click','change'])document.addEventListener(type,e=>{const m=state.measure;if(!m||m.started)return;const t=e.target;
          if((m.kind==='filter'&&type==='input'&&t.matches('input[type="number"]'))||(m.kind==='search'&&type==='input')||(m.kind==='sort'&&type==='change')||(m.kind==='detail'&&type==='click'))m.started=performance.now();},true);
        const nativeFetch=window.fetch;window.fetch=async(...args)=>{const m=state.measure;const initiated=!!m?.started;const url=String(args[0]);const response=await nativeFetch(...args);
          if(initiated&&m&&state.measure===m&&((m.kind==='detail'&&url.includes('/tokens/'))||(m.kind!=='detail'&&url.includes('pools?')))) {await response.clone().text();if(state.measure===m)m.requestDone=true;}return response;};
        function frame(now){const m=state.measure;if(m&&m.started&&m.requestDone&&m.elapsed===null){const row=document.querySelector('[data-testid="pool-row"]');
          const heading=document.querySelector('.detail-token h2');
          const ready=m.kind==='detail'?heading?.textContent===m.expected:m.expected==='empty'?(!row&&document.body.textContent.includes('Keine passenden Pools')):m.expected==='rows'?!!row:row?.getAttribute('data-pool-id')===m.expected;
          if(ready)m.elapsed=now-m.started;}requestAnimationFrame(frame);}requestAnimationFrame(frame);
      })();`,
      });
      const initialLoad: number[] = [],
        filter: number[] = [],
        sort: number[] = [],
        search: number[] = [],
        detail: number[] = [],
        longTaskSamples: number[] = [];
      const collectLongTasks = async () => {
        longTaskSamples.push(
          ...(await page.evaluate<number[]>(() => {
            const samples = (window as any).__elite.longTasks;
            (window as any).__elite.longTasks = [];
            return samples;
          })),
        );
      };
      for (let i = 0; i < loadSamples; i++) {
        const start = performance.now();
        await page.goto(baseURL);
        await page.getByTestId("pool-row").first().waitFor();
        await page
          .getByText("ISOLIERTE TESTDATEN · keine aktuellen Marktdaten", {
            exact: true,
          })
          .waitFor();
        await paint(page);
        initialLoad.push(performance.now() - start);
        await collectLongTasks();
      }
      const initial = await (
        await page.request.get(`${baseURL}/api/pools?page=1&pageSize=100`)
      ).json();
      if (initial.rows.length > 100 || initial.total !== count)
        throw new Error(
          "Expected bounded server page and full isolated row count.",
        );
      const mountedRows = await page.getByTestId("pool-row").count();
      await page.getByRole("button", { name: "Filter", exact: true }).click();
      for (let i = 0; i < samples; i++) {
        const noRows = i % 2 === 0;
        await arm(page, "filter", noRows ? "empty" : "rows");
        await page
          .getByLabel("Min. Liquidität (USD)", { exact: true })
          .fill(noRows ? String(count * 200) : "0");
        filter.push(await finish(page));
      }
      // Leave a known populated state even for odd sample counts.
      await page.getByLabel("Min. Liquidität (USD)", { exact: true }).fill("0");
      await page.getByTestId("pool-row").first().waitFor();
      await page.keyboard.press("Escape");
      for (let i = 0; i < samples; i++) {
        const value = i % 2 ? "firstSeenAt:desc" : "liquidityUsd:desc";
        const [sortKey, direction] = value.split(":");
        const expected = await (
          await page.request.get(
            `${baseURL}/api/pools?page=1&pageSize=1&sort=${sortKey}&direction=${direction}`,
          )
        ).json();
        await arm(page, "sort", expected.rows[0].id);
        await page
          .getByLabel("Scanner-Sortierung", { exact: true })
          .selectOption(value);
        sort.push(await finish(page));
      }
      for (let i = 0; i < samples; i++) {
        const noRows = i % 2 === 0;
        await arm(page, "search", noRows ? "empty" : "rows");
        await page
          .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
          .fill(noRows ? "no-isolated-qa-match" : "");
        search.push(await finish(page));
      }
      await page
        .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
        .fill("");
      await page.getByTestId("pool-row").first().waitFor();
      for (let i = 0; i < samples; i++) {
        const row = page.getByTestId("pool-row").first();
        const title = await row
          .locator(".token-name")
          .textContent()
          .catch(() => null);
        const chosenId = await row.getAttribute("data-pool-id");
        const selected = initial.rows.find(
          (value: any) => value.id === chosenId,
        );
        if (!selected && !title)
          throw new Error("Could not identify visible detail target.");
        const selectedPool = selected?.poolId ?? chosenId?.split(":")[1];
        await db.query(
          "UPDATE source_cache SET updated_at=clock_timestamp() WHERE key=ANY($1::text[])",
          [
            ["1h", "24h", "7d"].map(
              (window) => `candles:${selectedPool}:${window}`,
            ),
          ],
        );
        await row.locator(".token-cell").click();
        const openDetail = page.getByRole("button", {
          name: "Vollständige Analyse",
          exact: true,
        });
        await openDetail.waitFor();
        await arm(page, "detail", selected?.name ?? title!.trim());
        await openDetail.click();
        detail.push(await finish(page));
        await page
          .getByRole("button", { name: "Zurück zum Scanner", exact: true })
          .click();
        await page.getByTestId("pool-row").first().waitFor();
      }
      await page.getByTestId("virtual-table").scrollIntoViewIfNeeded();
      const frames = await page.evaluate<{
        fps: number;
        p95FrameMs: number;
        frames: number;
        scrollRangePx: number;
        endScrollTopPx: number;
      }>(
        `new Promise(resolve=>{const el=document.querySelector('[data-testid="virtual-table"]'),gaps=[];let start=0,last=0,n=0;function tick(now){if(!start){start=now;last=now;}else gaps.push(now-last);last=now;n++;const elapsed=now-start;if(el)el.scrollTop=elapsed/1500*(el.scrollHeight-el.clientHeight);if(elapsed<1500)requestAnimationFrame(tick);else{gaps.sort((a,b)=>a-b);resolve({fps:(n-1)/(elapsed/1000),p95FrameMs:gaps[Math.ceil(gaps.length*.95)-1]||0,frames:n,scrollRangePx:el.scrollHeight-el.clientHeight,endScrollTopPx:el.scrollTop});}}requestAnimationFrame(tick);})`,
      );
      const metrics = await cdp.send("Performance.getMetrics");
      await collectLongTasks();
      const heap =
        metrics.metrics.find((metric) => metric.name === "JSHeapUsedSize")
          ?.value ?? null;
      const filterSummary = summarize(filter);
      const result = {
        rows: count,
        profile,
        pageSize: initial.rows.length,
        mountedRows,
        initialLoad: summarize(initialLoad),
        filter: filterSummary,
        sort: summarize(sort),
        search: summarize(search),
        detail: summarize(detail),
        longTasks: summarize(longTaskSamples),
        ...frames,
        jsHeapUsedMiB: heap === null ? null : heap / 1024 / 1024,
        completedRequestEncodedBytes: bytes,
        standardApiFirstPageJsonBytes: Buffer.byteLength(
          JSON.stringify(initial),
        ),
        browserErrors: errors,
        controlledFilterGate:
          profile === "desktop"
            ? filterSummary.p95Ms! < 200 &&
              errors.length === 0 &&
              mountedRows <= 50
              ? "PASS"
              : "FAIL"
            : "NOT APPLICABLE: throttled profile is diagnostic",
      };
      results.push(result);
      console.log(
        JSON.stringify({
          rows: count,
          profile,
          filterP95Ms: filterSummary.p95Ms,
          gate: result.controlledFilterGate,
        }),
      );
      await context.close();
    }
  }
  const report = {
    at: new Date().toISOString(),
    gate: results.every(
      (result) =>
        result.controlledFilterGate !== "FAIL" &&
        result.browserErrors.length === 0 &&
        result.mountedRows <= 50,
    )
      ? "PASS"
      : "FAIL",
    environment: {
      node: process.version,
      browser: browser.version(),
      database: name,
      build: "production",
      platform: `${os.platform()} ${os.release()} ${os.arch()}`,
      cpuModel: os.cpus()[0]?.model,
      logicalCpus: os.cpus().length,
      totalMemoryMiB: os.totalmem() / 1024 / 1024,
      backgroundLoad:
        process.env.ELITE_BACKGROUND_LOAD ||
        "No additional load profile injected; ordinary host background processes are not isolated.",
      network:
        "same-host loopback; mobile adds 150ms latency, 1.6Mbps down, 750kbps up and 4x CPU throttle",
      rows: counts,
    },
    methodology: {
      data: "Stable deterministic synthetic fixtures in separate _performance_test database only; visible TESTDATEN banner. Real paginated API requests; no full-list browser interception; external provider network isolated.",
      interaction:
        "DOM capture listener starts at actual input/change/click. First rAF after matching API response and expected DOM outcome stops timer. Includes React, debounce, server, response-cloning instrumentation and paint scheduling; excludes automation polling. Detail target name checked. Durations are interaction-to-frame proxies, not physical display latency; an open filter dialog may cover the list.",
      load: "Navigation start in automation to populated scanner plus two rAFs; first navigation cold per profile, later samples warm browser caches. Includes automation overhead; this is a task-specific first-usable-data proxy, not Core Web Vitals.",
      quantiles:
        "Nearest-rank empirical p50/p95/p99; raw ordered samples retained. Seven initial loads and twenty interactions by default; small-sample p99 is the maximum and is not a tail SLA.",
      resources:
        "Long Tasks API collected across the measured documents; JS heap is one CDP point-in-time reading, not peak process RAM. FPS from a 1.5s scripted scanner scroll after bringing the table into the viewport; scroll range and final offset retained as evidence of actual scrolling. Encoded bytes cover completed browser requests, excluding the open SSE connection. Standard API page JSON size is measured separately from the UI transport. Server resources and provider latency are outside this script.",
      acceptance:
        "Only unthrottled desktop standard liquidity filter p95 <200ms and mounted row count <=50 are gates. Mobile throttle is reported independently.",
    },
    results,
  };
  await writeFile(
    process.env.ELITE_REPORT || "reports/elite-performance.json",
    JSON.stringify(report, null, 2) + "\n",
  );
  if (report.gate !== "PASS") process.exitCode = 1;
} catch (error) {
  await writeFile(
    process.env.ELITE_REPORT || "reports/elite-performance.json",
    JSON.stringify(
      {
        at: new Date().toISOString(),
        gate: "FAIL",
        error: error instanceof Error ? error.message : String(error),
        results,
      },
      null,
      2,
    ) + "\n",
  );
  throw error;
} finally {
  await browser?.close();
  server.kill("SIGTERM");
  if (server.exitCode === null)
    await Promise.race([
      new Promise((resolve) => server.once("exit", resolve)),
      wait(5000),
    ]);
  if (server.exitCode === null) server.kill("SIGKILL");
  await db.end();
}
