import { chromium, firefox, webkit } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";

const results = [];
for (const [name, browserType] of Object.entries({
  chromium,
  firefox,
  webkit,
})) {
  let browser;
  try {
    browser = await browserType.launch(
      name === "chromium" && process.env.CHROMIUM_PATH
        ? { executablePath: process.env.CHROMIUM_PATH }
        : name === "webkit" && process.env.WEBKIT_PATH
          ? { executablePath: process.env.WEBKIT_PATH }
          : {},
    );
    const page = await browser.newPage();
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.setContent(
      '<main><h1>Browser capability probe</h1><button aria-label="Probe">Ready</button></main>',
    );
    await page.getByRole("button", { name: "Probe", exact: true }).click();
    const appUrl = process.env.BROWSER_PROBE_URL;
    let app =
      "NOT VERIFIED: set BROWSER_PROBE_URL for an application smoke test";
    let applicationSmokeError: string | undefined;
    if (appUrl) {
      try {
        await page.goto(appUrl, {
          waitUntil: "domcontentloaded",
          timeout: 15000,
        });
        await page
          .getByRole("heading", { name: "Live Scanner", exact: true })
          .waitFor({ timeout: 10000 });
        await page.getByTestId("pool-row").first().waitFor({ timeout: 10000 });
        app = errors.length ? "FAIL" : "PASS";
      } catch (error) {
        app = "FAIL";
        applicationSmokeError =
          error instanceof Error ? error.message : String(error);
      }
    }
    results.push({
      name,
      status: "PASS",
      version: browser.version(),
      executableSource:
        name === "webkit" && process.env.WEBKIT_PATH
          ? "Local wrapper with extracted signed Debian packages"
          : name === "chromium" && process.env.CHROMIUM_PATH
            ? "Explicit Chromium executable"
            : "Playwright managed browser",
      applicationSmoke: app,
      applicationSmokeError,
      errors,
    });
  } catch (error) {
    results.push({
      name,
      status: "BLOCKED",
      reason: error instanceof Error ? error.message : String(error),
    });
  } finally {
    await browser?.close();
  }
}
const report = {
  at: new Date().toISOString(),
  node: process.version,
  platform: `${process.platform}/${process.arch}`,
  installCommand: "npx playwright install --with-deps chromium firefox webkit",
  transportSecurity: "Existing proxy and CA trust retained; no TLS bypass.",
  scope:
    "Actual headless browser launches, DOM action and optional app smoke; full regression results are separate.",
  browsers: results,
};
await mkdir("reports", { recursive: true });
await writeFile(
  "reports/elite-browser-availability.json",
  JSON.stringify(report, null, 2) + "\n",
);
console.log(JSON.stringify(report, null, 2));
if (
  process.env.CI &&
  results.some(
    (row) =>
      row.status !== "PASS" ||
      ("applicationSmoke" in row && row.applicationSmoke === "FAIL"),
  )
)
  process.exitCode = 1;
