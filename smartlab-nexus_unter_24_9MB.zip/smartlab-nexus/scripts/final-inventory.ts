import { numericFieldContracts } from "../lib/data-field-inventory";
import { writeFile } from "node:fs/promises";
const introduction = `# Numerisches Datenfeld-Inventar · Version 1\n\nStand 24.10.2026. UI-Feldfamilien im aktuellen Scanner, Detail, Risk Lab, Wallet, Command, Analytics, Quality, Health, Listen und Alerts. Wildcards bezeichnen wiederholte gleichartige Felder. Konfigurationswerte sind keine Marktbeobachtungen. Numerische Supply/Amounts bleiben dezimale Strings. Die zwölf Markt- und alle acht Risikosignal-Schlüssel werden automatisch geprüft; Wildcard-Aggregate sind manuell inventarisiert, keine universelle statische Vollständigkeitsgarantie.\n\n`;
const text = numericFieldContracts
  .map(
    (c) =>
      `## ${c.fields.join(", ")}\n\n| Eigenschaft | Vertrag |\n|---|---|\n` +
      Object.entries(c)
        .filter(([k]) => k !== "fields")
        .map(([k, v]) => `| ${k} | ${String(v).replaceAll("|", "/")} |`)
        .join("\n"),
  )
  .join("\n\n");
await writeFile("DATA_FIELD_INVENTORY.md", introduction + text + "\n");
