import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { writeFile } from "node:fs/promises";
const exec = promisify(execFile),
  base = process.env.CHAOS_URL || "http://localhost:3000";
if (!["localhost", "127.0.0.1"].includes(new URL(base).hostname))
  throw new Error("Der Ausfalltest ist auf lokalen Betrieb beschränkt.");
const beforeResponse = await fetch(base + "/api/health");
if (!beforeResponse.ok)
  throw new Error("Vor dem Ausfalltest muss die lokale API erreichbar sein.");
const before = await beforeResponse.json();
if (!before.worker?.active)
  throw new Error("Vor dem Ausfalltest muss ein Worker aktiv sein.");
const result: Record<string, unknown> = {
  at: new Date().toISOString(),
  beforePools: before.counts?.pools,
};
try {
  await exec("docker", ["compose", "stop", "-t", "1", "postgres"]);
  const response = await fetch(base + "/api/health");
  const unavailable = await response.json();
  result.databaseDown = { httpStatus: response.status, mode: unavailable.mode };
  if (response.status !== 503 || unavailable.mode !== "offline")
    throw new Error("DB-Ausfall nicht korrekt angezeigt");
  const restartedAt = Date.now();
  await exec("docker", ["compose", "start", "postgres"]);
  let recovered: any = null;
  while (Date.now() - restartedAt < 60000) {
    try {
      const response = await fetch(base + "/api/health");
      if (response.ok) {
        const h = await response.json();
        if (h.worker?.active && Date.parse(h.worker.lastCycle) > restartedAt) {
          recovered = h;
          break;
        }
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 1000));
  }
  if (!recovered)
    throw new Error("Worker ist nicht innerhalb von 60s wieder angelaufen");
  result.recovery = {
    elapsedMs: Date.now() - restartedAt,
    pools: recovered.counts.pools,
    workerStatus: recovered.worker.status,
    lastCycle: recovered.worker.lastCycle,
    providerMode: recovered.mode,
  };
  if (recovered.counts.pools < before.counts.pools)
    throw new Error("Persistierte Pools fehlen nach Neustart");
  let standbyCode = 0;
  try {
    await exec("npm", ["run", "worker:once"]);
  } catch (e) {
    standbyCode = Number((e as any).code);
  }
  const after = await (await fetch(base + "/api/health")).json();
  result.standby = {
    exitCode: standbyCode,
    activeWorkerStatus: after.worker?.status,
    active: after.worker?.active,
  };
  if (
    standbyCode !== 1 ||
    !after.worker?.active ||
    ["starting", "stopped"].includes(after.worker.status)
  )
    throw new Error("Standby-Worker hat aktive Health-Daten überschrieben");
  result.status = "passed";
} catch (e) {
  result.status = "failed";
  result.error = (e as Error).message;
  process.exitCode = 1;
} finally {
  await exec("docker", ["compose", "start", "postgres"]).catch(() => {});
  await writeFile("reports/chaos-db.json", JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
}
