import bs58 from "bs58";
import type pg from "pg";
import { observation } from "../tests/helpers";
import { scoreRisk } from "../lib/risk";

/** Only scripts that have already selected an explicitly isolated database may seed. */
export function isolatedDatabase(value: string | undefined, purpose: string) {
  if (!value)
    throw new Error(`${purpose}: explicit test database URL required.`);
  const url = new URL(value);
  if (!/^postgres(?:ql)?:$/.test(url.protocol))
    throw new Error(`${purpose}: PostgreSQL URL required.`);
  const name = decodeURIComponent(url.pathname.slice(1));
  if (!/^[a-zA-Z0-9_]+_test$/.test(name))
    throw new Error(`${purpose}: database name must end in _test.`);
  if (process.env.NEXUS_TEST_MODE !== "true")
    throw new Error(`${purpose}: NEXUS_TEST_MODE=true is required.`);
  return { url, name };
}

export async function seedEliteFixtures(db: pg.Pool, count: number) {
  const actual = (await db.query("SELECT current_database() AS name")).rows[0]
    .name as string;
  if (
    !/^[a-zA-Z0-9_]+_test$/.test(actual) ||
    process.env.NEXUS_TEST_MODE !== "true"
  )
    throw new Error("Refusing fixtures outside an isolated _test database.");
  if (!Number.isInteger(count) || count < 201 || count > 10000)
    throw new Error("Fixture count must be 201–10000.");
  await db.query(
    "TRUNCATE tokens,events,sessions,discoveries,chain_candidates,metrics,source_cache,provider_states,source_audits,worker_state RESTART IDENTITY CASCADE",
  );
  const now = new Date().toISOString();
  const base = observation({
    name: "Isolierte QA-Fixture",
    symbol: "QA",
    priceUsd: 1,
    liquidityUsd: 100000,
  });
  base.provenance = {
    ...base.provenance,
    endpoint: "isolated-qa-fixture; not current market data",
    fetchedAt: now,
    sourceAt: now,
  };
  for (let start = 0; start < count; start += 500) {
    const rows = Array.from(
      { length: Math.min(500, count - start) },
      (_, j) => {
        const index = start + j;
        const bytes = Buffer.alloc(32, 19);
        bytes.writeUInt32BE(index + 1);
        const mint = bs58.encode(bytes);
        const poolBytes = Buffer.alloc(32, 11);
        poolBytes.writeUInt32BE(index + 1);
        const poolId = bs58.encode(poolBytes);
        const selected = {
          ...base,
          mint,
          poolId,
          id: `${mint}:${poolId}`,
          name: `Isolierter QA Token ${String(index).padStart(5, "0")}`,
          symbol: `QA${index}`,
          priceUsd: 1 + index / 1000,
          liquidityUsd: 1000 + index * 100,
          volume5m: index * 10,
        };
        return {
          mint,
          id: selected.id,
          pool_id: poolId,
          name: selected.name,
          symbol: selected.symbol,
          selected,
          risk: scoreRisk(selected, null, [selected]),
          // Distinct, deterministic ordering prevents equal-timestamp page drift.
          first_seen_at: new Date(Date.parse(now) - index * 1000).toISOString(),
        };
      },
    );
    await db.query(
      "INSERT INTO tokens(mint,name,symbol,first_seen_at) SELECT mint,name,symbol,first_seen_at FROM jsonb_to_recordset($1::jsonb) x(mint text,name text,symbol text,first_seen_at timestamptz)",
      [JSON.stringify(rows)],
    );
    await db.query(
      "INSERT INTO pools(id,mint,pool_id,selected,risk,first_seen_at) SELECT id,mint,pool_id,selected,risk,first_seen_at FROM jsonb_to_recordset($1::jsonb) x(id text,mint text,pool_id text,selected jsonb,risk jsonb,first_seen_at timestamptz)",
      [JSON.stringify(rows)],
    );
    await db.query(
      "INSERT INTO observations(pool_key,provider,source_at,fetched_at,payload) SELECT id,selected->'provenance'->>'provider',$2::timestamptz,$2::timestamptz,selected FROM jsonb_to_recordset($1::jsonb) x(id text,selected jsonb)",
      [JSON.stringify(rows), now],
    );
    // Explicitly empty candle fixtures avoid inventing financial history.
    await db.query(
      "INSERT INTO source_cache(key,data) SELECT 'candles:'||pool_id||':'||window_name,$2::jsonb FROM jsonb_to_recordset($1::jsonb) x(pool_id text) CROSS JOIN unnest(ARRAY['1h','24h','7d']) AS windows(window_name)",
      [
        JSON.stringify(rows),
        JSON.stringify({
          candles: [],
          source: "isolated-qa-fixture",
          coverage: "No market candles in QA fixtures.",
        }),
      ],
    );
  }
  await db.query("ANALYZE pools");
  return { count, distinctPools: count, database: actual };
}
