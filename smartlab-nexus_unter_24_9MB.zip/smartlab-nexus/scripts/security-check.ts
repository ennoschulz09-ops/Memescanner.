import { readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
const roots = ["app", "components", "lib", "worker"];
const forbidden = [
  /\b(?:sendTransaction|sendRawTransaction|signTransaction|signAllTransactions|signMessage|requestAirdrop)\s*\(/i,
  /\b(?:privateKey|secretKey|seedPhrase|mnemonic)\b/i,
  /@solana\/wallet-adapter|walletconnect|wallet-connect|window\.solana|jupiter\/swap|\/api\/(?:swap|trade|order|execute)/i,
  />\s*(?:BUY|SELL|SWAP|Kaufen|Verkaufen|Auto-Trading)\s*</i,
  /dangerouslySetInnerHTML|eval\s*\(|new Function\s*\(/,
];
async function files(root: string): Promise<string[]> {
  return (
    await Promise.all(
      (await readdir(root, { withFileTypes: true })).map((d) =>
        d.isDirectory()
          ? files(path.join(root, d.name))
          : Promise.resolve([path.join(root, d.name)]),
      ),
    )
  ).flat();
}
const findings: { file: string; rule: string }[] = [];
const lock = JSON.parse(await readFile("package-lock.json", "utf8"));
for (const name of Object.keys(lock.packages ?? {}))
  if (
    /wallet[-/]adapter|walletconnect|@jup-ag\/(api|core)|@raydium-io\/raydium-sdk/i.test(
      name,
    )
  )
    findings.push({
      file: "package-lock.json",
      rule: "Forbidden transitive dependency: " + name,
    });
const pkg = JSON.parse(await readFile("package.json", "utf8"));
for (const name of Object.keys({ ...pkg.dependencies, ...pkg.devDependencies }))
  if (
    /wallet[-/]adapter|walletconnect|@jup-ag\/(api|core)|@raydium-io\/raydium-sdk/i.test(
      name,
    )
  )
    findings.push({
      file: "package.json",
      rule: "Forbidden wallet/order dependency: " + name,
    });
let scanned = 0;
for (const root of roots)
  for (const file of await files(root))
    if (/\.(tsx?|jsx?)$/.test(file)) {
      const code = await readFile(file, "utf8");
      scanned++;
      for (const pattern of forbidden)
        if (pattern.test(code)) findings.push({ file, rule: pattern.source });
    }
const rpc = await readFile("lib/providers/solana.ts", "utf8");
const allowlist = [
  "getHealth",
  "getAccountInfo",
  "getTokenLargestAccounts",
  "getBalance",
  "getTokenAccountsByOwner",
  "getSignaturesForAddress",
  "getTransaction",
];
const extracted =
  /const allowed = \[([\s\S]*?)\];/
    .exec(rpc)?.[1]
    .match(/"[A-Za-z0-9]+"/g)
    ?.map((x) => JSON.parse(x)) ?? [];
const exactAllowlist =
  JSON.stringify(extracted.slice().sort()) ===
  JSON.stringify(allowlist.slice().sort());
if (!exactAllowlist)
  findings.push({
    file: "lib/providers/solana.ts",
    rule: "Read-only RPC allowlist drift",
  });
for (const root of [...roots, "scripts"])
  for (const file of await files(root)) {
    if (file.endsWith("security-check.ts") || !/\.(tsx?|jsx?|mjs)$/.test(file))
      continue;
    const code = await readFile(file, "utf8");
    if (
      /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{36,}|\bAKIA[A-Z0-9]{16}\b/.test(
        code,
      )
    )
      findings.push({
        file,
        rule: "Potential embedded credential (value redacted)",
      });
  }
const report = {
  at: new Date().toISOString(),
  scanned,
  exactAllowlist,
  secretScan:
    "Source and scripts; known credential formats only, no external git history in ZIP",
  findings,
  rpcAllowlist: allowlist,
  allowlistGuardPresent: rpc.includes("allowed.includes(method)"),
  limits:
    "Static search and allowlist inspection; does not replace an external penetration test.",
};
await writeFile("reports/security.json", JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
if (findings.length || !report.allowlistGuardPresent) process.exitCode = 1;
