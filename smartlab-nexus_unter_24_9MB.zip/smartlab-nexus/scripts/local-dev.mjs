import { spawn } from "node:child_process";
const migration = spawn("npm", ["run", "db:migrate"], { stdio: "inherit" });
const code = await new Promise((r) => migration.on("exit", r));
if (code) process.exit(Number(code) || 1);
const processes = ["worker", "dev"].map((name) =>
  spawn("npm", ["run", name], {
    stdio: "inherit",
    detached: process.platform !== "win32",
  }),
);
let stopping = false;
function stop() {
  if (stopping) return;
  stopping = true;
  for (const child of processes)
    try {
      process.platform === "win32"
        ? child.kill("SIGTERM")
        : process.kill(-child.pid, "SIGTERM");
    } catch {}
}
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
await Promise.race(
  processes.map((child) => new Promise((r) => child.on("exit", r))),
);
stop();
