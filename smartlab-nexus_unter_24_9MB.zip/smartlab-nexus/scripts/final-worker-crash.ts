import { readFile, open, writeFile } from "node:fs/promises";
import { spawn } from "node:child_process";
import { db } from "../lib/db";
const pid = Number(process.env.CRASH_WORKER_PID);
if (!Number.isInteger(pid) || pid <= 1)
  throw Error("Set CRASH_WORKER_PID to the local worker process only");
const args = await readFile(`/proc/${pid}/cmdline`, "utf8");
if (!args.includes("worker/index.ts"))
  throw Error("Target is not the local NEXUS worker");
const result: Record<string, unknown> = {
  startedAt: new Date().toISOString(),
  killedPid: pid,
  method:
    "SIGKILL plus explicit new process; not an automatic supervisor claim",
};
try {
  const before = (await db.query("SELECT count(*)::int AS n FROM pools"))
    .rows[0].n;
  process.kill(pid, "SIGKILL");
  const started = Date.now();
  const log = await open("reports/final-restarted-worker.log", "a");
  const child = spawn(
    process.execPath,
    ["node_modules/tsx/dist/cli.mjs", "worker/index.ts"],
    { detached: true, env: process.env, stdio: ["ignore", log.fd, log.fd] },
  );
  child.unref();
  await log.close();
  result.restartedPid = child.pid;
  let recovered = false;
  while (Date.now() - started < 60000) {
    const w = (
      await db.query("SELECT heartbeat,data FROM worker_state WHERE id=1")
    ).rows[0];
    if (
      w &&
      new Date(w.heartbeat).getTime() > started &&
      !["starting", "stopped", "error"].includes(w.data.status)
    ) {
      result.worker = w;
      recovered = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  const after = (await db.query("SELECT count(*)::int AS n FROM pools")).rows[0]
    .n;
  result.poolsBefore = before;
  result.poolsAfter = after;
  result.recoveryMs = Date.now() - started;
  result.status = recovered && after >= before ? "PASS" : "FAIL";
  if (result.status !== "PASS") process.exitCode = 1;
} finally {
  await writeFile(
    "reports/final-worker-recovery.json",
    JSON.stringify(result, null, 2),
  );
  await db.end();
}
