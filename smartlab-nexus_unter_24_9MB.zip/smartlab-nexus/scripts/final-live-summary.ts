import { db } from "../lib/db";
import { writeFile, readFile } from "node:fs/promises";
import { getChainQueueHealth } from "../lib/chain-queue";
try {
  const started = (await db.query("SELECT min(at) AS at FROM source_audits"))
    .rows[0].at;
  const audits = (
    await db.query(
      "SELECT provider,endpoint,status,ok,count(*)::int AS n FROM source_audits GROUP BY provider,endpoint,status,ok ORDER BY provider,endpoint,status",
    )
  ).rows;
  const events = (
    await db.query(
      `SELECT signature,slot,observed_at,admitted_at,attempted_at,fetched_at,decoded_at,processed_at,event_at,status,from_replay FROM chain_candidates ORDER BY observed_at DESC LIMIT 100`,
    )
  ).rows;
  const timings = (
    await db.query(
      `SELECT count(*)::int AS n,percentile_cont(.5) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(processed_at-event_at))*1000) AS p50_ms,percentile_cont(.95) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(processed_at-event_at))*1000) AS p95_ms,percentile_cont(.99) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(processed_at-event_at))*1000) AS p99_ms FROM chain_candidates WHERE status='decoded' AND event_at IS NOT NULL AND processed_at>=event_at AND NOT from_replay`,
    )
  ).rows[0];
  const ui = (
    await db.query(
      `SELECT count(DISTINCT q.signature)::int AS n,percentile_cont(.95) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(r.rendered_at-q.event_at))*1000) AS p95_ms FROM chain_candidates q JOIN chain_ui_receipts r USING(signature) WHERE r.rendered_state='decoded' AND q.status='decoded' AND NOT q.from_replay AND q.event_at IS NOT NULL AND r.rendered_at>=q.event_at`,
    )
  ).rows[0];
  const restart = await readFile("reports/final-worker-recovery.json", "utf8")
    .then(JSON.parse)
    .catch(() => null);
  const finalBuildStartedAt =
    process.env.FINAL_BUILD_STARTED_AT || restart?.startedAt || null;
  const finalBuildEvents = events.filter(
    (e) =>
      e.status === "decoded" &&
      !e.from_replay &&
      finalBuildStartedAt &&
      new Date(e.observed_at).getTime() >= Date.parse(finalBuildStartedAt),
  );
  const stagePairs = [
    ["event_to_ws", "event_at", "observed_at"],
    ["ws_to_admission", "observed_at", "admitted_at"],
    ["admission_to_rpc", "admitted_at", "attempted_at"],
    ["rpc_fetch", "attempted_at", "fetched_at"],
    ["fetch_to_decode", "fetched_at", "decoded_at"],
    ["decode_to_completion_timestamp", "decoded_at", "processed_at"],
  ];
  const stageTimings = stagePairs.map(([stage, a, b]) => {
    const values = events
      .filter((e) => e.status === "decoded" && !e.from_replay && e[a] && e[b])
      .map((e) => new Date(e[b]).getTime() - new Date(e[a]).getTime());
    const sorted = values
      .filter((v) => v >= 0 && Number.isFinite(v))
      .sort((a, b) => a - b);
    const q = (p: number) =>
      sorted.length ? sorted[Math.ceil(sorted.length * p) - 1] : null;
    return {
      stage,
      n: sorted.length,
      p50_ms: q(0.5),
      p95_ms: q(0.95),
      p99_ms: q(0.99),
      negativeClockSamples: values.filter((v) => v < 0).length,
      scope:
        "all observed build phases; completion timestamp precedes COMMIT acknowledgement",
    };
  });
  const publishToDom = (
    await db.query(
      `SELECT rendered_state,count(*)::int AS n,percentile_cont(.5) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(rendered_at-published_at))*1000) AS p50_ms,percentile_cont(.95) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(rendered_at-published_at))*1000) AS p95_ms,percentile_cont(.99) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM(rendered_at-published_at))*1000) AS p99_ms FROM chain_ui_receipts WHERE rendered_state IN ('candidate','decoded') GROUP BY rendered_state`,
    )
  ).rows;
  const report = {
    at: new Date().toISOString(),
    startedAt: started,
    status: "PARTIAL",
    mainnet: true,
    audits,
    queue: await getChainQueueHealth(),
    timings,
    stageTimings,
    ui: {
      ...ui,
      scope: "Includes historical catch-up; not live chain-to-UI latency",
    },
    publishToDom,
    finalBuild: {
      startedAt: finalBuildStartedAt,
      decodedLiveEvents: finalBuildEvents.length,
      chainToUiStatus:
        "NOT VERIFIED: observer presence at event time and long-term tails unproven",
    },
    events,
    costs: { status: "unknown", totalUsd: null },
    coverage:
      "Raydium CPMM initialize only; no universal coverage; no new mint assertion",
    limits: [
      "Short local run; multi-hour and 24h NOT VERIFIED",
      "blockTime precision 1s, host/provider clock offset unknown",
      "Browser receipt self-reported; p95 with small N is no SLA",
      "Historical catch-up UI rendering must not be called live latency; build-phase boundaries are explicit",
    ],
  };
  await writeFile("reports/final-live.json", JSON.stringify(report, null, 2));
  console.log(
    JSON.stringify({ status: report.status, timings, ui, queue: report.queue }),
  );
} finally {
  await db.end();
}
