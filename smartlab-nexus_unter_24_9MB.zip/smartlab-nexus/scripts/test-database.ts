import pg from "pg";
const url = new URL(
  process.env.TEST_DATABASE_URL ||
    "postgresql://nexus:nexus_local_only@localhost:5432/nexus_test",
);
const name = url.pathname.slice(1);
if (!/^[a-zA-Z0-9_]+_test$/.test(name))
  throw new Error("Testdatenbankname muss auf _test enden.");
url.pathname = "/postgres";
const pool = new pg.Pool({ connectionString: url.toString() });
try {
  if (
    !(
      await pool.query("SELECT datname FROM pg_database WHERE datname=$1", [
        name,
      ])
    ).rowCount
  )
    await pool.query(`CREATE DATABASE "${name}"`);
  console.log("Getrennte Testdatenbank bereit.");
} finally {
  await pool.end();
}
