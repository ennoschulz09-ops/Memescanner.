import { writeFile } from "node:fs/promises";
import { chromium } from "@playwright/test";
import bs58 from "bs58";
import { observation } from "../tests/helpers";
import { scoreRisk } from "../lib/risk";
import { filterPools, sortPools } from "../lib/filters";
import type { PoolRow } from "../lib/domain";
const results: Record<string, unknown>[] = [];
const base = observation({ priceUsd: 0.001, liquidityUsd: 50000 });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox", "--enable-precise-memory-info"],
});
try {
  for (const count of [1000, 5000, 10000]) {
    const rows: PoolRow[] = Array.from({ length: count }, (_, i) => {
      const b = Buffer.alloc(32, 3);
      b.writeUInt32BE(i + 1);
      const mint = bs58.encode(b);
      const o = {
        ...base,
        id: mint + ":" + base.poolId,
        mint,
        symbol: "T" + i,
        name: "Benchmark Token " + i,
        priceUsd: 0.001 + i * 0.000001,
        liquidityUsd: 1000 + i * 100,
        volume5m: i * 10,
      };
      return {
        ...o,
        firstSeenAt: base.provenance.fetchedAt,
        updatedAt: base.provenance.fetchedAt,
        risk: scoreRisk(o, null, [o]),
        sources: [o],
        sparkline: [],
      };
    });
    const times: number[] = [];
    for (let i = 0; i < 30; i++) {
      const start = performance.now();
      sortPools(
        filterPools(rows, {
          minLiquidity: 10000,
          query: i % 2 ? "Benchmark" : "T9",
        }),
        "liquidityUsd",
        "desc",
      );
      times.push(performance.now() - start);
    }
    times.sort((a, b) => a - b);
    const page = await browser.newPage({
      viewport: { width: 1512, height: 982 },
    });
    let lastFilterCalculationMs: number | null = null;
    await page.route("**/api/**", async (route) => {
      const p = new URL(route.request().url()).pathname;
      const payload = p.endsWith("/session")
        ? { authorized: true, settings: {} }
        : p.endsWith("/pools")
          ? { rows, at: new Date().toISOString() }
          : p.endsWith("/watchlists")
            ? { lists: [] }
            : p.endsWith("/presets")
              ? { presets: [] }
              : p.endsWith("/health")
                ? {
                    mode: "degraded",
                    dataMode: "test-only",
                    providers: [],
                    counts: {
                      pools: count,
                      tokens: count,
                      new1: 0,
                      new5: 0,
                      new15: 0,
                      stale: 0,
                      last_update: new Date().toISOString(),
                    },
                    worker: null,
                    metrics: [],
                    budgets: [],
                    at: new Date().toISOString(),
                  }
                : p.endsWith("/discoveries")
                  ? { tokens: [] }
                  : {};
      if (p.endsWith("/stream"))
        return route.fulfill({
          contentType: "text/event-stream",
          body: 'event: status\ndata: {"transport":"connected","sourceMode":"benchmark"}\n\n',
        });
      if (p.endsWith("/metrics")) {
        const body = route.request().postDataJSON();
        const sample = (body?.samples ?? [body])
          .filter((s: any) => s?.stage === "filter")
          .at(-1);
        if (sample) lastFilterCalculationMs = sample.durationMs;
      }
      return route.fulfill({
        contentType: "application/json",
        body: JSON.stringify(payload),
      });
    });
    const start = performance.now();
    await page.goto(process.env.BENCH_URL || "http://localhost:3000");
    await page.getByTestId("pool-row").first().waitFor();
    const firstInteractiveDataMs = performance.now() - start;
    const mountedRows = await page.getByTestId("pool-row").count();
    const filterStart = performance.now();
    await page
      .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
      .fill("definitely-no-result");
    await page.getByText("Keine passenden Pools").waitFor();
    const searchToPaintMs = performance.now() - filterStart;
    await page
      .getByRole("main")
      .getByRole("button", { name: "Suche zurücksetzen" })
      .click();
    await page.getByTestId("pool-row").first().waitFor();
    // String evaluation keeps tsx/esbuild's Node-side function-name helper out of browser code.
    const frames = await page.evaluate<{
      fps: number;
      p95FrameMs: number;
      frames: number;
    }>(`new Promise(resolve=>{
      const el=document.querySelector('[data-testid="virtual-table"]'),gaps=[];let start=0,last=0,frames=0;
      function next(now){if(!start){start=now;last=now;}if(now>last)gaps.push(now-last);last=now;frames++;
        const t=now-start;el.scrollTop=t/1500*(el.scrollHeight-el.clientHeight);
        if(t<1500)requestAnimationFrame(next);else{gaps.sort((a,b)=>a-b);resolve({fps:frames/(t/1000),p95FrameMs:gaps[Math.floor(gaps.length*.95)]||0,frames});}}
      requestAnimationFrame(next);
    })`);
    const cdp = await page.context().newCDPSession(page);
    await cdp.send("Performance.enable");
    const m = await cdp.send("Performance.getMetrics");
    const heap =
      m.metrics.find((x) => x.name === "JSHeapUsedSize")?.value ?? null;
    const paints = await page.evaluate(() => ({
      firstPaintMs:
        performance.getEntriesByName("first-paint")[0]?.startTime ?? null,
      firstContentfulPaintMs:
        performance.getEntriesByName("first-contentful-paint")[0]?.startTime ??
        null,
    }));
    results.push({
      rows: count,
      ...paints,
      payloadBytes: Buffer.byteLength(JSON.stringify(rows)),
      calculationP50Ms: times[15],
      calculationP95Ms: times[28],
      calculationP99Ms: times[29],
      firstInteractiveDataMs,
      searchToPaintMs,
      filterCalculationMs: lastFilterCalculationMs,
      mountedRows,
      ...frames,
      jsHeapUsedMB: heap === null ? null : heap / 1024 / 1024,
    });
    await page.close();
  }
  const report = {
    browserVersion: await browser.version(),
    nodeVersion: process.version,
    buildMode: process.env.BENCH_BUILD_MODE ?? "unspecified",
    at: new Date().toISOString(),
    environment:
      "Local headless Chromium, 1512×982, synthetic intercepted browser responses only; no fixture inserted into PostgreSQL.",
    measurement:
      "First interactive data is a task-specific TTI proxy. Search-to-paint includes the 180 ms debounce and Playwright overhead. FPS is a 1.5-second scripted virtual-table scroll; memory is a point-in-time Chromium JS heap, not process peak RSS.",
    results,
  };
  await writeFile("reports/performance.json", JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  if (results.some((r) => Number(r.mountedRows) > 50)) process.exitCode = 1;
} finally {
  await browser.close();
}
