import { chromium } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
const root = process.env.SCREENSHOT_DIR || "reports/final-after";
await mkdir(root, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH,
  args: ["--no-sandbox"],
});
const shots = [];
try {
  for (const [device, width, height] of [
    ["desktop", 1512, 982],
    ["tablet", 834, 1194],
    ["mobile", 390, 844],
  ] as const) {
    const page = await browser.newPage({
      viewport: { width, height },
      isMobile: device === "mobile",
      hasTouch: device !== "desktop",
    });
    for (const view of ["command", "scanner", "token"]) {
      await page.goto("http://localhost:3000/?view=scanner");
      await page.getByTestId("pool-row").first().waitFor();
      const data = await (
        await page.request.get(
          "http://localhost:3000/api/pools?page=1&pageSize=1",
        )
      ).json();
      const row = data.rows[0];
      await page.goto(
        "http://localhost:3000/?view=" +
          view +
          (view === "token" ? `&mint=${row.mint}&pool=${row.poolId}` : ""),
      );
      if (view === "scanner")
        await page.getByTestId("pool-row").first().waitFor();
      if (view === "command")
        await page.getByTestId("pipeline-summary").waitFor();
      if (view === "token")
        await page.getByText("Datenherkunft", { exact: true }).waitFor();
      await page.waitForTimeout(500);
      const path = `${root}/${device}-${view}.png`;
      await page.screenshot({ path, fullPage: true });
      shots.push(path);
    }
    await page.close();
  }
  await writeFile(
    `${root}/manifest.json`,
    JSON.stringify(
      {
        at: new Date().toISOString(),
        data: "ISOLATED synthetic fixtures, not live market data",
        shots,
      },
      null,
      2,
    ),
  );
} finally {
  await browser.close();
}
