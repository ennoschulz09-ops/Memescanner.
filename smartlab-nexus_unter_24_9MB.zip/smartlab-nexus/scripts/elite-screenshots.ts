import { chromium } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
const root = "reports/elite-screens";
await mkdir(root, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const shots: string[] = [];
try {
  for (const [device, viewport] of [
    ["desktop", { width: 1512, height: 982 }],
    ["mobile", { width: 390, height: 844 }],
  ] as const) {
    const context = await browser.newContext({
      baseURL: "http://localhost:3000",
      viewport,
      isMobile: device === "mobile",
      hasTouch: device === "mobile",
    });
    const page = await context.newPage();
    await page.goto("http://localhost:3000");
    await page.getByTestId("pool-row").first().waitFor();
    const data = await (
      await page.request.get("/api/pools?page=1&pageSize=1")
    ).json();
    const token = data.rows[0];
    if (!token) throw Error("Real app data required for screenshots");
    await page.request.post("/api/watchlists/items", {
      headers: { origin: "http://localhost:3000" },
      data: { mint: token.mint },
    });
    for (const [name, url, heading] of [
      ["command", "/?view=command", "Command Dashboard"],
      ["radar", "/?view=scanner", "Live Scanner"],
      [
        "intelligence",
        `/?view=token&mint=${token.mint}&pool=${token.poolId}`,
        "Token-Analyse",
      ],
      ["watchlists", "/?view=watchlists", "Watchlists"],
      ["health", "/?view=health", "System Health"],
    ] as const) {
      await page.goto("http://localhost:3000" + url);
      await page.getByRole("heading", { name: heading, exact: true }).waitFor();
      if (name === "radar")
        await page.getByTestId("pool-row").first().waitFor();
      if (name === "intelligence")
        await page.getByText("Datenherkunft", { exact: true }).waitFor();
      if (name === "command")
        await page.getByTestId("pipeline-summary").waitFor();
      if (name === "health")
        await page
          .getByText("Quell-Audits · letzte Anfragen", { exact: true })
          .waitFor();
      await page.waitForTimeout(350);
      const path = `${root}/${device}-${name}.png`;
      await page.screenshot({ path, fullPage: true });
      shots.push(path);
    }
    await context.close();
  }
  await writeFile(
    `${root}/manifest.json`,
    JSON.stringify(
      {
        at: new Date().toISOString(),
        data: "Actual built application and real public-provider observations; dedicated browser-session watchlist only, no live-table fixtures",
        shots,
      },
      null,
      2,
    ),
  );
} finally {
  await browser.close();
}
