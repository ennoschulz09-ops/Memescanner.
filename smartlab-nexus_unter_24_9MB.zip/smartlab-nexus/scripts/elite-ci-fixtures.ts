import pg from "pg";
import { mkdir, writeFile } from "node:fs/promises";
import { isolatedDatabase, seedEliteFixtures } from "./elite-fixtures";

const { url, name } = isolatedDatabase(
  process.env.CI_TEST_DATABASE_URL,
  "CI fixtures",
);
const adminUrl = new URL(url);
adminUrl.pathname = "/postgres";
const admin = new pg.Pool({ connectionString: adminUrl.toString() });
try {
  if (
    !(await admin.query("SELECT 1 FROM pg_database WHERE datname=$1", [name]))
      .rowCount
  )
    await admin.query(`CREATE DATABASE "${name}"`);
} finally {
  await admin.end();
}
process.env.DATABASE_URL = url.toString();
const { db, migrate } = await import("../lib/db");
try {
  await migrate();
  const seeded = await seedEliteFixtures(db, 240);
  await mkdir("reports", { recursive: true });
  const report = {
    at: new Date().toISOString(),
    ...seeded,
    testMode: true,
    realProviderRequests: 0,
    purpose: "Isolated deterministic CI data; never current market data.",
  };
  await writeFile(
    "reports/elite-ci-fixtures.json",
    JSON.stringify(report, null, 2) + "\n",
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  await db.end();
}
