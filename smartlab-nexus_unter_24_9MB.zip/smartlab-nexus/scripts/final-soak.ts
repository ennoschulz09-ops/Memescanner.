/** Read-only observer of a real app + worker. Never seeds data or resets budgets. */
import { db } from "../lib/db";
import { getChainQueueHealth } from "../lib/chain-queue";
import { writeFile } from "node:fs/promises";
const seconds = Number(process.env.SOAK_SECONDS ?? 86400);
if (!Number.isInteger(seconds) || seconds < 60 || seconds > 172800)
  throw Error("SOAK_SECONDS must be 60..172800");
const startedAt = new Date().toISOString(),
  until = Date.now() + seconds * 1000;
const samples: unknown[] = [];
let interrupted = false;
process.on("SIGINT", () => {
  interrupted = true;
});
process.on("SIGTERM", () => {
  interrupted = true;
});
try {
  do {
    const at = new Date().toISOString();
    try {
      const [worker, errors, metrics, alerts] = await Promise.all([
        db.query("SELECT heartbeat,data FROM worker_state WHERE id=1"),
        db.query(
          "SELECT provider,status,ok,count(*)::int AS n FROM source_audits WHERE at >= $1 GROUP BY provider,status,ok",
          [startedAt],
        ),
        db.query(
          `SELECT stage,count(*)::int AS n,percentile_cont(.5) WITHIN GROUP(ORDER BY duration_ms) AS p50_ms,percentile_cont(.95) WITHIN GROUP(ORDER BY duration_ms) AS p95_ms,percentile_cont(.99) WITHIN GROUP(ORDER BY duration_ms) AS p99_ms FROM metrics WHERE at >= $1 GROUP BY stage`,
          [startedAt],
        ),
        db.query(
          "SELECT trigger_state,delivery_state,count(*)::int AS n FROM alert_events WHERE at >= $1 GROUP BY trigger_state,delivery_state",
          [startedAt],
        ),
      ]);
      const w = worker.rows[0];
      samples.push({
        at,
        status:
          w &&
          Date.now() - new Date(w.heartbeat).getTime() < 150000 &&
          !["error", "stopped"].includes(w.data.status)
            ? "observed"
            : "worker-unavailable",
        worker: w ?? null,
        queue: await getChainQueueHealth(),
        providers: errors.rows,
        metrics: metrics.rows,
        alerts: alerts.rows,
        observerMemory: process.memoryUsage(),
      });
    } catch {
      samples.push({ at, status: "database-unavailable" });
    }
    await writeFile(
      process.env.SOAK_REPORT || "reports/final-soak.json",
      JSON.stringify(
        {
          startedAt,
          updatedAt: at,
          plannedSeconds: seconds,
          elapsedSeconds: (Date.now() - Date.parse(startedAt)) / 1000,
          status: interrupted
            ? "INTERRUPTED"
            : Date.now() >= until
              ? "COMPLETED"
              : "RUNNING",
          samples,
          costs: "UNKNOWN: no billing source",
          limits:
            "Read-only local observer; worker RSS needs external process monitor. Complete elapsed time does not imply healthy uptime; inspect all samples. No universal feed coverage.",
        },
        null,
        2,
      ),
    );
    if (Date.now() >= until || interrupted) break;
    await new Promise((r) =>
      setTimeout(r, Math.min(30000, until - Date.now())),
    );
  } while (true);
} finally {
  await db.end();
}
