import pg from "pg";
import { writeFile } from "node:fs/promises";
const app = new URL(
  process.env.DATABASE_URL ||
    "postgresql://nexus:nexus_local_only@localhost:5432/nexus",
);
const url = new URL(process.env.ELITE_DATABASE_URL || app);
if (!process.env.ELITE_DATABASE_URL)
  url.pathname = "/nexus_elite_performance_test";
if (
  !/^[a-zA-Z0-9_]+_performance_test$/.test(url.pathname.slice(1)) ||
  (url.host === app.host && url.pathname === app.pathname)
)
  throw Error(
    "Query profiling requires a distinct _performance_test database seeded by bench:elite.",
  );
const pool = new pg.Pool({ connectionString: url.toString() });
try {
  const name = (await pool.query("SELECT current_database() AS name")).rows[0]
    .name;
  if (name !== url.pathname.slice(1)) throw Error("Unexpected database");
  const count = (await pool.query("SELECT count(*)::int AS n FROM pools"))
    .rows[0].n;
  if (count !== 10000)
    throw Error(
      "Run the complete bench:elite first; expected10000 isolated pools.",
    );
  const queries: {
    label: string;
    rank: string;
    where: string;
    parameters: (string | number)[];
  }[] = [
    {
      label: "standard first-seen page",
      rank: "p.first_seen_at",
      where: "",
      parameters: [],
    },
    {
      label: "standard liquidity filter",
      rank: "p.first_seen_at",
      where: "WHERE (p.selected->>'liquidityUsd')::double precision >= $1",
      parameters: [100000],
    },
    {
      label: "liquidity sort",
      rank: "(p.selected->>'liquidityUsd')::double precision",
      where: "",
      parameters: [],
    },
    {
      label: "text search",
      rank: "p.first_seen_at",
      where:
        "WHERE position(lower($1) in lower(concat_ws(' ',p.mint,p.pool_id,p.selected->>'name',p.selected->>'symbol')))>0",
      parameters: ["QA Token 00001"],
    },
  ];
  const results = [];
  for (const query of queries) {
    const sql = `WITH filtered AS MATERIALIZED (SELECT p.id,${query.rank} AS rank FROM pools p ${query.where}), ordered AS (SELECT id FROM filtered ORDER BY rank DESC NULLS LAST,id LIMIT 100 OFFSET 0) SELECT (SELECT count(*)::int FROM filtered) AS total,COALESCE((SELECT jsonb_agg(id) FROM ordered),'[]'::jsonb) AS ids`;
    const samples = [];
    for (let i = 0; i < 3; i++)
      samples.push(
        (
          await pool.query(
            "EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) " + sql,
            query.parameters,
          )
        ).rows[0]["QUERY PLAN"][0],
      );
    results.push({
      label: query.label,
      sql,
      parameters: query.parameters,
      samples,
    });
  }
  const indexes = (
    await pool.query(
      "SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' AND tablename IN ('pools','samples','chain_candidates') ORDER BY tablename,indexname",
    )
  ).rows;
  await writeFile(
    "reports/elite-query-plans.json",
    JSON.stringify(
      {
        at: new Date().toISOString(),
        database: name,
        rows: count,
        codePath:
          "lib/scanner-query.ts, equivalent query statements; real selected-row hydration is included in browser benchmark, not these EXPLAIN timings",
        methodology:
          "Three local EXPLAIN ANALYZE BUFFERS samples per query. No universal query-p95 or SQL statement count; no production table mutation.",
        indexes,
        results,
      },
      null,
      2,
    ) + "\n",
  );
} finally {
  await pool.end();
}
