import { chromium } from "@playwright/test";
import { writeFile } from "node:fs/promises";
import { db } from "../lib/db";
const start = new Date();
const baseUrl = process.env.RUNTIME_BASE_URL || "http://localhost:3000";
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1512, height: 982 },
  });
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(baseUrl);
  await page.getByTestId("pool-row").first().waitFor();
  while (Date.now() - start.getTime() < 125000) {
    const n = (
      await db.query(
        "SELECT count(*)::int as n FROM metrics WHERE at>=$1 AND stage='receipt_to_ui'",
        [start],
      )
    ).rows[0].n;
    if (n >= 5) break;
    await new Promise((r) => setTimeout(r, 2000));
  }
  const [metrics, providers, counts] = await Promise.all([
    db.query(
      "SELECT stage,count(*)::int as n,percentile_cont(.5) WITHIN GROUP(ORDER BY duration_ms) as p50,percentile_cont(.95) WITHIN GROUP(ORDER BY duration_ms) as p95,percentile_cont(.99) WITHIN GROUP(ORDER BY duration_ms) as p99 FROM metrics WHERE at>=$1 GROUP BY stage",
      [start],
    ),
    db.query(
      "SELECT provider,count(*)::int as calls,count(*) FILTER(WHERE ok)::int as successful,percentile_cont(.95) WITHIN GROUP(ORDER BY latency_ms) as httpP95 FROM source_audits WHERE at>=$1 GROUP BY provider",
      [start],
    ),
    db.query(
      "SELECT count(*)::int as pools,(SELECT count(*)::int FROM tokens) as tokens FROM pools",
    ),
  ]);
  await page.getByTestId("pool-row").first().click();
  await page.screenshot({ path: "reports/desktop.png", fullPage: true });
  const mobile = await browser.newPage({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    deviceScaleFactor: 1,
  });
  await mobile.goto(baseUrl);
  await mobile.getByTestId("pool-row").first().waitFor();
  await mobile.screenshot({ path: "reports/mobile.png", fullPage: true });
  const report = {
    at: new Date().toISOString(),
    from: start.toISOString(),
    durationSeconds: (Date.now() - start.getTime()) / 1000,
    mode: "Production server and real public provider responses; no fixture interception.",
    load: {
      ...counts.rows[0],
      pollIntervalSeconds: 60,
      workerConcurrency: 4,
      regularMintBatch: 30,
      regularMintIntervalSeconds: 15,
      regularPoolBatch: 20,
      regularPoolIntervalSeconds: 20,
    },
    metrics: metrics.rows,
    providerLatency: providers.rows,
    browserErrors: errors,
    limits:
      "Observed free-provider load, small sample size; no guaranteed event/chain latency. UI sample timestamps require synchronized clocks. Provider response latency is separate.",
  };
  await writeFile(
    process.env.RUNTIME_REPORT || "reports/runtime-metrics.json",
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report, null, 2));
  if (errors.length) process.exitCode = 1;
} finally {
  await browser.close();
  await db.end();
}
