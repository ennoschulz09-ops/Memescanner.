import { writeFile } from "node:fs/promises";
import { db, claimBudget, auditRequest } from "../lib/db";
import { HttpClient, ProviderError } from "../lib/providers/http";
import { DexProvider } from "../lib/providers/dex";
import { GeckoProvider } from "../lib/providers/gecko";
import { SolanaProvider } from "../lib/providers/solana";
const http = new HttpClient(undefined, {
  claim: claimBudget,
  audit: auditRequest,
});
const dex = new DexProvider(http),
  gecko = new GeckoProvider(http),
  solana = new SolanaProvider(http);
const checks: Record<string, unknown>[] = [];
async function check(name: string, run: () => Promise<unknown>) {
  const start = performance.now();
  try {
    const result = await run();
    const r = result as Record<string, unknown> | null;
    const partial =
      r &&
      typeof r === "object" &&
      (r.concentrationAvailable === false ||
        (typeof r.coverage === "number" && r.coverage < 1));
    checks.push({
      name,
      status: partial ? "partial" : "passed",
      durationMs: Math.round(performance.now() - start),
      result,
    });
  } catch (e) {
    checks.push({
      name,
      status: "blocked",
      reason:
        e instanceof ProviderError
          ? e.message
          : "Quelle oder Schema nicht verfügbar",
      retryAfterMs: e instanceof ProviderError ? e.retryAfterMs : null,
    });
  }
}
try {
  await check("GeckoTerminal new pools", async () => {
    const r = await gecko.discover();
    if (!r.length) throw new Error();
    return {
      pools: r.length,
      exampleMint: r[0].mint,
      provenance: r[0].provenance,
    };
  });
  await check("DexScreener token pairs", async () => {
    const r = await dex.tokens(["So11111111111111111111111111111111111111112"]);
    if (!r.length) throw new Error();
    return {
      pools: r.length,
      provenance: r[0].provenance,
      marketCap: r[0].marketCapUsd,
      fdv: r[0].fdvUsd,
    };
  });
  await check("Solana RPC health", () => solana.health());
  await check("Solana mint inspection", async () => {
    const r = await solana.inspect(
      "So11111111111111111111111111111111111111112",
    );
    return {
      controlsAvailable: !!r.controls,
      concentrationAvailable: !!r.concentration,
      error: r.error,
      checkedAt: r.checkedAt,
      slot: r.slot,
    };
  });
  await check("Solana public address read", async () => {
    const r = await solana.wallet("11111111111111111111111111111111");
    return {
      coverage: r.coverage,
      accounts: r.accounts.length,
      signatures: r.signatures.length,
      errors: r.errors,
      checkedAt: r.checkedAt,
    };
  });
  const report = {
    at: new Date().toISOString(),
    mode: "real public read-only endpoints; no fixtures and no data writes to tokens/pools",
    checks,
  };
  await writeFile("reports/live-check.json", JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  if (checks.some((c) => c.status !== "passed")) process.exitCode = 1;
} finally {
  await db.end();
}
