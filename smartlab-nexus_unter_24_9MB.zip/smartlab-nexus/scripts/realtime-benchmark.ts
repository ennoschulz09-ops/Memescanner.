import { spawn } from "node:child_process";
import { readFile, writeFile, open } from "node:fs/promises";
import { performance } from "node:perf_hooks";
import pg from "pg";
import { chromium } from "@playwright/test";
import bs58 from "bs58";
import { observation } from "../tests/helpers";
import { scoreRisk } from "../lib/risk";
const wait = (ms: number) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
const appUrl = new URL(
  process.env.DATABASE_URL ||
    "postgresql://nexus:nexus_local_only@localhost:5432/nexus",
);
const benchmarkUrl = new URL(
  process.env.BENCH_DATABASE_URL || appUrl.toString(),
);
if (!process.env.BENCH_DATABASE_URL)
  benchmarkUrl.pathname = "/nexus_performance_test";
const name = benchmarkUrl.pathname.slice(1);
if (benchmarkUrl.pathname === appUrl.pathname)
  throw Error("Benchmark database must be distinct from the app database.");
if (!/^[a-zA-Z0-9_]+_performance_test$/.test(name))
  throw Error(
    "Benchmark requires a separate database ending in _performance_test.",
  );
const adminUrl = new URL(benchmarkUrl);
adminUrl.pathname = "/postgres";
const admin = new pg.Pool({ connectionString: adminUrl.toString() });
try {
  if (
    !(await admin.query("SELECT 1 FROM pg_database WHERE datname=$1", [name]))
      .rowCount
  )
    await admin.query(`CREATE DATABASE "${name}"`);
} finally {
  await admin.end();
}
process.env.DATABASE_URL = benchmarkUrl.toString();
const { db, migrate } = await import("../lib/db");
await migrate();
const port = Number(process.env.BENCH_PORT || 3100);
if (!Number.isInteger(port) || port < 3100 || port > 3999)
  throw Error("Invalid isolated benchmark port");
await db.query(
  "TRUNCATE tokens,events,sessions,discoveries,chain_candidates,metrics RESTART IDENTITY CASCADE",
);
const base = observation({
  name: "Isolierte Performance-Fixture",
  symbol: "BENCH",
  priceUsd: 1,
  liquidityUsd: 100000,
});
base.provenance = {
  ...base.provenance,
  endpoint: "isolated-performance-fixture",
};
for (let start = 0; start < 5000; start += 500) {
  const rows = Array.from({ length: 500 }, (_, j) => {
    const bytes = Buffer.alloc(32, 9);
    bytes.writeUInt32BE(start + j + 1);
    const mint = bs58.encode(bytes);
    const o = {
      ...base,
      mint,
      id: mint + ":" + base.poolId,
      name: "Isolierter Lasttest " + (start + j),
      symbol: "BENCH" + (start + j),
    };
    return {
      mint,
      id: o.id,
      pool_id: o.poolId,
      name: o.name,
      symbol: o.symbol,
      selected: o,
      risk: scoreRisk(o, null, [o]),
    };
  });
  await db.query(
    "INSERT INTO tokens(mint,name,symbol) SELECT mint,name,symbol FROM jsonb_to_recordset($1::jsonb) x(mint text,name text,symbol text)",
    [JSON.stringify(rows)],
  );
  await db.query(
    "INSERT INTO pools(id,mint,pool_id,selected,risk) SELECT id,mint,pool_id,selected,risk FROM jsonb_to_recordset($1::jsonb) x(id text,mint text,pool_id text,selected jsonb,risk jsonb)",
    [JSON.stringify(rows)],
  );
}
const logfile = await open("reports/realtime-server.log", "w");
const server = spawn(
  process.execPath,
  [
    "node_modules/next/dist/bin/next",
    "start",
    "--hostname",
    "127.0.0.1",
    "--port",
    String(port),
  ],
  {
    env: {
      ...process.env,
      DATABASE_URL: benchmarkUrl.toString(),
      APP_ORIGIN: `http://localhost:${port}`,
      NEXUS_TEST_MODE: "true",
      SOLANA_WS_DISCOVERY: "false",
    },
    stdio: ["ignore", logfile.fd, logfile.fd],
  },
);
await logfile.close();
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined,
  timer: ReturnType<typeof setInterval> | undefined;
function summarize(input: number[]) {
  const values = input.filter(Number.isFinite).sort((a, b) => a - b);
  const q = (v: number[], p: number) =>
    v.length ? v[Math.floor((v.length - 1) * p)] : null;
  let seed = 143;
  const random = () => {
    seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const boot: number[] = [];
  if (values.length >= 20)
    for (let b = 0; b < 500; b++) {
      const sample: number[] = [];
      while (sample.length < input.length) {
        const start = Math.floor(random() * input.length);
        for (let j = 0; j < 10 && sample.length < input.length; j++)
          sample.push(input[(start + j) % input.length]);
      }
      sample.sort((a, b) => a - b);
      boot.push(q(sample, 0.95)!);
    }
  boot.sort((a, b) => a - b);
  return {
    n: values.length,
    p50Ms: q(values, 0.5),
    p95Ms: q(values, 0.95),
    p99Ms: q(values, 0.99),
    p95CI95: boot.length ? [q(boot, 0.025), q(boot, 0.975)] : null,
  };
}
async function resource() {
  try {
    const text = await readFile(`/proc/${server.pid}/stat`, "utf8");
    const fields = text
      .slice(text.lastIndexOf(")") + 2)
      .trim()
      .split(/\s+/);
    const status = await readFile(`/proc/${server.pid}/status`, "utf8");
    return {
      ticks: Number(fields[11]) + Number(fields[12]),
      rssKiB: Number(/VmRSS:\s+(\d+)/.exec(status)?.[1] ?? 0),
      peakRssKiB: Number(/VmHWM:\s+(\d+)/.exec(status)?.[1] ?? 0),
    };
  } catch {
    return null;
  }
}
try {
  for (let i = 0; i < 60; i++) {
    if (server.exitCode !== null) throw Error("Isolated server exited");
    try {
      const r = await fetch(`http://localhost:${port}/api/health`);
      if (r.ok) break;
    } catch {}
    await wait(500);
  }
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox", "--enable-precise-memory-info"],
  });
  const page = await browser.newPage({
      viewport: { width: 1512, height: 982 },
    }),
    errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.addInitScript({
    content: `(()=>{window.__nexusBench={samples:[],received:0,pending:{},rendered:0,comparisons:[],longTasks:[],capture(){const row=[...document.querySelectorAll('[data-testid="pool-row"]')].find(n=>n.getAttribute('data-pool-id')===window.__benchId);if(!row)return;const rendered=row.getAttribute('data-revision');if(!rendered)return;for(const [target,at] of Object.entries(this.pending)){if(BigInt(rendered)>=BigInt(target)){const latency=Date.now()-at;this.samples.push(latency);this.comparisons.push({target,rendered,latencyMs:latency});delete this.pending[target];}}}};const Native=window.EventSource;window.EventSource=class extends Native{constructor(...args){super(...args);this.addEventListener('update',e=>{const d=JSON.parse(e.data);if(!d.baseline&&d.ids?.includes(window.__benchId)){const revision=d.revisions?.[window.__benchId];if(revision)window.__nexusBench.pending[revision]=Date.parse(d.publishedAt);window.__nexusBench.received++;requestAnimationFrame(()=>window.__nexusBench.capture());}});}};try{new PerformanceObserver(list=>window.__nexusBench.longTasks.push(...list.getEntries().map(e=>e.duration))).observe({type:'longtask',buffered:true});}catch{}})();`,
  });
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Network.enable");
  let networkBytes = 0;
  cdp.on("Network.dataReceived", (e) => {
    networkBytes += e.encodedDataLength;
  });
  const ttiStart = performance.now();
  await page.goto(`http://localhost:${port}`);
  await page.getByTestId("pool-row").first().waitFor();
  const ttiMs = performance.now() - ttiStart;
  const chosen = await page
    .getByTestId("pool-row")
    .first()
    .getAttribute("data-pool-id");
  if (!chosen) throw Error("No visible benchmark row");
  await page.evaluate(
    `window.__benchId=${JSON.stringify(chosen)};new MutationObserver(list=>{if(!list.some(m=>m.target.getAttribute('data-pool-id')===window.__benchId))return;window.__nexusBench.rendered++;requestAnimationFrame(()=>window.__nexusBench.capture());}).observe(document.querySelector('[data-testid="virtual-table"]'),{subtree:true,attributes:true,attributeFilter:['data-revision']});`,
  );
  await wait(500);
  const beforeCpu = await resource(),
    rss: number[] = [];
  timer = setInterval(() => {
    void resource().then((r) => {
      if (r) rss.push(r.rssKiB);
    });
  }, 1000);
  const beforeDb = (
    await db.query(
      "SELECT xact_commit,tup_returned,tup_fetched,blks_hit,blks_read FROM pg_stat_database WHERE datname=current_database()",
    )
  ).rows[0];
  const start = performance.now();
  let finalRevision = "";
  for (let i = 0; i < 500; i++) {
    const r = await db.query(
      "UPDATE pools SET selected=jsonb_set(jsonb_set(selected,'{priceUsd}',to_jsonb($2::double precision)),'{provenance,fetchedAt}',to_jsonb($3::text)),updated_at=clock_timestamp() WHERE id=$1 RETURNING revision::text",
      [chosen, 100 + i / 100, new Date().toISOString()],
    );
    finalRevision = r.rows[0].revision;
    await wait(start + (i + 1) * 120 - performance.now());
  }
  const writeDurationMs = performance.now() - start;
  await page
    .locator(`[data-testid="pool-row"][data-revision="${finalRevision}"]`)
    .first()
    .waitFor({ timeout: 15000 });
  await wait(2500);
  const stats = await page.evaluate<{
    samples: number[];
    received: number;
    rendered: number;
    pending: Record<string, number>;
    comparisons: { target: string; rendered: string; latencyMs: number }[];
    longTasks: number[];
  }>("window.__nexusBench");
  const afterCpu = await resource(),
    afterDb = (
      await db.query(
        "SELECT xact_commit,tup_returned,tup_fetched,blks_hit,blks_read FROM pg_stat_database WHERE datname=current_database()",
      )
    ).rows[0];
  const telemetry = (
    await db.query(
      "SELECT stage,array_agg(duration_ms ORDER BY at) as samples FROM metrics WHERE stage IN ('publish_to_ui','db_to_ui','receipt_to_ui','ingest_commit') GROUP BY stage",
    )
  ).rows.map((r) => ({ stage: r.stage, ...summarize(r.samples) }));
  const htmlMarkers = await page
    .locator("[data-market-value]")
    .evaluateAll((nodes) => ({
      total: nodes.length,
      withSource: nodes.filter((n) => n.getAttribute("data-source")).length,
      withFreshness: nodes.filter((n) => n.getAttribute("data-freshness"))
        .length,
      withExplanation: nodes.filter((n) => n.getAttribute("title")).length,
    }));
  const searchStart = performance.now();
  await page
    .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
    .fill("nonexistent benchmark term");
  await page.getByText("Keine passenden Pools").waitFor();
  const searchMs = performance.now() - searchStart;

  const api = await fetch(
    `http://localhost:${port}/api/pools?page=1&pageSize=100&format=compact`,
  );
  const apiText = await api.text();
  const publish = summarize(stats.samples);
  const passed =
    stats.received >= 400 &&
    publish.n >= stats.received * 0.99 &&
    Object.keys(stats.pending).length === 0 &&
    (publish.p95Ms ?? Infinity) < 250 &&
    errors.length === 0;
  const report = {
    at: new Date().toISOString(),
    gate: passed ? "PASS" : "FAIL",
    environment: {
      build: "production",
      node: process.version,
      browser: await browser.version(),
      database: name,
      rows: 5000,
      port,
      network: "same-host loopback; synchronized clocks",
      data: "synthetic fixtures in isolated _performance_test database only; visible TESTDATEN banner; no main DB writes",
    },
    load: {
      committedUpdates: 500,
      durationMs: writeDurationMs,
      updatesPerMinute: 500 / (writeDurationMs / 60000),
      sameVisibleRow: true,
      receivedUpdateHints: stats.received,
      visibilitySamples: publish.n,
      observedRenderStates: stats.rendered,
      unresolvedUpdateHints: Object.keys(stats.pending).length,
      correlation:
        "Each published target revision is matched to the first frame showing that revision or a newer revision of the same row. All hints must resolve; intermediate versions may be coalesced.",
      finalRevision,
      finalStateVisible: true,
    },
    publishToDom: publish,
    revisionComparisons: stats.comparisons,
    telemetry,
    interaction: {
      firstInteractiveDataMs: ttiMs,
      searchToPaintMs: searchMs,
      longTasks: summarize(stats.longTasks),
      maximumLongTaskMs: Math.max(0, ...stats.longTasks),
    },
    resources: {
      serverCpuSeconds:
        beforeCpu && afterCpu ? (afterCpu.ticks - beforeCpu.ticks) / 100 : null,
      cpuClockTicksPerSecond: 100,
      serverRssPeakMiB: afterCpu ? afterCpu.peakRssKiB / 1024 : null,
      sampledRssMaxMiB: rss.length ? Math.max(...rss) / 1024 : null,
      browserNetworkPayloadBytes: networkBytes,
      firstPageJsonBytes: Buffer.byteLength(apiText),
      postgresCountersBefore: beforeDb,
      postgresCountersAfter: afterDb,
      sqlStatementCount:
        "NOT VERIFIED; pg_stat_statements is not enabled. Transaction/tuple/buffer counters are reported.",
    },
    marketEvidenceMarkers: htmlMarkers,
    browserErrors: errors,
    confidenceMethod:
      "Moving-block bootstrap of ordered samples, block length 10, 500 resamples, 95% percentile CI for p95. One local run; not an internet/provider SLA. Intermediate row versions may be coalesced; final revision is verified.",
  };
  await writeFile(
    "reports/realtime-performance.json",
    JSON.stringify(report, null, 2) + "\n",
  );
  console.log(JSON.stringify(report, null, 2));
  if (!passed) process.exitCode = 1;
} finally {
  clearInterval(timer);
  await browser?.close();
  server.kill("SIGTERM");
  await Promise.race([
    new Promise<void>((resolve) => server.once("exit", () => resolve())),
    wait(10000),
  ]);
  if (server.exitCode === null) server.kill("SIGKILL");
  await db.end();
}
