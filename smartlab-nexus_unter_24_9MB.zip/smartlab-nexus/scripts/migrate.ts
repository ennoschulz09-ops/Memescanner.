import { db, migrate } from "../lib/db";
try {
  await migrate();
  console.log("PostgreSQL-Schema bereit.");
} finally {
  await db.end();
}
