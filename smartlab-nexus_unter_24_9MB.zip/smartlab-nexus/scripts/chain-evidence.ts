import { writeFile } from "node:fs/promises";
import { db } from "../lib/db";
try {
  const candidates = (
    await db.query(
      "SELECT signature,slot::text,observed_at,processed_at,decoded FROM chain_candidates WHERE processed_at IS NOT NULL AND CASE WHEN jsonb_typeof(decoded)='array' THEN jsonb_array_length(decoded)>0 ELSE false END ORDER BY processed_at DESC LIMIT 20",
    )
  ).rows;
  const discoveries = (
    await db.query(
      "SELECT mint,first_seen_at,event_at,observed_at,hydrated_at FROM discoveries WHERE provider='solana' ORDER BY first_seen_at DESC LIMIT 100",
    )
  ).rows;
  const queue = (
    await db.query(
      "SELECT count(*) FILTER(WHERE processed_at IS NULL)::int AS pending,max(EXTRACT(EPOCH FROM (clock_timestamp()-observed_at))) FILTER(WHERE processed_at IS NULL) AS oldest_pending_seconds FROM chain_candidates",
    )
  ).rows[0];
  const report = {
    at: new Date().toISOString(),
    status:
      candidates.length && discoveries.length ? "PARTIAL" : "NOT VERIFIED",
    scope:
      "Real persisted Raydium CPMM initialize evidence; readback only, not an independent second RPC retrieval. At most 20 decoded transactions and 100 discoveries.",
    candidates,
    discoveries,
    queue,
    limits:
      "Narrow program coverage; public RPC rate limits and bounded replay permit gaps. Small live sample and previously queued candidates do not establish current event-to-dashboard latency or a discovery SLA.",
  };
  await writeFile(
    "reports/upgrade-chain-discovery.json",
    JSON.stringify(report, null, 2),
  );
  console.log(
    JSON.stringify({
      status: report.status,
      decodedTransactions: candidates.length,
      discoveries: discoveries.length,
      queue,
    }),
  );
  if (report.status === "NOT VERIFIED") process.exitCode = 1;
} finally {
  await db.end();
}
