import { constants } from "node:fs";
import {
  copyFile,
  mkdir,
  open,
  readFile,
  rm,
  writeFile,
} from "node:fs/promises";
import { loadEnvFile } from "node:process";
import { spawn } from "node:child_process";
import path from "node:path";

const runtime = path.resolve(".runtime");
const pidFile = path.join(runtime, "codespace.pid");
const logFile = path.join(runtime, "codespace.log");
const command = process.argv[2];

async function runningPid() {
  try {
    const pid = Number(await readFile(pidFile, "utf8"));
    if (!Number.isSafeInteger(pid) || pid < 2) return null;
    const cmdline = await readFile(`/proc/${pid}/cmdline`, "utf8");
    return cmdline.includes("dev:all") ? pid : null;
  } catch {
    return null;
  }
}

if (command === "setup") {
  try {
    await copyFile(".env.example", ".env", constants.COPYFILE_EXCL);
    console.log("Lokale .env angelegt; Container-Konfiguration hat Vorrang.");
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    console.log("Vorhandene .env beibehalten.");
  }
} else if (command === "start") {
  const old = await runningPid();
  if (old) {
    console.log(`SMARTLAB NEXUS läuft bereits. Log: ${logFile}`);
    process.exit(0);
  }
  loadEnvFile(".env");
  const env = { ...process.env };
  if (env.CODESPACE_NAME) {
    const domain =
      env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN || "app.github.dev";
    if (
      !/^[a-z0-9-]+$/i.test(env.CODESPACE_NAME) ||
      !/^[a-z0-9.-]+$/i.test(domain)
    )
      throw new Error("Ungültige Codespaces-URL-Konfiguration.");
    env.APP_ORIGIN = `https://${env.CODESPACE_NAME}-3000.${domain}`;
  }
  await mkdir(runtime, { recursive: true });
  const log = await open(logFile, "a", 0o600);
  const child = spawn("npm", ["run", "dev:all"], {
    detached: true,
    env,
    stdio: ["ignore", log.fd, log.fd],
  });
  await new Promise((resolve, reject) => {
    child.once("spawn", resolve);
    child.once("error", reject);
  });
  await writeFile(pidFile, String(child.pid), { mode: 0o600 });
  child.unref();
  await log.close();
  console.log(
    `App und Worker starten. Öffnen: ${env.APP_ORIGIN || "http://localhost:3000"}`,
  );
  console.log(`Im Reiter PORTS Port 3000 öffnen. Log: ${logFile}`);
} else if (command === "stop") {
  const pid = await runningPid();
  if (pid) {
    process.kill(-pid, "SIGTERM");
    const deadline = Date.now() + 10000;
    while ((await runningPid()) === pid) {
      if (Date.now() >= deadline)
        throw new Error(
          "Prozess beendet sich nicht. Log prüfen, bevor neu gestartet wird.",
        );
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }
  await rm(pidFile, { force: true });
  console.log("Codespaces-Startprozess gestoppt.");
} else {
  throw new Error("Aufruf: node scripts/codespace.mjs setup|start|stop");
}
