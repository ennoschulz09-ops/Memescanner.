# Numerisches Datenfeld-Inventar · Version 1

Stand 24.10.2026. UI-Feldfamilien im aktuellen Scanner, Detail, Risk Lab, Wallet, Command, Analytics, Quality, Health, Listen und Alerts. Wildcards bezeichnen wiederholte gleichartige Felder. Konfigurationswerte sind keine Marktbeobachtungen. Numerische Supply/Amounts bleiben dezimale Strings. Die zwölf Markt- und alle acht Risikosignal-Schlüssel werden automatisch geprüft; Wildcard-Aggregate sind manuell inventarisiert, keine universelle statische Vollständigkeitsgarantie.

## priceUsd, liquidityUsd, volume5m, volume1h, volume24h, buys5m, sells5m, change5m, change1h, change24h, fdvUsd, marketCapUsd

| Eigenschaft | Vertrag |
|---|---|
| unit | USD; change*=percent; buys/sells=count |
| source | selected provider + fieldEvidence[field].source |
| sourceTimestamp | fieldEvidence[field].sourceTimestamp (nullable); sourceResponseAt is response/cache estimate |
| fetchedAt | fieldEvidence[field].fetchedAt |
| freshnessBudget | provenance.freshnessBudgetSeconds ?? MARKET_FRESHNESS_SECONDS |
| nullState | null=UNAVAILABLE; zero stays zero; NaN/Infinity rejected |
| conflicts | fieldEvidence[field].conflicts; only same mint AND pool |
| formula | provider observation; no invented price/supply conversion |

## trades5m, ratio, relativeVolume, activityIncreasePct, poolAgeMinutes

| Eigenschaft | Vertrag |
|---|---|
| unit | count; ratio; ratio; percent; minutes |
| source | selected observation; activityIncrease uses last two samples |
| sourceTimestamp | selected provenance.sourceAt / both sample times |
| fetchedAt | selected provenance.fetchedAt |
| freshnessBudget | market |
| nullState | missing operand or zero denominator => null; zero trades/volume retained |
| conflicts | inherits operand evidence; not independent source |
| formula | buys+sells; buys/sells (positive buys / zero sells displayed infinity); V5m/(V1h/12); 100*(currentTrades-previousTrades)/previousTrades; (now-createdAt)/60000 |

## risk.overall, risk.coverage, risk.dataQuality, risk.signals[].value, risk.signals[].coverage, risk.signals[].weight

| Eigenschaft | Vertrag |
|---|---|
| unit | 0..100; fraction; 0..100; per signal; fraction; fraction |
| source | nexus-risk/3: provider observations + Solana RPC |
| sourceTimestamp | signals[].updatedAt; report.computedAt is NOT measurement time |
| fetchedAt | selected.provenance.fetchedAt; evidence.components.*.checkedAt |
| freshnessBudget | market per signal; onchain component-specific |
| nullState | unknown components=null; overall=null if required missing/stale; evidenceStatus explicit |
| conflicts | sourceConflicts flags, raw disagreement retained |
| formula | RISK_MODEL.md; weights .30 liquidity/.25 token-account concentration/.30 controls/.15 activity; no scam probability; LP/clusters unknown |

## evidence.controls.decimals, evidence.controls.slot, evidence.controls.supply, evidence.concentration.top1Pct, evidence.concentration.top20Pct, evidence.concentration.accounts[].amount, evidence.concentration.accounts[].pct, evidence.components.*.slot

| Eigenschaft | Vertrag |
|---|---|
| unit | decimal places; slot; integer base units (string); percent |
| source | Solana getAccountInfo + getTokenLargestAccounts |
| sourceTimestamp | component slot + checkedAt; no wall-clock block time asserted |
| fetchedAt | evidence.components.*.checkedAt |
| freshnessBudget | ONCHAIN_FRESHNESS_SECONDS |
| nullState | invalid owner/address/supply/duplicates or stale/failed component => UNKNOWN |
| conflicts | holder context cannot predate mint context; later slots not atomic snapshot |
| formula | 100*integer account amount / integer supply; raw accounts do not identify economic owners |

## history[].priceUsd, history[].liquidityUsd, history[].volume5m, history[].trades5m, candles[].open, candles[].high, candles[].low, candles[].close, candles[].volume, sparkline[].value

| Eigenschaft | Vertrag |
|---|---|
| unit | USD; count; OHLCV provider units |
| source | selected source own samples OR Gecko OHLCV, separately labelled |
| sourceTimestamp | sample.at / candle.at; interval close is not tick time |
| fetchedAt | sample provenance.fetchedAt / candle provenance.fetchedAt |
| freshnessBudget | market + cache.ageSeconds/stale |
| nullState | null or unobserved interval => segment break; no interpolation |
| conflicts | no joining of different providers into one continuous series |
| formula | actual stored values; segmentSeries breaks >180s gaps; OHLCV gap budget matched to candle interval |

## wallet.balanceSol, wallet.slot, wallet.coverage, wallet.accounts[].amount, wallet.signatures[].slot

| Eigenschaft | Vertrag |
|---|---|
| unit | SOL; slot; fraction; UI token amount (string); slot |
| source | Solana read-only RPC |
| sourceTimestamp | wallet.checkedAt + respective context slots |
| fetchedAt | wallet.checkedAt |
| freshnessBudget | onchain / service cache age displayed |
| nullState | failed requests null; errors list; coverage=successful requests/4 |
| conflicts | program-specific accounts; no wallet-cluster or identity claim |
| formula | lamports / 1e9; query success count/4; at most 20 signatures |

## health.counts.*, health.cache.requests, health.cache.hits, health.cache.staleFallbacks, health.cache.hitRate, health.providers[].latencyMs, health.providers[].consecutiveErrors, health.budgets[].used, health.metrics[].n, health.metrics[].p50, health.metrics[].p95, health.metrics[].p99, health.worker.queueDepth, health.worker.queueLagMs

| Eigenschaft | Vertrag |
|---|---|
| unit | count; fraction; milliseconds (metrics/latency/lag) |
| source | local PostgreSQL audits/metrics/counters + worker heartbeat |
| sourceTimestamp | health.at; metric window 1h; counts current database snapshot; heartbeat separate |
| fetchedAt | health.at |
| freshnessBudget | UI poll 15s; worker active heartbeat <150s |
| nullState | unknown latency null; absent worker null; disconnected API offline; counters zero only for no observations |
| conflicts | audit events are not unique HTTP requests; browser metrics self-reported |
| formula | COUNT; retained cache hits/requests; PostgreSQL percentile_cont; last rolling minute budget claims |

## chainQueue.pending, chainQueue.deadLetter, chainQueue.oldestAgeSeconds, chainQueue.dequeueRate.attempts, chainQueue.dequeueRate.perMinute, chainQueue.dropped, chainQueue.cursor.slot, chainQueue.cursor.coverageGaps, chainEvents[].slot, chainEvents[].blockTimeUncertaintyMs

| Eigenschaft | Vertrag |
|---|---|
| unit | count; seconds; attempts/minute; slot; milliseconds |
| source | chain_candidates, attempts, cursor; signature is event ID |
| sourceTimestamp | observed/admitted/attempted/fetched/decoded/processed + blockTime |
| fetchedAt | API publishedAt; DOM receipt renderedAt |
| freshnessBudget | pending is immediately visible; status remains UNKNOWN until decode |
| nullState | missing blockTime/clock offset/stage=null; no fabricated latency |
| conflicts | replay separately flagged; blockTime resolution 1s, clock offset unknown |
| formula | COUNT pending/dead; max(now-observed); attempts last300s/5; cumulative gaps/drops |

## quality.pools, quality.fields[].present, quality.fields[].missing, quality.fields[].total, quality.fields[].coveragePct, quality.freshness.*, quality.providers[].auditEvents24h, quality.providers[].failedAuditEvents24h, quality.providers[].rateLimitedAuditEvents24h, quality.providers[].failedAuditEventPct, quality.providers[].failedAuditRuns24h, quality.cache.*, quality.requestBudgets[].limit, quality.requestBudgets[].used, quality.requestBudgets[].remaining, quality.requestBudgets[].windowSeconds, quality.costs.totalUsd

| Eigenschaft | Vertrag |
|---|---|
| unit | count; percent; seconds; USD |
| source | local DB field counts / audits / retained counters |
| sourceTimestamp | quality.at, window.from/to, provider lastSuccess/Error |
| fetchedAt | quality.at |
| freshnessBudget | UI poll30s; audits window24h; budgets rolling60s |
| nullState | zero denominator => null; costs always unknown/null without billing evidence |
| conflicts | first-party completeness, not independent truth; audit runs not correlated request failures |
| formula | 100*present/total; missing=total-present; max(0,limit-used); percentages rounded2dp |

## analytics.pools, analytics.tokens, analytics.liquidity, analytics.volume24h, analytics.liquidityCoverage, analytics.volumeCoverage, analytics.quality, analytics.riskCounts.*, analytics.dex[].pools, analytics.dex[].liquidity, analytics.events[].count, dashboard.currentFreshPct, dashboard.totalLiquidity, scanner.page, scanner.pageSize, scanner.total, watchlist.items.length, alerts.rules[].threshold, alerts.rules[].cooldownSeconds, alerts.rules[].debounceSeconds, alerts.events[].value

| Eigenschaft | Vertrag |
|---|---|
| unit | count; USD; fraction; percent; score; seconds; rule-specific |
| source | local captured pools / session preferences / alert evaluations |
| sourceTimestamp | analytics.at; each selected provider provenance; alert event.at |
| fetchedAt | API response time; each underlying observation retained |
| freshnessBudget | underlying market/chain budgets; local config has no market freshness |
| nullState | unknown aggregate if no known values; partial sums explicitly covered; threshold never a recommendation |
| conflicts | different pools only; no provider double count; loaded-page dashboard explicitly scoped |
| formula | sum distinct observed pool values; coverage known/distinct; mean quality; events COUNT; local rules compare stated indicator |
