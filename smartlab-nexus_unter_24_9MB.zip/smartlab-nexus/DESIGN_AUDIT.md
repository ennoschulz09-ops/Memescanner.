# Elite Design-Audit

Stand: 23.10.2026. Gewählte Richtung: **ATLAS**. Grundlage ist die gebaute Anwendung mit echten öffentlichen Beobachtungen. Heuristische Entwicklerprüfung, automatisierte Browser-/Axe-Prüfungen und ein unabhängiger Code-Review ergänzen sich; eine Nutzerstudie oder vollständige Screenreader-Zertifizierung wurde nicht durchgeführt.

## Variantenwahl

Drei funktional identische Scanner wurden mit verschiedenen Layout-/Farb-/Typografieregeln im echten Browser prototypisiert. Die Varianten liegen als nachvollziehbare CSS-Dateien in `docs/design-variants/`; Screenshots und Manifest in [elite-prototypes](reports/elite-prototypes/manifest.json).

Rubrik: je 0–2 Punkte für Lesbarkeit, Hierarchie, Informationsdichte, erkennbare Zustände und mobile Eignung. Dies sind dokumentierte Designurteile, keine aus Testzahlen berechneten Qualitätsnoten.

| Variante | Lesbarkeit | Hierarchie | Dichte | Zustände | Mobil | Summe |
| -------- | ---------: | ---------: | -----: | -------: | ----: | ----: |
| ATLAS    |        1,8 |        1,8 |    1,8 |      1,6 |   1,4 |   8,4 |
| VECTOR   |        1,6 |        1,5 |    1,9 |      1,5 |   1,4 |   7,9 |
| FOLIO    |        1,7 |        1,8 |    1,4 |      1,4 |   1,5 |   7,8 |

ATLAS gewinnt durch eine gemeinsame ruhige Datenleiste, präzise Konturen und klare Gruppierung. VECTOR überbetonte Monospace/Konturen, FOLIO benötigte mehr Platz für dieselben Informationen. Erst die finale Umsetzung ergänzt Command, Quality und eigenständige mobile Abläufe; der CSS-Prototyp allein erfüllt den Elite-Auftrag nicht.

## Vorher und nachher

| Bereich      | Vorher                                                | Gebauter Elite-Stand                                                                     |
| ------------ | ----------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Orientierung | Scanner und technische Einzelansichten                | Command mit Quellenlage, Frische, Queue und Quality-Drilldown                            |
| Dichte       | Viele einzelne Karten und konkurrierende Akzente      | Gemeinsame Kennzahlenleiste, zurückhaltende Graphitflächen/Cyan-Akzente                  |
| Mobil        | Reduzierte Desktop-Tabelle, kompletter Analysewechsel | Tokenkarten, Bottom-Navigation und Schnellanalyse-Sheet                                  |
| Updates      | Automatisch wechselnde Zahlen                         | Explizites Pausieren mit Banner und Resynchronisierung                                   |
| Qualität     | Einzelne Datenqualitätsindikatoren                    | Feldabdeckung, Stale/Unknown, Auditereignisse, Budgets und Kosten unbekannt              |
| Risiko       | Signale und Auditverlauf                              | Modellversion, konservativere Evidenzgrenzen, unbekannte Legacy-Version bleibt erkennbar |
| Charts       | Gemeinsame Kurvenfarbe                                | Preis Cyan, Liquidität Amber; Zeit-/Quellkontext und echte Lücken                        |

Historische Aufnahmen: [Desktop vorher](reports/elite-before-desktop.png), [Mobil vorher](reports/elite-before-mobile.png). Aktuelle Aufnahmen zeigen wechselnde reale Marktbestände; inhaltliche Wertunterschiede sind keine Wirkung des Designs.

## Gebaute Hauptansichten

| Ansicht      | Desktop                                                    | Mobil                                                     |
| ------------ | ---------------------------------------------------------- | --------------------------------------------------------- |
| Command      | [Aufnahme](reports/elite-screens/desktop-command.png)      | [Aufnahme](reports/elite-screens/mobile-command.png)      |
| Radar        | [Aufnahme](reports/elite-screens/desktop-radar.png)        | [Aufnahme](reports/elite-screens/mobile-radar.png)        |
| Intelligence | [Aufnahme](reports/elite-screens/desktop-intelligence.png) | [Aufnahme](reports/elite-screens/mobile-intelligence.png) |
| Watchlists   | [Aufnahme](reports/elite-screens/desktop-watchlists.png)   | [Aufnahme](reports/elite-screens/mobile-watchlists.png)   |
| Health       | [Aufnahme](reports/elite-screens/desktop-health.png)       | [Aufnahme](reports/elite-screens/mobile-health.png)       |

[Manifest und Herkunft](reports/elite-screens/manifest.json). Eigene temporäre Browser-Sitzungen legen ausschließlich ihre Watchlists an; keine synthetischen Pools gelangen in Live-Tabellen. Vollseitenaufnahmen zeigen die feste mobile Navigation an ihrer tatsächlichen Viewportposition; darunterliegender Inhalt wird beim Scrollen sichtbar.

## Gefundene und behobene Probleme

- Die mobile virtuelle Zeilengruppe behielt eine Desktop-Mindestbreite: 908 statt 390 px Dokumentbreite. `mobile radar keeps cards and navigation inside the viewport` reproduzierte 518 px Überlauf. Die mobile Mindestbreite ist jetzt 0; Preis, Liquidität und Watchlistaktion bleiben im Kartenbereich.
- Die gewählte Zeile hatte zu wenig Kontrast im Datenqualitätslabel. Farbe und Schriftgröße wurden angepasst; Axe prüft den resultierenden Zustand ohne Regelausnahmen.
- Sichtbarer Pausentext und zugänglicher Name passten nicht zusammen. Beide enthalten nun „Updates pausieren/fortsetzen“; mobil ist die Aktion mindestens 44 px hoch.
- Horizontal scrollbare Health-Tabellen und der Quellenvergleich der Token-Analyse waren nicht per Tastatur fokussierbar. Sie haben jetzt einen Fokuspunkt und sichtbare Umrandung; Quellenvergleich und Alert-Ereignisprotokoll zusätzlich beschriftete Regionen.
- Der globale Suchshortcut konnte den Fokus aus dem mobilen Dialog holen. Das Sheet unterdrückt ihn und behandelt auch Tab bei unerwartetem Fokus außerhalb.
- Nachlaufende Seitenantworten konnten eine pausierte Ansicht ändern. Pause invalidiert die laufende Request-Sequenz.
- Das Command Dashboard leitete Frische aus `total − stale` ab. Es verwendet jetzt den expliziten `current`-Zustand der beschrifteten geladenen Auswahl; unbekannte Frische zählt nicht als frisch.

Die Regressionen stehen in `tests/e2e/elite.spec.ts`, die Axe-/Tastatur-/Touch-Prüfungen in `tests/e2e/accessibility.spec.ts`. Ergebnisse, Browserstände und offene Grenzen stehen in [QA_REPORT.md](QA_REPORT.md).

## Grenzen

Die fünf Hauptansichten wurden visuell geprüft. Keine universelle Prüfung aller Kombinationen von optionalen Spalten, Schriftgrößen, Sprachvarianten oder assistiven Technologien. Einige historische Komponenten besitzen weiterhin feste CSS-Werte und kleine ergänzende Texte. Automatisches Axe erkennt nur einen Teil der WCAG-Anforderungen; ein bestandener Lauf ist keine vollständige WCAG-2.2-AA-Zertifizierung. Es gibt keine getestete Nutzerpräferenz oder Begründung für eine pauschale 9,5/10-Note.
