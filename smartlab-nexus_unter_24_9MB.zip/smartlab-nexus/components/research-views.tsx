"use client";
import { useEffect, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  CheckCircle2,
  AlertTriangle,
  Database,
  Search,
  Server,
  ShieldAlert,
  RefreshCw,
  ExternalLink,
  Info,
  Clock,
} from "lucide-react";
import type { getHealth } from "../lib/ingestion";
import type { PoolRow } from "../lib/domain";
import { isAddress, freshness } from "../lib/domain";
import {
  api,
  usd,
  formatNumber,
  sourceName,
  short,
  ago,
  dateTime,
} from "../lib/client";
import {
  Badge,
  Panel,
  Empty,
  Loading,
  ErrorBox,
  Stat,
  TokenAvatar,
  RiskBadge,
  Quality,
  CopyAddress,
  KeyValue,
} from "./ui";
import { RiskSignals, eventLabel } from "./token-detail";
import { TimeChart } from "./charts";
import { PipelineSummary } from "./command-dashboard";
export type Health = Awaited<ReturnType<typeof getHealth>>;

export function RiskLab({
  rows,
  onOpen,
}: {
  rows: PoolRow[];
  onOpen: (r: PoolRow) => void;
}) {
  const [selected, setSelected] = useState<string>("");
  const r = rows.find((x) => x.id === selected) ?? rows[0];
  return (
    <>
      <div className="info-banner">
        <ShieldAlert size={18} />
        <div>
          <strong>Risiken sichtbar machen. Unsicherheit erhalten.</strong>
          <p>
            Deskriptive, gewichtete Prüfungen mit offener Methodik. Fehlende
            relevante Eingaben ergeben keinen Gesamtscore.
          </p>
        </div>
      </div>
      <div className="risk-lab-grid">
        <Panel title="Erfasste Pools" className="risk-pool-list">
          <div className="risk-selector">
            {rows.slice(0, 100).map((p) => (
              <button
                className={p.id === r?.id ? "active" : ""}
                key={p.id}
                onClick={() => setSelected(p.id)}
              >
                <TokenAvatar mint={p.mint} symbol={p.symbol} />
                <span>
                  <strong>{p.symbol}</strong>
                  <small>
                    {p.dex} · {short(p.poolId)}
                  </small>
                </span>
                <RiskBadge state={p.risk.state} />
              </button>
            ))}
          </div>
        </Panel>
        {r ? (
          <div className="risk-lab-right">
            <Panel>
              <div className="risk-lab-token">
                <div>
                  <TokenAvatar mint={r.mint} symbol={r.symbol} />
                  <div>
                    <h2>{r.name}</h2>
                    <CopyAddress value={r.mint} />
                  </div>
                </div>
                <button className="button" onClick={() => onOpen(r)}>
                  Alle Evidenzen
                  <ArrowUpRight size={14} />
                </button>
              </div>
              <div className="risk-explainer-summary">
                <div>
                  <span>Gewichteter Risikoindikator</span>
                  <strong>
                    {r.risk.overall === null
                      ? "Unbekannt"
                      : r.risk.overall + "/100"}
                  </strong>
                </div>
                <div>
                  <span>Abdeckung der Pflichtprüfungen</span>
                  <strong>{Math.round(r.risk.coverage * 100)} %</strong>
                </div>
                <div>
                  <span>Datenqualität</span>
                  <Quality value={r.risk.dataQuality} />
                </div>
              </div>
            </Panel>
            <Panel title="Signale & Methodik">
              <RiskSignals report={r.risk} />
            </Panel>
            <div className="info-banner subtle">
              <Info size={17} />
              <p>
                Schwellen sind transparente Rechercheheuristiken.
                Token-2022-Erweiterungen werden benannt, LP-Locks und
                Transaktionscluster ohne verifizierte Evidenz als unbekannt
                geführt. Ein geringer Indikator schließt Risiken nicht aus.
              </p>
            </div>
          </div>
        ) : (
          <Empty title="Noch keine Daten für Risikoanalysen" />
        )}
      </div>
    </>
  );
}
export function WalletExplorer({ timezone }: { timezone: string }) {
  const [address, setAddress] = useState(""),
    [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const load = async () => {
    if (!isAddress(address.trim())) {
      setError("Bitte eine gültige öffentliche Solana-Adresse eingeben.");
      return;
    }
    setBusy(true);
    setError("");
    setData(null);
    try {
      setData(await api("wallet/" + address.trim()));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const activity: Record<string, number> = {};
  for (const s of data?.signatures ?? [])
    if (s.at) {
      const hour = s.at.slice(0, 13) + ":00:00Z";
      activity[hour] = (activity[hour] ?? 0) + 1;
    }
  return (
    <>
      <div className="wallet-intro panel">
        <div className="wallet-orb">
          <Search size={30} />
        </div>
        <Badge tone="violet">Öffentliche Onchain-Recherche</Badge>
        <h2>
          Adressen verstehen.
          <br />
          <span>Ohne Identitätsannahmen.</span>
        </h2>
        <p>
          Analysiere öffentliche Salden, Tokenkonten und beobachtete Signaturen
          einer Solana-Adresse. Die Auswertung bleibt rein lesend.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void load();
          }}
        >
          <label htmlFor="public-address">Öffentliche Solana-Adresse</label>
          <div className="address-search">
            <Search size={18} />
            <input
              id="public-address"
              value={address}
              placeholder="Solana-Adresse eingeben"
              onChange={(e) => setAddress(e.target.value)}
              maxLength={64}
              autoComplete="off"
            />
            <button className="button primary" type="submit" disabled={busy}>
              {busy ? (
                <RefreshCw size={15} className="spin" />
              ) : (
                <ArrowUpRight size={15} />
              )}
              Adresse analysieren
            </button>
          </div>
        </form>
        <small>
          Solana RPC · budgetierte Abfragen · Cache mindestens 60 Sekunden
        </small>
      </div>
      {error && <ErrorBox error={error} />}{" "}
      {busy && <Loading label="Öffentliche Kontodaten werden abgefragt …" />}
      {data && (
        <div className="wallet-results">
          <Panel>
            <div className="wallet-result-heading">
              <div>
                <Badge tone={data.errors.length ? "amber" : "cyan"}>
                  Abdeckung {Math.round(data.coverage * 100)} %
                </Badge>
                <h3>Öffentliche Adresse</h3>
                <CopyAddress value={data.address} full />
              </div>
              <a
                className="button"
                href={"https://explorer.solana.com/address/" + data.address}
                target="_blank"
                rel="noopener noreferrer"
              >
                Explorer
                <ExternalLink size={14} />
              </a>
            </div>
            <div className="detail-stat-grid">
              <div className="mini-stat">
                <span>SOL-Saldo</span>
                <strong>
                  {data.balanceSol === null
                    ? "Unbekannt"
                    : formatNumber(data.balanceSol, false) + " SOL"}
                </strong>
              </div>
              <div className="mini-stat">
                <span>Gefundene Tokenkonten</span>
                <strong>{data.accounts.length}</strong>
              </div>
              <div className="mini-stat">
                <span>Signaturen (max. 20)</span>
                <strong>{data.signatures.length}</strong>
              </div>
              <div className="mini-stat">
                <span>RPC-Slot</span>
                <strong>{data.slot ?? "Unbekannt"}</strong>
              </div>
            </div>
            <p className="source-footnote">
              {data.source} · abgefragt {dateTime(data.checkedAt, timezone)} ·{" "}
              {data.cache.hit
                ? "Cache " + Math.round(data.cache.ageSeconds) + "s"
                : "Neuer Abruf"}
              {data.cache.stale ? " · VERALTET" : ""}
            </p>
          </Panel>
          {data.errors.length > 0 && (
            <ErrorBox
              error={
                "Nicht verfügbar: " +
                data.errors.join(", ") +
                ". Diese Bereiche bleiben unbekannt."
              }
            />
          )}
          <div className="detail-two-columns">
            <Panel title="Tokenkonten">
              <div className="horizontal-scroll" tabIndex={0}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Mint-Adresse</th>
                      <th>Gemeldeter Tokenbetrag</th>
                      <th>Programm</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.accounts.slice(0, 100).map((a: any) => (
                      <tr key={a.account}>
                        <td>
                          <CopyAddress value={a.mint} />
                        </td>
                        <td>{a.amount || "Unbekannt"}</td>
                        <td>
                          {a.program.startsWith("Tokenz")
                            ? "Token-2022"
                            : "SPL Token"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!data.accounts.length && (
                <Empty
                  title="Keine Tokenkonten verfügbar"
                  description="Ein leeres oder nicht verfügbares Ergebnis belegt keine vollständige Abwesenheit von Aktivitäten."
                />
              )}
              <p className="panel-note">
                Bis zu 500 Konten pro Auswertung, Anzeige der ersten 100. Keine
                USD-Bewertung ohne zugehörige belegte Preisdaten.
              </p>
            </Panel>
            <Panel title="Beobachtete Signaturaktivität">
              <TimeChart
                points={Object.entries(activity)
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([at, value]) => ({ at, value }))}
                label="Signaturen pro beobachteter Stunde"
                source="Solana RPC · Ausschnitt der letzten 20 Signaturen"
                unit="Anzahl"
                timezone={timezone}
              />
              <p className="panel-note">
                Keine vollständige Historie. Gegenparteien und Wallet-Cluster
                bleiben ohne Transaktionsdecodierung unbekannt.
              </p>
            </Panel>
          </div>
          <Panel title="Belegbare öffentliche Signaturen">
            <div className="horizontal-scroll" tabIndex={0}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Signatur</th>
                    <th>Zeit</th>
                    <th>Slot</th>
                    <th>Status</th>
                    <th>Quelle</th>
                  </tr>
                </thead>
                <tbody>
                  {data.signatures.map((s: any) => (
                    <tr key={s.signature}>
                      <td className="mono">{short(s.signature, 10)}</td>
                      <td>{dateTime(s.at, timezone)}</td>
                      <td>{s.slot}</td>
                      <td>
                        <Badge tone={s.failed ? "amber" : "neutral"}>
                          {s.failed ? "Fehler gemeldet" : "Bestätigt"}
                        </Badge>
                      </td>
                      <td>
                        <a
                          className="text-button"
                          href={"https://explorer.solana.com/tx/" + s.signature}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          Explorer
                          <ExternalLink size={12} />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!data.signatures.length && (
              <Empty title="Keine Signaturen verfügbar" />
            )}
          </Panel>
          <div className="info-banner subtle">
            <Info size={17} />
            <p>{data.limitations.join(" ")}</p>
          </div>
        </div>
      )}
    </>
  );
}
export function Analytics({ timezone }: { timezone: string }) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState("");
  const load = () =>
    api("analytics")
      .then(setData)
      .catch((e) => setError(e.message));
  useEffect(() => {
    void load();
  }, []);
  if (!data)
    return error ? (
      <ErrorBox error={error} retry={() => void load()} />
    ) : (
      <Loading label="Gespeicherte Beobachtungen werden aggregiert …" />
    );
  const points: Record<string, number> = {};
  for (const e of data.events) points[e.hour] = (points[e.hour] ?? 0) + e.count;
  const max = Math.max(1, ...data.dex.map((d: any) => d.liquidity));
  return (
    <>
      <div className="stats-grid four">
        <Stat
          label="Erfasste Liquidität"
          value={usd(data.liquidity)}
          sub={`${Math.round(data.liquidityCoverage * 100)} % der Pools mit Liquiditätswert`}
        />
        <Stat
          label="Volumen · 24h"
          value={usd(data.volume24h)}
          sub={`${Math.round(data.volumeCoverage * 100)} % der Pools mit Volumenwert`}
          tone="violet"
        />
        <Stat
          label="Ø Datenqualität"
          value={
            data.quality === null ? "—" : Math.round(data.quality) + "/100"
          }
          sub="Vollständigkeit und Frische"
        />
        <Stat
          label="Erfasste Tokens"
          value={formatNumber(data.tokens)}
          sub={`${formatNumber(data.pools)} unterschiedliche Pools`}
          tone="violet"
        />
      </div>
      <p className="scope-note">{data.scope}</p>
      <div className="detail-two-columns">
        <Panel title="Beobachtete Ereignisse · 24h">
          <TimeChart
            points={Object.entries(points).map(([at, value]) => ({
              at,
              value,
            }))}
            label="Persistierte Ereignisse pro Stunde"
            unit="Anzahl"
            source="SMARTLAB NEXUS · PostgreSQL-Ereignisprotokoll"
            timezone={timezone}
          />
        </Panel>
        <Panel title="Liquidität nach erfasstem DEX">
          <div className="distribution">
            {data.dex.slice(0, 10).map((d: any) => (
              <div key={d.name}>
                <div>
                  <span>{d.name}</span>
                  <strong>{usd(d.liquidity)}</strong>
                  <small>{d.pools} Pools</small>
                </div>
                <span className="bar-track">
                  <i style={{ width: (d.liquidity / max) * 100 + "%" }} />
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
      <Panel title="Risikostatus der erfassten Pools">
        <div className="risk-counts">
          {Object.entries(data.riskCounts).map(([state, n]) => (
            <div key={state}>
              <RiskBadge state={state as any} />
              <strong>{String(n)}</strong>
              <span>Pools</span>
            </div>
          ))}
        </div>
        <p className="panel-note">
          „Unbekannt“ bleibt ein eigenständiger Zustand. Kritische
          Einzelhinweise bleiben sichtbar, auch wenn der Gesamtscore nicht
          berechenbar ist.
        </p>
      </Panel>
    </>
  );
}
export function SystemHealth({
  health,
  stream,
  error,
  onReload,
  timezone,
}: {
  health: Health | null;
  stream: string;
  error: string;
  onReload: () => void;
  timezone: string;
}) {
  const [audit, setAudit] = useState<any[]>([]);
  useEffect(() => {
    api("analytics")
      .then((d) => setAudit(d.audits))
      .catch(() => {});
  }, [health?.at]);
  return (
    <>
      {error && <ErrorBox error={error} retry={onReload} />}
      <div
        className={`system-banner ${health?.mode === "current" ? "healthy" : ""}`}
      >
        <div>
          <Server size={24} />
          <div>
            <h2>
              {!health
                ? "Systemstatus nicht verfügbar"
                : health.mode === "current"
                  ? "Datenerfassung aktiv"
                  : "Eingeschränkter Betrieb"}
            </h2>
            <p>
              {health?.coverage ??
                "Datenbank oder lokale API nicht erreichbar."}
            </p>
          </div>
        </div>
        <button className="button" onClick={onReload}>
          <RefreshCw size={14} />
          Status aktualisieren
        </button>
      </div>
      <Panel title="Discovery-Abdeckung und Quellenzeiten">
        <p className="panel-note">
          Gezählte Mints je Feed, kein Anteil aller Solana-Token. Ereigniszeiten
          nur soweit veröffentlicht; Pool-Erstellung ist keine Mint-Erstellung.
        </p>
        <div className="horizontal-scroll" tabIndex={0}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Quelle</th>
                <th>Mints</th>
                <th>Unvollständig</th>
                <th>Ereigniszeiten n</th>
                <th>Erstellung → zuerst gesehen p50 / p95 / p99</th>
              </tr>
            </thead>
            <tbody>
              {health?.discoveryCoverage?.map((d: any) => (
                <tr key={d.provider}>
                  <td>{sourceName(d.provider)}</td>
                  <td>{d.discovered_mints}</td>
                  <td>{d.pending}</td>
                  <td>{d.event_time_samples}</td>
                  <td>
                    {[
                      d.first_seen_p50_ms,
                      d.first_seen_p95_ms,
                      d.first_seen_p99_ms,
                    ]
                      .map((v) =>
                        v === null ? "Unbekannt" : Math.round(v) + " ms",
                      )
                      .join(" / ")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <KeyValue
          label="Onchain-Discovery"
          value={(health?.worker as any)?.chainFeed?.status ?? "NOT VERIFIED"}
        />
        <KeyValue
          label="Geprüfte Programmabdeckung"
          value={(health?.worker as any)?.chainFeed?.scope ?? "Nicht aktiv"}
        />
        <KeyValue
          label="Gemeldete Abdeckungslücken"
          value={
            (health?.worker as any)?.chainFeed?.coverageGaps ?? "Unbekannt"
          }
        />
        <KeyValue
          label="Dekodierte Pool-Initialisierungen"
          value={(health?.worker as any)?.chainFeed?.decoded ?? "Unbekannt"}
        />
      </Panel>
      <Panel title="Onchain-Kandidaten und Verarbeitung">
        <PipelineSummary health={health} />
        <div className="queue-explanation">
          <p>
            Abgewiesene Kandidaten und Datenlücken werden nicht als neue Pools
            gezählt.
          </p>
          <p>
            Letzte verifizierte Initialisierung:{" "}
            {health?.chainQueue?.lastRealDiscovery
              ? dateTime(
                  health.chainQueue.lastRealDiscovery.processedAt,
                  timezone,
                )
              : "Noch nicht nachgewiesen"}
          </p>
          <details>
            <summary>Retry-Gründe und Replay-Cursor</summary>
            <pre>
              {JSON.stringify(
                health?.chainQueue ?? { status: "unavailable" },
                null,
                2,
              )}
            </pre>
          </details>
        </div>
      </Panel>
      <Panel title="Quellen-Scheduler und Circuit-Breaker">
        <div className="horizontal-scroll" tabIndex={0}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Aufgabe</th>
                <th>Takt</th>
                <th>Circuit</th>
                <th>Folgefehler</th>
                <th>Letzter Erfolg</th>
              </tr>
            </thead>
            <tbody>
              {((health?.worker as any)?.jobs ?? []).map((j: any) => (
                <tr key={j.key}>
                  <td>{j.key}</td>
                  <td>{j.intervalMs / 1000}s</td>
                  <td>{j.circuit}</td>
                  <td>{j.failures}</td>
                  <td>{dateTime(j.lastSuccess, timezone)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
      <div className="provider-grid">
        {health?.providers.map((p) => {
          const stale =
            !p.lastSuccess || Date.now() - Date.parse(p.lastSuccess) > 180000;
          return (
            <Panel key={p.provider}>
              <div className="provider-title">
                <div className="provider-icon">
                  <Database size={18} />
                </div>
                <h3>{sourceName(p.provider)}</h3>
                <Badge
                  tone={
                    p.status === "ok" && !stale
                      ? "cyan"
                      : p.status === "unknown"
                        ? "neutral"
                        : "amber"
                  }
                  dot
                >
                  {p.status === "ok"
                    ? stale
                      ? "Veraltet"
                      : "Erreichbar"
                    : p.status === "limited"
                      ? "Begrenzt"
                      : p.status === "error"
                        ? "Fehler"
                        : "Unbekannt"}
                </Badge>
              </div>
              <KeyValue
                label="Letzter Erfolg"
                value={dateTime(p.lastSuccess, timezone)}
              />
              <KeyValue
                label="HTTP-Latenz (letzte)"
                value={
                  p.latencyMs === null
                    ? "Unbekannt"
                    : Math.round(p.latencyMs) + " ms"
                }
              />
              <KeyValue label="Folgefehler" value={p.consecutiveErrors} />
              <KeyValue
                label="Nächster Versuch frühestens"
                value={dateTime(p.retryAt, timezone)}
              />
              {p.error && <p className="inline-warning">{p.error}</p>}
            </Panel>
          );
        })}
      </div>
      <div className="detail-two-columns">
        <Panel title="Erfassung & Verbindung">
          <KeyValue
            label="PostgreSQL"
            value={health ? "Erreichbar" : "Unbekannt"}
          />
          <KeyValue
            label="Worker"
            value={health?.worker?.active ? "Aktiv" : "Inaktiv / unbekannt"}
          />
          <KeyValue
            label="Worker-Heartbeat"
            value={dateTime(health?.worker?.heartbeat, timezone)}
          />
          <KeyValue
            label="Warteschlangengröße"
            value={health?.worker?.queueDepth ?? "Unbekannt"}
          />
          <KeyValue
            label="Queue-Wartezeit"
            value={
              health?.worker?.queueLagMs === undefined
                ? "Unbekannt"
                : Math.round(Number(health.worker.queueLagMs)) + " ms"
            }
          />
          <KeyValue label="Browser-Push" value={stream} />
          <KeyValue
            label="Offene SSE-Verbindungen"
            value={(health as any)?.stream?.connections ?? "Unbekannt"}
          />
          <KeyValue
            label="Cache-Trefferrate"
            value={
              health?.cache.hitRate === null || !health?.cache
                ? "Unbekannt"
                : Math.round(health.cache.hitRate * 100) + " %"
            }
          />
          <KeyValue label="Provider-Modus" value="Budgetiertes REST-Polling" />
          <KeyValue
            label={`Veraltete Pools (> ${health?.freshnessBudgets?.market ?? 180}s)`}
            value={health?.counts.stale ?? "Unbekannt"}
          />
        </Panel>
        <Panel title="Gemeinsame Anbieterbudgets">
          <div className="budget-list">
            {health?.budgets.map((b) => {
              const max =
                (
                  {
                    gecko: 8,
                    "dex-market": 30,
                    "dex-profiles": 6,
                    solana: 30,
                  } as Record<string, number>
                )[b.channel] ?? 1;
              return (
                <div key={b.channel}>
                  <div>
                    <span>{b.channel}</span>
                    <strong>
                      {b.used} / {max} pro Minute
                    </strong>
                  </div>
                  <span className="bar-track">
                    <i style={{ width: (b.used / max) * 100 + "%" }} />
                  </span>
                </div>
              );
            })}
          </div>
          <p className="panel-note">
            Worker und UI teilen diese PostgreSQL-Budgets. Anbieterlimits gelten
            zusätzlich; Backoff und Retry-After können die Abfragen weiter
            begrenzen.
          </p>
        </Panel>
      </div>
      <Panel title="Gemessene Latenzen · letzte Stunde">
        <div className="horizontal-scroll" tabIndex={0}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Messstrecke</th>
                <th>Stichproben</th>
                <th>p50</th>
                <th>p95</th>
                <th>p99</th>
              </tr>
            </thead>
            <tbody>
              {health?.metrics.map((m: any) => (
                <tr key={m.stage}>
                  <td>
                    {(
                      {
                        ingest:
                          "Validierte Beobachtung → Persistenz (vor Commit)",
                        ingest_commit: "Validierte Beobachtung → DB-Commit",
                        legacy_db_to_ui:
                          "DB-Update → Browserdarstellung (frühere Messung)",
                        receipt_to_ui:
                          "Provider-Antworteingang → Browserdarstellung (frische Updates)",
                        db_to_ui: "DB-Update → Browserdarstellung",
                        filter: "Lokale Filterberechnung",
                        search: "Quellensuche → Antwort",
                        tti: "Navigation → erste bedienbare Datenansicht",
                      } as Record<string, string>
                    )[m.stage] ?? m.stage}
                  </td>
                  <td>{m.n}</td>
                  <td>{Math.round(m.p50)} ms</td>
                  <td>{Math.round(m.p95)} ms</td>
                  <td>{Math.round(m.p99)} ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="panel-note">
          Provider-HTTP-Latenz steht separat oben. Latenz seit tatsächlichem
          Onchain-Ereignis ist ohne verlässlichen Messzeitpunkt unbekannt.
          Browser-Messungen setzen hinreichend synchrone Uhren voraus.
        </p>
      </Panel>
      <Panel title="Quell-Audits · letzte Anfragen">
        <div className="horizontal-scroll" tabIndex={0}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Zeit</th>
                <th>Quelle</th>
                <th>Endpunkt</th>
                <th>Ergebnis</th>
                <th>HTTP-Latenz</th>
              </tr>
            </thead>
            <tbody>
              {audit.map((a, i) => (
                <tr key={i}>
                  <td>{dateTime(a.at, timezone)}</td>
                  <td>{sourceName(a.provider)}</td>
                  <td>{a.endpoint}</td>
                  <td>
                    <Badge tone={a.ok ? "neutral" : "amber"}>
                      {a.status}
                      {a.ok ? " · OK" : " · Fehler"}
                    </Badge>
                  </td>
                  <td>{Math.round(a.latency_ms)} ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!audit.length && <Empty title="Noch keine Quell-Audits verfügbar" />}
      </Panel>
    </>
  );
}
