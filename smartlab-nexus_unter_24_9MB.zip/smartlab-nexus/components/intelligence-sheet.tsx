"use client";
import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import type { PoolRow } from "../lib/domain";
import { Preview } from "./scanner";
export function IntelligenceSheet({
  row,
  onClose,
  onOpen,
  onWatch,
  watched,
  timezone,
}: {
  row: PoolRow;
  onClose: () => void;
  onOpen: (row: PoolRow) => void;
  onWatch: (row: PoolRow) => void;
  watched: boolean;
  timezone: string;
}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    ref.current?.querySelector<HTMLButtonElement>("button")?.focus();
    const key = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        event.stopPropagation();
      }
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
      if (event.key === "Tab") {
        const nodes = [
          ...(ref.current?.querySelectorAll<HTMLElement>(
            'button,a[href],input,select,[tabindex="0"]',
          ) ?? []),
        ].filter(
          (n) =>
            n.getBoundingClientRect().width > 0 && !n.hasAttribute("disabled"),
        );
        const first = nodes[0],
          last = nodes.at(-1);
        if (!ref.current?.contains(document.activeElement)) {
          event.preventDefault();
          first?.focus();
        } else if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [onClose, row.id]);
  return (
    <div className="intelligence-overlay">
      <button
        className="intelligence-backdrop"
        aria-label="Schnellanalyse schließen"
        tabIndex={-1}
        onClick={onClose}
      />
      <section
        ref={ref}
        className="intelligence-sheet"
        role="dialog"
        aria-modal="true"
        aria-label="Token-Schnellanalyse"
      >
        <div className="sheet-handle" aria-hidden="true" />
        <div className="sheet-heading">
          <div>
            <span className="section-index">TOKEN INTELLIGENCE</span>
            <h2>Schnellanalyse</h2>
          </div>
          <button
            className="icon-button"
            aria-label="Analyse schließen"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
        <Preview
          row={row}
          watched={watched}
          onWatch={onWatch}
          timezone={timezone}
          onOpen={(r) => {
            onClose();
            onOpen(r);
          }}
        />
      </section>
    </div>
  );
}
