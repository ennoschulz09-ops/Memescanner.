"use client";
import { useState, type ReactNode } from "react";
import {
  Copy,
  Check,
  Info,
  SearchX,
  ArrowUpRight,
  Activity,
  LoaderCircle,
} from "lucide-react";
import { short, usd, formatNumber } from "../lib/client";
import type { SignalState } from "../lib/domain";

export function Badge({
  children,
  tone = "neutral",
  dot = false,
}: {
  children: ReactNode;
  tone?: string;
  dot?: boolean;
}) {
  return (
    <span className={`badge ${tone}`}>
      {dot && <i />}
      {children}
    </span>
  );
}
export function RiskBadge({ state }: { state: SignalState }) {
  return (
    <Badge
      tone={
        state === "critical"
          ? "red"
          : state === "unknown"
            ? "muted"
            : state === "notable"
              ? "amber"
              : "cyan"
      }
    >
      {
        {
          critical: "Kritisches Risiko",
          unknown: "Unbekannt",
          notable: "Auffällig",
          observed: "Beobachten",
        }[state]
      }
    </Badge>
  );
}
export function Panel({
  children,
  className = "",
  title,
  action,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  action?: ReactNode;
}) {
  return (
    <section className={`panel ${className}`}>
      {title && (
        <div className="panel-heading">
          <h3>{title}</h3>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
export function Empty({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="empty-state">
      {icon ?? <SearchX size={28} />}
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action}
    </div>
  );
}
export function Loading({
  label = "Daten werden geladen …",
}: {
  label?: string;
}) {
  return (
    <div className="loading" role="status">
      <LoaderCircle size={20} className="spin" />
      <span>{label}</span>
    </div>
  );
}
export function ErrorBox({
  error,
  retry,
}: {
  error: string;
  retry?: () => void;
}) {
  return (
    <div className="error-box" role="alert">
      <Info size={17} />
      <span>{error}</span>
      {retry && <button onClick={retry}>Erneut versuchen</button>}
    </div>
  );
}
export function TokenAvatar({
  mint,
  symbol,
  size = "normal",
}: {
  mint: string;
  symbol: string;
  size?: "normal" | "large";
}) {
  const hue = [...mint].reduce((n, c) => n + c.charCodeAt(0), 0) % 360;
  return (
    <span
      aria-hidden="true"
      className={`token-avatar ${size}`}
      style={{
        background: `linear-gradient(145deg,hsl(${hue} 45% 24%),hsl(${(hue + 50) % 360} 45% 12%))`,
        color: `hsl(${hue} 65% 80%)`,
      }}
    >
      {symbol.slice(0, 2).toUpperCase()}
    </span>
  );
}
export function CopyAddress({
  value,
  full = false,
}: {
  value: string;
  full?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className="copy-address"
      title={value}
      aria-label={`${full ? value : short(value)} — Contract-Adresse kopieren`}
      onClick={async (e) => {
        e.stopPropagation();
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        } catch {
          setCopied(false);
        }
      }}
    >
      <span>{full ? value : short(value)}</span>
      {copied ? <Check size={12} /> : <Copy size={12} />}
    </button>
  );
}
export function Stat({
  label,
  value,
  sub,
  icon,
  tone = "cyan",
}: {
  label: string;
  value: ReactNode;
  sub: ReactNode;
  icon?: ReactNode;
  tone?: string;
}) {
  return (
    <div className={`stat-card ${tone}`}>
      <div className="stat-top">
        <span>{label}</span>
        <span className="stat-icon">{icon ?? <Activity size={16} />}</span>
      </div>
      <strong>{value}</strong>
      <div className="stat-bottom">{sub}</div>
      <span className="stat-corner">
        <ArrowUpRight size={16} />
      </span>
    </div>
  );
}
export function Change({
  value,
  suffix = "%",
}: {
  value: number | null;
  suffix?: string;
}) {
  return (
    <span
      className={value === null ? "dim" : value >= 0 ? "positive" : "negative"}
    >
      {value === null
        ? "—"
        : (value > 0 ? "+" : "") +
          new Intl.NumberFormat("de-DE", { maximumFractionDigits: 2 }).format(
            value,
          ) +
          suffix}
    </span>
  );
}
export function Quality({ value }: { value: number }) {
  return (
    <span
      className="quality"
      title="Vollständigkeit, Quellenabdeckung und Frische; kein Sicherheitsnachweis"
    >
      <span className="quality-track">
        <i style={{ width: value + "%" }} />
      </span>
      <span>
        {value}
        <small>/100</small>
      </span>
    </span>
  );
}
export function KeyValue({
  label,
  value,
}: {
  label: string;
  value: ReactNode;
}) {
  return (
    <div className="key-value">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
export function Amount({
  value,
  price = false,
}: {
  value: number | null;
  price?: boolean;
}) {
  return (
    <span title={value === null ? "Unbekannt" : String(value)}>
      {value === null ? (
        <span className="unknown">unbekannt</span>
      ) : (
        usd(value, price)
      )}
    </span>
  );
}
export function MetricValue({ value }: { value: number | null }) {
  return value === null ? (
    <span className="unknown">unbekannt</span>
  ) : (
    <>{formatNumber(value)}</>
  );
}
