"use client";
import { memo, useMemo, useRef, useState, useEffect } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import {
  Star,
  SlidersHorizontal,
  Columns3,
  ArrowDown,
  ArrowUp,
  Plus,
  X,
  Search,
  ChevronRight,
  Radio,
  ArrowUpRight,
  ShieldAlert,
  Download,
  Check,
  BookmarkPlus,
} from "lucide-react";
import type { PoolRow } from "../lib/domain";
import { freshness } from "../lib/domain";
import { evidenceLabel, evidenceState } from "../lib/value-evidence";
import { MarketValue } from "./market-value";
import {
  filterPools,
  sortPools,
  relativeVolume,
  type Filters,
} from "../lib/filters";
import {
  ago,
  usd,
  formatNumber,
  sourceName,
  reportMetric,
  short,
} from "../lib/client";
import {
  Badge,
  TokenAvatar,
  CopyAddress,
  Change,
  Quality,
  RiskBadge,
  Empty,
  Amount,
  KeyValue,
} from "./ui";
import { Sparkline, TimeChart } from "./charts";

export const defaultColumns = [
  "token",
  "age",
  "priceUsd",
  "liquidityUsd",
  "volume5m",
  "change5m",
  "risk",
  "quality",
];
const columns = [
  { id: "token", label: "Token / Pool", width: 215, sort: "name" },
  { id: "age", label: "Poolalter", width: 65, sort: "createdAt" },
  { id: "dex", label: "DEX", width: 110, sort: "dex" },
  { id: "chain", label: "Chain", width: 80, sort: "chain" },
  { id: "priceUsd", label: "Preis", width: 105 },
  { id: "liquidityUsd", label: "Liquidität", width: 105 },
  { id: "volume5m", label: "Vol. 5m", width: 85 },
  { id: "volume1h", label: "Vol. 1h", width: 100 },
  { id: "volume24h", label: "Vol. 24h", width: 110 },
  { id: "trades", label: "Trades 5m", width: 95 },
  { id: "ratio", label: "Buy/Sell 5m", width: 100 },
  { id: "change5m", label: "Δ Preis 5m", width: 90 },
  { id: "fdvUsd", label: "FDV", width: 110 },
  { id: "marketCapUsd", label: "Market Cap", width: 115 },
  { id: "risk", label: "Risiko", width: 126 },
  { id: "quality", label: "Datenqualität", width: 100 },
  { id: "momentum", label: "Momentum 5m", width: 110 },
  { id: "sparkline", label: "Preisverlauf", width: 110 },
];
const presets = [
  { id: "all", label: "Alle Pools" },
  { id: "new", label: "Neue Listings" },
  { id: "rising", label: "Steigendes Volumen" },
  { id: "liquidity", label: "Hohe Liquidität" },
  { id: "unusual", label: "Auffällige Aktivität" },
  { id: "quality", label: "Wenig Daten" },
  { id: "critical", label: "Kritisches Risiko" },
];
interface Props {
  page?: number;
  totalRows?: number;
  pageSize?: number;
  onPage?: (page: number) => void;
  onServerSort?: (sort: { key: string; direction: "asc" | "desc" }) => void;
  rows: PoolRow[];
  filters: Filters;
  onFilters: (f: Filters) => void;
  selected: PoolRow | null;
  onSelect: (r: PoolRow) => void;
  watched: Set<string>;
  onWatch: (r: PoolRow) => void;
  onOpen: (r: PoolRow) => void;
  columns: string[];
  onColumns: (c: string[]) => void;
  presets: { id: string; name: string; filters: Filters }[];
  onSavePreset: (name: string) => Promise<void>;
  onDeletePreset: (id: string) => Promise<void>;
  onRemoteSearch: () => void;
  searching: boolean;
  now: number;
  timezone: string;
  compact: boolean;
}
function cell(id: string, r: PoolRow) {
  if (id === "age")
    return (
      <span
        title={
          r.createdAt
            ? `Pool erstellt: ${r.createdAt}; Tokenalter unbekannt`
            : "Pool- und Tokenalter unbekannt"
        }
      >
        {r.createdAt ? ago(r.createdAt) : "unbekannt"}
      </span>
    );
  if (id === "dex") return <span className="dex-name">{r.dex}</span>;
  if (id === "chain") return <Badge tone="violet">Solana</Badge>;
  if (
    [
      "priceUsd",
      "liquidityUsd",
      "volume5m",
      "volume1h",
      "volume24h",
      "fdvUsd",
      "marketCapUsd",
    ].includes(id)
  )
    return <Amount value={(r as any)[id]} price={id === "priceUsd"} />;
  if (id === "change5m" || id === "momentum")
    return <Change value={r.change5m} />;
  if (id === "risk") return <RiskBadge state={r.risk.state} />;
  if (id === "quality") return <Quality value={r.risk.dataQuality} />;
  if (id === "sparkline") return <Sparkline points={r.sparkline} />;
  if (id === "trades")
    return (
      <span>
        {r.buys5m === null || r.sells5m === null
          ? "unbekannt"
          : formatNumber(r.buys5m + r.sells5m)}
      </span>
    );
  if (id === "ratio")
    return (
      <span title="Gemeldete Kauf-/Verkaufsanzahl, reine Aktivitätsdaten">
        {r.buys5m === null || r.sells5m === null
          ? "unbekannt"
          : r.sells5m === 0
            ? r.buys5m === 0
              ? "—"
              : "∞"
            : formatNumber(r.buys5m / r.sells5m, false)}
      </span>
    );
  return null;
}
const TableRow = memo(function TableRow({
  row,
  cols,
  watched,
  selected,
  onSelect,
  onWatch,
  style,
}: {
  row: PoolRow;
  cols: typeof columns;
  watched: boolean;
  selected: boolean;
  onSelect: (r: PoolRow) => void;
  onWatch: (r: PoolRow) => void;
  style: React.CSSProperties;
}) {
  const fresh = freshness(row);
  return (
    <div
      data-testid="pool-row"
      role="row"
      tabIndex={0}
      aria-selected={selected}
      data-pool-id={row.id}
      data-revision={row.revision ?? row.updatedAt}
      className={`pool-row ${selected ? "selected" : ""} ${fresh === "stale" ? "stale-row" : ""}`}
      style={style}
      onClick={() => onSelect(row)}
      onKeyDown={(e) => {
        if (e.key === "Enter") onSelect(row);
      }}
    >
      {cols.map((c) => (
        <div
          role="cell"
          key={c.id}
          className={`table-cell ${c.id === "token" ? "token-cell" : ""}`}
          data-market-value={
            !["token", "age", "dex", "chain", "risk", "quality"].includes(c.id)
              ? c.id
              : undefined
          }
          data-source={row.provenance.provider}
          data-freshness={evidenceState(row, c.id).freshness}
          data-missing={evidenceState(row, c.id).missing}
          title={c.id !== "token" ? evidenceLabel(row, c.id) : undefined}
        >
          {c.id === "token" ? (
            <>
              <button
                className={`star-button ${watched ? "saved" : ""}`}
                aria-label={
                  watched
                    ? `${row.symbol} aus Watchlist entfernen`
                    : `${row.symbol} Zur Watchlist hinzufügen`
                }
                onClick={(e) => {
                  e.stopPropagation();
                  onWatch(row);
                }}
              >
                <Star size={14} fill={watched ? "currentColor" : "none"} />
              </button>
              <TokenAvatar mint={row.mint} symbol={row.symbol} />
              <div className="token-lines">
                <div>
                  <strong>{row.symbol}</strong>
                  <span className="token-name" title={row.name}>
                    {row.name}
                  </span>
                </div>
                <div className="token-meta">
                  <span title={row.mint}>{short(row.mint)}</span>
                  <span>·</span>
                  <span
                    title={`${sourceName(row.provenance.provider)} · ${row.provenance.sourceAt} · ${row.provenance.timestampKind}`}
                  >
                    {fresh === "stale"
                      ? "Veraltet · Abruf"
                      : row.provenance.timestampKind === "retrieval-only"
                        ? "Abruf"
                        : "HTTP-Cache"}{" "}
                    {ago(row.provenance.sourceAt)}
                  </span>
                </div>
              </div>
            </>
          ) : (
            cell(c.id, row)
          )}
        </div>
      ))}
    </div>
  );
});
export function Scanner(props: Props) {
  const { rows, filters, onFilters, selected, onSelect, watched, onWatch } =
    props;
  const parent = useRef<HTMLDivElement>(null);
  const [mobileCards, setMobileCards] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(max-width: 600px)");
    const update = () => setMobileCards(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const [sort, setSort] = useState({
    key: "firstSeenAt",
    direction: "desc" as "asc" | "desc",
  });
  const [filterOpen, setFilterOpen] = useState(false),
    [presetOpen, setPresetOpen] = useState(false),
    [presetName, setPresetName] = useState("");
  const shownCols = columns.filter(
    (c) => props.columns.includes(c.id) || c.id === "token",
  );
  const grid = shownCols.map((c) => `${c.width}px`).join(" ");
  const width = shownCols.reduce((n, c) => n + c.width, 0);
  const filtered = useMemo(() => {
    const start = performance.now();
    const result = sortPools(
      filterPools(rows, filters, props.now || Date.now()),
      sort.key,
      sort.direction,
    );
    // Rendering is measured separately by the browser benchmark; this records only calculation time.
    return { rows: result, duration: performance.now() - start };
  }, [rows, filters, sort, props.now]);
  useEffect(() => {
    if (filters.query) reportMetric("filter", filtered.duration);
  }, [filters.query, filtered.duration]);
  const virtual = useVirtualizer({
    count: filtered.rows.length,
    getScrollElement: () => parent.current,
    estimateSize: () => (mobileCards ? 128 : props.compact ? 56 : 68),
    overscan: 8,
  });
  useEffect(() => virtual.measure(), [mobileCards, virtual]);
  const customCount = Object.keys(filters).filter(
    (k) =>
      !["query", "preset"].includes(k) &&
      filters[k as keyof Filters] !== undefined &&
      filters[k as keyof Filters] !== "",
  ).length;
  const sortBy = (key: string) => {
    const next = {
      key,
      direction:
        sort.key === key && sort.direction === "desc"
          ? ("asc" as const)
          : ("desc" as const),
    };
    setSort(next);
    props.onServerSort?.(next);
  };
  const filterRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!filterOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const root = filterRef.current;
    const timer = setTimeout(
      () => root?.querySelector<HTMLElement>("input,select,button")?.focus(),
      0,
    );
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") setFilterOpen(false);
      if (event.key === "Tab" && window.innerWidth <= 800 && root) {
        const items = [
          ...root.querySelectorAll<HTMLElement>("input,select,button"),
        ].filter((x) => !x.hasAttribute("disabled"));
        if (event.shiftKey && document.activeElement === items[0]) {
          event.preventDefault();
          items.at(-1)?.focus();
        } else if (!event.shiftKey && document.activeElement === items.at(-1)) {
          event.preventDefault();
          items[0]?.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [filterOpen]);
  return (
    <div className="scanner-layout">
      <section className="scanner-main">
        <div className="quick-filter-row">
          {presets.slice(0, 4).map((p) => (
            <button
              key={p.id}
              className={`filter-pill ${(filters.preset ?? "all") === p.id ? "active" : ""}`}
              onClick={() => onFilters({ ...filters, preset: p.id })}
            >
              {p.id === "new" && <span className="new-dot" />}
              {p.label}
              {p.id === "all" && (
                <small>{props.totalRows ?? rows.length}</small>
              )}
            </button>
          ))}
          <details className="more-filters">
            <summary aria-label="Weitere Schnellfilter">
              <Plus size={14} />
            </summary>
            <div className="dropdown">
              {presets.slice(4).map((p) => (
                <button
                  key={p.id}
                  onClick={() => onFilters({ ...filters, preset: p.id })}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </details>
        </div>
        <div className="scanner-panel panel">
          <div className="scanner-toolbar">
            <div className="table-title">
              <Radio size={16} />
              <h2>Token-Radar</h2>
              <Badge>{filtered.rows.length} Pools</Badge>
            </div>
            <div className="toolbar-actions">
              <label className="scanner-sort-control">
                <span className="sr-only">Sortierung</span>
                <select
                  aria-label="Scanner-Sortierung"
                  value={`${sort.key}:${sort.direction}`}
                  onChange={(e) => {
                    const [key, direction] = e.target.value.split(":");
                    const next = {
                      key,
                      direction: direction as "asc" | "desc",
                    };
                    setSort(next);
                    props.onServerSort?.(next);
                  }}
                >
                  <option value="firstSeenAt:desc">Neueste Funde</option>
                  <option value="liquidityUsd:desc">Liquidität ↓</option>
                  <option value="priceUsd:desc">Preis ↓</option>
                  <option value="name:asc">Name A–Z</option>
                  {![
                    "firstSeenAt:desc",
                    "liquidityUsd:desc",
                    "priceUsd:desc",
                    "name:asc",
                  ].includes(`${sort.key}:${sort.direction}`) && (
                    <option value={`${sort.key}:${sort.direction}`}>
                      Aktuelle Spaltensortierung
                    </option>
                  )}
                </select>
              </label>
              <button
                className={`button subtle small ${customCount ? "highlight" : ""}`}
                onClick={() => setFilterOpen(!filterOpen)}
              >
                <SlidersHorizontal size={14} />
                Filter{customCount > 0 && <small>{customCount}</small>}
              </button>
              <details className="column-picker">
                <summary
                  className="button subtle small"
                  aria-label="Spalten auswählen"
                >
                  <Columns3 size={14} />
                  <span>Spalten</span>
                </summary>
                <div className="dropdown columns-dropdown">
                  {columns
                    .filter((c) => c.id !== "token")
                    .map((c) => (
                      <label key={c.id}>
                        <input
                          type="checkbox"
                          checked={props.columns.includes(c.id)}
                          onChange={(e) =>
                            props.onColumns(
                              e.target.checked
                                ? [...props.columns, c.id]
                                : props.columns.filter((x) => x !== c.id),
                            )
                          }
                        />
                        {c.label}
                      </label>
                    ))}
                </div>
              </details>
              <a
                className="icon-button export-icon"
                href="/api/export?format=csv"
                aria-label="Scanner als CSV exportieren"
              >
                <Download size={15} />
              </a>
            </div>
          </div>
          {filterOpen && (
            <div
              className="filter-drawer"
              ref={filterRef}
              role="dialog"
              aria-label="Scanner-Filter"
              aria-modal={
                typeof window !== "undefined" && window.innerWidth <= 800
                  ? true
                  : undefined
              }
            >
              <button
                className="button small filter-close"
                onClick={() => setFilterOpen(false)}
                aria-label="Scanner-Filter schließen"
              >
                <X size={14} />
                Filter schließen
              </button>
              <div className="filter-fields">
                {[
                  ["minLiquidity", "Min. Liquidität (USD)"],
                  ["maxPoolAgeMins", "Max. Poolalter (Min.)"],
                  ["minRelativeVolume", "Min. relatives Volumen"],
                  ["minActivity", "Min. Trades (5m)"],
                  ["minActivityIncrease", "Min. Aktivitätsanstieg (%)"],
                  ["maxConcentration", "Max. größtes Tokenkonto (%)"],
                  ["minQuality", "Min. Datenqualität"],
                ].map(([k, label]) => (
                  <label key={k}>
                    {label}
                    <input
                      type="number"
                      min="0"
                      value={(filters as any)[k] ?? ""}
                      placeholder="Beliebig"
                      onChange={(e) =>
                        onFilters({
                          ...filters,
                          [k]:
                            e.target.value === ""
                              ? undefined
                              : Number(e.target.value),
                        })
                      }
                    />
                  </label>
                ))}
                <label>
                  DEX
                  <select
                    value={filters.dex ?? ""}
                    onChange={(e) =>
                      onFilters({ ...filters, dex: e.target.value })
                    }
                  >
                    <option value="">Alle DEXes</option>
                    {[...new Set(rows.map((x) => x.dex))].sort().map((d) => (
                      <option key={d}>{d}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Risikostatus
                  <select
                    value={filters.security ?? ""}
                    onChange={(e) =>
                      onFilters({
                        ...filters,
                        security: e.target.value as Filters["security"],
                      })
                    }
                  >
                    <option value="">Alle Zustände</option>
                    <option value="critical">Kritisches Risiko</option>
                    <option value="unknown">Unbekannt</option>
                    <option value="observed">Beobachten</option>
                  </select>
                </label>
              </div>
              <div className="filter-actions">
                <button
                  className="button subtle small"
                  onClick={() =>
                    onFilters({ query: filters.query, preset: "all" })
                  }
                >
                  Filter zurücksetzen
                </button>
                <button
                  className="button small"
                  onClick={() => setPresetOpen(!presetOpen)}
                >
                  <BookmarkPlus size={14} />
                  Als Preset speichern
                </button>
                <button
                  className="button primary small"
                  onClick={() => setFilterOpen(false)}
                >
                  <Check size={14} />
                  Anwenden
                </button>
              </div>
              {presetOpen && (
                <form
                  className="inline-form"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    await props.onSavePreset(presetName);
                    setPresetName("");
                    setPresetOpen(false);
                  }}
                >
                  <input
                    aria-label="Preset-Name"
                    placeholder="Name des Presets"
                    value={presetName}
                    maxLength={64}
                    required
                    onChange={(e) => setPresetName(e.target.value)}
                  />
                  <button className="button primary small" type="submit">
                    Speichern
                  </button>
                </form>
              )}
            </div>
          )}
          {props.presets.length > 0 && (
            <div className="saved-presets">
              {props.presets.map((p) => (
                <span key={p.id}>
                  <button
                    onClick={() =>
                      onFilters({ ...p.filters, query: filters.query })
                    }
                  >
                    {p.name}
                  </button>
                  <button
                    aria-label={`${p.name} löschen`}
                    onClick={() => void props.onDeletePreset(p.id)}
                  >
                    <X size={11} />
                  </button>
                </span>
              ))}
            </div>
          )}
          <div
            className="virtual-table"
            role="table"
            aria-label="Solana Token Scanner"
            aria-rowcount={filtered.rows.length + 1}
            ref={parent}
            data-testid="virtual-table"
          >
            <div
              role="row"
              className="table-header"
              style={{
                gridTemplateColumns: grid,
                minWidth: mobileCards ? 0 : width,
              }}
            >
              {shownCols.map((c) => (
                <div
                  key={c.id}
                  role="columnheader"
                  aria-sort={
                    sort.key === (c.sort ?? c.id)
                      ? sort.direction === "asc"
                        ? "ascending"
                        : "descending"
                      : "none"
                  }
                >
                  <button onClick={() => sortBy(c.sort ?? c.id)}>
                    {c.label}
                    {sort.key === (c.sort ?? c.id) ? (
                      sort.direction === "desc" ? (
                        <ArrowDown size={11} />
                      ) : (
                        <ArrowUp size={11} />
                      )
                    ) : null}
                  </button>
                </div>
              ))}
            </div>
            {filtered.rows.length ? (
              <div
                role="rowgroup"
                style={{
                  height: virtual.getTotalSize(),
                  minWidth: mobileCards ? 0 : width,
                  position: "relative",
                }}
              >
                {virtual.getVirtualItems().map((v) => {
                  const row = filtered.rows[v.index];
                  return (
                    <TableRow
                      key={row.id}
                      row={row}
                      cols={shownCols}
                      watched={watched.has(row.mint)}
                      selected={row.id === selected?.id}
                      onSelect={onSelect}
                      onWatch={onWatch}
                      style={{
                        gridTemplateColumns: grid,
                        height: v.size,
                        transform: `translateY(${v.start}px)`,
                        minWidth: mobileCards ? 0 : width,
                      }}
                    />
                  );
                })}
              </div>
            ) : (
              <Empty
                title="Keine passenden Pools"
                description={
                  filters.query
                    ? "Suche in den erfassten Daten oder frage die dokumentierte DexScreener-Suche ab."
                    : "Passe die Filter an. Fehlende Werte erfüllen numerische Mindestanforderungen nicht."
                }
                action={
                  <div className="empty-actions">
                    <button
                      className="button"
                      onClick={() => onFilters({ preset: "all" })}
                    >
                      Suche zurücksetzen
                    </button>
                    {filters.query && (
                      <button
                        className="button primary"
                        disabled={props.searching}
                        onClick={props.onRemoteSearch}
                      >
                        <Search size={14} />
                        {props.searching
                          ? "Suche läuft …"
                          : "Quelle durchsuchen"}
                      </button>
                    )}
                  </div>
                }
              />
            )}
          </div>
          <div className="table-footer">
            <span>
              <span className="tiny-dot" />
              GeckoTerminal + DexScreener · budgetiertes Polling
            </span>
            <span>
              {Math.min(filtered.rows.length, virtual.getVirtualItems().length)}{" "}
              sichtbare Zeilen · {filtered.rows.length} gesamt
            </span>
            {props.totalRows !== undefined && (
              <div className="pagination-controls">
                <button
                  className="button small"
                  aria-label="Vorherige Scanner-Seite"
                  disabled={(props.page ?? 1) <= 1}
                  onClick={() => props.onPage?.((props.page ?? 1) - 1)}
                >
                  ‹
                </button>
                <span>
                  Seite {props.page ?? 1} /{" "}
                  {Math.max(
                    1,
                    Math.ceil(props.totalRows / (props.pageSize ?? 100)),
                  )}{" "}
                  · {props.totalRows} Treffer
                </span>
                <button
                  className="button small"
                  aria-label="Nächste Scanner-Seite"
                  disabled={
                    (props.page ?? 1) * (props.pageSize ?? 100) >=
                    props.totalRows
                  }
                  onClick={() => props.onPage?.((props.page ?? 1) + 1)}
                >
                  ›
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="scanner-note">
          <ShieldAlert size={14} />
          <span>
            Recherche beginnt mit Daten. Ein Score ist keine Empfehlung.
            Fehlende Prüfungen bleiben unbekannt.
          </span>
        </div>
      </section>
      <Preview
        row={selected}
        onOpen={props.onOpen}
        onWatch={onWatch}
        watched={selected ? watched.has(selected.mint) : false}
        timezone={props.timezone}
      />
    </div>
  );
}
export function Preview({
  row,
  onOpen,
  onWatch,
  watched,
  timezone,
}: {
  row: PoolRow | null;
  onOpen: (r: PoolRow) => void;
  onWatch: (r: PoolRow) => void;
  watched: boolean;
  timezone: string;
}) {
  if (!row)
    return (
      <aside className="token-preview panel">
        <Empty
          title="Pool auswählen"
          description="Öffne einen Pool, um seine Daten und Risiken zu prüfen."
        />
      </aside>
    );
  const signals = row.risk.signals.filter(
    (x) =>
      x.key !== "quality" &&
      x.key !== "lp-lock" &&
      x.key !== "clusters" &&
      x.key !== "momentum",
  );
  return (
    <aside className="token-preview panel">
      <div className="preview-heading">
        <span>POOL-INSIGHT</span>
        <Badge tone="violet">SOLANA</Badge>
      </div>
      <div className="preview-token">
        <TokenAvatar mint={row.mint} symbol={row.symbol} size="large" />
        <div>
          <h2>{row.symbol}</h2>
          <span>{row.name}</span>
        </div>
        <button
          className={`icon-button ${watched ? "saved" : ""}`}
          onClick={() => onWatch(row)}
          aria-label={
            watched ? "Aus Watchlist entfernen" : "Zur Watchlist hinzufügen"
          }
        >
          <Star size={17} fill={watched ? "currentColor" : "none"} />
        </button>
      </div>
      <CopyAddress value={row.mint} />
      <div className="preview-price">
        <strong>
          <MarketValue row={row} field="priceUsd" price />
        </strong>
        <Change value={row.change5m} />
        <small>5m</small>
      </div>
      <div className="preview-chart">
        <TimeChart
          points={row.sparkline}
          label="Eigene Preisbeobachtungen"
          source={sourceName(row.provenance.provider)}
          height={150}
          timezone={timezone}
        />
      </div>
      <div className="preview-metrics">
        <div>
          <span>Liquidität</span>
          <strong>
            <MarketValue row={row} field="liquidityUsd" />
          </strong>
        </div>
        <div>
          <span>Volumen · 24h</span>
          <strong>
            <MarketValue row={row} field="volume24h" />
          </strong>
        </div>
        <div>
          <span>Market Cap</span>
          <strong>
            <MarketValue row={row} field="marketCapUsd" />
          </strong>
        </div>
        <div>
          <span>FDV</span>
          <strong>
            <MarketValue row={row} field="fdvUsd" />
          </strong>
        </div>
      </div>
      <div className="preview-risk">
        <div>
          <h3>
            <ShieldAlert size={15} />
            Risiko-Überblick
          </h3>
          <RiskBadge state={row.risk.state} />
        </div>
        {signals.map((s) => (
          <div className="preview-signal" key={s.key} title={s.explanation}>
            <span>{s.label}</span>
            <strong
              className={
                s.state === "critical"
                  ? "negative"
                  : s.state === "unknown"
                    ? "dim"
                    : s.state === "notable"
                      ? "amber-text"
                      : ""
              }
            >
              {s.value === null
                ? "Unbekannt"
                : Math.round(s.value) + (s.unit === "%" ? " %" : " / 100")}
            </strong>
          </div>
        ))}
        <p>
          {row.risk.overall === null
            ? "Nicht ausreichend Daten für einen Gesamtscore."
            : `Gewichteter Risikoindikator ${row.risk.overall}/100; Methodik in der Analyse.`}
        </p>
      </div>
      <div className="preview-provenance">
        <span>Datenherkunft</span>
        <strong>{sourceName(row.provenance.provider)}</strong>
        <small>
          HTTP-Stand:{" "}
          {new Date(row.provenance.sourceAt).toLocaleTimeString("de-DE")} ·{" "}
          {ago(row.provenance.sourceAt)} alt
        </small>
        <small>Messzeitpunkt vom Anbieter nicht veröffentlicht</small>
      </div>
      <button className="button primary full" onClick={() => onOpen(row)}>
        Vollständige Analyse
        <ArrowUpRight size={15} />
      </button>
    </aside>
  );
}
export function Discovery({
  rows,
  onOpen,
  onWatch,
  watched,
}: {
  rows: PoolRow[];
  onOpen: (r: PoolRow) => void;
  onWatch: (r: PoolRow) => void;
  watched: Set<string>;
}) {
  const newest = [...rows]
    .sort((a, b) => Date.parse(b.firstSeenAt) - Date.parse(a.firstSeenAt))
    .slice(0, 30);
  return (
    <>
      <div className="section-intro">
        <div>
          <Badge tone="cyan" dot>
            Öffentliche Entdeckungen
          </Badge>
          <h2>Neu in deinem Radar.</h2>
          <p>
            Zuletzt erfasste Pools. Der Entdeckungszeitpunkt ist kein Nachweis
            für das Alter eines Tokens.
          </p>
        </div>
        <span className="dim">{newest.length} zuletzt erkannt</span>
      </div>
      <div className="discovery-grid">
        {newest.map((r) => (
          <article className="discovery-card panel" key={r.id}>
            <div className="discovery-card-top">
              <TokenAvatar mint={r.mint} symbol={r.symbol} />
              <div>
                <h3>{r.symbol}</h3>
                <p>{r.name}</p>
              </div>
              <button
                className={`icon-button ${watched.has(r.mint) ? "saved" : ""}`}
                aria-label="Zur Watchlist hinzufügen"
                onClick={() => onWatch(r)}
              >
                <Star
                  size={16}
                  fill={watched.has(r.mint) ? "currentColor" : "none"}
                />
              </button>
            </div>
            <div className="discovery-price">
              <strong>{usd(r.priceUsd, true)}</strong>
              <Change value={r.change5m} />
            </div>
            <KeyValue
              label="Poolalter"
              value={r.createdAt ? ago(r.createdAt) : "Unbekannt"}
            />
            <KeyValue label="Liquidität" value={usd(r.liquidityUsd)} />
            <KeyValue
              label="Datenqualität"
              value={`${r.risk.dataQuality}/100`}
            />
            <div className="discovery-card-bottom">
              <RiskBadge state={r.risk.state} />
              <button className="text-button" onClick={() => onOpen(r)}>
                Analysieren
                <ChevronRight size={14} />
              </button>
            </div>
            <small className="source-footnote">
              {sourceName(r.provenance.provider)} · HTTP-Stand{" "}
              {ago(r.provenance.sourceAt)} · {r.dex}
            </small>
          </article>
        ))}
      </div>
      {!rows.length && (
        <Empty
          title="Noch keine Entdeckungen"
          description="Sobald der Worker öffentliche Pools erfasst, erscheinen sie hier."
        />
      )}
    </>
  );
}
