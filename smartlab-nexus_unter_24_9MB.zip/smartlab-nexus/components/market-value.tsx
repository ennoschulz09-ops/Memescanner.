"use client";
import type { Observation } from "../lib/domain";
import { freshness } from "../lib/domain";
import { evidenceLabel } from "../lib/value-evidence";
import { usd } from "../lib/client";
import { Change } from "./ui";
export function MarketValue({
  row,
  field,
  price = false,
}: {
  row: Observation;
  field:
    | "priceUsd"
    | "liquidityUsd"
    | "volume24h"
    | "fdvUsd"
    | "marketCapUsd"
    | "change5m";
  price?: boolean;
}) {
  const missing = row[field] === null || row[field] === undefined;
  return (
    <span
      data-market-value={field}
      data-source={row.provenance.provider}
      data-missing={missing}
      data-freshness={
        missing
          ? "UNAVAILABLE"
          : freshness(row) === "stale"
            ? "STALE"
            : row.provenance.measuredAt
              ? "LIVE"
              : "CACHED"
      }
      title={evidenceLabel(row, field)}
    >
      {missing ? (
        "Unbekannt"
      ) : field === "change5m" ? (
        <Change value={row.change5m} />
      ) : (
        usd(row[field], price)
      )}
    </span>
  );
}
