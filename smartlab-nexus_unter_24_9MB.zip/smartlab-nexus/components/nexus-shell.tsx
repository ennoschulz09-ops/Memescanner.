"use client";
import { useEffect, useState, useMemo, useCallback, useRef } from "react";
import {
  Activity,
  Compass,
  Radio,
  ScanLine,
  ShieldCheck,
  Wallet,
  Star,
  Bell,
  ChartNoAxesCombined,
  HeartPulse,
  Settings2,
  Search,
  Menu,
  X,
  ChevronRight,
  ArrowUpRight,
  Layers,
  Plus,
  Command,
  RefreshCw,
  Clock,
  Info,
  LockKeyhole,
  Pause,
  Play,
  LayoutDashboard,
  Database,
} from "lucide-react";
import type { PoolRow } from "../lib/domain";
import type { Filters } from "../lib/filters";
import { PendingUpdates } from "../lib/sync";
import { DiscoveryFeed } from "./discovery-feed";
import { CommandDashboard, DataQualityDashboard } from "./command-dashboard";
import { IntelligenceSheet } from "./intelligence-sheet";
import {
  api,
  mergeRows,
  ClientError,
  reportMetric,
  formatNumber,
  usd,
  ago,
  dateTime,
  short,
} from "../lib/client";
import { Badge, Panel, Empty, ErrorBox, Stat, Loading } from "./ui";
import { Scanner, Discovery, defaultColumns } from "./scanner";
import { TokenDetail } from "./token-detail";
import {
  RiskLab,
  WalletExplorer,
  Analytics,
  SystemHealth,
  type Health,
} from "./research-views";
import {
  Watchlists,
  Alerts,
  Settings,
  type Watchlist,
  type Preferences,
} from "./managed-views";

const nav = [
  { id: "command", label: "Command Dashboard", icon: LayoutDashboard },
  { id: "discovery", label: "Discovery", icon: Compass },
  { id: "scanner", label: "Live Scanner", icon: Radio },
  { id: "token", label: "Token-Analyse", icon: ScanLine },
  { id: "risk", label: "Risk Lab", icon: ShieldCheck },
  { id: "wallet", label: "Wallet Explorer", icon: Wallet },
  { id: "watchlists", label: "Watchlists", icon: Star },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "analytics", label: "Analytics", icon: ChartNoAxesCombined },
  { id: "quality", label: "Datenqualität", icon: Database },
  { id: "health", label: "System Health", icon: HeartPulse },
  { id: "settings", label: "Einstellungen", icon: Settings2 },
];
const subtitles: Record<string, string> = {
  command: "Quellen verstehen. Neue Funde prüfen. Den Datenstand einordnen.",
  quality: "Abdeckung, Aktualität und Ausfälle aus dem eigenen Datenbestand.",
  scanner:
    "Öffentliche Solana-Pools entdecken. Daten einordnen. Risiken verstehen.",
  discovery: "Neue Perspektiven auf öffentliche Solana-Token- und Pooldaten.",
  token:
    "Marktdaten, öffentliche Evidenzen und nachvollziehbare Risikoindikatoren.",
  risk: "Technische Signale prüfen – mit Herkunft, Schwellen und klaren Grenzen.",
  wallet: "Öffentliche Kontodaten und belegbare Aktivität analysieren.",
  watchlists: "Deine Recherche. Organisiert und kontinuierlich beobachtet.",
  alerts:
    "Relevante Veränderungen erkennen und nachvollziehbar protokollieren.",
  analytics: "Der erfasste Marktausschnitt, transparent aggregiert.",
  health: "Datenfrische, Anbieterbudgets und Erfassung im Blick.",
  settings: "Passe dein Research-Terminal an deinen Arbeitsablauf an.",
};
function Brand() {
  return (
    <div className="brand">
      <span className="brand-icon">
        <svg
          width="30"
          height="30"
          viewBox="0 0 30 30"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M15 2 27 9v12l-12 7L3 21V9L15 2Z"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <path
            d="m9 11 6-3 6 3-6 3-6-3Zm0 5 6 3 6-3M9 21l6 3 6-3"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span>
        <strong>SMARTLAB</strong>
        <span>
          NEXUS<span className="brand-version"> / 01</span>
        </span>
      </span>
    </div>
  );
}
export function NexusShell() {
  const [view, setView] = useState("scanner"),
    [mobileNav, setMobileNav] = useState(false),
    [rows, setRows] = useState<PoolRow[]>([]),
    [health, setHealth] = useState<Health | null>(null);
  const [frozen, setFrozen] = useState(false),
    frozenRef = useRef(false);
  const [sheetRow, setSheetRow] = useState<PoolRow | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const closeSheet = useCallback(() => setSheetRow(null), []);
  useEffect(() => {
    const media = window.matchMedia("(max-width: 800px)");
    const update = () => setIsMobile(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const [lists, setLists] = useState<Watchlist[]>([]),
    [presets, setPresets] = useState<any[]>([]),
    [preferences, setPreferences] = useState<Preferences>({}),
    [filters, setFilters] = useState<Filters>({ preset: "all" });
  const [query, setQuery] = useState(""),
    [selectedId, setSelectedId] = useState<string | null>(null),
    [detailMint, setDetailMint] = useState<string | null>(null),
    [detailPool, setDetailPool] = useState<string | undefined>();
  const [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [healthError, setHealthError] = useState(""),
    [stream, setStream] = useState("Verbinde …"),
    [authorized, setAuthorized] = useState<boolean | null>(null),
    [searching, setSearching] = useState(false),
    [toast, setToast] = useState(""),
    [now, setNow] = useState(0);
  const [page, setPage] = useState(1),
    [pageMeta, setPageMeta] = useState<{
      total: number;
      pageSize: number;
    } | null>(null),
    [serverSort, setServerSort] = useState({
      key: "firstSeenAt",
      direction: "desc" as "asc" | "desc",
    });
  const pageQuery =
    "pools?" +
    new URLSearchParams({
      page: String(page),
      pageSize: String(isMobile ? 25 : 100),
      sort: serverSort.key,
      direction: serverSort.direction,
      filters: JSON.stringify(filters),
      format: "compact",
    }).toString();
  const activePageSize = useRef(isMobile ? 25 : 100);
  activePageSize.current = isMobile ? 25 : 100;
  const pageQueryRef = useRef(pageQuery),
    rowsRef = useRef(rows),
    pagedRef = useRef(false),
    requestSequence = useRef(0);
  pageQueryRef.current = pageQuery;
  rowsRef.current = rows;
  const searchRef = useRef<HTMLInputElement>(null),
    ttiSent = useRef(false);
  const timezone = preferences.timezone ?? "local";
  const watched = useMemo(
    () => new Set(lists.flatMap((l) => l.items.map((x) => x.mint))),
    [lists],
  );
  const selected = useMemo(
    () => rows.find((x) => x.id === selectedId) ?? rows[0] ?? null,
    [rows, selectedId],
  );
  const notify = useCallback((text: string) => {
    setToast(text);
  }, []);
  const reloadLists = useCallback(async () => {
    setLists((await api("watchlists")).lists);
  }, []);
  const reloadPresets = useCallback(async () => {
    setPresets((await api("presets")).presets);
  }, []);
  const reloadPools = useCallback(async () => {
    const sequence = ++requestSequence.current;
    const queryAtStart = pageQueryRef.current;
    const frozenAtStart = frozenRef.current;
    const d = await api(queryAtStart);
    if (
      sequence !== requestSequence.current ||
      queryAtStart !== pageQueryRef.current ||
      (!frozenAtStart && frozenRef.current)
    )
      return;
    pagedRef.current = typeof d.total === "number";
    setPageMeta(
      pagedRef.current ? { total: d.total, pageSize: d.pageSize } : null,
    );
    setRows((old) => {
      const merged = mergeRows(old, d.rows);
      if (!pagedRef.current) return merged;
      const byId = new Map(merged.map((r) => [r.id, r]));
      return d.rows.map((r: PoolRow) => byId.get(r.id)!);
    });
    setError("");
  }, []);
  const reloadHealth = useCallback(async () => {
    try {
      setHealth(await api("health"));
      setHealthError("");
    } catch (e) {
      setHealth(null);
      setHealthError((e as Error).message);
    }
  }, []);
  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const session = await api("session");
      setAuthorized(true);
      setPreferences(session.settings ?? {});
      const results = await Promise.allSettled([
        reloadPools(),
        reloadHealth(),
        reloadLists(),
        reloadPresets(),
      ]);
      for (const result of results)
        if (result.status === "rejected")
          setError((result.reason as Error).message);
    } catch (e) {
      if (e instanceof ClientError && e.status === 401) setAuthorized(false);
      else setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [reloadPools, reloadHealth, reloadLists, reloadPresets]);
  useEffect(() => {
    const readLocation = () => {
      const params = new URLSearchParams(window.location.search),
        v = params.get("view");
      setView(nav.some((n) => n.id === v) ? v! : "scanner");
      setDetailMint(params.get("mint"));
      setDetailPool(params.get("pool") ?? undefined);
    };
    readLocation();
    void load();
    window.addEventListener("popstate", readLocation);
    return () => window.removeEventListener("popstate", readLocation);
  }, [load]);
  useEffect(() => {
    if (authorized)
      void reloadPools().catch((e) => setError((e as Error).message));
  }, [authorized, pageQuery, reloadPools]);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 5000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 4000);
    return () => clearTimeout(id);
  }, [toast]);
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      setFilters((f) => ({ ...f, query: query.trim() }));
    }, 60);
    return () => clearTimeout(timer);
  }, [query]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);
  useEffect(() => {
    if (!authorized) return;
    const es = new EventSource("/api/stream");
    let active = true;
    const pending = new PendingUpdates();
    let syncing = false,
      connected = false,
      retry: ReturnType<typeof setTimeout> | undefined,
      latestNotice: any = null;
    const flush = async () => {
      if (!active || syncing || frozenRef.current) return;
      const task = pending.take();
      if (!task) return;
      syncing = true;
      const notice = latestNotice;
      const queryAtStart = pageQueryRef.current;
      let failed = false;
      try {
        const collected: PoolRow[] = [];
        if (task.full)
          collected.push(...(await api(pageQueryRef.current)).rows);
        else
          for (let i = 0; i < task.ids.length; i += 300)
            collected.push(
              ...(
                await api("pools/query?format=compact", "POST", {
                  ids: task.ids.slice(i, i + 300),
                })
              ).rows,
            );
        if (
          active &&
          !frozenRef.current &&
          queryAtStart === pageQueryRef.current
        ) {
          if (
            pagedRef.current &&
            !task.full &&
            collected.some(
              (r) => !rowsRef.current.some((old) => old.id === r.id),
            )
          )
            void reloadPools().catch(() => {});
          setRows((old) => {
            const merged = mergeRows(old, collected);
            if (!pagedRef.current) return merged;
            const allowed = new Set(
              (task.full ? collected : old).map((r) => r.id),
            );
            return merged
              .filter((r) => allowed.has(r.id))
              .slice(0, activePageSize.current);
          });
          setError("");
          setStream("Verbunden");
          if (notice?.inputAt && !notice.baseline)
            requestAnimationFrame(() =>
              requestAnimationFrame(() => {
                if (notice.publishedAt)
                  reportMetric(
                    "publish_to_ui",
                    Date.now() - Date.parse(notice.publishedAt),
                  );
                reportMetric("db_to_ui", Date.now() - Date.parse(notice.at));
                if (
                  notice.inputAt &&
                  Date.parse(notice.at) - Date.parse(notice.inputAt) < 10000
                )
                  reportMetric(
                    "receipt_to_ui",
                    Date.now() - Date.parse(notice.inputAt),
                  );
              }),
            );
        }
      } catch (e) {
        failed = true;
        pending.failed(task);
        if (active) {
          setError((e as Error).message);
          setStream("Eingeschränkt");
        }
      } finally {
        syncing = false;
        if (active && (failed || pending.hasPending))
          retry = setTimeout(() => void flush(), failed ? 2500 : 25);
      }
    };
    const enqueue = (d: any) => {
      if (frozenRef.current) return;
      latestNotice = d;
      pending.add(d);
      if (retry) clearTimeout(retry);
      retry = setTimeout(() => void flush(), 50);
    };
    es.addEventListener("status", (event) => {
      const d = JSON.parse((event as MessageEvent).data);
      connected = d.transport === "connected";
      if (active && d.resync) enqueue(d);
      if (active)
        setStream(
          d.transport === "connected"
            ? "Verbunden"
            : d.mode === "offline"
              ? "Datenbank offline"
              : "Eingeschränkt",
        );
    });
    es.addEventListener("discovery", () =>
      window.dispatchEvent(new Event("nexus-discovery")),
    );
    es.addEventListener("update", (event) => {
      const d = JSON.parse((event as MessageEvent).data);
      if (frozenRef.current) return;
      if (d.removedIds?.length)
        setRows((old) => old.filter((r) => !d.removedIds.includes(r.id)));
      if (active) enqueue(d);
    });
    es.onerror = () => {
      connected = false;
      if (active) setStream(navigator.onLine ? "Wiederverbinden …" : "Offline");
    };
    es.addEventListener("reconnect", () => {
      if (active) setStream("Wiederverbinden …");
    });
    const timer = setInterval(() => {
      void reloadHealth();
      if (!connected && !frozenRef.current) void reloadPools().catch(() => {});
    }, 15000);
    const offline = () => setStream("Offline"),
      online = () => {
        setStream("Wiederverbinden …");
        void reloadHealth();
      };
    window.addEventListener("offline", offline);
    window.addEventListener("online", online);
    return () => {
      active = false;
      if (retry) clearTimeout(retry);
      es.close();
      clearInterval(timer);
      window.removeEventListener("offline", offline);
      window.removeEventListener("online", online);
    };
  }, [authorized, reloadHealth]);
  useEffect(() => {
    if (!loading && rows.length && !ttiSent.current) {
      ttiSent.current = true;
      requestAnimationFrame(() => reportMetric("tti", performance.now()));
    }
  }, [loading, rows.length]);
  const navigate = useCallback((next: string, mint?: string, pool?: string) => {
    setView(next);
    setMobileNav(false);
    setSheetRow(null);
    if (mint) setDetailMint(mint);
    setDetailPool(pool);
    const params = new URLSearchParams({ view: next });
    if (mint) params.set("mint", mint);
    if (pool) params.set("pool", pool);
    window.history.pushState({}, "", "/?" + params.toString());
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);
  const openToken = useCallback(
    (r: PoolRow) => {
      setSelectedId(r.id);
      navigate("token", r.mint, r.poolId);
      setPreferences((old) => {
        const recent = [
          r.mint,
          ...(old.recentMints ?? []).filter((m) => m !== r.mint),
        ].slice(0, 10);
        void api("settings", "PATCH", { recentMints: recent }).catch(() => {});
        return { ...old, recentMints: recent };
      });
    },
    [navigate],
  );
  const selectRow = useCallback((r: PoolRow) => {
    setSelectedId(r.id);
    if (window.innerWidth <= 800) setSheetRow(r);
  }, []);
  const toggleWatch = useCallback(
    async (r: PoolRow) => {
      try {
        const existing = lists.filter((l) =>
          l.items.some((x) => x.mint === r.mint),
        );
        if (existing.length) {
          for (const l of existing)
            await api("watchlists/items", "DELETE", {
              mint: r.mint,
              listId: l.id,
            });
          notify(r.symbol + " aus Watchlists entfernt.");
        } else {
          await api("watchlists/items", "POST", { mint: r.mint });
          notify(r.symbol + " in der Watchlist gespeichert.");
        }
        await reloadLists();
      } catch (e) {
        notify((e as Error).message);
      }
    },
    [lists, reloadLists, notify],
  );
  const remoteSearch = async () => {
    if (query.trim().length < 2) {
      notify("Bitte mindestens zwei Zeichen eingeben.");
      return;
    }
    setSearching(true);
    const start = performance.now();
    try {
      const d = await api("search", "POST", { query: query.trim() });
      setRows((old) => mergeRows(old, d.rows));
      if (d.rows.length) setSelectedId(d.rows[0].id);
      notify(`${d.rows.length} passende Solana-Pools aus der Quelle erfasst.`);
      reportMetric("search", performance.now() - start);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSearching(false);
    }
  };
  const updateFilters = (f: Filters) => {
    setFilters(f);
    if ((f.query ?? "") !== query) setQuery(f.query ?? "");
  };
  const updateColumns = (columns: string[]) => {
    setPreferences((p) => ({ ...p, columns }));
    void api("settings", "PATCH", { columns }).catch((e) => notify(e.message));
  };
  const savePreset = async (name: string) => {
    try {
      await api("presets", "POST", { name, filters });
      await reloadPresets();
      notify("Filter-Preset gespeichert.");
    } catch (e) {
      notify((e as Error).message);
    }
  };
  const deletePreset = async (id: string) => {
    try {
      await api("presets/" + id, "DELETE");
      await reloadPresets();
    } catch (e) {
      notify((e as Error).message);
    }
  };
  const heading = nav.find((n) => n.id === view)?.label ?? "Live Scanner";
  const totalLiquidity = useMemo(
    () =>
      [...new Map(rows.map((r) => [r.poolId, r])).values()].reduce(
        (n, r) => n + (r.liquidityUsd ?? 0),
        0,
      ),
    [rows],
  );
  const quality = useMemo(
    () =>
      rows.length
        ? Math.round(
            rows.reduce((n, r) => n + r.risk.dataQuality, 0) / rows.length,
          )
        : null,
    [rows],
  );
  const current =
    health?.mode === "current" && stream === "Verbunden" && !error;
  const healthWarnings =
    (health?.providers.filter((p) => p.status !== "ok").length ?? 0) +
    (health?.counts.stale ?? 0);
  if (authorized === false) return <AccessGate onSuccess={() => void load()} />;
  return (
    <div
      className={`app-shell ${preferences.reducedMotion ? "reduced-motion" : ""}`}
    >
      <a href="#research-main" className="skip-link">
        Zum Research-Inhalt
      </a>
      {mobileNav && (
        <button
          aria-label="Navigation schließen"
          className="nav-backdrop"
          onClick={() => setMobileNav(false)}
        />
      )}
      <aside
        className={`sidebar ${mobileNav ? "mobile-open" : ""}`}
        inert={isMobile && !mobileNav ? true : undefined}
      >
        <Brand />
        <button
          className="workspace-switch"
          onClick={() => navigate("scanner")}
        >
          <span className="workspace-avatar">S</span>
          <span>
            <strong>Research Workspace</strong>
            <small>Solana Mainnet</small>
          </span>
          <ChevronRight size={14} />
        </button>
        <span className="nav-section-label">ENTDECKEN & ANALYSIEREN</span>
        <nav aria-label="Hauptnavigation">
          {nav
            .filter((n) =>
              [
                "command",
                "discovery",
                "scanner",
                "token",
                "risk",
                "wallet",
              ].includes(n.id),
            )
            .map((n) => (
              <button
                key={n.id}
                onClick={() =>
                  navigate(
                    n.id,
                    n.id === "token"
                      ? (detailMint ?? selected?.mint)
                      : undefined,
                    n.id === "token"
                      ? (detailPool ?? selected?.poolId)
                      : undefined,
                  )
                }
                className={view === n.id ? "active" : ""}
                aria-current={view === n.id ? "page" : undefined}
              >
                <n.icon size={17} />
                <span>{n.label}</span>
                {n.id === "scanner" && <span className="nav-live-dot" />}
              </button>
            ))}
          <span className="nav-section-label">DEIN RESEARCH</span>
          {nav
            .filter((n) =>
              ["watchlists", "alerts", "analytics", "quality"].includes(n.id),
            )
            .map((n) => (
              <button
                key={n.id}
                aria-label={n.label}
                onClick={() => navigate(n.id)}
                className={view === n.id ? "active" : ""}
                aria-current={view === n.id ? "page" : undefined}
              >
                <n.icon size={17} />
                <span>{n.label}</span>
                {n.id === "watchlists" && watched.size > 0 && (
                  <small className="nav-count">{watched.size}</small>
                )}
              </button>
            ))}
        </nav>
        <div className="sidebar-watchlists">
          <div>
            <span>WATCHLISTS</span>
            <button
              aria-label="Watchlist erstellen"
              onClick={() => navigate("watchlists")}
            >
              <Plus size={12} />
            </button>
          </div>
          {lists.length ? (
            lists.slice(0, 3).map((l) => (
              <button key={l.id} onClick={() => navigate("watchlists")}>
                <span className="list-dot" />
                {l.name}
                <small>{l.items.length}</small>
              </button>
            ))
          ) : (
            <p>
              Dein nächster Fund
              <br />
              beginnt im Scanner.
            </p>
          )}
        </div>
        {!!preferences.recentMints?.length && (
          <div className="sidebar-recents">
            <span className="nav-section-label">ZULETZT ANGESEHEN</span>
            {preferences.recentMints.slice(0, 3).map((m) => {
              const r = rows.find((x) => x.mint === m);
              return (
                <button
                  key={m}
                  data-mint={m}
                  aria-label={`Token ${r?.symbol ?? short(m)} ${m} öffnen`}
                  onClick={() => (r ? openToken(r) : navigate("token", m))}
                >
                  <Clock size={12} />
                  <span>{r?.symbol ?? short(m)}</span>
                  <ArrowUpRight size={12} />
                </button>
              );
            })}
          </div>
        )}
        <div className="sidebar-bottom">
          <div className="sidebar-utility">
            {nav
              .filter((n) => ["health", "settings"].includes(n.id))
              .map((n) => (
                <button
                  key={n.id}
                  onClick={() => navigate(n.id)}
                  className={view === n.id ? "active" : ""}
                >
                  <n.icon size={16} />
                  {n.label}
                  {n.id === "health" && (
                    <span
                      className={`tiny-dot ${current ? "" : "amber-dot"}`}
                    />
                  )}
                </button>
              ))}
          </div>
          <div className="research-notice">
            <ShieldCheck size={17} />
            <div>
              <strong>Research. Mit Klarheit.</strong>
              <span>
                Öffentliche Daten.
                <br />
                Nachvollziehbare Evidenz.
              </span>
            </div>
          </div>
          <div className="sidebar-footer">
            <span>SMARTLAB NEXUS</span>
            <Badge>v1.0</Badge>
          </div>
        </div>
      </aside>
      <div className="main-frame">
        <header className="topbar">
          <div className="topbar-breadcrumb">
            <button
              className="mobile-menu icon-button"
              aria-label="Navigation öffnen"
              onClick={() => setMobileNav(true)}
            >
              <Menu size={20} />
            </button>
            <span>Workspace</span>
            <ChevronRight size={13} />
            <strong>{heading}</strong>
          </div>
          <div className="global-search">
            <Search size={16} />
            <input
              ref={searchRef}
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                if (!["scanner", "discovery"].includes(view))
                  navigate("scanner");
              }}
              placeholder="Token, Symbol oder Mint-Adresse suchen"
              aria-label="Token, Symbol oder Mint-Adresse suchen"
              onKeyDown={(e) => {
                if (e.key === "Enter") void remoteSearch();
              }}
            />
            <kbd>⌘ K</kbd>
            {query && (
              <button
                aria-label="Suche zurücksetzen"
                onClick={() => {
                  setQuery("");
                  setFilters({ preset: "all" });
                }}
              >
                <X size={13} />
              </button>
            )}
          </div>
          <div className="topbar-right">
            <span className="network-badge">
              <span className="solana-mark">≋</span>Solana<small>Mainnet</small>
            </span>
            <button
              className="icon-button"
              onClick={() => navigate("alerts")}
              aria-label="Alert-Posteingang"
            >
              <Bell size={18} />
            </button>
            <span className="user-avatar">R</span>
          </div>
        </header>
        <main className="page-content" id="research-main" tabIndex={-1}>
          <div className="page-header">
            <div>
              <div className="eyebrow">
                <span className="tiny-dot" />
                SOLANA TOKEN INTELLIGENCE
                <span className="eyebrow-line" />
              </div>
              <h1>
                {heading}
                <span className="heading-dot" aria-hidden="true">
                  .
                </span>
              </h1>
              <p>{subtitles[view]}</p>
            </div>
            <div className="page-header-actions">
              <Badge tone={current ? "cyan" : "amber"} dot>
                {current
                  ? "Abruf aktiv"
                  : health
                    ? "Degradierter Modus"
                    : loading
                      ? "Verbinde Quellen"
                      : "Status unbekannt"}
              </Badge>
              <span className="last-update">
                <RefreshCw size={12} />
                Update{" "}
                {ago(
                  health?.counts.last_update
                    ? String(health.counts.last_update)
                    : null,
                  now,
                )}
              </span>
              {query.length >= 2 && ["scanner", "discovery"].includes(view) && (
                <button
                  className="button small"
                  onClick={() => void remoteSearch()}
                  disabled={searching}
                >
                  {searching ? (
                    <RefreshCw className="spin" size={13} />
                  ) : (
                    <Search size={13} />
                  )}
                  Quelle durchsuchen
                </button>
              )}
            </div>
          </div>
          {error && <ErrorBox error={error} retry={() => void load()} />}
          {health?.dataMode === "test-only" && (
            <div
              className="info-banner"
              role="status"
              data-testid="test-mode-banner"
            >
              <strong>ISOLIERTE TESTDATEN · keine aktuellen Marktdaten</strong>
            </div>
          )}
          {!error && stream !== "Verbunden" && authorized && (
            <div className="connection-banner">
              <RefreshCw size={13} />
              {stream} · Zuletzt gespeicherte Beobachtungen bleiben mit ihrem
              Zeitstand sichtbar.
            </div>
          )}
          {view === "scanner" && (
            <div className="research-control-bar">
              <span>
                <Radio size={14} /> TOKEN RADAR{" "}
                <span className="control-separator">/</span> öffentliche
                Beobachtungen
              </span>
              <button
                className="button small"
                aria-label={
                  frozen ? "Live-Updates fortsetzen" : "Live-Updates pausieren"
                }
                aria-pressed={frozen}
                onClick={() => {
                  const next = !frozen;
                  frozenRef.current = next;
                  if (next) requestSequence.current++;
                  setFrozen(next);
                  if (!next)
                    void reloadPools().catch((e) =>
                      setError((e as Error).message),
                    );
                }}
              >
                {frozen ? <Play size={14} /> : <Pause size={14} />}{" "}
                {frozen ? "Updates fortsetzen" : "Updates pausieren"}
              </button>
            </div>
          )}
          {frozen && view === "scanner" && (
            <div
              className="info-banner"
              role="status"
              data-testid="frozen-banner"
            >
              <Pause size={16} />
              <span>
                Tabellenwerte eingefroren. Status und Filter bleiben aktiv; beim
                Fortsetzen wird die aktuelle Seite neu abgeglichen.
              </span>
            </div>
          )}
          {["scanner", "discovery"].includes(view) && (
            <div className="stats-grid">
              <Stat
                label="Erfasste Pools"
                value={health ? formatNumber(health.counts.pools) : "—"}
                sub={
                  <>
                    <span className="tiny-dot" />
                    Öffentlicher Marktausschnitt
                  </>
                }
                icon={<Layers size={16} />}
              />
              <Stat
                label="Neu erkannt · 5 Min."
                value={health ? formatNumber(health.counts.new5) : "—"}
                sub={
                  health ? (
                    <>
                      <span className="cyan-text">{health.counts.new1}</span> in
                      1m <span className="stat-separator">/</span>{" "}
                      {health.counts.new15} in 15m
                    </>
                  ) : (
                    "Entdeckungszeitpunkt"
                  )
                }
                icon={<Compass size={16} />}
                tone="violet"
              />
              <Stat
                label="Liquidität · Auswahl"
                value={
                  rows.some((r) => r.liquidityUsd !== null)
                    ? usd(totalLiquidity)
                    : "Unbekannt"
                }
                sub={
                  <>
                    {rows.filter((r) => r.liquidityUsd !== null).length} Pools
                    mit verfügbarem Wert
                  </>
                }
                icon={<Activity size={16} />}
              />
              <Stat
                label="Ø Datenqualität · Auswahl"
                value={
                  quality === null ? (
                    "—"
                  ) : (
                    <>
                      {quality}
                      <small>/100</small>
                    </>
                  )
                }
                sub={
                  <>
                    <span className="amber-text">{healthWarnings}</span>{" "}
                    Quellen-/Frischehinweise
                  </>
                }
                icon={<ShieldCheck size={16} />}
                tone="violet"
              />
            </div>
          )}
          {loading && rows.length === 0 ? (
            <div
              className="scanner-skeleton"
              role="status"
              aria-label="Scanner wird geladen"
            >
              <div className="skeleton-bar" />
              {Array.from({ length: 8 }, (_, i) => (
                <div key={i} className="skeleton-row">
                  <i />
                  <span />
                  <span />
                  <span />
                  <span />
                </div>
              ))}
              <Loading label="Öffentliche Quelldaten werden geladen …" />
            </div>
          ) : (
            <>
              {view === "command" && (
                <CommandDashboard
                  health={health}
                  rows={rows}
                  onNavigate={navigate}
                  onOpen={openToken}
                />
              )}
              {view === "quality" && <DataQualityDashboard />}
              {["scanner", "discovery"].includes(view) && (
                <DiscoveryFeed compact={view === "scanner"} />
              )}
              {["scanner", "discovery"].includes(view) &&
                !!health?.counts.stale && (
                  <div className="connection-banner" role="status">
                    STALE · {health.counts.stale} erfasste Pools überschreiten
                    das Frischebudget. Dieser Feed deckt nur einen Teil des
                    Marktes ab.
                  </div>
                )}
              {view === "scanner" && (
                <Scanner
                  rows={rows}
                  page={page}
                  pageSize={pageMeta?.pageSize}
                  totalRows={pageMeta?.total}
                  onPage={setPage}
                  onServerSort={(value) => {
                    setServerSort(value);
                    setPage(1);
                  }}
                  filters={filters}
                  onFilters={(value) => {
                    setPage(1);
                    updateFilters(value);
                  }}
                  selected={selected}
                  onSelect={selectRow}
                  onOpen={openToken}
                  watched={watched}
                  onWatch={(r) => void toggleWatch(r)}
                  columns={preferences.columns ?? defaultColumns}
                  onColumns={updateColumns}
                  presets={presets}
                  onSavePreset={savePreset}
                  onDeletePreset={deletePreset}
                  onRemoteSearch={() => void remoteSearch()}
                  searching={searching}
                  now={now}
                  timezone={timezone}
                  compact={!!preferences.compact}
                />
              )}
              {view === "discovery" && (
                <Discovery
                  rows={filterRows(rows, filters)}
                  onOpen={openToken}
                  watched={watched}
                  onWatch={(r) => void toggleWatch(r)}
                />
              )}
              {view === "token" &&
                ((detailMint ?? selected?.mint) ? (
                  <TokenDetail
                    key={detailMint ?? selected!.mint}
                    mint={detailMint ?? selected!.mint}
                    revision={rows
                      .filter((r) => r.mint === (detailMint ?? selected!.mint))
                      .map((r) => r.revision ?? r.updatedAt)
                      .join(":")}
                    poolId={detailPool ?? selected?.poolId}
                    onBack={() => navigate("scanner")}
                    onWatch={(r) => void toggleWatch(r)}
                    watched={watched}
                    onRefreshed={reloadPools}
                    timezone={timezone}
                  />
                ) : (
                  <Empty
                    title="Token auswählen"
                    description="Öffne einen Token im Scanner oder suche nach einer vollständigen Mint-Adresse."
                    action={
                      <button
                        className="button primary"
                        onClick={() => navigate("scanner")}
                      >
                        Zum Scanner
                        <ArrowUpRight size={14} />
                      </button>
                    }
                  />
                ))}
              {view === "risk" && <RiskLab rows={rows} onOpen={openToken} />}
              {view === "wallet" && <WalletExplorer timezone={timezone} />}
              {view === "watchlists" && (
                <Watchlists
                  lists={lists}
                  rows={rows}
                  onReload={async () => {
                    await Promise.all([reloadLists(), reloadPools()]);
                  }}
                  onOpen={openToken}
                />
              )}
              {view === "alerts" && (
                <Alerts lists={lists} timezone={timezone} />
              )}
              {view === "analytics" && <Analytics timezone={timezone} />}
              {view === "health" && (
                <SystemHealth
                  health={health}
                  stream={stream}
                  error={healthError}
                  onReload={() => void reloadHealth()}
                  timezone={timezone}
                />
              )}
              {view === "settings" && (
                <Settings preferences={preferences} onSaved={setPreferences} />
              )}
            </>
          )}
          <footer className="page-footer">
            <span>
              <LockKeyhole size={11} />
              READ-ONLY RESEARCH<span className="footer-divider">/</span>
              Datenqualität ist kein Sicherheitsnachweis.
            </span>
            <span>
              {now ? dateTime(new Date(now).toISOString(), "UTC") : "UTC"}
              <span className="footer-divider">·</span>Quellenstand je Wert
              sichtbar
            </span>
          </footer>
        </main>
      </div>
      <nav
        className="mobile-research-nav"
        aria-label="Mobile Research-Navigation"
      >
        {["command", "scanner", "token", "watchlists", "health"].map((id) => {
          const item = nav.find((n) => n.id === id)!;
          return (
            <button
              key={id}
              aria-current={view === id ? "page" : undefined}
              onClick={() =>
                navigate(
                  id,
                  id === "token" ? (detailMint ?? selected?.mint) : undefined,
                )
              }
            >
              <item.icon size={20} />
              <span>
                {
                  (
                    {
                      command: "Command",
                      scanner: "Radar",
                      token: "Analyse",
                      watchlists: "Watchlists",
                      health: "Status",
                    } as Record<string, string>
                  )[id]
                }
              </span>
            </button>
          );
        })}
      </nav>
      {sheetRow && (
        <IntelligenceSheet
          row={rows.find((r) => r.id === sheetRow.id) ?? sheetRow}
          watched={watched.has(sheetRow.mint)}
          onClose={closeSheet}
          onOpen={openToken}
          onWatch={(r) => void toggleWatch(r)}
          timezone={timezone}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          <Info size={16} />
          <span>{toast}</span>
          <button onClick={() => setToast("")} aria-label="Hinweis schließen">
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
function filterRows(rows: PoolRow[], filters: Filters) {
  const q = filters.query?.toLowerCase();
  return q
    ? rows.filter((r) =>
        [r.name, r.symbol, r.mint].some((v) => v.toLowerCase().includes(q)),
      )
    : rows;
}
function AccessGate({ onSuccess }: { onSuccess: () => void }) {
  const [token, setToken] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <div className="access-page">
      <Brand />
      <Panel>
        <LockKeyhole size={28} />
        <h1>Dein Research-Workspace.</h1>
        <p>Gib den serverseitig eingerichteten Zugangscode ein.</p>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              await api("access", "POST", { token });
              onSuccess();
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Zugangscode
            <input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              required
              autoComplete="current-password"
            />
          </label>
          {error && <ErrorBox error={error} />}
          <button type="submit" disabled={busy} className="button primary full">
            Workspace öffnen
            <ArrowUpRight size={15} />
          </button>
        </form>
      </Panel>
    </div>
  );
}
