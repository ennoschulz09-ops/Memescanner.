"use client";
import { useEffect, useState } from "react";
import {
  Star,
  Plus,
  Trash2,
  ArrowUpRight,
  Bell,
  Check,
  Download,
  Clock,
  Search,
  Settings2,
  Info,
  FolderOpen,
  Shield,
  Save,
  RefreshCw,
} from "lucide-react";
import type { PoolRow } from "../lib/domain";
import { isAddress } from "../lib/domain";
import {
  api,
  short,
  usd,
  dateTime,
  ago,
  formatNumber,
  sourceName,
} from "../lib/client";
import { MarketValue } from "./market-value";
import {
  Panel,
  Badge,
  Empty,
  Loading,
  ErrorBox,
  TokenAvatar,
  RiskBadge,
  CopyAddress,
  KeyValue,
} from "./ui";
import { eventLabel } from "./token-detail";
export interface Watchlist {
  id: string;
  name: string;
  items: { mint: string; name: string; symbol: string; list_id: string }[];
}
export interface Preferences {
  compact?: boolean;
  timezone?: "UTC" | "local";
  reducedMotion?: boolean;
  columns?: string[];
  recentMints?: string[];
  defaultWindow?: "1h" | "24h" | "7d";
}

export function Watchlists({
  lists,
  rows,
  onReload,
  onOpen,
}: {
  lists: Watchlist[];
  rows: PoolRow[];
  onReload: () => Promise<void>;
  onOpen: (r: PoolRow) => void;
}) {
  const [name, setName] = useState(""),
    [chosen, setChosen] = useState<string | null>(null),
    [error, setError] = useState(""),
    [mint, setMint] = useState(""),
    [busy, setBusy] = useState(false);
  const active = lists.find((x) => x.id === chosen) ?? lists[0];
  const [itemQuery, setItemQuery] = useState("");
  const action = async (fn: () => Promise<unknown>) => {
    setError("");
    try {
      await fn();
      await onReload();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const add = async () => {
    if (!isAddress(mint)) {
      setError("Bitte eine gültige Mint-Adresse eingeben.");
      return;
    }
    setBusy(true);
    try {
      if (!rows.some((x) => x.mint === mint))
        await api("search", "POST", { query: mint });
      await api("watchlists/items", "POST", { mint, listId: active.id });
      setMint("");
      await onReload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      {error && <ErrorBox error={error} />}
      <div className="watchlist-layout">
        <Panel
          className="watchlist-folders"
          title="Deine Listen"
          action={<Star size={15} />}
        >
          <div className="folder-list">
            {lists.map((l) => (
              <button
                className={l.id === active?.id ? "active" : ""}
                key={l.id}
                onClick={() => setChosen(l.id)}
              >
                <FolderOpen size={16} />
                <span>{l.name}</span>
                <Badge>{l.items.length}</Badge>
              </button>
            ))}
          </div>
          <form
            className="create-list-form"
            onSubmit={(e) => {
              e.preventDefault();
              void action(async () => {
                const r = await api("watchlists", "POST", { name });
                setChosen(r.id);
                setName("");
              });
            }}
          >
            <label htmlFor="list-name">Neue Watchlist</label>
            <input
              id="list-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name deiner Liste"
              required
              maxLength={64}
            />
            <button type="submit" className="button full">
              <Plus size={14} />
              Liste erstellen
            </button>
          </form>
          <p className="panel-note">
            Diese Listen gehören zu deiner Browsersitzung und bleiben nach einem
            Neuladen erhalten.
          </p>
        </Panel>
        <Panel className="watchlist-content">
          {active ? (
            <>
              <div className="panel-heading">
                <div>
                  <h2>{active.name}</h2>
                  <span>{active.items.length} beobachtete Tokens</span>
                </div>
                <button
                  className="icon-button"
                  aria-label="Watchlist löschen"
                  onClick={() =>
                    void action(() => api("watchlists/" + active.id, "DELETE"))
                  }
                >
                  <Trash2 size={15} />
                </button>
              </div>
              <form
                className="inline-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  void add();
                }}
              >
                <input
                  value={mint}
                  placeholder="Mint-Adresse zur Liste hinzufügen"
                  aria-label="Mint-Adresse zur Watchlist"
                  onChange={(e) => setMint(e.target.value)}
                  maxLength={44}
                />
                <button
                  type="submit"
                  disabled={busy}
                  className="button primary"
                >
                  <Plus size={14} />
                  {busy ? "Wird geprüft …" : "Hinzufügen"}
                </button>
              </form>
              <div className="watchlist-tokens">
                {itemQuery &&
                  !active.items.some((item) =>
                    [item.name, item.symbol, item.mint].some((v) =>
                      v.toLowerCase().includes(itemQuery.toLowerCase()),
                    ),
                  ) && <Empty title="Keine Treffer in dieser Watchlist" />}
                <label className="watchlist-search">
                  Watchlist durchsuchen
                  <input
                    value={itemQuery}
                    onChange={(e) => setItemQuery(e.target.value)}
                    placeholder="Name, Symbol oder Mint in dieser Liste"
                  />
                </label>
                {active.items
                  .filter(
                    (item) =>
                      !itemQuery ||
                      [item.name, item.symbol, item.mint].some((v) =>
                        v.toLowerCase().includes(itemQuery.toLowerCase()),
                      ),
                  )
                  .map((item) => {
                    const row = rows
                      .filter((x) => x.mint === item.mint)
                      .sort(
                        (a, b) => (b.liquidityUsd ?? 0) - (a.liquidityUsd ?? 0),
                      )[0];
                    return (
                      <div key={item.mint} className="watchlist-token">
                        <button
                          data-testid="watchlist-token"
                          className="watchlist-token-open"
                          onClick={async () => {
                            if (row) onOpen(row);
                            else
                              try {
                                const detail = await api("tokens/" + item.mint);
                                if (detail?.pool) onOpen(detail.pool);
                                else if (detail?.selected)
                                  onOpen(detail.selected);
                                else if (detail?.pools?.[0])
                                  onOpen(detail.pools[0]);
                                else
                                  setError("Noch keine Pooldaten verfügbar.");
                              } catch (e) {
                                setError((e as Error).message);
                              }
                          }}
                        >
                          <TokenAvatar mint={item.mint} symbol={item.symbol} />
                          <span>
                            <strong>{item.symbol}</strong>
                            <small>
                              {item.name} · {short(item.mint)}
                            </small>
                            <small
                              title={
                                row
                                  ? `Eigene Abdeckungsberechnung ${row.risk.modelVersion ?? "Legacy"}; Abruf ${row.provenance.fetchedAt}; tatsächliche Messzeit ${row.provenance.measuredAt ?? "unbekannt"}`
                                  : "Noch keine zugeordnete Poolbeobachtung"
                              }
                            >
                              {row
                                ? `Datenabdeckung ${row.risk.dataQuality}/100 · ${sourceName(row.provenance.provider)} · ${ago(row.provenance.fetchedAt)}`
                                : "Datenabdeckung unbekannt"}
                            </small>
                          </span>
                          <strong>
                            {row ? (
                              <MarketValue row={row} field="priceUsd" price />
                            ) : (
                              "Unbekannt"
                            )}
                          </strong>
                          {row && <RiskBadge state={row.risk.state} />}
                          <ArrowUpRight size={16} />
                        </button>
                        <button
                          className="icon-button"
                          aria-label={`${item.symbol} aus Liste entfernen`}
                          onClick={() =>
                            void action(() =>
                              api("watchlists/items", "DELETE", {
                                mint: item.mint,
                                listId: active.id,
                              }),
                            )
                          }
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    );
                  })}
              </div>
              {!active.items.length && (
                <Empty
                  title="Dein Radar wartet auf Entdeckungen"
                  description="Speichere einen Token mit dem Stern im Scanner oder ergänze eine vollständige Mint-Adresse."
                  icon={<Star size={28} />}
                />
              )}
            </>
          ) : (
            <Empty
              title="Deine erste Watchlist"
              description="Erstelle eine Liste oder speichere direkt einen Token im Scanner."
              icon={<Star size={28} />}
            />
          )}
        </Panel>
      </div>
    </>
  );
}
export function Alerts({
  lists,
  timezone,
}: {
  lists: Watchlist[];
  timezone: string;
}) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [open, setOpen] = useState(false),
    [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    name: "",
    kind: "liquidity_change",
    threshold: 30,
    cooldownSeconds: 300,
    debounceSeconds: 0,
    quotaPerHour: 5,
    quietStart: 22 as number | null,
    quietEnd: 7 as number | null,
    enabled: true,
    mint: "",
    watchlistId: "",
  });
  const load = async () => {
    try {
      const d = await api("alerts");
      setData(d);
      if (d.events.some((e: any) => e.delivery_state === "pending")) {
        await api("alerts/ack", "POST", {
          ids: d.events
            .filter((e: any) => e.delivery_state === "pending")
            .map((e: any) => e.id),
        });
        setData(await api("alerts"));
      }
    } catch (e) {
      setError((e as Error).message);
    }
  };
  useEffect(() => {
    void load();
    const id = setInterval(() => void load(), 15000);
    return () => clearInterval(id);
  }, []);
  const action = async (fn: () => Promise<unknown>) => {
    setError("");
    try {
      await fn();
      await load();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const create = async () => {
    if (form.mint && !isAddress(form.mint)) {
      setError("Mint-Adresse ungültig.");
      return;
    }
    setBusy(true);
    try {
      await api("alerts", "POST", {
        ...form,
        name: form.name || eventLabel(form.kind),
        mint: form.mint || null,
        watchlistId: form.watchlistId || null,
      });
      setOpen(false);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      {error && <ErrorBox error={error} />}
      <div className="section-action-row">
        <div>
          <Badge tone="cyan" dot>
            In-App-Benachrichtigungen
          </Badge>
          <p>
            Beobachtungen mit Cooldown, Deduplizierung und Ruhezeiten.
            Zustellung erfolgt beim Öffnen dieses Posteingangs.
          </p>
        </div>
        <button className="button primary" onClick={() => setOpen(!open)}>
          <Plus size={15} />
          Neue Alert-Regel
        </button>
      </div>
      {open && (
        <Panel title="Neue Beobachtungsregel">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void create();
            }}
          >
            <div className="form-grid">
              <label>
                Name
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  maxLength={64}
                  placeholder="Z. B. Liquidität beobachten"
                />
              </label>
              <label>
                Ereignis
                <select
                  value={form.kind}
                  onChange={(e) => setForm({ ...form, kind: e.target.value })}
                >
                  <option value="new_token">Neu erfasster Token</option>
                  <option value="new_pool">Neu erfasster Pool</option>
                  <option value="concentration_increase">
                    Konzentrationsanstieg
                  </option>
                  <option value="feed_outage">Feed-Ausfall</option>
                  <option value="liquidity_change">Liquiditätsänderung</option>
                  <option value="risk_flag">Neuer Risiko-Hinweis</option>
                  <option value="watchlist_activity">
                    Watchlist-Aktivität
                  </option>
                </select>
              </label>
              <label>
                Schwelle (
                {form.kind === "watchlist_activity"
                  ? "Trades 5m"
                  : form.kind === "concentration_increase"
                    ? "Prozentpunkte"
                    : "% absolut"}
                )
                <input
                  type="number"
                  min="0"
                  max="1000000"
                  value={form.threshold}
                  disabled={
                    ![
                      "liquidity_change",
                      "watchlist_activity",
                      "concentration_increase",
                    ].includes(form.kind)
                  }
                  onChange={(e) =>
                    setForm({ ...form, threshold: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Cooldown (Sekunden)
                <input
                  type="number"
                  min="60"
                  max="86400"
                  value={form.cooldownSeconds}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      cooldownSeconds: Number(e.target.value),
                    })
                  }
                />
              </label>
              <label>
                Debounce (Sekunden, 0 = sofort)
                <input
                  type="number"
                  min="0"
                  max="3600"
                  value={form.debounceSeconds ?? 0}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      debounceSeconds: Number(e.target.value),
                    })
                  }
                />
              </label>
              <label>
                Max. Benachrichtigungen / Stunde
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={form.quotaPerHour}
                  onChange={(e) =>
                    setForm({ ...form, quotaPerHour: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Watchlist (optional)
                <select
                  value={form.watchlistId}
                  onChange={(e) =>
                    setForm({ ...form, watchlistId: e.target.value })
                  }
                >
                  <option value="">Alle erfassten Tokens</option>
                  {lists.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Mint-Adresse (optional)
                <input
                  value={form.mint}
                  maxLength={44}
                  onChange={(e) => setForm({ ...form, mint: e.target.value })}
                  placeholder="Auf einen Token begrenzen"
                />
              </label>
              <label>
                Ruhezeit ab (UTC)
                <select
                  value={form.quietStart ?? ""}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      quietStart:
                        e.target.value === "" ? null : Number(e.target.value),
                    })
                  }
                >
                  <option value="">Keine Ruhezeit</option>
                  {Array.from({ length: 24 }, (_, i) => (
                    <option key={i} value={i}>
                      {String(i).padStart(2, "0")}:00
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Ruhezeit bis (UTC)
                <select
                  value={form.quietEnd ?? ""}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      quietEnd:
                        e.target.value === "" ? null : Number(e.target.value),
                    })
                  }
                >
                  <option value="">Keine Ruhezeit</option>
                  {Array.from({ length: 24 }, (_, i) => (
                    <option key={i} value={i}>
                      {String(i).padStart(2, "0")}:00
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <p className="panel-note">
              Bei Watchlist-Aktivität muss eine Liste oder Mint-Adresse gewählt
              sein. Benachrichtigungen werden ausschließlich hier angezeigt; es
              ist kein externer Versand eingerichtet.
            </p>
            <div className="form-actions">
              <button
                className="button"
                type="button"
                onClick={() => setOpen(false)}
              >
                Abbrechen
              </button>
              <button className="button primary" type="submit" disabled={busy}>
                <Check size={14} />
                {busy ? "Wird gespeichert …" : "Regel speichern"}
              </button>
            </div>
          </form>
        </Panel>
      )}
      <div className="detail-two-columns">
        <Panel
          title="Deine Alert-Regeln"
          action={<Badge>{data?.rules.length ?? 0}</Badge>}
        >
          {!data ? (
            <Loading />
          ) : !data.rules.length ? (
            <Empty
              title="Beobachte, was dir wichtig ist"
              description="Erstelle deine erste Regel für neue Tokens, Liquiditätsänderungen oder Risiko-Hinweise."
              icon={<Bell size={28} />}
            />
          ) : (
            <div className="alert-rules">
              {data.rules.map((r: any) => (
                <div className="alert-rule" key={r.id}>
                  <div className="alert-rule-title">
                    <Bell size={16} />
                    <strong>{r.name}</strong>
                    <button
                      className={`toggle ${r.data.enabled ? "on" : ""}`}
                      role="switch"
                      aria-checked={r.data.enabled}
                      aria-label={`${r.name} aktiv`}
                      onClick={() =>
                        void action(() =>
                          api("alerts/" + r.id, "PATCH", {
                            enabled: !r.data.enabled,
                          }),
                        )
                      }
                    >
                      <i />
                    </button>
                  </div>
                  <div className="rule-meta">
                    <span>{eventLabel(r.data.kind)}</span>
                    <span>Cooldown {r.data.cooldownSeconds}s</span>
                    <span>Quota {r.data.quotaPerHour}/h</span>
                    <span>
                      UTC {r.data.quietStart ?? "—"}–{r.data.quietEnd ?? "—"}
                    </span>
                  </div>
                  <div className="alert-rule-footer">
                    <Badge tone={r.data.enabled ? "cyan" : "neutral"}>
                      {r.data.enabled ? "Aktiv" : "Pausiert"}
                    </Badge>
                    <button
                      className="text-button danger-text"
                      onClick={() =>
                        void action(() => api("alerts/" + r.id, "DELETE"))
                      }
                    >
                      <Trash2 size={12} />
                      Entfernen
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>
        <Panel
          title="Benachrichtigungen"
          action={
            <a
              className="icon-button"
              aria-label="Alerts als JSON exportieren"
              href="/api/export?scope=alerts&format=json"
            >
              <Download size={15} />
            </a>
          }
        >
          {!data ? (
            <Loading />
          ) : !data.events.length ? (
            <Empty
              title="Noch keine Benachrichtigungen"
              description="Ausgelöste und zugestellte Zustände werden getrennt protokolliert."
              icon={<Bell size={28} />}
            />
          ) : (
            <div className="notification-list">
              {data.events.map((e: any) => (
                <article key={e.id}>
                  <div>
                    <Badge tone="violet">Ausgelöst</Badge>
                    <Badge
                      tone={
                        e.delivery_state === "failed"
                          ? "red"
                          : e.delivery_state === "delivered"
                            ? "cyan"
                            : "amber"
                      }
                    >
                      {e.delivery_state === "failed"
                        ? "Fehlgeschlagen"
                        : e.delivery_state === "delivered"
                          ? "Zugestellt"
                          : "Ausstehend"}
                    </Badge>
                  </div>
                  <h4>{e.data.ruleName}</h4>
                  <p>
                    {eventLabel(e.data.kind)} ·{" "}
                    {e.mint ? short(e.mint, 6) : "Quelle: " + e.data.source}
                    {e.data.kind === "liquidity_change"
                      ? " · " + Number(e.data.value).toFixed(1) + " %"
                      : ""}
                  </p>
                  <small title={e.at}>{dateTime(e.at, timezone)}</small>
                  <details>
                    <summary>Was hat sich geändert?</summary>
                    <p>
                      Vorher: {JSON.stringify(e.data.before ?? "unbekannt")} ·
                      Nachher: {JSON.stringify(e.data.after ?? "unbekannt")}
                    </p>
                    <p>
                      Quelle: {e.data.source ?? "unbekannt"} · Messzeit:{" "}
                      {e.data.measuredAt ?? "nicht veröffentlicht"}
                    </p>
                    <p>
                      {e.data.limits ??
                        "Beobachtetes Recherche-Ereignis; kein Nachweis einer Ursache."}
                    </p>
                  </details>
                </article>
              ))}
            </div>
          )}
        </Panel>
      </div>
      <EventLog timezone={timezone} />
    </>
  );
}
function EventLog({ timezone }: { timezone: string }) {
  const [events, setEvents] = useState<any[]>([]),
    [q, setQ] = useState(""),
    [error, setError] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => {
      api("events?q=" + encodeURIComponent(q))
        .then((d) => {
          setEvents(d.events);
          setError("");
        })
        .catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(timer);
  }, [q]);
  return (
    <Panel
      title="Historisches Ereignisprotokoll"
      action={
        <div className="export-actions">
          <a
            className="button subtle small"
            href="/api/export?scope=events&format=csv"
          >
            <Download size={12} />
            CSV
          </a>
          <a
            className="button subtle small"
            href="/api/export?scope=events&format=json"
          >
            JSON
          </a>
        </div>
      }
    >
      <div className="log-search">
        <Search size={15} />
        <input
          placeholder="Ereignisse oder Mint-Adresse suchen"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          maxLength={96}
        />
      </div>
      {error && <ErrorBox error={error} />}
      <div
        className="horizontal-scroll"
        tabIndex={0}
        role="region"
        aria-label="Alert-Ereignisprotokoll"
      >
        <table className="data-table">
          <thead>
            <tr>
              <th>Zeit ({timezone === "UTC" ? "UTC" : "lokal"})</th>
              <th>Ereignis</th>
              <th>Mint-Adresse</th>
              <th>Beobachteter Wert</th>
            </tr>
          </thead>
          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td title={new Date(e.at).toISOString()}>
                  {dateTime(e.at, timezone)}
                </td>
                <td>{eventLabel(e.kind)}</td>
                <td>
                  {e.mint ? (
                    <CopyAddress value={e.mint} />
                  ) : (
                    <span>Quelle: {e.payload?.source ?? "unbekannt"}</span>
                  )}
                </td>
                <td>
                  {e.kind === "liquidity_change"
                    ? Number(e.payload.value).toFixed(2) + " %"
                    : (e.payload.value ?? "—")}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!events.length && <Empty title="Keine passenden Ereignisse" />}
      <p className="panel-note">
        Anzeige bis zu 300 Ereignisse, Export bis zu 10.000. Zeitstempel werden
        in UTC gespeichert; die lokale Anzeige folgt deinen Einstellungen.
      </p>
    </Panel>
  );
}
export function Settings({
  preferences,
  onSaved,
}: {
  preferences: Preferences;
  onSaved: (p: Preferences) => void;
}) {
  const [draft, setDraft] = useState<Preferences>(preferences),
    [runtime, setRuntime] = useState<any>(null),
    [error, setError] = useState(""),
    [saved, setSaved] = useState(false),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    api("settings")
      .then((d) => setRuntime(d.runtime))
      .catch((e) => setError(e.message));
  }, []);
  const save = async () => {
    setBusy(true);
    try {
      const d = await api("settings", "PATCH", draft);
      onSaved(d.settings);
      setSaved(true);
      setError("");
      setTimeout(() => setSaved(false), 2500);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      {error && <ErrorBox error={error} />}
      <div className="settings-grid">
        <Panel title="Dein Terminal">
          <div className="setting-row">
            <div>
              <h4>Kompakte Tabelle</h4>
              <p>
                Dichtere Tabellenansicht. Mobile Karten behalten ihre
                Touch-Größe.
              </p>
            </div>
            <button
              className={`toggle ${draft.compact ? "on" : ""}`}
              role="switch"
              aria-checked={!!draft.compact}
              aria-label="Kompakte Tabelle"
              onClick={() => setDraft({ ...draft, compact: !draft.compact })}
            >
              <i />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <h4>Animationen reduzieren</h4>
              <p>Weniger Bewegung in der Oberfläche.</p>
            </div>
            <button
              className={`toggle ${draft.reducedMotion ? "on" : ""}`}
              role="switch"
              aria-checked={!!draft.reducedMotion}
              aria-label="Animationen reduzieren"
              onClick={() =>
                setDraft({ ...draft, reducedMotion: !draft.reducedMotion })
              }
            >
              <i />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <h4>Zeitzone</h4>
              <p>
                UTC wird zusätzlich in Exporten und Quellbelegen gespeichert.
              </p>
            </div>
            <select
              aria-label="Zeitzone"
              value={draft.timezone ?? "local"}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  timezone: e.target.value as "UTC" | "local",
                })
              }
            >
              <option value="local">Lokal</option>
              <option value="UTC">UTC</option>
            </select>
          </div>
          <button
            className="button primary"
            onClick={() => void save()}
            disabled={busy}
          >
            {saved ? <Check size={15} /> : <Save size={15} />}{" "}
            {saved
              ? "Gespeichert"
              : busy
                ? "Wird gespeichert …"
                : "Einstellungen speichern"}
          </button>
        </Panel>
        <Panel title="Erfassung & Aufbewahrung">
          <KeyValue
            label="Provider-Modus"
            value={runtime?.providerMode ?? "Unbekannt"}
          />
          <KeyValue
            label="Abrufintervall mindestens"
            value={
              runtime ? runtime.pollIntervalSeconds + " Sekunden" : "Unbekannt"
            }
          />
          <KeyValue
            label="Historien-Aufbewahrung"
            value={runtime ? runtime.retentionDays + " Tage" : "Unbekannt"}
          />
          <KeyValue
            label="Zugangsschutz"
            value={runtime?.authentication ? "Aktiv" : "Lokale Browsersitzung"}
          />
          <KeyValue label="Echtzeittransport" value="Server-Sent Events" />
          <p className="panel-note">
            Anbieterbudgets, Verbindungskonfiguration und API-Zugangsdaten
            werden ausschließlich serverseitig verwaltet. Nach Änderungen der
            Umgebungskonfiguration müssen App und Worker neu gestartet werden.
          </p>
        </Panel>
        <Panel title="Transparenz & Methodik">
          <div className="settings-methodology">
            <Shield size={24} />
            <h3>Gebaut für nachvollziehbare Recherche.</h3>
            <p>
              SMARTLAB NEXUS entdeckt und beobachtet öffentliche Solana-Token-
              und Pooldaten. Provider können gecachte, unvollständige oder
              widersprüchliche Werte liefern.
            </p>
            <p>
              Datenqualität, Liquiditätsrisiko, Konzentration, auffällige
              Aktivität, Contract-Kontrollen und Momentum-Kontext werden
              getrennt ausgewiesen. Fehlende Eingaben bleiben unbekannt.
            </p>
            <p>
              Auch gute Datenqualität und niedrige Risikoindikatoren schließen
              Verluste nicht aus. Memecoin-Märkte sind extrem volatil.
            </p>
          </div>
        </Panel>
        <Panel title="Sitzung & Daten">
          <p className="panel-note">
            Watchlists, Presets, Alert-Regeln und Einstellungen sind an ein
            zufälliges HttpOnly-Browsercookie gebunden. Das Entfernen dieses
            Cookies trennt den Zugriff auf diese Sitzung. Sichere wichtige
            Ereignisprotokolle regelmäßig per Export.
          </p>
          <div className="settings-exports">
            <a className="button" href="/api/export?format=csv">
              <Download size={14} />
              Scanner als CSV
            </a>
            <a className="button" href="/api/export?scope=events&format=json">
              <Download size={14} />
              Ereignisse als JSON
            </a>
          </div>
          <div className="info-banner subtle">
            <Info size={16} />
            <p>
              Für gemeinsame oder öffentlich erreichbare Installationen den
              optionalen Zugangsschutz konfigurieren und eine geeignete
              Deployment-Absicherung ergänzen.
            </p>
          </div>
        </Panel>
      </div>
    </>
  );
}
