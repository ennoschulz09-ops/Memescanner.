"use client";
import { useId, useState, useMemo } from "react";
import { segmentSeries, chartScale } from "../lib/chart-series";
import { Empty } from "./ui";
import { usd, dateTime, formatNumber } from "../lib/client";
export interface Point {
  at: string;
  value: number | null;
}
export function Sparkline({ points }: { points: Point[] }) {
  const segments = segmentSeries(points);
  const ps = segments.flat();
  if (ps.length < 2)
    return (
      <span
        className="spark-empty"
        title="Mindestens zwei eigene Beobachtungen nötig"
      >
        Historie folgt
      </span>
    );
  const scale = chartScale(ps.map((x) => x.value));
  const start = Date.parse(ps[0].at),
    duration = Date.parse(ps.at(-1)!.at) - start || 1;
  const path = segments
    .map((segment) =>
      segment
        .map(
          (p, i) =>
            `${i ? "L" : "M"}${((Date.parse(p.at) - start) / duration) * 90},${26 - scale.fraction(p.value) * 22}`,
        )
        .join(" "),
    )
    .join(" ");
  return (
    <svg
      width="90"
      height="30"
      viewBox="0 0 90 30"
      aria-label="Eigene Preisbeobachtungen"
      role="img"
    >
      <path
        d={path}
        fill="none"
        stroke={ps.at(-1)!.value >= ps[0].value ? "#36d8c2" : "#f17b91"}
        strokeWidth="1.7"
      />
    </svg>
  );
}
export function TimeChart({
  points,
  label,
  unit = "USD",
  height = 240,
  source,
  timezone = "local",
  maxGapMs = 180000,
}: {
  points: Point[];
  label: string;
  unit?: string;
  height?: number;
  source: string;
  timezone?: string;
  maxGapMs?: number;
}) {
  const gradient = useId().replace(/:/g, "");
  const [hover, setHover] = useState<number | null>(null);
  const segments = useMemo(
    () => segmentSeries(points, maxGapMs),
    [points, maxGapMs],
  );
  const p = useMemo(() => segments.flat(), [segments]);
  if (!p.length)
    return (
      <Empty
        title="Noch keine Zeitreihe"
        description="Es werden ausschließlich verfügbare Quellenwerte und eigene gespeicherte Beobachtungen dargestellt."
      />
    );
  const w = 800,
    h = height,
    top = 15,
    bottom = 30,
    right = 80,
    plot = w - right;
  const scale = chartScale(
    p.map((x) => x.value),
    unit === "USD",
  );
  const start = Date.parse(p[0].at),
    end = Date.parse(p.at(-1)!.at);
  const x = (v: string) =>
    p.length === 1
      ? plot / 2
      : ((Date.parse(v) - start) / (end - start || 1)) * plot;
  const y = (v: number) => top + (1 - scale.fraction(v)) * (h - top - bottom);
  const paths = segments.map((segment) =>
    segment
      .map(
        (v, i) =>
          `${i ? "L" : "M"}${x(v.at).toFixed(2)},${y(v.value).toFixed(2)}`,
      )
      .join(" "),
  );
  const index = Math.min(hover ?? p.length - 1, p.length - 1);
  const current = p[index];
  return (
    <div
      className="time-chart"
      data-chart-measure={/liquidit/i.test(label) ? "liquidity" : "market"}
    >
      <div className="chart-readout">
        <span>{label}</span>
        <strong>
          {unit === "USD"
            ? usd(current.value, true)
            : formatNumber(current.value, false)}
        </strong>
        <small aria-live="polite">
          {dateTime(current.at, timezone)} · {source}
        </small>
      </div>
      <svg
        role="img"
        tabIndex={0}
        onKeyDown={(e) => {
          if (["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) {
            e.preventDefault();
            setHover(
              e.key === "Home"
                ? 0
                : e.key === "End"
                  ? p.length - 1
                  : Math.max(
                      0,
                      Math.min(
                        p.length - 1,
                        index + (e.key === "ArrowLeft" ? -1 : 1),
                      ),
                    ),
            );
          }
        }}
        aria-label={`${label}; ${p.length} Datenpunkte; Quelle ${source}`}
        viewBox={`0 0 ${w} ${h}`}
        style={{ height }}
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * w;
          let best = 0;
          for (let i = 1; i < p.length; i++)
            if (Math.abs(x(p[i].at) - px) < Math.abs(x(p[best].at) - px))
              best = i;
          setHover(best);
        }}
      >
        <defs>
          <linearGradient id={gradient} x1="0" y1="0" x2="0" y2="1">
            <stop stopColor="#4fdcda" stopOpacity=".18" />
            <stop offset="1" stopColor="#4fdcda" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 1, 2, 3].map((i) => {
          const value = scale.valueAt(i / 3);
          return (
            <g key={i}>
              <line
                x1="0"
                x2={plot}
                y1={y(value)}
                y2={y(value)}
                stroke="#243040"
                strokeDasharray="3 6"
              />
              <text x={plot + 12} y={y(value) + 4} fill="#8391a8" fontSize="11">
                {unit === "USD" ? usd(value, true) : formatNumber(value)}
              </text>
            </g>
          );
        })}
        {segments.map((segment, i) => (
          <g key={segment[0].at}>
            {segment.length > 1 && (
              <>
                <path
                  d={`${paths[i]} L${x(segment.at(-1)!.at)},${h - bottom} L${x(segment[0].at)},${h - bottom} Z`}
                  fill={`url(#${gradient})`}
                />
                <path
                  className="time-chart-curve"
                  d={paths[i]}
                  stroke="#50d9d3"
                  strokeWidth="2"
                  fill="none"
                />
              </>
            )}
            {segment.length === 1 && (
              <circle
                cx={x(segment[0].at)}
                cy={y(segment[0].value)}
                r="3"
                fill="#76ede6"
              />
            )}
          </g>
        ))}
        <circle
          cx={x(current.at)}
          cy={y(current.value)}
          r="3.5"
          fill="#76ede6"
          stroke="#0c1521"
          strokeWidth="2"
        />
        {hover !== null && (
          <line
            x1={x(current.at)}
            x2={x(current.at)}
            y1={top}
            y2={h - bottom}
            stroke="#8493a8"
            strokeDasharray="3 4"
          />
        )}
        {[0, 0.5, 1].map((f, i) => (
          <text
            key={f}
            x={f * plot}
            y={h - 5}
            textAnchor={i === 0 ? "start" : i === 2 ? "end" : "middle"}
            fill="#8391a8"
            fontSize="11"
          >
            {new Date(start + (end - start) * f).toLocaleTimeString("de-DE", {
              hour: "2-digit",
              minute: "2-digit",
              ...(timezone === "UTC" ? { timeZone: "UTC" } : {}),
            })}
          </text>
        ))}
      </svg>
      <div className="chart-caption">
        <span>
          <i />
          {source}
        </span>
        <span>
          {p.length} Messpunkte · {segments.length} Segmente · Lücken bleiben
          offen
        </span>
      </div>
    </div>
  );
}
