"use client";
import { useEffect, useState, useRef } from "react";
import { api, short, sourceName, ago } from "../lib/client";
import { Panel, Badge, CopyAddress, ErrorBox } from "./ui";
interface Entry {
  mint: string;
  provider: string;
  firstSeenAt: string;
  status: string;
  discoveryFreshness: "recent" | "historical";
  freshnessBudgetSeconds: number;
  error: string | null;
}
interface ChainEvent {
  eventId: string;
  slot: number;
  status: string;
  observedAt: string;
  eventAt: string | null;
  committedAt: string | null;
  reason: string | null;
  pools: { poolAddress: string; mints: string[] }[];
}
export function DiscoveryFeed({ compact = false }: { compact?: boolean }) {
  const [chainEvents, setChainEvents] = useState<ChainEvent[]>([]);
  const envelope = useRef<{ publishedAt: string; eventIds: string[] } | null>(
    null,
  );
  const [tokens, setTokens] = useState<Entry[]>([]),
    [error, setError] = useState("");
  useEffect(() => {
    let active = true,
      timer: ReturnType<typeof setTimeout> | undefined;
    const load = async () => {
      try {
        const data = await api("discoveries");
        if (!Array.isArray(data.tokens))
          throw new Error("Ungültiges Discovery-Schema");
        if (active) {
          envelope.current = {
            publishedAt: data.publishedAt,
            eventIds: (data.chainEvents ?? []).map(
              (e: ChainEvent) => e.eventId,
            ),
          };
          setChainEvents(data.chainEvents ?? []);
          setTokens(data.tokens);
          setError("");
        }
      } catch {
        if (active) setError("Entdeckungsfeed vorübergehend nicht verfügbar.");
      }
    };
    const update = () => {
      if (!timer)
        timer = setTimeout(() => {
          timer = undefined;
          void load();
        }, 300);
    };
    void load();
    window.addEventListener("nexus-discovery", update);
    const fallback = setInterval(update, 10000);
    return () => {
      active = false;
      clearTimeout(timer);
      clearInterval(fallback);
      window.removeEventListener("nexus-discovery", update);
    };
  }, []);
  useEffect(() => {
    const sample = envelope.current;
    if (
      !sample?.publishedAt ||
      !sample.eventIds.length ||
      document.visibilityState !== "visible"
    )
      return;
    let secondFrame = 0;
    const frame = requestAnimationFrame(() => {
      secondFrame = requestAnimationFrame(() => {
        if (document.visibilityState !== "visible") return;
        const elements = [
          ...document.querySelectorAll<HTMLElement>("[data-chain-event]"),
        ].filter((el) => {
          const r = el.getBoundingClientRect();
          return (
            r.bottom > 0 &&
            r.top < innerHeight &&
            sample.eventIds.includes(el.dataset.chainEvent!)
          );
        });
        for (const stage of ["candidate", "decoded"] as const) {
          const visibleIds = elements
            .filter(
              (el) =>
                (el.dataset.chainStatus === "decoded") ===
                (stage === "decoded"),
            )
            .map((el) => el.dataset.chainEvent!);
          if (visibleIds.length)
            void api("chain-receipts", "POST", {
              eventIds: visibleIds,
              publishedAt: sample.publishedAt,
              renderedAt: new Date().toISOString(),
              stage,
            }).catch(() => {});
        }
      });
    });
    return () => {
      cancelAnimationFrame(frame);
      cancelAnimationFrame(secondFrame);
    };
  }, [chainEvents]);
  const shown = (
    compact ? tokens.filter((t) => t.status === "incomplete") : tokens
  ).slice(0, compact ? 4 : 12);
  if (compact && !shown.length && !chainEvents.length && !error) return null;
  return (
    <Panel
      title="Zuerst entdeckt · anschließend angereichert"
      className="early-discovery"
    >
      <p className="muted">
        Öffentliche Profil-/Poolfeeds. „Entdeckt“ bezeichnet unsere erste
        Beobachtung, keine bestätigte Mint-Erstellung.
      </p>
      {error && <ErrorBox error={error} />}
      {chainEvents.length > 0 && (
        <div className="chain-event-list" aria-label="Onchain-Ereignisse">
          {chainEvents
            .filter((e) => e.status !== "rejected")
            .slice(0, compact ? 3 : 8)
            .map((e) => (
              <article
                key={e.eventId}
                data-chain-event={e.eventId}
                data-chain-status={e.status}
              >
                <div>
                  <strong>
                    {e.status === "decoded"
                      ? "Pool-Initialisierung bestätigt"
                      : "Pool-Kandidat · Prüfung ausstehend"}
                  </strong>
                  <Badge tone={e.status === "decoded" ? "cyan" : "amber"}>
                    {e.status === "decoded"
                      ? "DECODED"
                      : e.status === "dead-letter"
                        ? "FEHLER"
                        : "PENDING / UNKNOWN"}
                  </Badge>
                </div>
                <small title={e.eventId}>
                  Event {short(e.eventId, 8)} · Slot {e.slot} · beobachtet{" "}
                  {new Date(e.observedAt).toISOString()}
                </small>
                {e.pools.map((p, i) => (
                  <small key={i}>
                    Pool {short(p.poolAddress ?? "unbekannt", 8)} ·{" "}
                    {p.mints.length} Pair-Assets · kein Nachweis neuer Mints
                  </small>
                ))}
                {e.reason && <small>Diagnose: {e.reason}</small>}
              </article>
            ))}
        </div>
      )}
      <div className="discovery-feed">
        {shown.map((t) => (
          <article key={t.mint}>
            <div>
              <strong>{short(t.mint, 6)}</strong>
              <CopyAddress value={t.mint} />
            </div>
            <Badge tone={t.status === "hydrated" ? "cyan" : "amber"}>
              {t.status === "hydrated"
                ? "Marktdaten erfasst"
                : "Entdeckt · Daten unvollständig"}
            </Badge>
            <small>
              {t.provider.split(", ").map(sourceName).join(" + ")} · zuerst vor{" "}
              {ago(t.firstSeenAt)}
            </small>
            <small title="Alter des ersten eigenen Funds; keine Aussage zur Kursfrische oder Mint-Erstellung.">
              {t.discoveryFreshness === "recent"
                ? "Frischer Fund"
                : "Historischer Fund"}{" "}
              · Fundbudget {t.freshnessBudgetSeconds}s
            </small>
            {t.error && <p>{t.error}</p>}
          </article>
        ))}
      </div>
      {!shown.length && !error && (
        <p>Noch keine unabhängigen Entdeckungen in diesem Bestand.</p>
      )}
    </Panel>
  );
}
