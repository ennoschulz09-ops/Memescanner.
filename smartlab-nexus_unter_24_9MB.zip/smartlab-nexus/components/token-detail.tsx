"use client";
import { useEffect, useState, useCallback, useRef } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  ShieldCheck,
  RefreshCw,
  Database,
  Star,
  AlertTriangle,
  Clock,
  Layers,
  ExternalLink,
} from "lucide-react";
import type { tokenDetail } from "../lib/services";
import type { ChainEvidence, PoolRow, RiskReport } from "../lib/domain";
import {
  api,
  usd,
  sourceName,
  dateTime,
  ago,
  short,
  formatNumber,
} from "../lib/client";
import {
  Badge,
  TokenAvatar,
  CopyAddress,
  Change,
  Panel,
  KeyValue,
  RiskBadge,
  Quality,
  Empty,
  Loading,
  ErrorBox,
} from "./ui";
import { TimeChart, type Point } from "./charts";
import { MarketValue } from "./market-value";
type Detail = NonNullable<Awaited<ReturnType<typeof tokenDetail>>>;

export function RiskSignals({ report }: { report: RiskReport }) {
  return (
    <div className="risk-signals">
      <p className="risk-model-version">
        Risikomodell: {report.modelVersion ?? "Legacy · Version unbekannt"} ·
        Fehlende Evidenz ist kein niedriges Risiko.
      </p>
      {report.signals.map((s) => (
        <details className={`risk-signal ${s.state}`} key={s.key}>
          <summary>
            <div className="signal-dot" />
            <span>{s.label}</span>
            <strong>
              {s.value === null
                ? "Unbekannt"
                : formatNumber(s.value, false) +
                  (s.unit === "%" ? " %" : s.unit ? " / 100" : "")}
            </strong>
            <span className="signal-chevron">+</span>
          </summary>
          <div className="signal-evidence">
            <p>{s.explanation}</p>
            <dl>
              <dt>Formel</dt>
              <dd>{s.formula}</dd>
              <dt>Schwelle</dt>
              <dd>{s.threshold}</dd>
              <dt>Quelle</dt>
              <dd>{sourceName(s.source)}</dd>
              <dt>Aktualisiert</dt>
              <dd>{dateTime(s.updatedAt, "UTC")}</dd>
              <dt>Gewichtung</dt>
              <dd>{Math.round(s.weight * 100)} % im Gesamtscore</dd>
              <dt>Datenabdeckung</dt>
              <dd>
                {s.coverage
                  ? "Eingabe verfügbar; keine Sicherheitswahrscheinlichkeit"
                  : "Keine belegte Eingabe verfügbar"}
              </dd>
            </dl>
          </div>
        </details>
      ))}
    </div>
  );
}
export function TokenDetail({
  mint,
  poolId,
  onBack,
  onWatch,
  watched,
  onRefreshed,
  timezone,
  revision,
}: {
  mint: string;
  poolId?: string;
  onBack: () => void;
  onWatch: (r: PoolRow) => void;
  watched: Set<string>;
  onRefreshed: () => Promise<void>;
  timezone: string;
  revision?: string;
}) {
  const [data, setData] = useState<Detail | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [inspecting, setInspecting] = useState(false);
  const [pool, setPool] = useState(poolId),
    [window, setWindow] = useState<"1h" | "24h" | "7d">("1h"),
    [field, setField] = useState<
      "priceUsd" | "volume5m" | "liquidityUsd" | "trades5m"
    >("priceUsd");
  const [candles, setCandles] = useState<any>(null),
    [chartError, setChartError] = useState(""),
    [chartBusy, setChartBusy] = useState(false);
  const generation = useRef(0);
  const load = useCallback(async () => {
    const request = ++generation.current;
    setBusy(true);
    try {
      const d = await api<Detail>(
        "tokens/" + mint + (pool ? "?pool=" + pool : ""),
      );
      if (request === generation.current) {
        setData(d);
        setError("");
      }
    } catch (e) {
      if (request === generation.current) setError((e as Error).message);
    } finally {
      if (request === generation.current) setBusy(false);
    }
  }, [mint, pool, revision]);
  useEffect(() => {
    void load();
    return () => {
      generation.current++;
    };
  }, [load]);
  useEffect(() => {
    setData(null);
  }, [mint, pool]);
  useEffect(() => {
    setPool(poolId);
  }, [mint, poolId]);
  const selectedId = data?.selected.poolId;
  useEffect(() => {
    if (!selectedId) return;
    let valid = true;
    setChartBusy(true);
    setCandles(null);
    setChartError("");
    api("candles/" + selectedId + "/" + window)
      .then((d) => {
        if (valid) {
          setCandles(d);
          if (d.cache?.stale)
            setChartError(
              "Quellabfrage fehlgeschlagen; gekennzeichnete ältere Chartdaten.",
            );
        }
      })
      .catch((e) => {
        if (valid)
          setChartError(
            e.message +
              " Eigene gespeicherte Beobachtungen werden weiter angezeigt.",
          );
      })
      .finally(() => {
        if (valid) setChartBusy(false);
      });
    return () => {
      valid = false;
    };
  }, [selectedId, window]);
  if (!data)
    return error ? (
      <ErrorBox error={error} retry={() => void load()} />
    ) : (
      <Loading label="Token-Analyse wird aus gespeicherten Quelldaten aufgebaut …" />
    );
  const r = data.selected;
  const from =
    Date.now() - { "1h": 3600000, "24h": 86400000, "7d": 604800000 }[window];
  const remote =
    (field === "priceUsd" || field === "volume5m") && candles?.candles?.length;
  const points: Point[] = remote
    ? candles.candles.map((c: any) => ({
        at: c.at,
        value: field === "priceUsd" ? c.close : c.volume,
      }))
    : data.history
        .filter((x) => Date.parse(x.at) >= from)
        .map((x) => ({ at: x.at, value: x[field] }));
  const chartLabel =
    field === "priceUsd"
      ? "Preis"
      : field === "liquidityUsd"
        ? "Liquidität"
        : field === "trades5m"
          ? "Trades (rollierend 5m)"
          : remote
            ? "Volumen pro Kerzenintervall"
            : "Volumen (rollierend 5m)";
  const inspect = async () => {
    setInspecting(true);
    try {
      await api("tokens/" + mint + "/inspect", "POST", {});
      await load();
      await onRefreshed();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setInspecting(false);
    }
  };
  return (
    <div className="token-detail">
      {data.alerts.length > 0 && (
        <Panel title="Persönliche Alert-Historie">
          <div className="audit-list">
            {data.alerts.map((a: any) => (
              <div key={a.id} className="audit-row">
                <Clock size={14} />
                <span>{dateTime(a.at, timezone)}</span>
                <strong>{a.data.ruleName}</strong>
                <Badge>Ausgelöst</Badge>
                <Badge
                  tone={
                    a.delivery_state === "delivered"
                      ? "cyan"
                      : a.delivery_state === "failed"
                        ? "red"
                        : "amber"
                  }
                >
                  {a.delivery_state === "delivered"
                    ? "Zugestellt"
                    : a.delivery_state === "failed"
                      ? "Fehlgeschlagen"
                      : "Ausstehend"}
                </Badge>
              </div>
            ))}
          </div>
        </Panel>
      )}
      <div className="detail-back">
        <button className="text-button" onClick={onBack}>
          <ArrowLeft size={14} />
          Zurück zum Scanner
        </button>
        <span>
          Solana / {r.dex} / {short(r.poolId)}
        </span>
      </div>
      {error && <ErrorBox error={error} retry={() => void load()} />}
      <div className="detail-hero panel">
        <div className="detail-token">
          <TokenAvatar mint={mint} symbol={r.symbol} size="large" />
          <div>
            <div className="title-with-badge">
              <h2>{r.name}</h2>
              <Badge tone="violet">{r.symbol}</Badge>
            </div>
            <CopyAddress value={mint} full />
          </div>
        </div>
        <div className="detail-hero-price">
          <strong>
            <MarketValue row={r} field="priceUsd" price />
          </strong>
          <span>
            <Change value={r.change5m} /> · 5m
          </span>
        </div>
        <div className="detail-hero-actions">
          <button className="button" onClick={() => onWatch(r)}>
            <Star
              size={15}
              fill={watched.has(mint) ? "currentColor" : "none"}
            />
            {watched.has(mint) ? "Gespeichert" : "Beobachten"}
          </button>
          <button
            className="button"
            onClick={() => void load()}
            disabled={busy}
            aria-label="Analyse aktualisieren"
          >
            <RefreshCw size={15} className={busy ? "spin" : ""} />
          </button>
        </div>
      </div>
      <div className="detail-stat-grid">
        {[
          [
            "Liquidität",
            <MarketValue key="liquidity" row={r} field="liquidityUsd" />,
          ],
          [
            "Volumen · 24h",
            <MarketValue key="volume" row={r} field="volume24h" />,
          ],
          [
            "Market Cap",
            <MarketValue key="cap" row={r} field="marketCapUsd" />,
          ],
          ["FDV", <MarketValue key="fdv" row={r} field="fdvUsd" />],
          ["Poolalter", r.createdAt ? ago(r.createdAt) : "Unbekannt"],
        ].map(([label, value]) => (
          <div className="mini-stat" key={String(label)}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
      <div className="detail-main-grid">
        <Panel className="detail-chart-panel">
          <div className="chart-controls">
            <div className="segmented">
              {[
                ["priceUsd", "Preis"],
                ["volume5m", "Volumen"],
                ["liquidityUsd", "Liquidität"],
                ["trades5m", "Trades"],
              ].map(([key, label]) => (
                <button
                  className={field === key ? "active" : ""}
                  key={key}
                  onClick={() => setField(key as typeof field)}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="segmented muted">
              {(["1h", "24h", "7d"] as const).map((w) => (
                <button
                  key={w}
                  className={w === window ? "active" : ""}
                  onClick={() => setWindow(w)}
                >
                  {w}
                </button>
              ))}
            </div>
          </div>
          {chartBusy && (
            <div className="chart-loading">
              <RefreshCw size={12} className="spin" /> Historische Quelle wird
              abgefragt …
            </div>
          )}
          <TimeChart
            points={points}
            maxGapMs={
              remote
                ? window === "1h"
                  ? 180000
                  : window === "24h"
                    ? 900000
                    : 21600000
                : 180000
            }
            label={chartLabel}
            source={
              remote
                ? "GeckoTerminal OHLCV · " +
                  (candles.cache?.hit ? "Cache" : "Abruf")
                : sourceName(r.provenance.provider) + " · eigene Samples"
            }
            unit={field === "trades5m" ? "Anzahl" : "USD"}
            height={260}
            timezone={timezone}
          />
          {chartError && (
            <p className="inline-warning">
              <AlertTriangle size={13} />
              {chartError}
            </p>
          )}
        </Panel>
        <Panel title="Rechercheprofil" className="research-profile">
          <Badge tone={r.risk.evidenceStatus === "COMPLETE" ? "cyan" : "amber"}>
            {r.risk.evidenceStatus ?? "UNKNOWN"} · Evidenzstatus
          </Badge>
          <RiskBadge state={r.risk.state} />
          <div className="overall-score">
            <strong>{r.risk.overall === null ? "—" : r.risk.overall}</strong>
            <span>/ 100 Risikoindikator</span>
          </div>
          <p>
            {r.risk.overall === null
              ? "Nicht ausreichend Daten. Fehlende Pflichtprüfungen verhindern einen Gesamtscore."
              : "Gewichteter deskriptiver Risikoindikator. Kein Nachweis von Sicherheit."}
          </p>
          <KeyValue
            label="Abdeckung Pflichtprüfungen"
            value={`${Math.round(r.risk.coverage * 100)} %`}
          />
          <KeyValue
            label="Datenqualität"
            value={<Quality value={r.risk.dataQuality} />}
          />
          <button
            className="button full"
            disabled={inspecting}
            onClick={() => void inspect()}
          >
            <RefreshCw size={14} className={inspecting ? "spin" : ""} />
            {inspecting ? "Onchain-Prüfung läuft …" : "Onchain-Daten prüfen"}
          </button>
          <small>Solana RPC · mindestens 60s Cache · begrenztes Budget</small>
        </Panel>
      </div>
      <div className="detail-two-columns">
        <Panel
          title="Risk Lab · nachvollziehbare Signale"
          action={<ShieldCheck size={16} />}
        >
          <RiskSignals report={r.risk} />
        </Panel>
        <div className="detail-stack">
          <Panel title="Contract & Datenabdeckung">
            <KeyValue
              label="Tokenprogramm"
              value={
                data.evidence?.controls ? (
                  <span title={data.evidence.controls.program}>
                    {short(data.evidence.controls.program, 7)}
                  </span>
                ) : (
                  "Unbekannt"
                )
              }
            />
            <KeyValue
              label="Mint-Authority"
              value={authority(data.evidence?.controls?.mintAuthority)}
            />
            <KeyValue
              label="Freeze-Authority"
              value={authority(data.evidence?.controls?.freezeAuthority)}
            />
            <KeyValue
              label="RPC-Slot"
              value={data.evidence?.slot ?? "Unbekannt"}
            />
            <KeyValue
              label="Prüfzeit"
              value={dateTime(data.evidence?.checkedAt, timezone)}
            />
            <KeyValue label="Tokenalter (Mint)" value="Unbekannt" />
            <KeyValue label="LP-Lock" value="Unbekannt" />
            {data.evidence?.error && (
              <p className="inline-warning">{data.evidence.error}</p>
            )}
            <p className="panel-note">
              Contract-Kontrollen gelten nach einer Stunde als erneut
              prüfungsbedürftig. Kein externer Sicherheitsbericht angebunden.
            </p>
          </Panel>
          <HolderPanel evidence={data.evidence} timezone={timezone} />
        </div>
      </div>
      <Panel title="Datenherkunft" action={<Database size={16} />}>
        <div className="source-description">
          <p>
            Jeder Wert stammt aus einer konkreten Provider-Beobachtung. Der
            Messzeitpunkt der Marktwerte wird von den Anbietern nicht
            veröffentlicht. HTTP-Zeit und Cache-Alter sind Näherungen der
            Antwortfrische.
          </p>
          <label>
            Pool wählen
            <select value={r.poolId} onChange={(e) => setPool(e.target.value)}>
              {data.pools.map((p) => (
                <option key={p.id} value={p.poolId}>
                  {p.dex} · {short(p.poolId)} · {usd(p.liquidityUsd)}
                </option>
              ))}
            </select>
          </label>
        </div>
        {data.conflicts.length > 0 && (
          <div className="error-box">
            <AlertTriangle size={16} />
            <span>
              Quellenkonflikt:{" "}
              {data.conflicts
                .map(
                  (x) =>
                    `${x.field}: ${x.differencePct.toFixed(1)} % Abweichung`,
                )
                .join("; ")}
              . Abweichende Zeitstände und Anbieterabdeckung beachten.
            </span>
          </div>
        )}
        <div
          className="horizontal-scroll"
          tabIndex={0}
          role="region"
          aria-label="Quellenvergleich"
        >
          <table className="data-table">
            <thead>
              <tr>
                <th>Quelle</th>
                <th>Preis</th>
                <th>Liquidität</th>
                <th>FDV</th>
                <th>Market Cap</th>
                <th>HTTP-Stand</th>
                <th>Abrufzeit</th>
                <th>Zeittyp</th>
              </tr>
            </thead>
            <tbody>
              {r.sources.map((s) => (
                <tr key={s.provenance.provider}>
                  <td>{sourceName(s.provenance.provider)}</td>
                  <td>
                    <MarketValue row={s} field="priceUsd" price />
                  </td>
                  <td>
                    <MarketValue row={s} field="liquidityUsd" />
                  </td>
                  <td>
                    <MarketValue row={s} field="fdvUsd" />
                  </td>
                  <td>
                    <MarketValue row={s} field="marketCapUsd" />
                  </td>
                  <td title={s.provenance.sourceAt}>
                    {dateTime(s.provenance.sourceAt, timezone)}
                  </td>
                  <td>{dateTime(s.provenance.fetchedAt, timezone)}</td>
                  <td>
                    {s.provenance.timestampKind === "retrieval-only"
                      ? "Nur Abrufzeit"
                      : "HTTP-Cache-Näherung"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pool-address">
          <span>Pooladresse</span>
          <CopyAddress value={r.poolId} full />
          <a
            href={`https://explorer.solana.com/address/${r.poolId}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-button"
          >
            Öffentlicher Explorer
            <ExternalLink size={12} />
          </a>
        </div>
      </Panel>
      <div className="detail-two-columns">
        <Panel title="Audit-Trail · Score-Veränderungen">
          <div className="audit-list">
            {data.audits.length ? (
              data.audits.slice(0, 12).map((a, i) => (
                <div className="audit-row" key={i}>
                  <Clock size={14} />
                  <span>{dateTime(String(a.at), timezone)}</span>
                  <strong>
                    {a.report.overall === null
                      ? "Gesamtscore unbekannt"
                      : `${a.report.overall}/100`}
                  </strong>
                  <small>
                    DQ {a.report.dataQuality}/100 ·{" "}
                    {a.report.modelVersion ?? "Legacy · Version unbekannt"}
                  </small>
                </div>
              ))
            ) : (
              <Empty title="Noch kein Audit-Trail" />
            )}
          </div>
        </Panel>
        <Panel title="Token-Ereignisse">
          <div className="audit-list">
            {data.events.length ? (
              data.events.slice(0, 12).map((e, i) => (
                <div className="audit-row" key={i}>
                  <Layers size={14} />
                  <span>{dateTime(String(e.at), timezone)}</span>
                  <strong>{eventLabel(e.kind)}</strong>
                  <small>
                    {e.payload.value !== undefined
                      ? formatNumber(e.payload.value, false)
                      : ""}
                  </small>
                </div>
              ))
            ) : (
              <Empty title="Noch keine Ereignisse" />
            )}
          </div>
          <p className="panel-note">
            Öffentlich beobachtete Ereignisse; persönliche Benachrichtigungen im
            Alert-Posteingang.
          </p>
        </Panel>
      </div>
    </div>
  );
}
function authority(a: string | null | undefined) {
  return a === null ? (
    <Badge tone="cyan">Deaktiviert</Badge>
  ) : a === undefined || a === "unknown" ? (
    <Badge>Unbekannt</Badge>
  ) : (
    <Badge tone="amber">Aktiv</Badge>
  );
}
export function eventLabel(kind: string) {
  return (
    {
      new_token: "Token erkannt",
      liquidity_change: "Liquiditätsänderung",
      risk_flag: "Neuer Risiko-Hinweis",
      watchlist_activity: "Beobachtete Aktivität",
      new_pool: "Pool zuerst erfasst",
      concentration_increase: "Tokenkonto-Konzentration gestiegen",
      feed_outage: "Feed eingeschränkt",
    }[kind] ?? kind
  );
}
export function HolderPanel({
  evidence,
  timezone,
}: {
  evidence: ChainEvidence | null;
  timezone: string;
}) {
  const c = evidence?.concentration;
  return (
    <Panel title="Größte öffentliche Tokenkonten">
      {c?.accounts.length ? (
        <>
          <div className="holder-summary">
            <strong>{formatNumber(c.top20Pct, false)} %</strong>
            <span>Anteil der bis zu 20 größten Tokenkonten</span>
          </div>
          <div className="holder-bars">
            {c.accounts.slice(0, 8).map((a, i) => (
              <div key={a.address}>
                <span>
                  {i + 1}. {short(a.address, 5)}
                </span>
                <span className="bar-track">
                  <i style={{ width: (a.pct ?? 0) + "%" }} />
                </span>
                <strong>{formatNumber(a.pct, false)} %</strong>
              </div>
            ))}
          </div>
        </>
      ) : (
        <Empty
          title="Kontoverteilung unbekannt"
          description="Die größten Tokenkonten wurden noch nicht erfolgreich abgefragt."
        />
      )}
      <p className="panel-note">
        Tokenkonten sind keine eindeutigen Wallet-Holder. Pool- und
        Verwahrkonten können enthalten sein. Owner-Konzentration und
        Personenbezug bleiben unbekannt.
      </p>
      {evidence && (
        <small className="source-footnote">
          Solana RPC · {dateTime(evidence.checkedAt, timezone)}
        </small>
      )}
    </Panel>
  );
}
