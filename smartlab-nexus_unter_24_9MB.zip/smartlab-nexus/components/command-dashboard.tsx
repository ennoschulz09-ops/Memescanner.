"use client";
import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  ArrowRight,
  Activity,
  Database,
  ShieldCheck,
  Radio,
  Clock,
  Layers,
  AlertTriangle,
} from "lucide-react";
import type { PoolRow } from "../lib/domain";
import { freshness } from "../lib/domain";
import type { DataQualityReport } from "../lib/data-quality";
import type { Health } from "./research-views";
import { api, ago, formatNumber, sourceName, short } from "../lib/client";
import {
  Badge,
  Panel,
  Empty,
  ErrorBox,
  Loading,
  TokenAvatar,
  RiskBadge,
} from "./ui";
import { MarketValue } from "./market-value";
import { DiscoveryFeed } from "./discovery-feed";

export function PipelineSummary({ health }: { health: Health | null }) {
  const q = (health as any)?.chainQueue;
  const cells = [
    ["In Prüfung", q?.pending, "Offene Onchain-Kandidaten"],
    [
      "Ältester Fund",
      q?.oldestAgeSeconds == null
        ? null
        : Math.round(q.oldestAgeSeconds) + " s",
      "Wartealter des ältesten offenen Kandidaten",
    ],
    [
      "Ausgesetzt",
      q?.deadLetter,
      "Dauerhaft fehlerhafte Kandidaten mit Diagnose",
    ],
    [
      "Prüfungen / Min.",
      q?.dequeueRate?.perMinute?.toFixed(1),
      "Versuche im letzten 5-Minuten-Fenster",
    ],
  ];
  return (
    <div className="pipeline-summary" data-testid="pipeline-summary">
      {cells.map(([label, value, explanation], i) => (
        <div key={String(label)} title={String(explanation)}>
          <span className="pipeline-step">0{i + 1}</span>
          <div>
            <span>{label}</span>
            <strong>{value ?? "Unbekannt"}</strong>
          </div>
          {i < 3 && <ArrowRight size={15} aria-hidden="true" />}
        </div>
      ))}
    </div>
  );
}
export function CommandDashboard({
  health,
  rows,
  onNavigate,
  onOpen,
}: {
  health: Health | null;
  rows: PoolRow[];
  onNavigate: (view: string) => void;
  onOpen: (row: PoolRow) => void;
}) {
  const stages = (health as any)?.metrics ?? [];
  const published = stages.find((s: any) => s.stage === "publish_to_ui");
  const total = health?.counts?.pools;
  const current = rows.length
    ? (rows.filter((row) => freshness(row) === "current").length /
        rows.length) *
      100
    : null;
  const movers = rows
    .filter((r) => r.change5m !== null)
    .sort((a, b) => Math.abs(b.change5m!) - Math.abs(a.change5m!))
    .slice(0, 4);
  return (
    <div className="command-workspace">
      <section className="command-intro">
        <div>
          <span className="section-index">01 / RESEARCH OPERATIONS</span>
          <h2>Erfassen. Prüfen. Einordnen.</h2>
          <p>
            Solana Research Workspace · Read-only
            <br />
            Quellen, Frische und Risiko gemeinsam im Blick.
          </p>
          <button
            className="button primary"
            onClick={() => onNavigate("scanner")}
          >
            Token Radar öffnen <ArrowUpRight size={16} />
          </button>
        </div>
        <div className="command-signal">
          <div className="signal-caption">
            <Radio size={15} />
            <span>ERFASSUNG IM BLICK</span>
            <Badge tone={health?.mode === "current" ? "cyan" : "amber"}>
              {health?.mode === "current"
                ? "Quellen erreichbar"
                : "Teilabdeckung"}
            </Badge>
          </div>
          <div className="signal-value">
            {total == null ? "—" : formatNumber(total)}
            <span>beobachtete Pools</span>
          </div>
          <p>Keine vollständige Marktübersicht. Keine Handlungsaufforderung.</p>
          <div className="signal-stats">
            <div>
              <strong>
                {current == null ? "Unbekannt" : current.toFixed(1) + " %"}
              </strong>
              <span>frisch · geladene Auswahl</span>
            </div>
            <div title="Gemessener Server-Publish bis UI; kein Markt-SLA">
              <strong>
                {published?.p95 == null
                  ? "Unbekannt"
                  : Math.round(published.p95) + " ms"}
              </strong>
              <span>UI-Latenz p95 · {published?.n ?? 0} Proben</span>
            </div>
          </div>
        </div>
      </section>
      <PipelineSummary health={health} />
      <Panel
        title="Research-Blotter"
        action={
          <button className="text-button" onClick={() => onNavigate("scanner")}>
            Alle Pools im Radar <ArrowUpRight size={14} />
          </button>
        }
      >
        <div className="blotter-head" aria-hidden="true">
          <span>Token / Pool</span>
          <span>Entdeckt</span>
          <span>Preis</span>
          <span>Liquidität</span>
          <span>Risiko / Frische</span>
        </div>
        {rows.length ? (
          <div className="research-blotter">
            {rows.slice(0, 6).map((row) => (
              <button
                key={row.id}
                className="blotter-row"
                onClick={() => onOpen(row)}
              >
                <span className="blotter-token">
                  <TokenAvatar mint={row.mint} symbol={row.symbol} />
                  <span>
                    <strong>{row.symbol}</strong>
                    <small title={row.name}>{row.name}</small>
                    <small>
                      {short(row.poolId, 6)} ·{" "}
                      {sourceName(row.provenance.provider)}
                    </small>
                  </span>
                </span>
                <span title={row.firstSeenAt}>
                  <small className="blotter-mobile-label">Entdeckt</small>
                  {ago(row.firstSeenAt)}
                </span>
                <span>
                  <small className="blotter-mobile-label">Preis</small>
                  <MarketValue row={row} field="priceUsd" />
                </span>
                <span>
                  <small className="blotter-mobile-label">Liquidität</small>
                  <MarketValue row={row} field="liquidityUsd" />
                </span>
                <span className="blotter-status">
                  <RiskBadge state={row.risk.state} />
                  <small>
                    {freshness(row) === "current"
                      ? "Innerhalb Frischebudget"
                      : freshness(row) === "stale"
                        ? "Veraltet"
                        : "Frische unbekannt"}{" "}
                    · {ago(row.provenance.fetchedAt)}
                  </small>
                </span>
              </button>
            ))}
          </div>
        ) : (
          <Empty
            title="Warte auf erste Beobachtungen"
            description="Quellenstatus und offene Prüfungen bleiben sichtbar."
          />
        )}
      </Panel>
      <div className="command-columns">
        <Panel
          title="Quellenlage"
          action={
            <button
              className="text-button"
              onClick={() => onNavigate("health")}
            >
              Diagnose <ArrowUpRight size={13} />
            </button>
          }
        >
          <div className="command-sources">
            {health?.providers?.map((p) => (
              <div key={p.provider}>
                <span className="source-monogram">
                  {p.provider.slice(0, 1).toUpperCase()}
                </span>
                <div>
                  <strong>{sourceName(p.provider)}</strong>
                  <small>
                    {p.lastSuccess
                      ? "Letzte Antwort " + ago(p.lastSuccess)
                      : "Noch keine bestätigte Antwort"}
                  </small>
                </div>
                <Badge tone={p.status === "ok" ? "cyan" : "amber"}>
                  {p.status === "ok"
                    ? "Erreichbar"
                    : p.status === "limited"
                      ? "Begrenzt"
                      : "Eingeschränkt"}
                </Badge>
              </div>
            )) ?? <Loading />}
          </div>
          <p className="panel-note">
            HTTP-Stand ist keine bestätigte Markt-Messzeit. Quellen können
            abweichen oder verzögert sein.
          </p>
        </Panel>
        <Panel
          title="Daten vor Interpretation"
          action={<ShieldCheck size={17} />}
        >
          <div className="quality-callout">
            <span className="section-index">QUALITY FIRST</span>
            <h3>Was wissen wir wirklich?</h3>
            <p>
              Feldabdeckung, veraltete Daten und Quellenstörungen bilden die
              Grundlage jeder Analyse. Fehlende Evidenz bleibt unbekannt.
            </p>
            <button
              className="button"
              aria-label="Datenqualität öffnen"
              onClick={() => onNavigate("quality")}
            >
              Datenqualität öffnen <ArrowUpRight size={14} />
            </button>
          </div>
        </Panel>
      </div>
      <Panel
        title="Beobachtete Marktänderungen"
        action={<Badge>5m · geladene Auswahl</Badge>}
      >
        <p className="panel-note">
          Gemeldete Preisbewegungen der aktuellen Scannerseite. Reihenfolge nach
          absoluter Änderung, ohne Prognose.
        </p>
        {movers.length ? (
          <div className="movement-grid">
            {movers.map((r) => (
              <button
                key={r.id}
                className="movement-card"
                onClick={() => onOpen(r)}
              >
                <div>
                  <TokenAvatar mint={r.mint} symbol={r.symbol} />
                  <span>
                    <strong>{r.symbol}</strong>
                    <small>{short(r.mint)}</small>
                  </span>
                  <ArrowUpRight size={14} />
                </div>
                <MarketValue row={r} field="change5m" />
                <span>
                  {sourceName(r.provenance.provider)} ·{" "}
                  {ago(r.provenance.fetchedAt)}
                </span>
                <RiskBadge state={r.risk.state} />
              </button>
            ))}
          </div>
        ) : (
          <Empty
            title="Noch keine vergleichbaren Marktwerte"
            description="Die Erfassung beginnt mit echten Funden. Nicht verfügbare Kennzahlen werden nicht geschätzt."
          />
        )}
      </Panel>
      <DiscoveryFeed />
    </div>
  );
}

export function DataQualityDashboard() {
  const [data, setData] = useState<DataQualityReport | null>(null),
    [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const d = await api("quality");
        if (active) {
          setData(d);
          setError("");
        }
      } catch (e) {
        if (active) setError((e as Error).message);
      }
    };
    void load();
    const timer = setInterval(load, 30000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  if (error && !data) return <ErrorBox error={error} />;
  if (!data) return <Loading label="Datenabdeckung wird geprüft …" />;
  return (
    <div className="quality-workspace">
      {error && <ErrorBox error={error} />}
      <div className="quality-summary">
        <div>
          <Database size={22} />
          <strong>{formatNumber(data.pools)}</strong>
          <span>gespeicherte Pool-Beobachtungen</span>
        </div>
        <div>
          <Clock size={22} />
          <strong>
            {data.freshness.stalePct == null
              ? "Unbekannt"
              : data.freshness.stalePct.toFixed(1) + " %"}
          </strong>
          <span>außerhalb des Frischebudgets</span>
        </div>
        <div>
          <AlertTriangle size={22} />
          <strong>API-Kosten unbekannt</strong>
          <span>Keine Tarif-/Abrechnungsquelle angebunden</span>
        </div>
      </div>
      <Panel
        title="Feldabdeckung"
        action={<Badge>Keine Sicherheitsbewertung</Badge>}
      >
        <p className="panel-note">
          Anteil gespeicherter Werte. Vorhanden bedeutet nicht automatisch
          aktuell oder korrekt; Nullwerte bleiben getrennt von fehlenden Werten.
        </p>
        <div className="coverage-grid">
          {data.fields.map((f) => (
            <div key={f.field} className="coverage-field">
              <div>
                <strong>
                  {(
                    {
                      priceUsd: "Preis · USD",
                      liquidityUsd: "Liquidität · USD",
                      volume5m: "Volumen 5m · USD",
                      volume1h: "Volumen 1h · USD",
                      volume24h: "Volumen 24h · USD",
                      marketCapUsd: "Market Cap · USD",
                      fdvUsd: "FDV · USD",
                      buys5m: "Käufe 5m",
                      sells5m: "Verkäufe 5m",
                      change5m: "Preisänderung 5m · %",
                      change1h: "Preisänderung 1h · %",
                      change24h: "Preisänderung 24h · %",
                    } as Record<string, string>
                  )[f.field] ?? f.field}
                </strong>
                <span>
                  {f.coveragePct == null
                    ? "Unbekannt"
                    : f.coveragePct.toFixed(1) + " %"}
                </span>
              </div>
              <meter
                min={0}
                max={100}
                value={f.coveragePct ?? 0}
                aria-label={"Feldabdeckung " + f.field}
              />
              <small>
                {f.present} vorhanden · {f.missing} fehlen · {f.total} geprüft
              </small>
            </div>
          ))}
        </div>
      </Panel>
      <Panel
        title="Anbieter und Fehlerhäufigkeit"
        action={<Badge>Letzte 24 Stunden</Badge>}
      >
        <div className="quality-provider-grid">
          {data.providers.map((p) => (
            <div key={p.provider}>
              <strong>{sourceName(p.provider)}</strong>
              <Badge tone={p.status === "ok" ? "cyan" : "amber"}>
                {p.status}
              </Badge>
              <dl>
                <div>
                  <dt>Auditereignisse</dt>
                  <dd>{p.auditEvents24h}</dd>
                </div>
                <div>
                  <dt>Fehleranteil der Audits</dt>
                  <dd>
                    {p.failedAuditEventPct == null
                      ? "Unbekannt"
                      : p.failedAuditEventPct.toFixed(1) + " %"}
                  </dd>
                </div>
                <div>
                  <dt>Rate-Limits</dt>
                  <dd>{p.rateLimitedAuditEvents24h}</dd>
                </div>
                <div>
                  <dt>Fehlerfolgen im Audit</dt>
                  <dd>{p.failedAuditRuns24h}</dd>
                </div>
              </dl>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title="Budgets und Aussagegrenzen">
        <div className="budget-list">
          {data.requestBudgets.map((b) => (
            <div key={b.channel}>
              <strong>{b.channel}</strong>
              <span>
                {b.used} / {b.limit} in {b.windowSeconds}s · {b.remaining}{" "}
                verbleibend
              </span>
            </div>
          ))}
        </div>
        <p className="panel-note">{data.costs.reason}</p>
        {data.limits.map((limit, i) => (
          <p className="panel-note" key={i}>
            {limit}
          </p>
        ))}
      </Panel>
    </div>
  );
}
