# Elite — Performance und Messgrenzen

Stand: 23.10.2026. Anwendungscode `c9369c7`. Rohdaten: [Standardseiten und Interaktionen](reports/elite-performance.json), [Umgebung](reports/elite-environment.json), [vorherige Realtime-Baseline](reports/elite-baseline-realtime.json), [vorherige vollständige Browserlisten](reports/elite-baseline-frontend.json). Die folgenden lokalen Messungen begründen keine Internet-/Provider-SLA.

## Umgebung und Isolation

Linux 6.18.55/x86_64, Node 24.19, Next 16.4.2 im Produktionsbuild, PostgreSQL 17 im lokalen Docker. Der Host stellt eine CPU-Quota von 2 Kernen und8 GiB RAM bereit. Die vom OS gemeldeten logischen CPUs/der Gesamtspeicher im Rohbericht sind keine zusätzlichen garantierten Containerressourcen. Gemeinsame verwaltete Umgebung mit gewöhnlicher App-/Workerlast; keine parallelen Browser-/Build-/Chaoslasten während der finalen Benchmarks.

Der Standardseitenbenchmark verwendet Chromium 156.0.8078.4, einen eigenen Produktionsserver auf 3200 und ausschließlich `nexus_elite_performance_test`. Echte paginierte APIs,100Einträge pro Seite; synthetische, gekennzeichnete Fixtures bleiben ausschließlich dort. Externer Providerzugriff dieses Servers ist gesperrt. Der Realtime-Test nutzt eine weitere eigene Datenbank `nexus_performance_test` und Port 3100. Guards verweigern dieselbe Datenbank wie die App. Keine Last-Fixtures in Live-Tabellen.

## Standardinteraktionen bei 1k/5k/10k

Je Profil7Initialloads und20Interaktionen pro Messart. Interaktionsbeginn ist das echte DOM-Eingabe-/Change-/Klickereignis. Ende ist die erste Animation-Frame mit passender API-Antwort und erwarteter DOM-Wirkung. Debounce, Server, React und Frameplanung sind enthalten; Playwright-Pollingzeit ist außerhalb der Interaktionsdauer. Detailmessungen prüfen die konkrete Tokenantwort und Überschrift. Initialload ist Navigation→gefüllterScanner plus zwei Frames einschließlich Automationsanteil; erste Navigation kalt, weitere mit warmem Browsercache. Kein offizieller Web-Vitals-TTI oder optischer Screen-to-photon-Nachweis.

**Gate PASS:** p95 der kontrollierten Desktop-Liquiditätsfilterinteraktion <200 ms, höchstens50 montierte Zeilen, keine Browserfehler. Der vorab definierte Mobil-Drosselungslauf ist separat diagnostisch; er erhält kein200 ms- oder60 FPS-PASS.

| Datensätze | Profil           |  Load p50/p95/p99 ms | Filter p50/p95/p99 ms | Sort p95 ms | Suche p95 ms | Detail p95 ms |
| ---------: | ---------------- | -------------------: | --------------------: | ----------: | -----------: | ------------: |
|       1000 | desktop          |    352.8/569.6/569.6 |        33.3/52.9/55.4 |       125.2 |        108.0 |          28.7 |
|       1000 | mobile-throttled | 2879.7/4704.8/4704.8 |     198.7/875.0/875.5 |       921.8 |        961.1 |         296.5 |
|       5000 | desktop          |    405.4/614.0/614.0 |        41.3/55.9/57.1 |        73.2 |        114.5 |          28.9 |
|       5000 | mobile-throttled | 2931.0/4664.1/4664.1 |     201.4/870.7/875.1 |       895.2 |        949.3 |         312.8 |
|      10000 | desktop          |    523.4/664.1/664.1 |       41.3/95.5/104.7 |        88.4 |        123.2 |          28.7 |
|      10000 | mobile-throttled | 2860.1/4736.9/4736.9 |     199.4/884.9/888.2 |       896.6 |        943.7 |         289.3 |

Alle weiteren p50/p95/p99 einschließlich Sortierung, Suche, Detail und Long Tasks sowie sämtliche Einzelproben stehen im Rohbericht. Bei20 Proben ist p99 faktisch das Maximum; es gibt keinen belastbaren Tail-/Produktionsnachweis. Die sieben Load-Proben erlauben ebenfalls keine zuverlässige Tail-Schätzung.

Mobilprofil: Chromium-iPhone13-Emulation,4×CPU-Verlangsamung,150 ms zusätzliche Netzlatenz,1,6 Mbit/s Down/750kbit/s Up. Filter-p95~871–885 ms, Lade-p95~4,7s und Scroll~24–29 FPS bleiben eine tatsächliche Einschränkung. Dies ist kein reales iPhone-/Safari-Gerät und keine pauschale mobile Qualitätsfreigabe.

| Datensätze | Profil           | Montierte Zeilen | Scroll-FPS | Frame p95 ms | JS-Heap MiB | Long Task max ms |
| ---------: | ---------------- | ---------------: | ---------: | -----------: | ----------: | ---------------: |
|       1000 | desktop          |               17 |       58.0 |         16.8 |        34.9 |             63.0 |
|       1000 | mobile-throttled |               12 |       25.7 |         50.1 |        35.6 |            156.0 |
|       5000 | desktop          |               17 |       60.0 |         16.7 |        38.4 |            152.0 |
|       5000 | mobile-throttled |               12 |       24.1 |         50.1 |        38.3 |            187.0 |
|      10000 | desktop          |               17 |       59.3 |         16.8 |        25.2 |             73.0 |
|      10000 | mobile-throttled |               12 |       28.7 |         50.0 |        35.6 |            176.0 |

FPS stammt aus1,5s Skript-Scroll im sichtbaren Scanner. Scrollbereich und Endoffset sind als Beleg tatsächlicher Bewegung gespeichert. Heap ist eine CDP-Momentaufnahme mit GC-Einfluss, kein Spitzen-RAM. Long Tasks wurden über die gemessenen Dokumente gesammelt; kleine Stichproben. Netzwerkbytes schließen den offenen SSE-Stream aus. Die separat gemessene vollständige100er-API-Antwort (~890kB im Fixturebestand) ist **nicht** die kompakte UI-Wire-Antwort.

## Payload, Querypläne und Regression

Eine tatsächliche100er-Seite öffentlicher Beobachtungen reduzierte der kompakte Vertrag von1.623.897auf153.889Bytes (−90,52%). Herkunft, individuelle Evidenz, Missing-State, Konflikte und Risikosignale bleiben erhalten. Vollständige Quellenbeobachtungen werden beim Detailabruf nachgeladen (`sourceDetail: deferred`), nicht fälschlich als bereits geladen ausgegeben. Dies ist eine Stichprobe, keine universelle Byteobergrenze und kein kausaler Latenz-Speedup: [Wire-/Quality-Rohbericht](reports/elite-data-wire-quality.json).

Quality-EXPLAIN bei3.358gespeicherten Pools: Feldabdeckung65,939 ms, Freshness21,966 ms, Auditaggregation3,953 ms, Cache0,052 ms, Budgets0,025 ms. Diese Samples stammen vor der rein semantischen Auditfeldumbenennung; Pläne/Bufferdaten sind im Rohbericht erhalten. Sie sind keine Query-p95-Verteilung. Standardseitenpläne bei 10.000 isolierten Pools: standard first-seen page 9.433/4.950/3.964 ms; standard liquidity filter 15.538/10.171/9.964 ms; liquidity sort 10.131/11.103/9.454 ms; text search 13.565/13.698/13.994 ms. Drei EXPLAIN-ANALYZE-Samples je Query samt Bufferdaten und vorhandenen Indizes: [Rohbericht](reports/elite-query-plans.json). Diese Queryzeiten schließen Detailhydration nicht ein; diese ist im Browserbenchmark enthalten. `pg_stat_statements` ist nicht aktiviert: vollständige SQL-Statementzahl und Query-p95 bleiben NOT VERIFIED.

Frische Baseline vor dem UI-Umbau:47 Unit/33 Integration/39 Browser erneut grün. Realtime-DOM-p95 damals100 ms; der vorher dokumentierte82 ms-Wert gehört zu einem älteren Telemetrielauf und wurde nicht ungeprüft übernommen. Vollständige10k-Browserlisten hatten in der neuen Baseline12,86s bis bedienbare Daten,56,06MBPayload und13,2 FPS. Jener Lauf hatte parallele Prüf-/Prototyplast. Der finale Standardseitenbenchmark verwendet einen anderen, produktiven Seitenvertrag und exklusive Browserlast: **kein behaupteter kausaler Vorher-Nachher-Speedup-Faktor**. Keine vollständigen10k-Payloads im normalen Scanner.

## Realtime und echte Discovery

**Drei getrennte Läufe: PASS.** Je 5.000 gespeicherte Fixtures,500SQL-Updates über ~60s auf derselben sichtbaren Zeile; kein künstlicher Providertraffic. Chromium 154.0.8037.57. Jeder veröffentlichte Hinweis wird der ersten beobachteten Frame mit Zielrevision oder einer neueren Revision derselben Zeile zugeordnet. Zwischenrevisionen dürfen zusammengefasst werden; alle Hinweise müssen aufgelöst und Endrevision501sichtbar sein. Ein MutationObserver plus requestAnimationFrame misst unabhängig von der Anwendungstelemetrie.

| Lauf                                   | Aufgelöste Hinweise | DOM p50/p95/p99 ms | 95%-Intervall p95 ms | Client-Publish→UI p95 ms | CPU s | Server Peak-RSS MiB | Kompakte erste Seite Bytes |
| -------------------------------------- | ------------------: | -----------------: | -------------------: | -----------------------: | ----: | ------------------: | -------------------------: |
| [1](reports/elite-realtime-run-1.json) |             500/500 |            2/14/65 |                13–17 |                       83 |  7.31 |               442.4 |                     127541 |
| [2](reports/elite-realtime-run-2.json) |             500/500 |            2/13/65 |                12–14 |                       81 |  7.09 |               433.1 |                     127220 |
| [3](reports/elite-realtime-run-3.json) |             499/499 |            2/13/65 |                11–18 |                       81 |  6.71 |               440.1 |                     127217 |

Keine offenen Hinweise oder Browserfehler; alle Endzustände sichtbar. Gate: mindestens400 Hinweise,≥99%Messzuordnung, keine offenen Revisionen, DOM-p95<250 ms. Die Clienttelemetrie wartet zusätzlich zweiFrames nach Verarbeitung und ist deshalb separat ausgewiesen. Kleine gemessene Latenzen können entstehen, wenn eine schon laufende Delta-Abfrage eine neuere Revision bereits vor deren eigenem Hinweis liefert. Das ist der dokumentierte Zustandssynchronisationsvertrag, kein Nachweis einzeln dargestellter500Zwischenversionen.

Das p95-Intervall verwendet Moving-Block-Bootstrap (Block10,500 Resamples). Drei lokale Minutenläufe schätzen keine Variabilität zwischen Maschinen, Deployments, Tagen oder WAN-Clients. CPU/RSS betrifft den Next-Serverprozess; Browser-/PostgreSQL-Spitzen-RSS ist nicht gemessen. Netzwerkbytes, LongTasks und PostgreSQL-Transaktions-/Tuple-/Bufferzähler stehen in jedem Rohbericht. Transaktionszahl ist keine SQL-Statementzahl.

Zeitmodell: eventAt nur bei tatsächlicher Quellzeit; firstSeen ist eigene Erfassung. DB-Updatezeit ist kein exakter Commit-Wandzeitstempel; `ingest_commit` endet nach COMMIT-Rückkehr. `publishedAt` bezeichnet SSE-Erzeugung. Browser und Server teilen im lokalen Test eine Host-Uhr. Echte Chain-Beobachtung bleibt davon getrennt: [692,788s Livefenster](reports/elite-chain-live-summary.json), ein echter Nicht-Replay-CPMM-Pool, Event→WS 1.274 ms und Event→Persistenz 114.161 ms (N=1, keine Tail-/SLA-Schätzung). Davon112.680 ms bis zum erfolgreichen Dequeue unter tatsächlichem öffentlichem RPC-/Backoff-Verhalten. BlockTime hat1s Auflösung; Upstream-/Host-Uhrenabweichung ist nicht unabhängig gemessen. Reales Chain→SSE→sichtbarerBrowser bleibt NOT VERIFIED. Der spätere Cursor-Crashfix ist lokal regressionsgeprüft, nicht rückwirkend Teil jenes Livefensters.

## Reproduktion

```bash
npm run build
npm run bench:elite
npm run bench:realtime
# realtime dreimal getrennt ausführen und jeden Bericht archivieren
npx tsx --env-file-if-exists=.env scripts/elite-query-plans.ts
```

Alle Benchmarks sequenziell ohne weitere Browser-/Build-/DB-Ausfalltests ausführen. Betrieb, Providerlimits und weitere Grenzen: [README](README.md), [SOURCE_COVERAGE](SOURCE_COVERAGE.md), [QA_REPORT](QA_REPORT.md).


## FINAL PRECISION · aktueller reproduzierter Vergleich

Aktuelle Belege: `reports/final-baseline-performance.json`, `reports/final-performance.json`, `reports/final-performance-comparison.json`. Historische Elite-Zahlen weiter oben werden nicht rückwirkend geändert. Identischer Produktionsbenchmark mit echten API-Seiten: 5 Interaktionen und 3 Loads je Profil/Größe; N=5 ist keine Tail-SLA. Baseline und Final auf demselben geteilten Rechner, finale Messung ohne parallele Browser-Suiten. Mobile: 4× CPU, 150ms, 1.6Mbps down/750kbps up.

| Tokens | Profil | Filter p95 vorher → nachher | Scroll-FPS vorher → nachher |
|---|---|---|---|
| 1000 | desktop | 54.6 → 55.3 ms | 58.0 → 60.0 |
| 1000 | mobile-throttled | 881.6 → 380.3 ms | 12.5 → 57.3 |
| 5000 | desktop | 56.6 → 54.0 ms | 57.4 → 60.0 |
| 5000 | mobile-throttled | 872.9 → 362.7 ms | 28 → 58.7 |
| 10000 | desktop | 92.0 → 56.9 ms | 58.7 → 60 |
| 10000 | mobile-throttled | 870.2 → 373.5 ms | 30.0 → 50.8 |

Ursachen: wiederverwendete Intl-Formatierer; Evidenz-Fallback nur für tatsächliche Marktfelder statt wiederholter Berechnung aller zwölf Felder bei Metadatenzellen; mobil 25 statt 100 echte Serverzeilen, unveränderte Filter-/Sortiersemantik und Pagination. Kein Vollbestand im Browser nötig. Normales Desktop-Filtergate <200ms bestanden, gedrosseltes Mobilprofil weiterhin >200ms. Scroll-FPS sind ein 1,5s-Skript, kein Dauertest.

Realtime separat: `reports/final-realtime.json` (500 echte DB-Updates/Minute, eine sichtbare Zeile, finale Revision nachgewiesen); 1/5/20 unabhängige SSE-Sitzungen inklusive Reconnect stehen in Integrationstests. Dies ersetzt keinen 20-Browser-WAN-Soak. Querypläne: `reports/final-query-plans.json`. Legacy-Benchmark `reports/final-legacy-benchmark.json` liefert bewusst voll injizierte 1k/5k/10k Browserbestände und ist keine Messung der begrenzten Produktions-API. Der zusätzliche Lauf lief parallel zu Browser-QA und dient nur als Diagnose.
