import { it, expect } from "vitest";
import { HttpClient } from "../../lib/providers/http";
import {
  decodePoolInitializations,
  CPMM_PROGRAM,
} from "../../lib/providers/pool-init";
import bs58 from "bs58";
import { createHash } from "node:crypto";
it("blocks external transport and budget claims in explicitly isolated browser tests", async () => {
  const previous = [
    process.env.CI_NETWORK_ISOLATION,
    process.env.NEXUS_TEST_MODE,
  ];
  let requests = 0,
    claims = 0;
  try {
    process.env.CI_NETWORK_ISOLATION = "true";
    process.env.NEXUS_TEST_MODE = "true";
    const http = new HttpClient(
      async () => {
        requests++;
        return new Response("{}");
      },
      {
        claim: async () => {
          claims++;
        },
      },
    );
    await expect(
      http.get("dex", "fixture", "https://example.test"),
    ).rejects.toMatchObject({
      status: 503,
      message: "Externe Abrufe im isolierten Test deaktiviert",
    });
    expect({ requests, claims }).toEqual({ requests: 0, claims: 0 });
    process.env.NEXUS_TEST_MODE = "false";
    await http.get("dex", "fixture", "https://example.test");
    expect({ requests, claims }).toEqual({ requests: 1, claims: 1 });
  } finally {
    for (const [i, key] of [
      "CI_NETWORK_ISOLATION",
      "NEXUS_TEST_MODE",
    ].entries())
      if (previous[i] === undefined) delete process.env[key];
      else process.env[key] = previous[i];
  }
});
it("refuses unknown transaction versions even when the instruction shape matches", () => {
  const tx = {
    version: 2,
    slot: 1,
    blockTime: null,
    meta: { err: null },
    transaction: {
      message: {
        instructions: [
          {
            programId: CPMM_PROGRAM,
            accounts: Array.from({ length: 20 }, (_, i) =>
              bs58.encode(Buffer.alloc(32, i + 1)),
            ),
            data: bs58.encode(
              Buffer.concat([
                createHash("sha256")
                  .update("global:initialize")
                  .digest()
                  .subarray(0, 8),
                Buffer.alloc(24),
              ]),
            ),
          },
        ],
      },
    },
  };
  expect(decodePoolInitializations(tx)).toEqual([]);
});
it("retains inspection Retry-After so the risk scheduler can back off after storing incomplete evidence", async () => {
  const { SolanaProvider } = await import("../../lib/providers/solana");
  const provider = new SolanaProvider(
    new HttpClient(
      async () =>
        new Response("limited", {
          status: 429,
          headers: { "Retry-After": "600" },
        }),
    ),
  );
  const result = await provider.inspect(bs58.encode(Buffer.alloc(32, 5)));
  expect(result).toMatchObject({
    error: "Contract-Kontrollen nicht verfügbar",
    requestFailure: { status: 429, retryAfterMs: 600000 },
  });
});
it("stores incomplete risk evidence before opening scheduler backoff", async () => {
  const { runRiskEnrichment } = await import("../../worker/risk-enrichment");
  const { SolanaProvider } = await import("../../lib/providers/solana");
  const { SourceScheduler } = await import("../../worker/scheduler");
  let now = 1000;
  const stored: unknown[] = [];
  const provider = new SolanaProvider(
    new HttpClient(
      async () =>
        new Response("limited", {
          status: 429,
          headers: { "Retry-After": "600" },
        }),
    ),
  );
  const scheduler = new SourceScheduler(
    1,
    () => now,
    () => 0,
  );
  scheduler.add({
    key: "risk",
    intervalMs: 10000,
    priority: 4,
    run: () =>
      runRiskEnrichment(
        bs58.encode(Buffer.alloc(32, 5)),
        provider,
        async (_mint, evidence) => {
          stored.push(evidence);
        },
      ),
  });
  scheduler.tick();
  await scheduler.stop();
  expect(stored).toMatchObject([
    { error: "Contract-Kontrollen nicht verfügbar", controls: null },
  ]);
  expect(scheduler.snapshot()[0]).toMatchObject({
    failures: 1,
    lastSuccess: null,
    nextAt: 601000,
  });
});
it("decodes the stored official v1 fixture and rejects its malformed counterpart", async () => {
  const good = (await import("../fixtures/chain-cpmm-v1-initialize.json"))
    .default;
  const bad = (await import("../fixtures/chain-cpmm-v1-invalid.json")).default;
  expect(decodePoolInitializations(good)).toEqual([
    {
      poolAddress: "GgBaCs3NCBuZN12kCJgAW63ydqohFkHEdfdEXBPzLHq",
      mints: [
        "LbUiWL3xVV8hTFYBVdbTNrpDo41NKS6o3LHHuDzjfcY",
        "QWmroo4YnnMqYW3cnxWkFdaTxGD3P7vMSzwMHGbUzwF",
      ],
      slot: 123,
      eventAt: "2026-05-28T20:26:40.000Z",
      decoderVersion: "raydium-cpmm-initialize-v1",
    },
  ]);
  expect(decodePoolInitializations(bad)).toEqual([]);
});
