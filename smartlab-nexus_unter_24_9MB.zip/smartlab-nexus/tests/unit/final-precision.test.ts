import { it, expect } from "vitest";
import { segmentSeries } from "../../lib/chart-series";
import { observation } from "../helpers";
import { scoreRisk } from "../../lib/risk";
import {
  SolanaProvider,
  TOKEN_PROGRAM,
  concentration,
} from "../../lib/providers/solana";
import { HttpClient } from "../../lib/providers/http";
import bs58 from "bs58";
const at = new Date().toISOString();
const address = bs58.encode(Buffer.alloc(32, 7));
it("keeps successful mint controls when holder RPC is limited, preserving Retry-After", async () => {
  const provider = new SolanaProvider(
    new HttpClient(async (_url, init) => {
      const request = JSON.parse(String(init?.body));
      if (request.method === "getAccountInfo")
        return Response.json({
          result: {
            context: { slot: 10 },
            value: {
              owner: TOKEN_PROGRAM,
              data: {
                parsed: {
                  type: "mint",
                  info: {
                    supply: "1000",
                    decimals: 6,
                    mintAuthority: null,
                    freezeAuthority: null,
                  },
                },
              },
            },
          },
        });
      expect(request.params[1].minContextSlot).toBe(10);
      return new Response("limited", {
        status: 429,
        headers: { "Retry-After": "600" },
      });
    }),
  );
  const evidence = await provider.inspect(address);
  const report = scoreRisk(observation(), evidence, []);
  expect(evidence.requestFailure?.retryAfterMs).toBe(600000);
  expect(report.signals.find((s) => s.key === "contract")).toMatchObject({
    value: 0,
    state: "observed",
  });
  expect(report.signals.find((s) => s.key === "concentration")?.state).toBe(
    "unknown",
  );
  expect(report).toMatchObject({
    evidenceStatus: "DEGRADED",
    overall: null,
    modelVersion: "nexus-risk/3",
  });
});
it("never uses stale market signals as current risk evidence", () => {
  const obs = observation({ liquidityUsd: 0 });
  obs.provenance = { ...obs.provenance, sourceAt: "2020-01-01T00:00:00.000Z" };
  const report = scoreRisk(obs, null, []);
  for (const key of ["liquidity", "activity", "momentum"])
    expect(report.signals.find((s) => s.key === key)?.state).toBe("unknown");
  expect(report.overall).toBeNull();
});
it("rejects duplicate accounts and malformed supplies as concentration evidence", () => {
  expect(
    concentration(
      [
        { address, amount: "50" },
        { address, amount: "50" },
      ],
      "1000",
    ).top20Pct,
  ).toBeNull();
  expect(concentration([{ address, amount: "50" }], "NaN").top1Pct).toBeNull();
});
it("breaks chart lines at explicit nulls and observation outages, sorts and deduplicates timestamps", () => {
  const p = (n: number, value: number | null) => ({
    at: new Date(Date.parse(at) + n * 60000).toISOString(),
    value,
  });
  expect(
    segmentSeries([p(12, 9), p(0, 1), p(1, null), p(2, 3), p(2, 4)]),
  ).toEqual([[p(0, 1)], [p(2, 4)], [p(12, 9)]]);
  expect(segmentSeries([p(0, NaN), { at: "invalid", value: 1 }])).toEqual([]);
});
it("inventories every numeric market field and describes null, clocks, units and formulas", async () => {
  const { numericFieldContracts } =
    await import("../../lib/data-field-inventory");
  const { marketFields } = await import("../../lib/value-evidence");
  const keys = new Set(numericFieldContracts.flatMap((c) => c.fields));
  for (const field of marketFields) expect(keys.has(field)).toBe(true);
  for (const contract of numericFieldContracts)
    for (const key of [
      "unit",
      "source",
      "sourceTimestamp",
      "fetchedAt",
      "freshnessBudget",
      "nullState",
      "conflicts",
      "formula",
    ] as const)
      expect(contract[key].length).toBeGreaterThan(5);
  const report = scoreRisk(observation(), null, []);
  expect(report.signals.map((s) => s.key).sort()).toEqual(
    [
      "quality",
      "liquidity",
      "concentration",
      "contract",
      "activity",
      "momentum",
      "lp-lock",
      "clusters",
    ].sort(),
  );
  for (const signal of report.signals) expect(signal).toHaveProperty("formula");
});
it("wakes discovery immediately after durable admission and never cancels scheduler backoff", async () => {
  const { SourceScheduler } = await import("../../worker/scheduler");
  let now = 0,
    calls = 0;
  const scheduler = new SourceScheduler(
    1,
    () => now,
    () => 0,
  );
  scheduler.add({
    key: "decode",
    priority: 0,
    intervalMs: 5000,
    run: async () => {
      calls++;
      if (calls === 3)
        throw Object.assign(new Error("429"), { retryAfterMs: 60000 });
    },
  });
  scheduler.tick();
  await new Promise(setImmediate);
  now = 250;
  scheduler.tick();
  await new Promise(setImmediate);
  expect(calls).toBe(1);
  expect(scheduler.wake("decode")).toBe(true);
  scheduler.tick();
  await new Promise(setImmediate);
  expect(calls).toBe(2);
  scheduler.wake("decode");
  scheduler.tick();
  await new Promise(setImmediate);
  expect(calls).toBe(3);
  now = 500;
  expect(scheduler.wake("decode")).toBe(false);
  scheduler.tick();
  await new Promise(setImmediate);
  expect(calls).toBe(3);
  await scheduler.stop();
});
it("renders finite chart geometry for zero, constant and extreme finite observations", async () => {
  const { chartScale } = await import("../../lib/chart-series");
  for (const values of [
    [0, 0],
    [Number.MAX_VALUE, Number.MAX_VALUE],
    [0, Number.MAX_VALUE],
    [-Number.MAX_VALUE, Number.MAX_VALUE],
  ]) {
    const scale = chartScale(values);
    for (const value of values)
      expect(Number.isFinite(scale.fraction(value))).toBe(true);
    for (const fraction of [0, 0.5, 1])
      expect(Number.isFinite(scale.valueAt(fraction))).toBe(true);
  }
});
