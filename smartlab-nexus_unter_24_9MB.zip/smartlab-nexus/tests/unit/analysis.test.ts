import { describe, it, expect } from "vitest";
import { scoreRisk, sourceConflicts } from "../../lib/risk";
import { filterPools, sortPools } from "../../lib/filters";
import { shouldAlert, isQuiet } from "../../lib/alerts";
import { observation } from "../helpers";
import type { PoolRow, ChainEvidence } from "../../lib/domain";

const obs = observation();
const known: ChainEvidence = {
  controls: {
    mintAuthority: null,
    freezeAuthority: null,
    program: "SPL Token",
    supply: "1000",
    decimals: 6,
    slot: 1,
    extensions: [],
  },
  concentration: {
    top1Pct: 10,
    top20Pct: 20,
    scope: "token-accounts",
    accounts: [],
  },
  checkedAt: new Date().toISOString(),
  error: null,
  slot: 1,
};
const row = (overrides: Partial<PoolRow> = {}): PoolRow => ({
  ...obs,
  firstSeenAt: obs.provenance.fetchedAt,
  updatedAt: obs.provenance.fetchedAt,
  risk: scoreRisk(obs, null, [obs]),
  sources: [obs],
  sparkline: [],
  ...overrides,
});
describe("explainable risk", () => {
  it("never treats missing chain checks as zero risk", () => {
    const r = scoreRisk(observation({ liquidityUsd: 1e6 }), null, [obs]);
    expect(r.overall).toBeNull();
    expect(r.state).not.toBe("observed");
    expect(r.signals.find((x) => x.key === "contract")?.value).toBeNull();
    expect(r.coverage).toBeLessThan(1);
  });
  it("computes documented weighted risk only with all required checks", () => {
    const r = scoreRisk(
      observation({ liquidityUsd: 300000, volume5m: 100 }),
      known,
      [obs],
    );
    expect(r.overall).toBe(7); // .30*10 + .25*10 + .30*0 + .15*10 = 7
    expect(r.signals.every((x) => !!x.formula && !!x.explanation)).toBe(true);
    expect(r.signals.find((x) => x.key === "lp-lock")?.state).toBe("unknown");
  });
  it("treats zero liquidity as critical and invalidates old chain checks", () => {
    expect(
      scoreRisk(observation({ liquidityUsd: 0 }), known, [obs]).signals.find(
        (x) => x.key === "liquidity",
      )?.value,
    ).toBe(100);
    const old = { ...known, checkedAt: "2020-01-01T00:00:00Z" };
    expect(scoreRisk(obs, old, [obs]).overall).toBeNull();
  });
  it("compares like pools across sources, with explicit conflicts", () => {
    const a = observation({ priceUsd: 1 }),
      b = observation({
        priceUsd: 1.3,
        provenance: { ...obs.provenance, provider: "dex" },
      });
    expect(sourceConflicts([a, b])).toHaveLength(1);
    expect(sourceConflicts([a, { ...b, poolId: "different" }])).toHaveLength(0);
  });
  it("exposes controls and concentration as observations with evidence", () => {
    const r = scoreRisk(
      obs,
      {
        ...known,
        controls: {
          ...known.controls!,
          mintAuthority: "active",
          freezeAuthority: "active",
        },
        concentration: { ...known.concentration!, top1Pct: 85 },
      },
      [obs],
    );
    expect(r.signals.find((x) => x.key === "contract")?.value).toBe(100);
    expect(r.flags.some((x) => x.includes("Konzentration"))).toBe(true);
  });
});
describe("scanner filtering", () => {
  it("filters activity increases separately from absolute trade counts", () => {
    expect(
      filterPools([row({ activityIncreasePct: 50 })], {
        minActivityIncrease: 40,
      }),
    ).toHaveLength(1);
    expect(
      filterPools([row({ activityIncreasePct: null })], {
        minActivityIncrease: 40,
      }),
    ).toHaveLength(0);
    expect(
      filterPools(
        [row({ activityIncreasePct: 10, buys5m: 1000, sells5m: 1000 })],
        { minActivityIncrease: 40 },
      ),
    ).toHaveLength(0);
  });
  it("sorts derived trade counts, activity ratio and momentum by their real values", () => {
    const a = row({ id: "a", buys5m: 10, sells5m: 5, change5m: -20 }),
      b = row({ id: "b", buys5m: 20, sells5m: 2, change5m: 40 });
    expect(sortPools([a, b], "trades", "desc")[0].id).toBe("b");
    expect(sortPools([a, b], "ratio", "desc")[0].id).toBe("b");
    expect(sortPools([a, b], "momentum", "desc")[0].id).toBe("b");
  });
  it("searches full mint addresses, symbols and names", () => {
    const rows = [row()];
    expect(filterPools(rows, { query: obs.mint })).toHaveLength(1);
    expect(filterPools(rows, { query: obs.symbol.toLowerCase() })).toHaveLength(
      1,
    );
    expect(filterPools(rows, { query: "does not exist" })).toHaveLength(0);
  });
  it("combines nullable filters conservatively", () => {
    expect(
      filterPools([row({ liquidityUsd: null })], { minLiquidity: 1 }),
    ).toHaveLength(0);
    expect(
      filterPools([row({ liquidityUsd: 50000 })], {
        minLiquidity: 10000,
        dex: "does-not-exist",
      }),
    ).toHaveLength(0);
    expect(
      filterPools([row({ liquidityUsd: 50000 })], { minLiquidity: 10000 }),
    ).toHaveLength(1);
    expect(
      filterPools([row({ volume5m: 200, volume1h: 1000 })], {
        preset: "rising",
      }),
    ).toHaveLength(1);
  });
  it("keeps unknown numeric values last in both sort directions", () => {
    const rows = [
      row({ id: "a", priceUsd: null }),
      row({ id: "b", priceUsd: 1 }),
      row({ id: "c", priceUsd: 2 }),
    ];
    expect(sortPools(rows, "priceUsd", "desc").map((x) => x.id)).toEqual([
      "c",
      "b",
      "a",
    ]);
    expect(sortPools(rows, "priceUsd", "asc").map((x) => x.id)).toEqual([
      "b",
      "c",
      "a",
    ]);
  });
});
describe("alert delivery policy", () => {
  const rule = {
    kind: "liquidity_change" as const,
    threshold: 30,
    cooldownSeconds: 300,
    quotaPerHour: 3,
    quietStart: 22,
    quietEnd: 7,
    enabled: true,
    mint: null,
  };
  const event = {
    kind: "liquidity_change" as const,
    mint: obs.mint,
    key: "event-1",
    value: -45,
    at: "2026-10-23T12:00:00Z",
  };
  it("triggers absolute liquidity changes above threshold", () => {
    expect(shouldAlert(rule, event, [], new Date(event.at))).toBe(true);
    expect(
      shouldAlert(rule, { ...event, value: 10 }, [], new Date(event.at)),
    ).toBe(false);
  });
  it("deduplicates events and applies cooldown and hourly quota", () => {
    expect(
      shouldAlert(
        rule,
        event,
        [{ key: "event-1", at: "2026-10-23T10:00:00Z" }],
        new Date(event.at),
      ),
    ).toBe(false);
    expect(
      shouldAlert(
        rule,
        event,
        [{ key: "old", at: "2026-10-23T11:59:00Z" }],
        new Date(event.at),
      ),
    ).toBe(false);
    expect(
      shouldAlert(
        rule,
        event,
        [0, 1, 2].map((x) => ({ key: String(x), at: "2026-10-23T11:10:00Z" })),
        new Date(event.at),
      ),
    ).toBe(false);
  });
  it("handles quiet hours over midnight and exact end boundary in UTC", () => {
    expect(isQuiet(new Date("2026-10-23T23:00:00Z"), 22, 7)).toBe(true);
    expect(isQuiet(new Date("2026-10-23T07:00:00Z"), 22, 7)).toBe(false);
    expect(shouldAlert(rule, event, [], new Date("2026-10-23T23:00:00Z"))).toBe(
      false,
    );
  });
  it("requires the configured mint and enabled rule", () => {
    expect(
      shouldAlert({ ...rule, enabled: false }, event, [], new Date(event.at)),
    ).toBe(false);
    expect(
      shouldAlert({ ...rule, mint: "other" }, event, [], new Date(event.at)),
    ).toBe(false);
  });
});
