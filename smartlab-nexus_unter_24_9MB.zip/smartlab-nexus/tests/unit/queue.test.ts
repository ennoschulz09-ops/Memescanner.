import { it, expect } from "vitest";
import { PriorityQueue } from "../../worker/queue";
it("prioritizes watchlist/new-listing work, deduplicates and bounds concurrency", async () => {
  const q = new PriorityQueue();
  const order: string[] = [];
  let running = 0,
    max = 0;
  const task = (key: string, p: number) =>
    q.add(key, p, async () => {
      order.push(key);
      running++;
      max = Math.max(max, running);
      await new Promise((r) => setTimeout(r, 5));
      running--;
    });
  task("regular", 3);
  task("watch", 0);
  task("new", 1);
  expect(task("new", 1)).toBe(false);
  const results = await q.drain(2);
  expect(order.slice(0, 2)).toEqual(["watch", "new"]);
  expect(max).toBe(2);
  expect(results.every((x) => x.ok)).toBe(true);
  expect(q.size).toBe(0);
});
it("continues after a failed task and reports the failure", async () => {
  const q = new PriorityQueue();
  let completed = false;
  q.add("bad", 0, async () => {
    throw new Error("network failure");
  });
  q.add("good", 1, async () => {
    completed = true;
  });
  const results = await q.drain(1);
  expect(completed).toBe(true);
  expect(results.find((x) => x.key === "bad")?.ok).toBe(false);
});
