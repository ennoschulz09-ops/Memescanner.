import { describe, it, expect } from "vitest";
import gecko from "../fixtures/gecko-live.json";
import dex from "../fixtures/dex-live.json";
import { normalizeDex, normalizeGecko } from "../../lib/providers/normalize";
import {
  HttpClient,
  ProviderError,
  provenance,
} from "../../lib/providers/http";
import { isAddress, safeText } from "../../lib/domain";
import { parseMint, concentration } from "../../lib/providers/solana";

const meta = provenance(
  "gecko",
  "new_pools",
  new Headers({ date: "Fri, 23 Oct 2026 09:56:00 GMT", age: "24" }),
  new Date("2026-10-23T09:56:18Z"),
  42,
);
describe("public provider normalization", () => {
  it("normalizes real captured new pools and retains provenance", () => {
    const result = normalizeGecko(gecko, meta);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0].chain).toBe("solana");
    expect(isAddress(result[0].mint)).toBe(true);
    expect(result[0].liquidityUsd).toBe(1144.13809557979);
    expect(result[0].marketCapUsd).toBeNull();
    expect(result[0].provenance.measuredAt).toBeNull();
    expect(result[0].provenance.sourceAt).toBe("2026-10-23T09:55:54.000Z");
  });
  it("retains market cap and FDV as separate fields", () => {
    const rows = normalizeDex(dex, { ...meta, provider: "dex" });
    expect(rows.length).toBeGreaterThan(0);
    expect(rows[0].fdvUsd).toBeNull();
    expect(rows[0].marketCapUsd).toBe(dex[0].marketCap);
    const distinct = normalizeDex(
      [{ ...dex[0], fdv: 123, marketCap: 456 }],
      meta,
    )[0];
    expect(distinct.fdvUsd).toBe(123);
    expect(distinct.marketCapUsd).toBe(456);
    expect(rows[0].provenance.provider).toBe("dex");
  });
  it("does not coerce missing, empty, negative or infinite market values to zero", () => {
    const row = {
      ...dex[0],
      priceUsd: "",
      liquidity: { usd: -1 },
      marketCap: null,
      fdv: Infinity,
      volume: { m5: 0 },
    };
    const result = normalizeDex([row], { ...meta, provider: "dex" })[0];
    expect(result.priceUsd).toBeNull();
    expect(result.liquidityUsd).toBeNull();
    expect(result.marketCapUsd).toBeNull();
    expect(result.fdvUsd).toBeNull();
    expect(result.volume5m).toBe(0);
    expect(result.volume1h).toBeNull();
  });
  it("rejects wrong chains, invalid addresses and malformed roots", () => {
    expect(normalizeDex([{ ...dex[0], chainId: "ethereum" }], meta)).toEqual(
      [],
    );
    expect(
      normalizeDex([{ ...dex[0], pairAddress: "<script>" }], meta),
    ).toEqual([]);
    expect(() => normalizeGecko({ data: "bad" }, meta)).toThrow();
  });
  it("treats metadata as untrusted and bounds length", () => {
    expect(safeText("<script>\u0000bad</script>", 10)).not.toMatch(
      /[<>\u0000]/,
    );
    expect(safeText("x".repeat(200), 32)).toHaveLength(32);
    expect(isAddress("0".repeat(44))).toBe(false);
    expect(isAddress("11111111111111111111111111111111")).toBe(true);
  });
  it("uses conservative HTTP age and explicitly marks a retrieval-only timestamp", () => {
    const p = provenance(
      "dex",
      "search",
      new Headers(),
      new Date("2026-10-23T10:00:00Z"),
      1,
    );
    expect(p.timestampKind).toBe("retrieval-only");
    expect(p.measuredAt).toBeNull();
    expect(meta.cacheAgeSeconds).toBe(24);
  });
});
describe("transport and RPC limits", () => {
  it("honors Retry-After without retrying a rate-limited request", async () => {
    let calls = 0;
    const http = new HttpClient(async () => {
      calls++;
      return new Response("{}", {
        status: 429,
        headers: { "Retry-After": "15" },
      });
    });
    await expect(
      http.get("gecko", "test", "https://example.test"),
    ).rejects.toMatchObject({ status: 429, retryAfterMs: 15000 });
    expect(calls).toBe(1);
  });
  it("rejects invalid JSON rather than publishing empty live data", async () => {
    const http = new HttpClient(
      async () => new Response("not-json", { status: 200 }),
    );
    await expect(
      http.get("dex", "test", "https://example.test"),
    ).rejects.toBeInstanceOf(ProviderError);
  });
  it("stops before fetching when a shared budget is exhausted", async () => {
    let calls = 0;
    const http = new HttpClient(
      async () => {
        calls++;
        return new Response("{}");
      },
      {
        claim: async () => {
          throw new ProviderError("gecko", 429, 60000);
        },
      },
    );
    await expect(
      http.get("gecko", "test", "https://example.test"),
    ).rejects.toMatchObject({ status: 429 });
    expect(calls).toBe(0);
  });
  it("distinguishes disabled mint controls from absent RPC fields", () => {
    const a = parseMint(
      {
        owner: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
        data: {
          parsed: {
            type: "mint",
            info: {
              supply: "1000",
              decimals: 6,
              mintAuthority: null,
              freezeAuthority: null,
            },
          },
        },
      },
      55,
    );
    expect(a.mintAuthority).toBeNull();
    expect(a.freezeAuthority).toBeNull();
    expect(a.slot).toBe(55);
    expect(() => parseMint(null, 55)).toThrow();
    expect(() =>
      parseMint(
        { owner: "bad", data: { parsed: { type: "account", info: {} } } },
        55,
      ),
    ).toThrow();
  });
  it("computes token-account concentration with integer supply, never wallet holder identity", () => {
    expect(
      concentration(
        [
          { address: "11111111111111111111111111111111", amount: "400" },
          {
            address: "So11111111111111111111111111111111111111112",
            amount: "100",
          },
        ],
        "1000",
      ),
    ).toMatchObject({ top1Pct: 40, top20Pct: 50, scope: "token-accounts" });
    expect(concentration([], "0").top20Pct).toBeNull();
  });
});
