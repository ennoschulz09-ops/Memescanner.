import { it, expect } from "vitest";
import { TokenBucket, SourceScheduler } from "../../worker/scheduler";
import { PriorityQueue } from "../../worker/queue";
import { withFieldEvidence } from "../../lib/value-evidence";
import { observation } from "../helpers";

it("limits source bursts and refills by elapsed time without bypassing quotas", () => {
  let now = 0;
  const bucket = new TokenBucket(2, 2, () => now);
  expect(bucket.take()).toBe(true);
  expect(bucket.take()).toBe(true);
  expect(bucket.take()).toBe(false);
  expect(bucket.retryAfterMs()).toBe(30000);
  now = 30000;
  expect(bucket.take()).toBe(true);
  expect(bucket.take()).toBe(false);
});
it("does not promote HTTP cache time to a measured market event and preserves missing states", () => {
  const row = observation({ liquidityUsd: null, priceUsd: 0 });
  const result = withFieldEvidence(row);
  expect(result.fieldEvidence?.liquidityUsd.freshness).toBe("UNAVAILABLE");
  expect(result.fieldEvidence?.priceUsd.missing).toBe(false);
  expect(result.fieldEvidence?.priceUsd.sourceTimestamp).toBeNull();
  expect(result.fieldEvidence?.priceUsd.freshness).toBe("CACHED");
  const stale = withFieldEvidence(
    row,
    [row],
    Date.parse(row.provenance.sourceAt) + 181000,
  );
  expect(stale.fieldEvidence?.priceUsd.freshness).toBe("STALE");
});
it("bounds queued plus running work without forgetting rejected keys", async () => {
  const queue = new PriorityQueue(2);
  expect(queue.add("one", 0, async () => {})).toBe(true);
  expect(queue.add("two", 0, async () => {})).toBe(true);
  expect(queue.add("three", 0, async () => {})).toBe(false);
  expect(queue.rejected).toBe(1);
  await queue.drain();
  expect(queue.add("three", 0, async () => {})).toBe(true);
});
it("does not let a slow risk job block the independent discovery schedule", async () => {
  let now = 0,
    release!: () => void,
    discoveries = 0;
  const scheduler = new SourceScheduler(
    2,
    () => now,
    () => 0,
  );
  scheduler.add({
    key: "risk",
    intervalMs: 10000,
    priority: 2,
    run: () =>
      new Promise<void>((r) => {
        release = r;
      }),
  });
  scheduler.add({
    key: "discovery",
    intervalMs: 1000,
    priority: 0,
    run: async () => {
      discoveries++;
    },
  });
  scheduler.tick();
  await new Promise((r) => setTimeout(r, 0));
  now = 1000;
  scheduler.tick();
  await new Promise((r) => setTimeout(r, 0));
  expect(discoveries).toBe(2);
  release();
  await scheduler.stop();
});
it("opens a circuit after repeated source failure and honors a longer retry delay", async () => {
  let now = 0,
    attempts = 0;
  const scheduler = new SourceScheduler(
    1,
    () => now,
    () => 0,
  );
  scheduler.add({
    key: "feed",
    intervalMs: 1000,
    priority: 0,
    run: async () => {
      attempts++;
      throw Object.assign(new Error("rate limited"), { retryAfterMs: 60000 });
    },
  });
  for (let i = 0; i < 3; i++) {
    scheduler.tick();
    await new Promise((r) => setTimeout(r, 0));
    now += 60000;
  }
  const state = scheduler.snapshot()[0];
  expect(state.circuit).toBe("open");
  expect(state.nextAt).toBeGreaterThanOrEqual(180000);
  now = 179999;
  scheduler.tick();
  expect(attempts).toBe(3);
  await scheduler.stop();
});
