import { createServer } from "node:http";
import { beforeAll, afterAll, it, expect } from "vitest";
import { HttpClient } from "../../lib/providers/http";

// Real local HTTP failures, never an injected success response or a live-provider flood.
const calls = new Map<string, number>();
const server = createServer((request, response) => {
  const route = request.url ?? "/";
  calls.set(route, (calls.get(route) ?? 0) + 1);
  if (route === "/timeout") return;
  response.writeHead(route === "/limited" ? 429 : 500, {
    "Retry-After": "3",
  });
  response.end("upstream failure");
});
let base: string;
beforeAll(async () => {
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("No HTTP port");
  base = `http://127.0.0.1:${address.port}`;
});
afterAll(async () => {
  server.closeAllConnections();
  await new Promise<void>((resolve) => server.close(() => resolve()));
});
it.each([
  ["/limited", 429],
  ["/failure", 500],
] as const)(
  "rejects a real HTTP failure from %s without an immediate retry",
  async (route, status) => {
    const audits: unknown[] = [];
    const http = new HttpClient(undefined, {
      audit: async (value) => {
        audits.push(value);
      },
    });
    await expect(http.get("dex", "chaos", base + route)).rejects.toMatchObject({
      status,
      retryAfterMs: 3000,
    });
    expect(calls.get(route)).toBe(1);
    expect(audits).toMatchObject([{ ok: false, status }]);
  },
);
it("aborts a genuinely stalled HTTP server and records unavailability without leaking its URL", async () => {
  const audits: unknown[] = [];
  const http = new HttpClient(undefined, {
    audit: async (value) => {
      audits.push(value);
    },
  });
  const started = Date.now();
  await expect(
    http.get("dex", "chaos", base + "/timeout"),
  ).rejects.toMatchObject({
    status: 503,
    message: "Provider nicht erreichbar oder Zeitlimit überschritten",
  });
  expect(Date.now() - started).toBeGreaterThanOrEqual(11000);
  expect(calls.get("/timeout")).toBe(1);
  expect(audits).toMatchObject([{ ok: false, status: 503 }]);
}, 16000);
