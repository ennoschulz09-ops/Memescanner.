import { afterEach, expect, it, vi } from "vitest";
import { db } from "../../lib/db";
import { getDataQuality } from "../../lib/data-quality";

afterEach(() => vi.restoreAllMocks());
it("reports nullable percentages and unknown cost for an empty, unobserved installation", async () => {
  vi.spyOn(db, "query").mockResolvedValue({ rows: [] } as never);
  const report = await getDataQuality(Date.parse("2026-10-23T12:00:00Z"));
  expect(report.version).toBe(1);
  expect(report.pools).toBe(0);
  expect(report.fields).toHaveLength(12);
  expect(
    report.fields.every(
      (field) => field.coveragePct === null && field.missing === 0,
    ),
  ).toBe(true);
  expect(report.freshness.stalePct).toBeNull();
  expect(report.providers).toHaveLength(3);
  expect(
    report.providers.every(
      (p) => p.status === "unknown" && p.failedAuditEventPct === null,
    ),
  ).toBe(true);
  expect(report.cache.hitRatePct).toBeNull();
  expect(report.costs).toMatchObject({ status: "unknown", totalUsd: null });
  expect(
    report.requestBudgets.find((b) => b.channel === "solana"),
  ).toMatchObject({ used: 0, remaining: 30, limit: 30, windowSeconds: 60 });
});

it("maps real aggregate counts into denominators, field coverage, observed failed-audit runs and request limits", async () => {
  vi.spyOn(db, "query").mockImplementation((async (sql: string) => {
    if (sql.includes("quality:fields"))
      return { rows: [{ field: "priceUsd", total: 4, present: 3 }] };
    if (sql.includes("quality:freshness"))
      return { rows: [{ total: 4, current: 1, stale: 2, unknown: 1 }] };
    if (sql.includes("quality:providers"))
      return {
        rows: [
          {
            provider: "dex",
            status: "limited",
            audit_events: 8,
            failed_audit_events: 4,
            rate_limited_audit_events: 2,
            failed_audit_runs: 2,
            last_success: null,
            last_error: new Date("2026-10-23T11:59:00Z"),
            retry_at: new Date("2026-10-23T12:01:00Z"),
          },
        ],
      };
    if (sql.includes("quality:cache"))
      return {
        rows: [
          { name: "cache_requests", value: "10" },
          { name: "cache_hits", value: "8" },
          { name: "cache_stale_fallbacks", value: "2" },
        ],
      };
    if (sql.includes("quality:budgets"))
      return { rows: [{ channel: "gecko", used: 8 }] };
    throw new Error("Unexpected query");
  }) as never);
  const report = await getDataQuality(Date.parse("2026-10-23T12:00:00Z"));
  expect(report.fields.find((f) => f.field === "priceUsd")).toMatchObject({
    present: 3,
    missing: 1,
    total: 4,
    coveragePct: 75,
  });
  expect(report.freshness).toMatchObject({
    current: 1,
    stale: 2,
    unknown: 1,
    total: 4,
    stalePct: 50,
    unknownPct: 25,
  });
  expect(report.providers.find((p) => p.provider === "dex")).toMatchObject({
    status: "limited",
    auditEvents24h: 8,
    failedAuditEvents24h: 4,
    rateLimitedAuditEvents24h: 2,
    failedAuditEventPct: 50,
    failedAuditRuns24h: 2,
  });
  expect(report.cache.hitRatePct).toBe(80);
  expect(
    report.requestBudgets.find((b) => b.channel === "gecko"),
  ).toMatchObject({ used: 8, remaining: 0 });
  expect(report.costs.totalUsd).toBeNull();
  for (const provider of report.providers) {
    expect(provider).not.toHaveProperty("requests24h");
    expect(provider).not.toHaveProperty("failurePct");
  }
});
