import { it, expect } from "vitest";
import { shouldAlert } from "../../lib/alerts";
import { PendingUpdates } from "../../lib/sync";
it("suppresses an event that occurred in quiet hours even when processed after quiet hours", () => {
  const rule = {
    kind: "new_token" as const,
    enabled: true,
    threshold: 0,
    cooldownSeconds: 60,
    quotaPerHour: 10,
    quietStart: 22,
    quietEnd: 7,
    mint: null,
  };
  expect(
    shouldAlert(
      rule,
      {
        kind: "new_token",
        mint: "a",
        key: "a",
        value: 1,
        at: "2026-10-23T06:59:00Z",
      },
      [],
      new Date("2026-10-23T07:01:00Z"),
    ),
  ).toBe(false);
});
it("requeues failed pool IDs and combines notifications arriving during a fetch", () => {
  const pending = new PendingUpdates();
  pending.add({ ids: ["a"] });
  const taken = pending.take()!;
  pending.add({ ids: ["b"] });
  pending.failed(taken);
  expect(pending.take()?.ids.sort()).toEqual(["a", "b"]);
  expect(pending.take()).toBeNull();
  pending.add({ ids: ["a"] });
  pending.add({ resync: true });
  expect(pending.take()?.full).toBe(true);
});
