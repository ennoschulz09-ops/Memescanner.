import { it, expect } from "vitest";
import { num } from "../../lib/domain";
import { HttpClient } from "../../lib/providers/http";
import { SolanaProvider, concentration } from "../../lib/providers/solana";
import { DexProvider } from "../../lib/providers/dex";
import { rotatingBatch } from "../../worker/refresh";
it("treats whitespace and nondecimal numeric strings as missing", () => {
  expect(num("   ")).toBeNull();
  expect(num("0xff")).toBeNull();
  expect(num("1.2e-5")).toBe(0.000012);
});
it("marks RPC application errors as source failures, even with HTTP 200", async () => {
  const audits: { ok: boolean }[] = [];
  const http = new HttpClient(
    async () =>
      new Response(
        JSON.stringify({
          jsonrpc: "2.0",
          error: { code: -32005, message: "unavailable" },
        }),
      ),
    {
      audit: async (e) => {
        audits.push(e);
      },
    },
  );
  await expect(new SolanaProvider(http).health()).rejects.toThrow();
  expect(audits.at(-1)?.ok).toBe(false);
});
it("does not accept malformed signatures as successful wallet coverage", async () => {
  const audits: { ok: boolean }[] = [];
  const http = new HttpClient(
    async () =>
      new Response(JSON.stringify({ jsonrpc: "2.0", result: "wrong-shape" })),
    {
      audit: async (e) => {
        audits.push(e);
      },
    },
  );
  await expect(
    new SolanaProvider(http).rpc("getSignaturesForAddress", [
      "11111111111111111111111111111111",
    ]),
  ).rejects.toThrow();
  expect(audits.at(-1)?.ok).toBe(false);
});
it("marks structurally invalid market provider responses as failed", async () => {
  const audits: { ok: boolean }[] = [];
  const http = new HttpClient(async () => new Response('{"not":"an array"}'), {
    audit: async (e) => {
      audits.push(e);
    },
  });
  await expect(
    new DexProvider(http).tokens([
      "So11111111111111111111111111111111111111112",
    ]),
  ).rejects.toThrow();
  expect(audits.at(-1)?.ok).toBe(false);
});
it("never emits impossible concentration percentages as valid evidence", () => {
  expect(
    concentration(
      [{ address: "11111111111111111111111111111111", amount: "1500" }],
      "1000",
    ).top20Pct,
  ).toBeNull();
  expect(
    concentration(
      [
        { address: "11111111111111111111111111111111", amount: "50" },
        {
          address: "So11111111111111111111111111111111111111112",
          amount: "500",
        },
      ],
      "1000",
    ).top1Pct,
  ).toBe(50);
});
it("wraps refresh batches without starving older tokens", () => {
  const a = rotatingBatch([0, 1, 2, 3, 4], 3, 3);
  expect(a).toEqual({ items: [3, 4, 0], next: 1 });
  expect(rotatingBatch([], 3, 30)).toEqual({ items: [], next: 0 });
});
