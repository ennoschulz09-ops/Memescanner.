import { afterEach, describe, expect, it, vi } from "vitest";
import fc from "fast-check";
import { observation } from "../helpers";
import type { PoolRow, ChainEvidence } from "../../lib/domain";
import { scoreRisk, sourceConflicts } from "../../lib/risk";
import { withFieldEvidence } from "../../lib/value-evidence";
import * as wire from "../../lib/scanner-wire";
import { api } from "../../lib/client";

const now = Date.parse("2026-10-23T12:00:00.000Z");
function row(values: Parameters<typeof observation>[0] = {}): PoolRow {
  const original = observation(values);
  const obs = {
    ...original,
    normalizedAt: new Date(now).toISOString(),
    provenance: {
      ...original.provenance,
      cacheAgeSeconds: 1,
      fetchedAt: new Date(now).toISOString(),
      sourceAt: new Date(now - 1000).toISOString(),
    },
  };
  const alternate = {
    ...obs,
    priceUsd: obs.priceUsd === null ? null : obs.priceUsd * 2,
    provenance: { ...obs.provenance, provider: "dex" as const },
  };
  return {
    ...withFieldEvidence(obs, [obs, alternate], now),
    revision: "9007199254740999",
    activityIncreasePct: null,
    firstSeenAt: new Date(now - 60000).toISOString(),
    updatedAt: new Date(now).toISOString(),
    sources: [obs, alternate],
    risk: scoreRisk(obs, null, [obs, alternate], now),
    sparkline: [],
  };
}
afterEach(() => vi.unstubAllGlobals());

describe("compact scanner contract", () => {
  it("round-trips all displayed evidence and defers complete source observations explicitly", () => {
    const original = row({
      priceUsd: 0,
      liquidityUsd: null,
      volume5m: Number.MAX_VALUE,
      change5m: -99.999,
    });
    const page = {
      rows: [original],
      total: 1,
      page: 1,
      at: new Date(now).toISOString(),
    };
    const encoded = wire.packPoolPage(page);
    expect(encoded.format).toBe("nexus-pools/1");
    const decoded = wire.unpackPoolPage(JSON.parse(JSON.stringify(encoded)));
    expect(decoded).toMatchObject({ total: 1, page: 1, at: page.at });
    expect(decoded.rows[0]).toEqual({
      ...original,
      sources: [],
      sourceDetail: "deferred",
      sourceSummaries: original.sources.map((s) => s.provenance),
    });
    expect(decoded.rows[0].priceUsd).toBe(0);
    expect(decoded.rows[0].liquidityUsd).toBeNull();
    expect(decoded.rows[0].fieldEvidence?.liquidityUsd.missing).toBe(true);
    expect(wire.packPoolPage(decoded)).toEqual(encoded);
  });

  it("keeps field-specific conflicts and provenance overrides, without recomputing evidence", () => {
    const original = row({ priceUsd: 0.5 });
    original.fieldEvidence!.volume5m = {
      ...original.fieldEvidence!.volume5m,
      source: "solana",
      sourceTimestamp: "2026-10-23T11:00:00.000Z",
      conflicts: ["dex", "gecko"],
      freshness: "STALE",
      confidenceLevel: "unknown",
    };
    const decoded = wire.unpackPoolPage(
      JSON.parse(JSON.stringify(wire.packPoolPage({ rows: [original] }))),
    ).rows[0];
    expect(decoded.fieldEvidence).toEqual(original.fieldEvidence);
    expect(decoded.risk).toEqual(original.risk);
    expect(decoded.fieldEvidence?.priceUsd.conflicts).toEqual(["gecko", "dex"]);
  });

  it("reduces a representative 100 row payload with full sparklines below 200 kB raw", () => {
    const rows = Array.from({ length: 100 }, (_, i) => ({
      ...row({ id: `pool-${i}`, name: `Token ${i}`, liquidityUsd: i * 1.3e5 }),
      sparkline: Array.from({ length: 32 }, (_, sample) => ({
        at: new Date(now - sample * 60000).toISOString(),
        value: (sample + 1) / 1000,
      })),
    }));
    const fullBytes = Buffer.byteLength(JSON.stringify({ rows }));
    const compactBytes = Buffer.byteLength(
      JSON.stringify(wire.packPoolPage({ rows })),
    );
    expect(compactBytes).toBeLessThan(200000);
    expect(compactBytes / fullBytes).toBeLessThan(0.5);
  });

  it("automatically expands compact responses in the generic API client", async () => {
    const original = row();
    vi.stubGlobal(
      "fetch",
      async () =>
        new Response(
          JSON.stringify(wire.packPoolPage({ rows: [original], total: 1 })),
        ),
    );
    const result = await api<{ rows: PoolRow[]; total: number }>(
      "pools?format=compact",
    );
    expect(result.rows[0].risk).toEqual(original.risk);
    expect(result.rows[0].fieldEvidence).toEqual(original.fieldEvidence);
    expect(result.total).toBe(1);
  });

  it("preserves null, zero, extreme finite values and risk semantics across generated DTO round-trips", () => {
    const value = fc.option(
      fc.double({
        noNaN: true,
        noDefaultInfinity: true,
        min: 0,
        max: Number.MAX_VALUE,
      }),
      { nil: null },
    );
    fc.assert(
      fc.property(
        value,
        value,
        fc.double({ noNaN: true, noDefaultInfinity: true }),
        (priceUsd, liquidityUsd, change5m) => {
          // Values have already crossed JSON on the real API; JSON canonicalizes -0 to 0.
          const original = row(
            JSON.parse(JSON.stringify({ priceUsd, liquidityUsd, change5m })),
          );
          const result = wire.unpackPoolPage(
            JSON.parse(JSON.stringify(wire.packPoolPage({ rows: [original] }))),
          ).rows[0];
          expect(result.priceUsd).toBe(original.priceUsd);
          expect(result.liquidityUsd).toBe(original.liquidityUsd);
          expect(result.change5m).toBe(original.change5m);
          expect(result.fieldEvidence).toEqual(original.fieldEvidence);
          expect(result.risk).toEqual(original.risk);
        },
      ),
      { numRuns: 150, seed: 20261023 },
    );
  });
});

describe("versioned conservative risk model", () => {
  it("versions every report including wholly unknown evidence", () => {
    const obs = row();
    expect(obs.risk.modelVersion).toBe("nexus-risk/3");
    expect(obs.risk.overall).toBeNull();
    expect(obs.risk.state).not.toBe("observed");
  });

  it("does not count a zero supply or failed/future chain check as verified controls", () => {
    const obs = row({ liquidityUsd: 1000000, volume5m: 10 });
    const evidence: ChainEvidence = {
      controls: {
        mintAuthority: null,
        freezeAuthority: null,
        supply: "0",
        decimals: 9,
        slot: 1,
        program: "spl-token",
        extensions: [],
      },
      concentration: {
        top1Pct: 0,
        top20Pct: 0,
        scope: "token-accounts",
        accounts: [],
      },
      checkedAt: new Date(now).toISOString(),
      slot: 1,
      error: null,
    };
    for (const e of [
      evidence,
      {
        ...evidence,
        controls: { ...evidence.controls!, supply: "100" },
        error: "incomplete RPC",
      },
      {
        ...evidence,
        controls: { ...evidence.controls!, supply: "100" },
        checkedAt: new Date(now + 120000).toISOString(),
      },
    ]) {
      const risk = scoreRisk(obs, e, obs.sources, now);
      expect(risk.overall).toBeNull();
      expect(risk.signals.find((s) => s.key === "contract")?.state).toBe(
        "unknown",
      );
    }
  });

  it("detects depeg/zero-liquidity disagreements and bounds extreme conflicts", () => {
    const obs = row({ priceUsd: 0.01, liquidityUsd: 0, fdvUsd: 0 });
    const alternate = {
      ...obs,
      priceUsd: 1,
      liquidityUsd: Number.MAX_VALUE,
      fdvUsd: Number.MAX_VALUE,
      provenance: { ...obs.provenance, provider: "dex" as const },
    };
    const conflicts = sourceConflicts([obs, alternate]);
    expect(conflicts.map((c) => c.field)).toEqual([
      "priceUsd",
      "fdvUsd",
      "liquidityUsd",
    ]);
    expect(conflicts.every((c) => Number.isFinite(c.differencePct))).toBe(true);
    const risk = scoreRisk(obs, null, [obs, alternate], now);
    expect(risk.signals.find((s) => s.key === "liquidity")?.state).toBe(
      "critical",
    );
    expect(risk.signals.find((s) => s.key === "activity")?.state).toBe(
      "unknown",
    );
    expect(risk.overall).toBeNull();
  });
});

it("never turns invalid numbers or stale/retrieval-only evidence into a low overall score", () => {
  const original = row({ liquidityUsd: 1000000, volume5m: 1 });
  const evidence: ChainEvidence = {
    controls: {
      mintAuthority: null,
      freezeAuthority: null,
      supply: "100",
      decimals: 9,
      slot: 1,
      program: "spl-token",
      extensions: [],
    },
    concentration: {
      top1Pct: 0,
      top20Pct: 0,
      scope: "token-accounts",
      accounts: [],
    },
    checkedAt: new Date(now).toISOString(),
    slot: 1,
    error: null,
  };
  expect(scoreRisk(original, evidence, [original], now).overall).not.toBeNull();
  for (const obs of [
    { ...original, liquidityUsd: Number.NaN },
    { ...original, volume5m: Infinity },
    {
      ...original,
      provenance: {
        ...original.provenance,
        sourceAt: new Date(now - 300000).toISOString(),
      },
    },
    {
      ...original,
      provenance: {
        ...original.provenance,
        timestampKind: "retrieval-only" as const,
      },
    },
  ]) {
    expect(scoreRisk(obs, evidence, [obs], now).overall).toBeNull();
    expect(scoreRisk(obs, evidence, [obs], now).state).not.toBe("observed");
  }
  expect(
    withFieldEvidence({ ...original, liquidityUsd: NaN }, [original], now)
      .fieldEvidence?.liquidityUsd.missing,
  ).toBe(true);
});

it("uses a bounded, finite relative source difference even at underflow/overflow extremes", () => {
  const a = observation({ priceUsd: Number.MIN_VALUE });
  const b = {
    ...a,
    priceUsd: Number.MAX_VALUE,
    provenance: { ...a.provenance, provider: "dex" as const },
  };
  expect(
    sourceConflicts([a, b]).find((c) => c.field === "priceUsd")?.differencePct,
  ).toBe(100);
  fc.assert(
    fc.property(
      fc.double({
        min: 0,
        max: Number.MAX_VALUE,
        noNaN: true,
        noDefaultInfinity: true,
      }),
      fc.double({
        min: 0,
        max: Number.MAX_VALUE,
        noNaN: true,
        noDefaultInfinity: true,
      }),
      (x, y) => {
        const conflicts = sourceConflicts([
          { ...a, priceUsd: x },
          { ...b, priceUsd: y },
        ]);
        for (const conflict of conflicts) {
          expect(conflict.differencePct).toBeGreaterThan(0);
          expect(conflict.differencePct).toBeLessThanOrEqual(100);
        }
      },
    ),
    { numRuns: 100, seed: 20261023 },
  );
});
