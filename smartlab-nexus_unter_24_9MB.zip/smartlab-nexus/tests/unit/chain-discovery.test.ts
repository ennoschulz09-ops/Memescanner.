import { it, expect } from "vitest";
import { SolanaProvider } from "../../lib/providers/solana";
import { HttpClient } from "../../lib/providers/http";
import bs58 from "bs58";
import { createHash } from "node:crypto";
import {
  CPMM_PROGRAM,
  decodePoolInitializations,
  isOwnInitializeLog,
} from "../../lib/providers/pool-init";
const address = (n: number) => bs58.encode(Buffer.alloc(32, n));
it("blocks write and signing RPC methods before any network request", async () => {
  let calls = 0;
  const provider = new SolanaProvider(
    new HttpClient(async () => {
      calls++;
      return new Response("{}");
    }),
  );
  for (const method of [
    "sendTransaction",
    "sendRawTransaction",
    "signTransaction",
    "requestAirdrop",
  ])
    await expect(provider.rpc(method)).rejects.toThrow("nicht freigegeben");
  expect(calls).toBe(0);
});
const accounts = Array.from({ length: 20 }, (_, i) => address(i + 1));
const data = bs58.encode(
  Buffer.concat([
    createHash("sha256").update("global:initialize").digest().subarray(0, 8),
    Buffer.alloc(24),
  ]),
);
it("passes a transaction object through the RPC adapter into the pool decoder and accepts pending null", async () => {
  const tx = {
    slot: 123,
    blockTime: 1780000000,
    meta: { err: null, innerInstructions: [] },
    transaction: {
      message: { instructions: [{ programId: CPMM_PROGRAM, accounts, data }] },
    },
  };
  const provider = new SolanaProvider(
    new HttpClient(
      async () => new Response(JSON.stringify({ jsonrpc: "2.0", result: tx })),
    ),
  );
  const result = await provider.rpc("getTransaction", [
    "test",
    { encoding: "jsonParsed" },
  ]);
  expect(decodePoolInitializations(result)).toMatchObject([
    { poolAddress: accounts[3], mints: [accounts[4], accounts[5]] },
  ]);
  const pending = new SolanaProvider(
    new HttpClient(
      async () =>
        new Response(JSON.stringify({ jsonrpc: "2.0", result: null })),
    ),
  );
  await expect(pending.rpc("getTransaction", ["test"])).resolves.toBeNull();
});
it("decodes only the documented CPMM initialize discriminator and validated account positions", () => {
  const tx = {
    slot: 123,
    blockTime: Math.floor(Date.now() / 1000) - 1,
    meta: { err: null },
    transaction: {
      message: { instructions: [{ programId: CPMM_PROGRAM, accounts, data }] },
    },
  };
  const decoded = decodePoolInitializations(tx);
  expect(decoded).toHaveLength(1);
  expect(decoded[0].poolAddress).toBe(accounts[3]);
  expect(decoded[0].mints).toEqual([accounts[4], accounts[5]]);
  expect(
    decodePoolInitializations({ ...tx, meta: { err: { failed: true } } }),
  ).toEqual([]);
  expect(
    decodePoolInitializations({
      ...tx,
      transaction: {
        message: { instructions: [{ programId: address(30), accounts, data }] },
      },
    }),
  ).toEqual([]);
  expect(
    decodePoolInitializations({
      ...tx,
      transaction: {
        message: {
          instructions: [
            {
              programId: CPMM_PROGRAM,
              accounts,
              data: bs58.encode(Buffer.alloc(32)),
            },
          ],
        },
      },
    }),
  ).toEqual([]);
});
it("ignores inner token initialization logs and failed program invocations", () => {
  expect(
    isOwnInitializeLog([
      `Program ${CPMM_PROGRAM} invoke [1]`,
      `Program ${address(1)} invoke [2]`,
      "Program log: Instruction: Initialize",
      `Program ${address(1)} success`,
    ]),
  ).toBe(false);
  expect(
    isOwnInitializeLog([
      `Program ${CPMM_PROGRAM} invoke [1]`,
      "Program log: Instruction: Initialize",
    ]),
  ).toBe(true);
});
it("records the decoder version and rejects truncated official initialize accounts", () => {
  const tx = {
    slot: 123,
    blockTime: 0,
    meta: { err: null },
    transaction: {
      message: { instructions: [{ programId: CPMM_PROGRAM, accounts, data }] },
    },
  };
  expect(decodePoolInitializations(tx)[0]).toMatchObject({
    decoderVersion: "raydium-cpmm-initialize-v1",
    eventAt: "1970-01-01T00:00:00.000Z",
  });
  expect(
    decodePoolInitializations({
      ...tx,
      transaction: {
        message: {
          instructions: [
            { programId: CPMM_PROGRAM, accounts: accounts.slice(0, 6), data },
          ],
        },
      },
    }),
  ).toEqual([]);
});
it("preserves the actionable RPC code instead of classifying unsupported versions as schema errors", async () => {
  const provider = new SolanaProvider(
    new HttpClient(
      async () =>
        new Response(
          JSON.stringify({ error: { code: -32015, message: "unsupported" } }),
        ),
    ),
  );
  await expect(provider.rpc("getTransaction")).rejects.toMatchObject({
    rpcCode: -32015,
    reason: "unsupported_transaction_version",
    permanent: true,
  });
});
