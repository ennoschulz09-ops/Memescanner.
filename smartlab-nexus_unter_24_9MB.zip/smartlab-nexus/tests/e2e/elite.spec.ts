import { test, expect } from "@playwright/test";
test("command workspace exposes real pipeline and quality drilldowns", async ({
  page,
}) => {
  await page.goto("/?view=command");
  await expect(
    page.getByRole("heading", { name: "Command Dashboard", exact: true }),
  ).toBeVisible();
  await expect(page.getByTestId("pipeline-summary")).toBeVisible();
  await page.getByRole("button", { name: "Datenqualität öffnen" }).click();
  await expect(
    page.getByRole("heading", { name: "Datenqualität", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("Feldabdeckung", { exact: true })).toBeVisible();
  await expect(
    page.getByText("API-Kosten unbekannt", { exact: true }),
  ).toBeVisible();
});
test("researcher can freeze live updates and explicitly resynchronize", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const pause = page.getByRole("button", {
    name: "Live-Updates pausieren",
    exact: true,
  });
  await pause.click();
  await expect(
    page.getByRole("button", { name: "Live-Updates fortsetzen", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByTestId("frozen-banner")).toBeVisible();
  const refreshed = page.waitForResponse(
    (r) =>
      r.url().includes("/api/pools?") &&
      r.request().method() === "GET" &&
      r.ok(),
  );
  await page
    .getByRole("button", { name: "Live-Updates fortsetzen", exact: true })
    .click();
  await refreshed;
  await expect(pause).toHaveAttribute("aria-pressed", "false");
  await expect(page.getByTestId("frozen-banner")).toHaveCount(0);
});
test("mobile research navigation and intelligence sheet preserve keyboard focus", async ({
  page,
}) => {
  test.skip((page.viewportSize()?.width ?? 1000) > 800, "Mobile interaction");
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const bottom = page.getByRole("navigation", {
    name: "Mobile Research-Navigation",
  });
  await expect(bottom).toBeVisible();
  const row = page.getByTestId("pool-row").first();
  await row.click();
  const sheet = page.getByRole("dialog", { name: "Token-Schnellanalyse" });
  await expect(sheet).toBeVisible();
  await expect(
    sheet.getByRole("button", { name: "Vollständige Analyse" }),
  ).toBeVisible();
  await page.keyboard.press("Control+k");
  await expect(
    sheet.getByRole("button", { name: "Analyse schließen", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(sheet).toHaveCount(0);
  await expect(row).toBeFocused();
});

test("mobile radar keeps cards and navigation inside the viewport", async ({
  page,
}) => {
  test.skip((page.viewportSize()?.width ?? 1000) > 600, "Mobile cards");
  await page.goto("/");
  const row = page.getByTestId("pool-row").first();
  await row.waitFor();
  await row.scrollIntoViewIfNeeded();
  await expect
    .poll(() =>
      page.evaluate(
        () =>
          document.documentElement.scrollWidth -
          document.documentElement.clientWidth,
      ),
    )
    .toBeLessThanOrEqual(1);
  await expect(row.locator('[data-market-value="liquidityUsd"]')).toBeVisible();
  await expect(row.getByRole("button", { name: /Watchlist/ })).toBeInViewport();
});

test("freezing also discards a page response already in flight", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  let release!: () => void;
  let captured!: () => void;
  const pending = new Promise<void>((resolve) => {
    captured = resolve;
  });
  await page.route("**/api/pools?**", async (route) => {
    captured();
    await new Promise<void>((resolve) => {
      release = resolve;
    });
    await route.fulfill({
      json: { rows: [], total: 0, page: 1, pageSize: 100 },
    });
  });
  await page.getByLabel("Scanner-Sortierung").selectOption("liquidityUsd:desc");
  await pending;
  const row = page.getByTestId("pool-row").first();
  const id = await row.getAttribute("data-pool-id");
  await page
    .getByRole("button", { name: "Live-Updates pausieren", exact: true })
    .click();
  const response = page.waitForResponse(
    (r) => r.url().includes("/api/pools?") && r.request().method() === "GET",
  );
  release();
  await response;
  await page.evaluate(
    () =>
      new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      ),
  );
  await expect(row).toHaveAttribute("data-pool-id", id!);
  await expect(page.getByTestId("frozen-banner")).toBeVisible();
});

test("command excludes retrieval-only observations from its fresh share", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const data = await (
    await page.request.get("/api/pools?page=1&pageSize=1")
  ).json();
  const row = data.rows[0];
  row.provenance = {
    ...row.provenance,
    timestampKind: "retrieval-only",
    sourceAt: new Date().toISOString(),
  };
  await page.route("**/api/pools?**", (route) =>
    route.fulfill({ json: { rows: [row], total: 1, page: 1, pageSize: 100 } }),
  );
  const health = await (await page.request.get("/api/health")).json();
  await page.route("**/api/health", (route) =>
    route.fulfill({
      json: { ...health, counts: { ...health.counts, pools: 1, stale: 0 } },
    }),
  );
  await page.goto("/?view=command");
  await expect(
    page.locator(".signal-stats > div").first().locator("strong"),
  ).toHaveText("0.0 %");
});
