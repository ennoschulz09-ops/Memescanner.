import { test, expect } from "@playwright/test";
test("command blotter opens a full analysis and remains inside every viewport", async ({
  page,
}) => {
  await page.goto("/?view=command");
  const row = page.locator(".blotter-row").first();
  await expect(row).toBeVisible();
  await expect(page.locator(".blotter-row")).toHaveCount(6);
  expect(
    await page.evaluate(
      () =>
        document.documentElement.scrollWidth -
        document.documentElement.clientWidth,
    ),
  ).toBeLessThanOrEqual(1);
  await row.click();
  await expect(
    page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("Datenherkunft", { exact: true })).toBeVisible();
  const chart = page.locator('.time-chart svg[tabindex="0"]').first();
  if (await chart.count()) {
    await chart.focus();
    await page.keyboard.press("Home");
    await expect(chart).toBeFocused();
    await page.keyboard.press("ArrowRight");
    await expect(page.getByText(/Lücken bleiben offen/).first()).toBeVisible();
  }
});
test("mobile uses a smaller genuine server page while retaining pagination", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const size = (page.viewportSize()?.width ?? 1000) <= 800 ? 25 : 100;
  await expect
    .poll(() =>
      page.evaluate(() =>
        performance
          .getEntriesByType("resource")
          .map((e) => e.name)
          .some(
            (n) =>
              n.includes("/api/pools?") &&
              n.includes("pageSize=" + String(innerWidth <= 800 ? 25 : 100)),
          ),
      ),
    )
    .toBe(true);
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  expect(size).toBeGreaterThan(0);
});

test("correlates the same pending event through decoded DOM without claiming a new mint", async ({
  page,
}) => {
  const eventId = "3".repeat(88),
    stages: string[] = [];
  let decoded = false;
  await page.route("**/api/discoveries", (route) =>
    route.fulfill({
      json: {
        tokens: [],
        publishedAt: new Date().toISOString(),
        chainEvents: [
          {
            eventId,
            slot: 123,
            status: decoded ? "decoded" : "pending",
            observedAt: new Date().toISOString(),
            eventAt: null,
            committedAt: null,
            reason: null,
            pools: decoded
              ? [
                  {
                    poolAddress: "So11111111111111111111111111111111111111112",
                    mints: [
                      "So11111111111111111111111111111111111111112",
                      "11111111111111111111111111111111",
                    ],
                  },
                ]
              : [],
          },
        ],
      },
    }),
  );
  await page.route("**/api/chain-receipts", (route) => {
    stages.push(route.request().postDataJSON().stage);
    return route.fulfill({ json: { ok: true } });
  });
  await page.goto("/?view=discovery");
  const card = page.locator("[data-chain-event]").first();
  await card.scrollIntoViewIfNeeded();
  await expect(card).toContainText("PENDING / UNKNOWN");
  // A fresh feed envelope after scrolling is visible and may produce a receipt.
  await page.evaluate(() => window.dispatchEvent(new Event("nexus-discovery")));
  await expect.poll(() => stages.includes("candidate")).toBe(true);
  decoded = true;
  await page.evaluate(() => window.dispatchEvent(new Event("nexus-discovery")));
  await expect(card).toHaveAttribute("data-chain-status", "decoded");
  await expect(card).toContainText("kein Nachweis neuer Mints");
  await expect(page.locator("[data-chain-event]")).toHaveCount(1);
  await expect.poll(() => stages.includes("decoded")).toBe(true);
});
