import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";

for (const [view, heading] of [
  ["scanner", "Live Scanner"],
  ["command", /Command/],
  ["watchlists", "Watchlists"],
  ["health", "System Health"],
  ["quality", "Datenqualität"],
  ["discovery", "Discovery"],
  ["risk", "Risk Lab"],
  ["wallet", "Wallet Explorer"],
  ["alerts", "Alerts"],
  ["analytics", "Analytics"],
  ["settings", "Einstellungen"],
] as const) {
  test(`${view} exposes labels, landmarks and sufficient text contrast`, async ({
    page,
  }, info) => {
    await page.goto(view === "scanner" ? "/" : `/?view=${view}`);
    await expect(page.getByRole("main")).toBeVisible();
    await expect(
      page.getByRole("heading", {
        name: heading,
        exact: typeof heading === "string",
      }),
    ).toBeVisible();
    if (view === "scanner")
      await page.getByTestId("pool-row").first().waitFor();
    if (view === "quality")
      await expect(
        page.getByText("Feldabdeckung", { exact: true }),
      ).toBeVisible();
    const report = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    await info.attach(`axe-${view}`, {
      body: JSON.stringify(report, null, 2),
      contentType: "application/json",
    });
    expect(
      report.violations.map(({ id, nodes }) => ({
        id,
        targets: nodes.map(({ target }) => target),
      })),
      view,
    ).toEqual([]);
  });
}

test("token intelligence exposes labels, landmarks and sufficient text contrast", async ({
  page,
}, info) => {
  const response = await page.request.get("/api/pools?page=1&pageSize=1");
  expect(response.ok()).toBe(true);
  const { rows } = await response.json();
  expect(rows).toHaveLength(1);
  const chosen = rows[0];
  await Promise.all([
    page.waitForResponse(
      (result) =>
        result.url().includes(`/api/candles/${chosen.poolId}/`) && result.ok(),
    ),
    page.goto(
      "/?" +
        new URLSearchParams({
          view: "token",
          mint: chosen.mint,
          pool: chosen.poolId,
        }),
    ),
  ]);
  await expect(
    page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  ).toBeVisible();
  await expect(page.locator(".detail-token h2")).toHaveText(chosen.name);
  const report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  await info.attach("axe-token-intelligence", {
    body: JSON.stringify(report, null, 2),
    contentType: "application/json",
  });
  expect(
    report.violations.map(({ id, nodes }) => ({
      id,
      targets: nodes.map(({ target }) => target),
    })),
  ).toEqual([]);
});

test("scanner filters support keyboard focus, Escape and reduced motion", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  if (process.env.NEXUS_TEST_MODE === "true")
    await expect(page.getByTestId("test-mode-banner")).toBeVisible();
  const trigger = page.getByRole("button", { name: "Filter", exact: true });
  await trigger.focus();
  await page.keyboard.press("Enter");
  const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  await expect(dialog).toBeVisible();
  await expect(dialog.locator(":focus")).toHaveCount(1);
  await page.keyboard.press("Tab");
  expect(
    await page.evaluate(
      () => document.activeElement?.closest('[role="dialog"]') !== null,
    ),
  ).toBe(true);
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(trigger).toBeFocused();
  expect(
    await page.evaluate(
      () => matchMedia("(prefers-reduced-motion: reduce)").matches,
    ),
  ).toBe(true);
});

test("mobile research controls meet WCAG 2.2 minimum target size", async ({
  page,
}, info) => {
  test.skip(
    info.project.name !== "mobile",
    "Touch target check uses the mobile project viewport.",
  );
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  await expect(
    page.getByRole("button", { name: "Navigation öffnen", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("navigation", { name: "Mobile Research-Navigation" }),
  ).toBeVisible();
  const targets: {
    name: string | null | undefined;
    width: number;
    height: number;
    stage: string;
  }[] = [];
  const sample = async (stage: string) =>
    targets.push(
      ...(
        await page
          .locator('button,a[href],input,select,summary,[role="button"]')
          .evaluateAll((nodes) =>
            nodes.flatMap((node) => {
              const element = node as HTMLElement;
              const rect = element.getBoundingClientRect();
              const style = getComputedStyle(element);
              // Offscreen/hidden/disabled elements are not available pointer targets.
              if (
                !rect.width ||
                !rect.height ||
                rect.right <= 0 ||
                rect.left >= innerWidth ||
                rect.bottom <= 0 ||
                rect.top >= innerHeight ||
                style.visibility === "hidden" ||
                element.matches(":disabled")
              )
                return [];
              return [
                {
                  name:
                    element.getAttribute("aria-label") ||
                    element.textContent?.trim().slice(0, 80),
                  width: rect.width,
                  height: rect.height,
                },
              ];
            }),
          )
      ).map((target) => ({ ...target, stage })),
    );
  await sample("page-top");
  const trigger = page.getByRole("button", { name: "Filter", exact: true });
  await trigger.scrollIntoViewIfNeeded();
  await expect(
    page.getByLabel("Scanner-Sortierung", { exact: true }),
  ).toBeVisible();
  await sample("scanner-toolbar");
  await page.getByTestId("pool-row").first().scrollIntoViewIfNeeded();
  await sample("scanner-rows");
  await trigger.click();
  await expect(
    page.getByRole("dialog", { name: "Scanner-Filter" }),
  ).toBeVisible();
  await sample("filter-dialog");
  await info.attach("touch-targets", {
    body: JSON.stringify(targets, null, 2),
    contentType: "application/json",
  });
  expect(targets.some((target) => target.name === "Navigation öffnen")).toBe(
    true,
  );
  expect(targets.some((target) => target.name === "Scanner-Sortierung")).toBe(
    true,
  );
  // 24 CSS px is the WCAG 2.2 AA size route; no spacing exception is claimed.
  expect(
    targets.filter((target) => target.width < 24 || target.height < 24),
  ).toEqual([]);
});
