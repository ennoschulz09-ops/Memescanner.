import { test, expect } from "@playwright/test";
test("has no browser runtime or hydration errors", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  expect(errors).toEqual([]);
});
test("scanner shows real provenance, opens analysis and persists a watchlist", async ({
  page,
}, info) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Live Scanner", exact: true }),
  ).toBeVisible();
  await expect(page.getByTestId("pool-row").first()).toBeVisible({
    timeout: 20000,
  });
  const row = page.getByTestId("pool-row").first();
  await expect(row).toContainText(/HTTP|Abruf|Cache/);
  await row.getByRole("button", { name: /Zur Watchlist/ }).click();
  await page.reload();
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  if (info.project.name === "mobile")
    await page.getByRole("button", { name: "Navigation öffnen" }).click();
  await page
    .getByRole("button", { name: "Watchlists", exact: true })
    .first()
    .click();
  await expect(
    page.getByRole("heading", { name: "Watchlists", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Meine Watchlist", { exact: true }).last(),
  ).toBeVisible();
  await page
    .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
    .fill("no-watchlist-match-92371");
  await expect(
    page.getByText("Keine Treffer in dieser Watchlist"),
  ).toBeVisible();
  await expect(page.getByTestId("watchlist-token")).toHaveCount(0);
  await page
    .getByPlaceholder("Name, Symbol oder Mint in dieser Liste")
    .fill("");
  await page.getByTestId("watchlist-token").first().click();
  await expect(
    page.getByRole("heading", { name: "Token-Analyse", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("Datenherkunft", { exact: true })).toBeVisible();
});
test("filters, column selection and empty states work", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  await page
    .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
    .fill("unfindable-token-xyz-293");
  await expect(page.getByText("Keine passenden Pools")).toBeVisible();
  await page
    .getByRole("main")
    .getByRole("button", { name: "Suche zurücksetzen" })
    .click();
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  await page.locator('summary[aria-label="Spalten auswählen"]').click();
  await page.getByLabel("FDV", { exact: true }).check();
  await expect(
    page.getByRole("columnheader", { name: "FDV", exact: true }),
  ).toHaveCount(1);
  await page.getByLabel("FDV", { exact: true }).uncheck();
  await page.locator('summary[aria-label="Spalten auswählen"]').click();
  await expect(
    page.getByRole("columnheader", { name: "FDV", exact: true }),
  ).toHaveCount(0);
});
test("all research views render and fit their viewport", async ({
  page,
}, info) => {
  for (const [view, heading] of [
    ["discovery", "Discovery"],
    ["risk", "Risk Lab"],
    ["wallet", "Wallet Explorer"],
    ["watchlists", "Watchlists"],
    ["alerts", "Alerts"],
    ["analytics", "Analytics"],
    ["health", "System Health"],
    ["settings", "Einstellungen"],
  ]) {
    await page.goto("/?view=" + view);
    await expect(
      page.getByRole("heading", { name: heading, exact: true }),
    ).toBeVisible();
    await expect(page.getByTestId("virtual-table")).toHaveCount(0);
    if (info.project.name === "mobile")
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        view,
      ).toBe(true);
  }
});
test("saves a filter preset and persists a compact terminal preference", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  await page.getByRole("button", { name: "Filter", exact: true }).click();
  await page.getByLabel("Min. Liquidität (USD)", { exact: true }).fill("100");
  await page.getByRole("button", { name: "Als Preset speichern" }).click();
  await page
    .getByRole("textbox", { name: "Preset-Name" })
    .fill("Mein Recherchefilter");
  await page.getByRole("button", { name: "Speichern", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Mein Recherchefilter", exact: true }),
  ).toBeVisible();
  await page.goto("/?view=settings");
  await expect(
    page.getByRole("switch", { name: "Kompakte Tabelle" }),
  ).toBeVisible();
  await page.getByRole("switch", { name: "Kompakte Tabelle" }).click();
  await page.getByRole("button", { name: "Einstellungen speichern" }).click();
  await expect(
    page.getByRole("button", { name: "Gespeichert", exact: true }),
  ).toBeVisible();
  await page.goto("/");
  await expect(page.getByTestId("pool-row").first()).toBeVisible();
  const persisted = await (await page.request.get("/api/session")).json();
  expect(persisted.settings.compact).toBe(true);
  expect(
    await page
      .getByTestId("pool-row")
      .first()
      .evaluate((e) => e.getBoundingClientRect().height),
  ).toBe((page.viewportSize()?.width ?? 1000) <= 600 ? 128 : 56);
});
test("creates, pauses and removes an in-app alert rule", async ({ page }) => {
  await page.goto("/?view=alerts");
  await page.getByRole("button", { name: "Neue Alert-Regel" }).click();
  await page
    .getByLabel("Name", { exact: true })
    .fill("E2E Liquiditätsbeobachtung");
  await page.getByRole("button", { name: "Regel speichern" }).click();
  const toggle = page.getByRole("switch", {
    name: "E2E Liquiditätsbeobachtung aktiv",
  });
  await expect(toggle).toBeChecked();
  await toggle.click();
  await expect(toggle).not.toBeChecked();
  await page
    .locator(".alert-rule")
    .filter({ hasText: "E2E Liquiditätsbeobachtung" })
    .getByRole("button", { name: "Entfernen" })
    .click();
  await expect(toggle).toHaveCount(0);
});
test("database and provider failures produce an explicit error state", async ({
  page,
}) => {
  await page.route("**/api/pools**", (route) =>
    route.fulfill({
      status: 503,
      contentType: "application/json",
      body: JSON.stringify({
        error: "Datenbank nicht verfügbar.",
        mode: "offline",
      }),
    }),
  );
  await page.goto("/");
  await expect(
    page.getByRole("alert").filter({ hasText: "Datenbank nicht verfügbar." }),
  ).toBeVisible();
  await expect(page.getByTestId("pool-row")).toHaveCount(0);
});
test("wallet validation is local and mobile layout has no page overflow", async ({
  page,
}, info) => {
  await page.goto("/?view=wallet");
  await expect(
    page.getByRole("heading", { name: "Wallet Explorer", exact: true }),
  ).toBeVisible();
  await page.getByLabel("Öffentliche Solana-Adresse").fill("invalid");
  await page.getByRole("button", { name: "Adresse analysieren" }).click();
  await expect(
    page.getByText("Bitte eine gültige öffentliche Solana-Adresse eingeben."),
  ).toBeVisible();
  if (info.project.name === "mobile")
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
    ).toBe(true);
});
