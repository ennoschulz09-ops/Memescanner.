import { test, expect } from "@playwright/test";
test("retries a failed delta fetch without needing another scanner event", async ({
  page,
}) => {
  const rows = (await (await page.request.get("/api/pools")).json()).rows;
  const chosen = rows[0],
    updated = {
      ...chosen,
      priceUsd: 123.456,
      revision: String(BigInt(chosen.revision ?? "1") + 1n),
      updatedAt: new Date().toISOString(),
    };
  let attempts = 0,
    streams = 0;
  await page.route("**/api/stream", (r) =>
    r.fulfill({
      contentType: "text/event-stream",
      body:
        ++streams === 1
          ? 'event: status\ndata: {"transport":"connected"}\n\nevent: update\ndata: ' +
            JSON.stringify({ ids: [chosen.id], at: new Date().toISOString() }) +
            "\n\n"
          : 'event: status\ndata: {"transport":"connected"}\n\n',
    }),
  );
  await page.route("**/api/pools/query*", (r) =>
    ++attempts === 1
      ? r.fulfill({
          status: 503,
          contentType: "application/json",
          body: '{"error":"Temporärer Deltafehler"}',
        })
      : r.fulfill({
          contentType: "application/json",
          body: JSON.stringify({ rows: [updated] }),
        }),
  );
  await page.goto("/");
  await page
    .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
    .fill(chosen.mint);
  await expect(
    page.getByTestId("pool-row").getByText("$123.456", { exact: true }),
  ).toBeVisible({ timeout: 15000 });
  expect(attempts).toBeGreaterThanOrEqual(2);
});
test("a delayed token response cannot replace the currently selected mint analysis", async ({
  page,
}) => {
  const rows = (await (await page.request.get("/api/pools")).json()).rows,
    a = rows[0],
    b = rows.find((r: any) => r.mint !== a.mint && r.name !== a.name);
  const da = await (
      await page.request.get("/api/tokens/" + a.mint + "?pool=" + a.poolId)
    ).json(),
    db = await (
      await page.request.get("/api/tokens/" + b.mint + "?pool=" + b.poolId)
    ).json();
  await page.request.patch("/api/settings", {
    headers: { origin: "http://localhost:3000" },
    data: { recentMints: [a.mint, b.mint] },
  });
  let release!: () => void;
  const held = new Promise<void>((r) => {
    release = r;
  });
  let requested!: () => void;
  const started = new Promise<void>((r) => {
    requested = r;
  });
  await page.route("**/api/candles/**", (r) =>
    r.fulfill({ contentType: "application/json", body: '{"candles":[]}' }),
  );
  await page.route("**/api/tokens/**", async (route) => {
    const mint = new URL(route.request().url()).pathname.split("/")[3];
    if (mint === a.mint) {
      requested();
      await held;
      return route.fulfill({
        contentType: "application/json",
        body: JSON.stringify(da),
      });
    }
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify(db),
    });
  });
  await page.goto("/?view=token&mint=" + a.mint + "&pool=" + a.poolId);
  await started;
  if (test.info().project.name === "mobile")
    await page.getByRole("button", { name: "Navigation öffnen" }).click();
  const button = page
    .locator(`.sidebar-recents button[data-mint="${b.mint}"]`)
    .first();
  await button.click();
  await expect(page.locator(".detail-token h2")).toHaveText(b.name);
  const response = page.waitForResponse((r) =>
    r.url().includes("/api/tokens/" + a.mint),
  );
  release();
  await response;
  await expect(page.locator(".detail-token h2")).toHaveText(b.name);
});
