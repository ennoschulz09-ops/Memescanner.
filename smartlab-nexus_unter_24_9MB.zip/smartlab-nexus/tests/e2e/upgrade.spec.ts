import { test, expect } from "@playwright/test";
test("uses bounded server pages and finds a mint beyond the current page", async ({
  page,
}) => {
  const a = await (
    await page.request.get("/api/pools?page=1&pageSize=2")
  ).json();
  expect(a.rows.length).toBeLessThanOrEqual(2);
  expect(a.total).toBeGreaterThan(2);
  const b = await (
    await page.request.get("/api/pools?page=2&pageSize=2")
  ).json();
  expect(b.rows.length).toBe(2);
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  await expect(page.getByLabel("Nächste Scanner-Seite")).toBeEnabled();
  await page.getByLabel("Nächste Scanner-Seite").click();
  await expect(page.getByText(/Seite 2 \/ /)).toBeVisible();
  await page
    .getByPlaceholder("Token, Symbol oder Mint-Adresse suchen")
    .fill(a.rows[0].mint);
  await expect(page.getByTestId("pool-row").first()).toContainText(
    a.rows[0].symbol,
  );
  await expect(page.getByText(/Seite 1 \/ /)).toBeVisible();
});
test("all visible scalar market markers expose source, freshness and explanation", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const evidence = await page
    .locator("[data-market-value]")
    .evaluateAll((nodes) =>
      nodes
        .filter((n) => n.getBoundingClientRect().width > 0)
        .map((n) => ({
          source: n.getAttribute("data-source"),
          freshness: n.getAttribute("data-freshness"),
          explanation: n.getAttribute("title"),
        })),
    );
  expect(evidence.length).toBeGreaterThan(10);
  for (const value of evidence) {
    expect(value.source).toBeTruthy();
    expect(["LIVE", "CACHED", "STALE", "UNAVAILABLE"]).toContain(
      value.freshness,
    );
    expect(value.explanation).toBeTruthy();
  }
});
test("filter sheet supports keyboard escape, focus restoration and the current viewport", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByTestId("pool-row").first().waitFor();
  const trigger = page.getByRole("button", { name: "Filter", exact: true });
  await trigger.click();
  const dialog = page.getByRole("dialog", { name: "Scanner-Filter" });
  await expect(dialog).toBeVisible();
  const rect = await dialog.boundingBox();
  expect(rect!.x).toBeGreaterThanOrEqual(0);
  expect(rect!.width).toBeLessThanOrEqual(page.viewportSize()!.width);
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(trigger).toBeFocused();
});
