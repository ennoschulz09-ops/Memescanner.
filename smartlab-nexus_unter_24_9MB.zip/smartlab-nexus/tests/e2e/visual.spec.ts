import { test, expect } from "@playwright/test";
test("research blotter matches its reviewed layout baseline", async ({
  page,
}) => {
  await page.goto("/?view=command");
  const blotter = page.locator(".research-blotter");
  await expect(blotter.locator(".blotter-row")).toHaveCount(6);
  const subject = blotter.locator(".blotter-row").first();
  await expect(subject).toHaveScreenshot("research-blotter.png", {
    animations: "disabled",
    mask: [
      page.locator(".blotter-status"),
      page.locator(".blotter-row > span:nth-child(2)"),
    ],
    maxDiffPixelRatio: 0.005,
  });
});
