import gecko from "./fixtures/gecko-live.json";
import { normalizeGecko } from "../lib/providers/normalize";
import { provenance } from "../lib/providers/http";
import type { Observation } from "../lib/domain";
export function observation(overrides: Partial<Observation> = {}): Observation {
  const now = new Date();
  return {
    ...normalizeGecko(
      gecko,
      provenance(
        "gecko",
        "test",
        new Headers({ date: now.toUTCString() }),
        now,
        10,
      ),
    )[0],
    ...overrides,
  };
}
