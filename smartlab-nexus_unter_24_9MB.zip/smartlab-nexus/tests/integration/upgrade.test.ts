import { beforeAll, afterAll, it, expect } from "vitest";
import { db, migrate } from "../../lib/db";
import { recordDiscoveries, getDiscoveries } from "../../lib/discovery";
import { ingest } from "../../lib/ingestion";
import { openStream } from "../../lib/stream";
import { observation } from "../helpers";
import { createHash } from "node:crypto";
import { ProgramFeed } from "../../worker/chain-feed";
import { SolanaProvider } from "../../lib/providers/solana";
import { HttpClient } from "../../lib/providers/http";
import { CPMM_PROGRAM } from "../../lib/providers/pool-init";
import bs58 from "bs58";
import { scannerPage } from "../../lib/scanner-query";
import { processAlerts, processPendingAlerts } from "../../lib/ingestion";
beforeAll(async () => {
  await migrate();
  await db.query("TRUNCATE discoveries");
});
afterAll(async () => {
  await db.query("TRUNCATE discoveries");
  await db.end();
});
it("persists a decoded candidate as a JSON array and discovers its actual pair assets", async () => {
  await db.query("TRUNCATE chain_candidates,discoveries");
  const accounts = Array.from({ length: 20 }, (_, i) =>
    bs58.encode(Buffer.alloc(32, i + 1)),
  );
  const signature = bs58.encode(Buffer.alloc(64, 3));
  const data = bs58.encode(
    Buffer.concat([
      createHash("sha256").update("global:initialize").digest().subarray(0, 8),
      Buffer.alloc(24),
    ]),
  );
  const tx = {
    slot: 123,
    blockTime: Math.floor(Date.now() / 1000) - 1,
    meta: { err: null },
    transaction: {
      message: { instructions: [{ programId: CPMM_PROGRAM, accounts, data }] },
    },
  };
  const feed = new ProgramFeed(
    new SolanaProvider(
      new HttpClient(async (_url, init) => {
        expect(JSON.parse(String(init?.body)).params[0]).toBe(signature);
        return new Response(JSON.stringify({ jsonrpc: "2.0", result: tx }));
      }),
    ),
  );
  try {
    await db.query(
      "INSERT INTO chain_candidates(signature,slot,observed_at,next_attempt_at) VALUES($1,123,clock_timestamp()-interval '1 hour',clock_timestamp()-interval '1 hour')",
      [signature],
    );
    await db.query(
      "INSERT INTO chain_candidates(signature,slot,observed_at,next_attempt_at) VALUES($1,122,clock_timestamp()-interval '1 day',clock_timestamp()-interval '1 second')",
      [bs58.encode(Buffer.alloc(64, 4))],
    );
    await feed.processCandidate();
    const stored = (
      await db.query(
        "SELECT decoded,processed_at FROM chain_candidates WHERE signature=$1",
        [signature],
      )
    ).rows[0];
    expect(stored.decoded).toEqual([
      expect.objectContaining({
        poolAddress: accounts[3],
        mints: [accounts[4], accounts[5]],
      }),
    ]);
    expect(stored.processed_at).toBeTruthy();
    expect((await getDiscoveries()).map((d) => d.mint).sort()).toEqual(
      [accounts[4], accounts[5]].sort(),
    );
  } finally {
    await feed.stop();
    await db.query("TRUNCATE chain_candidates,discoveries");
  }
});
it("persists early discovery independently, preserves first-seen, and hydrates without invented pools", async () => {
  const row = observation();
  await db.query("TRUNCATE tokens CASCADE");
  expect(await recordDiscoveries([{ mint: row.mint }], row.provenance)).toBe(1);
  const first = (await getDiscoveries())[0];
  expect(first.status).toBe("incomplete");
  expect(
    (await db.query("SELECT count(*)::int as n FROM pools")).rows[0].n,
  ).toBe(0);
  expect(await recordDiscoveries([{ mint: row.mint }], row.provenance)).toBe(0);
  expect((await getDiscoveries())[0].firstSeenAt).toBe(first.firstSeenAt);
  await expect(ingest([{ ...row, id: "invalid" }])).rejects.toThrow();
  expect((await getDiscoveries())[0].status).toBe("incomplete");
  const inserted = await ingest([row]);
  const firstToken = inserted.events.find((e) => e.kind === "new_token")!;
  expect(firstToken).toMatchObject({
    source: row.provenance.provider,
    after: row.mint,
    before: null,
  });
  expect(firstToken).toHaveProperty("measuredAt", null);
  expect(firstToken.limits).toContain("kein Nachweis");
  expect((await getDiscoveries())[0].status).toBe("hydrated");
  const previousBudget = process.env.DISCOVERY_FRESHNESS_SECONDS;
  try {
    process.env.DISCOVERY_FRESHNESS_SECONDS = "180";
    await db.query(
      "UPDATE discoveries SET first_seen_at=clock_timestamp()-interval '10 minutes'",
    );
    expect((await getDiscoveries())[0].discoveryFreshness).toBe("historical");
    process.env.DISCOVERY_FRESHNESS_SECONDS = "3600";
    expect((await getDiscoveries())[0].discoveryFreshness).toBe("recent");
  } finally {
    if (previousBudget === undefined)
      delete process.env.DISCOVERY_FRESHNESS_SECONDS;
    else process.env.DISCOVERY_FRESHNESS_SECONDS = previousBudget;
  }
});
it("paginates and filters in PostgreSQL, preserves literal search and sorts missing values last", async () => {
  await db.query("TRUNCATE tokens CASCADE");
  const rows = Array.from({ length: 6 }, (_, i) => {
    const key = Buffer.alloc(32, 7);
    key.writeUInt32BE(i + 1);
    const mint = bs58.encode(key);
    const o = observation({
      mint,
      name: i === 2 ? "literal % value" : "Token " + i,
      symbol: "S" + i,
      liquidityUsd: i === 5 ? null : i * 10000,
    });
    return { ...o, id: mint + ":" + o.poolId };
  });
  await ingest(rows);
  const first = await scannerPage({
    page: 1,
    pageSize: 2,
    sort: "liquidityUsd",
    direction: "desc",
    filters: {},
  });
  const second = await scannerPage({
    page: 2,
    pageSize: 2,
    sort: "liquidityUsd",
    direction: "desc",
    filters: {},
  });
  expect(first.total).toBe(6);
  expect(first.rows.map((r) => r.liquidityUsd)).toEqual([40000, 30000]);
  expect(second.rows.map((r) => r.liquidityUsd)).toEqual([20000, 10000]);
  const literal = await scannerPage({
    page: 1,
    pageSize: 10,
    sort: "name",
    direction: "asc",
    filters: { query: "%" },
  });
  expect(literal.total).toBe(1);
  const missing = await scannerPage({
    page: 3,
    pageSize: 2,
    sort: "liquidityUsd",
    direction: "desc",
    filters: {},
  });
  expect(missing.rows.at(-1)?.liquidityUsd).toBeNull();
  const minimum = await scannerPage({
    page: 1,
    pageSize: 10,
    sort: "liquidityUsd",
    direction: "desc",
    filters: { minLiquidity: 30000 },
  });
  expect(minimum.total).toBe(2);
});
it("persists debounce candidates and delivers only after the quiet period while retaining deduplication", async () => {
  await db.query("TRUNCATE sessions CASCADE");
  await db.query("TRUNCATE events");
  await db.query("INSERT INTO sessions(id) VALUES('upgrade-owner')");
  const rule = {
    kind: "feed_outage" as const,
    threshold: 0,
    cooldownSeconds: 60,
    quotaPerHour: 5,
    quietStart: null,
    quietEnd: null,
    enabled: true,
    mint: null,
    debounceSeconds: 5,
  };
  await db.query(
    "INSERT INTO alert_rules(id,owner,name,data,created_at) VALUES('upgrade-rule','upgrade-owner','Feed',$1,now()-interval '1 hour')",
    [rule],
  );
  const event = {
    kind: "feed_outage" as const,
    mint: null,
    key: "feed:test:1",
    source: "solana",
    value: 1,
    at: new Date().toISOString(),
    before: "ok",
    after: "limited",
  };
  await db.query(
    "INSERT INTO provider_states(provider,status) VALUES('solana','limited') ON CONFLICT(provider) DO UPDATE SET status='limited'",
  );
  await processAlerts([event]);
  expect((await db.query("SELECT * FROM alert_events")).rowCount).toBe(0);
  expect((await db.query("SELECT * FROM alert_candidates")).rowCount).toBe(1);
  await db.query(
    "UPDATE alert_candidates SET not_before=clock_timestamp()-interval '1 second'",
  );
  await processPendingAlerts();
  expect((await db.query("SELECT * FROM alert_events")).rowCount).toBe(1);
  await processAlerts([event]);
  await processPendingAlerts();
  expect((await db.query("SELECT * FROM alert_events")).rowCount).toBe(1);
  await db.query("TRUNCATE sessions CASCADE");
});
it("replays latest state from a bounded stream checkpoint and resyncs unknown checkpoints", async () => {
  const row = observation();
  await ingest([row]);
  const abort = new AbortController();
  const res = await openStream(
    new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
  );
  const reader = res.body!.getReader();
  await reader.read();
  const initial = new TextDecoder().decode((await reader.read()).value);
  const cursor = /id: ([^\n]+)/.exec(initial)?.[1];
  expect(cursor).toBeTruthy();
  abort.abort();
  await reader.cancel();
  await db.query("UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1", [
    row.id,
  ]);
  const again = new AbortController();
  const resumed = await openStream(
    new Request("http://localhost:3000/api/stream", {
      signal: again.signal,
      headers: { "Last-Event-ID": cursor! },
    }),
  );
  const replay = resumed.body!.getReader();
  expect(new TextDecoder().decode((await replay.read()).value)).toContain(
    '"resumed":true',
  );
  expect(new TextDecoder().decode((await replay.read()).value)).toContain(
    row.id,
  );
  again.abort();
  await replay.cancel();
  const unknown = new AbortController();
  const fallback = await openStream(
    new Request("http://localhost:3000/api/stream", {
      signal: unknown.signal,
      headers: { "Last-Event-ID": "unknown:1" },
    }),
  );
  const fallbackReader = fallback.body!.getReader();
  expect(
    new TextDecoder().decode((await fallbackReader.read()).value),
  ).toContain('"resync":true');
  unknown.abort();
  await fallbackReader.cancel();
});
