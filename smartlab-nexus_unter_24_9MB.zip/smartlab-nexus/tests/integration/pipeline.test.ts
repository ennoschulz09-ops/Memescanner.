import { beforeAll, beforeEach, afterAll, describe, it, expect } from "vitest";
import { db, migrate, claimBudget, auditRequest } from "../../lib/db";
import {
  ingest,
  getPools,
  getHealth,
  processAlerts,
  processPendingAlerts,
  saveEvidence,
  rescorePools,
} from "../../lib/ingestion";
import { observation } from "../helpers";
import { HttpClient } from "../../lib/providers/http";
import { DexProvider } from "../../lib/providers/dex";
import fixture from "../fixtures/dex-live.json";

beforeAll(async () => {
  await migrate();
});
beforeEach(async () => {
  await db.query(
    "TRUNCATE tokens, events, provider_states, source_audits, provider_budgets, provider_budget_claims, worker_state, sessions, source_cache RESTART IDENTITY CASCADE",
  );
});
afterAll(async () => {
  await db.end();
});
describe("persistent research pipeline", () => {
  it("computes activity increase from two distinct own samples from the same provider", async () => {
    const o = observation({ buys5m: 10, sells5m: 5 });
    await ingest([o]);
    expect((await getPools())[0].activityIncreasePct).toBeNull();
    await ingest([
      {
        ...o,
        buys5m: 20,
        sells5m: 10,
        provenance: {
          ...o.provenance,
          sourceAt: new Date(
            Date.parse(o.provenance.sourceAt) + 1000,
          ).toISOString(),
        },
      },
    ]);
    expect((await getPools())[0].activityIncreasePct).toBe(100);
  });
  it("does not shorten Retry-After when an earlier in-flight request subsequently fails", async () => {
    await auditRequest({
      provider: "gecko",
      endpoint: "new_pools",
      ok: false,
      status: 429,
      latencyMs: 1,
      error: "HTTP 429",
      retryAfterMs: 600000,
    });
    const initial = (
      await db.query(
        "SELECT retry_at FROM provider_states WHERE provider='gecko'",
      )
    ).rows[0].retry_at;
    await auditRequest({
      provider: "gecko",
      endpoint: "pools/multi",
      ok: false,
      status: 503,
      latencyMs: 2,
      error: "HTTP 503",
      retryAfterMs: 0,
    });
    const after = (
      await db.query(
        "SELECT retry_at FROM provider_states WHERE provider='gecko'",
      )
    ).rows[0].retry_at;
    expect(after.getTime()).toBeGreaterThanOrEqual(initial.getTime());
  });
  it("audits scores that change solely because their data became stale", async () => {
    const o = observation();
    await ingest([o]);
    const before = (await db.query("SELECT risk FROM pools")).rows[0].risk;
    await rescorePools(Date.now() + 240000);
    const after = (await db.query("SELECT risk FROM pools")).rows[0].risk;
    expect(after.dataQuality).toBeLessThan(before.dataQuality);
    expect((await db.query("SELECT * FROM risk_audits")).rowCount).toBe(2);
  });
  it("counts requests in a rolling minute rather than allowing a boundary burst", async () => {
    for (let i = 0; i < 8; i++) await claimBudget("gecko", "gecko");
    await db.query(
      "UPDATE provider_budget_claims SET at=clock_timestamp()-interval '59 seconds'",
    );
    await db.query(
      "UPDATE provider_budgets SET window_start=clock_timestamp()-interval '61 seconds'",
    );
    await expect(claimBudget("gecko", "gecko")).rejects.toMatchObject({
      status: 429,
    });
    await db.query(
      "UPDATE provider_budget_claims SET at=clock_timestamp()-interval '61 seconds' WHERE id=(SELECT min(id) FROM provider_budget_claims)",
    );
    await expect(claimBudget("gecko", "gecko")).resolves.toBeUndefined();
  });
  it("keeps Retry-After active when an earlier in-flight request succeeds", async () => {
    await auditRequest({
      provider: "gecko",
      endpoint: "new_pools",
      ok: false,
      status: 429,
      latencyMs: 1,
      error: "HTTP 429",
      retryAfterMs: 60000,
    });
    await auditRequest({
      provider: "gecko",
      endpoint: "pools/multi",
      ok: true,
      status: 200,
      latencyMs: 2,
      error: null,
      retryAfterMs: 0,
    });
    await expect(claimBudget("gecko", "gecko")).rejects.toMatchObject({
      status: 429,
    });
  });
  it("persists newly discovered authority risk from an explicit onchain inspection", async () => {
    const o = observation({ liquidityUsd: 500000, volume5m: 10 });
    await ingest([o]);
    await saveEvidence(o.mint, {
      controls: {
        mintAuthority: "active",
        freezeAuthority: "active",
        program: "SPL Token",
        decimals: 6,
        supply: "1000",
        slot: 10,
        extensions: [],
      },
      concentration: null,
      error: null,
      checkedAt: new Date().toISOString(),
      slot: 10,
    });
    const events = (
      await db.query("SELECT payload FROM events WHERE kind='risk_flag'")
    ).rows;
    expect(
      events.some((e) =>
        e.payload.flags.some((f: string) => f.includes("Contract")),
      ),
    ).toBe(true);
  });
  it("retries a persisted alert outbox after a delivery database failure", async () => {
    await db.query("INSERT INTO sessions(id) VALUES('outbox-owner')");
    const rule = {
      kind: "liquidity_change",
      threshold: 30,
      cooldownSeconds: 60,
      quotaPerHour: 10,
      quietStart: null,
      quietEnd: null,
      enabled: true,
      mint: null,
    };
    await db.query(
      "INSERT INTO alert_rules(id,owner,name,data) VALUES('outbox-rule','outbox-owner','outbox',$1)",
      [rule],
    );
    const event = {
      kind: "liquidity_change",
      mint: observation().mint,
      key: "retry-me",
      value: -50,
      at: new Date().toISOString(),
    };
    await db.query(
      "INSERT INTO events(kind,mint,payload) VALUES('liquidity_change',$1,$2)",
      [event.mint, event],
    );
    await db.query(
      "ALTER TABLE alert_events ADD CONSTRAINT simulate_delivery_failure CHECK (id = 'never') NOT VALID",
    );
    try {
      await expect(processPendingAlerts()).rejects.toThrow();
    } finally {
      await db.query(
        "ALTER TABLE alert_events DROP CONSTRAINT simulate_delivery_failure",
      );
    }
    expect(
      (await db.query("SELECT alerts_processed_at FROM events")).rows[0]
        .alerts_processed_at,
    ).toBeNull();
    await processPendingAlerts();
    await processPendingAlerts();
    expect((await db.query("SELECT * FROM alert_events")).rowCount).toBe(1);
  });
  it("ingests, deduplicates by mint/pool and prevents cross-source volume addition", async () => {
    const a = observation({ volume5m: 100 });
    await ingest([a, a]);
    await ingest([
      {
        ...a,
        volume5m: 150,
        provenance: {
          ...a.provenance,
          provider: "dex",
          sourceAt: new Date(
            Date.parse(a.provenance.sourceAt) + 1000,
          ).toISOString(),
        },
      },
    ]);
    const rows = await getPools();
    expect(rows).toHaveLength(1);
    expect(rows[0].sources).toHaveLength(2);
    expect(rows[0].volume5m).toBe(150);
    expect((await db.query("SELECT * FROM samples")).rows).toHaveLength(2);
    expect(
      (await db.query("SELECT * FROM events WHERE kind='new_token'")).rows,
    ).toHaveLength(1);
  });
  it("rejects delayed observations without rolling latest values backward", async () => {
    const a = observation({ priceUsd: 2 });
    await ingest([a]);
    await ingest([
      {
        ...a,
        priceUsd: 1,
        provenance: { ...a.provenance, sourceAt: "2020-01-01T00:00:00Z" },
      },
    ]);
    expect((await getPools())[0].priceUsd).toBe(2);
  });
  it("does not publish partial writes if the database rejects a row", async () => {
    const a = observation();
    await expect(
      ingest([{ ...a, mint: null as unknown as string }]),
    ).rejects.toThrow();
    expect((await getPools()).length).toBe(0);
  });
  it("exposes unavailable and stale providers as degraded health", async () => {
    await ingest([observation()]);
    await auditRequest({
      provider: "gecko",
      endpoint: "new_pools",
      ok: false,
      status: 429,
      latencyMs: 12,
      error: "HTTP 429",
      retryAfterMs: 30000,
    });
    const health = await getHealth();
    expect(health.mode).toBe("degraded");
    expect(health.providers.find((x) => x.provider === "gecko")?.status).toBe(
      "limited",
    );
    expect(
      health.providers.find((x) => x.provider === "gecko")?.retryAt,
    ).toBeTruthy();
  });
  it("shares budgets across concurrent callers and respects Retry-After", async () => {
    const attempts = await Promise.allSettled(
      Array.from({ length: 12 }, () => claimBudget("gecko", "gecko")),
    );
    expect(attempts.filter((x) => x.status === "fulfilled")).toHaveLength(8);
    await auditRequest({
      provider: "dex",
      endpoint: "search",
      ok: false,
      status: 429,
      latencyMs: 1,
      error: "HTTP 429",
      retryAfterMs: 60000,
    });
    await expect(claimBudget("dex", "dex-market")).rejects.toMatchObject({
      status: 429,
    });
  });
  it("validates and persists mocked provider responses through the real pipeline", async () => {
    const http = new HttpClient(
      async () =>
        new Response(JSON.stringify(fixture), {
          headers: { date: new Date().toUTCString() },
        }),
      { claim: claimBudget, audit: auditRequest },
    );
    await ingest(
      await new DexProvider(http).tokens([
        "So11111111111111111111111111111111111111112",
      ]),
    );
    expect((await getPools()).length).toBeGreaterThan(0);
    expect((await db.query("SELECT * FROM source_audits")).rows).toHaveLength(
      1,
    );
  });
  it("persists cooldown and deduplication for alert rules", async () => {
    await db.query("INSERT INTO sessions(id) VALUES('test-owner')");
    const rule = {
      kind: "liquidity_change",
      threshold: 30,
      cooldownSeconds: 300,
      quotaPerHour: 3,
      quietStart: null,
      quietEnd: null,
      enabled: true,
      mint: null,
    };
    await db.query(
      "INSERT INTO alert_rules(id,owner,name,data) VALUES('rule','test-owner','test',$1)",
      [rule],
    );
    const event = {
      kind: "liquidity_change" as const,
      mint: observation().mint,
      key: "evt",
      value: -50,
      at: new Date().toISOString(),
    };
    await processAlerts([event]);
    await processAlerts([event]);
    const rows = (await db.query("SELECT * FROM alert_events")).rows;
    expect(rows).toHaveLength(1);
    expect(rows[0].delivery_state).toBe("pending");
  });
});
