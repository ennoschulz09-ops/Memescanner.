import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import bs58 from "bs58";
import { auditRequest, db, migrate } from "../../lib/db";
import { HttpClient } from "../../lib/providers/http";
import { SolanaProvider } from "../../lib/providers/solana";
import { ingest } from "../../lib/ingestion";
import { getDataQuality } from "../../lib/data-quality";
import { handleApi } from "../../lib/api";
import { isCompactPoolPage, unpackPoolPage } from "../../lib/scanner-wire";
import { observation } from "../helpers";

beforeAll(async () => {
  await migrate();
});
beforeEach(async () => {
  await db.query(
    "TRUNCATE tokens,provider_states,source_audits,provider_budget_claims,service_counters CASCADE",
  );
});
afterAll(async () => {
  await db.query(
    "TRUNCATE tokens,provider_states,source_audits,provider_budget_claims,service_counters CASCADE",
  );
  await db.end();
});
it("aggregates zero, null, stale and retrieval-only evidence from real PostgreSQL rows", async () => {
  const now = Date.now();
  const rows = Array.from({ length: 4 }, (_, index) => {
    const mint = bs58.encode(Buffer.alloc(32, 40 + index));
    const obs = observation({
      mint,
      priceUsd: index === 3 ? null : 0,
      liquidityUsd: index === 0 ? null : 1,
    });
    return {
      ...obs,
      id: `${mint}:${obs.poolId}`,
      provenance: {
        ...obs.provenance,
        fetchedAt: new Date(now).toISOString(),
        sourceAt: new Date(now - (index === 1 ? 300000 : 1000)).toISOString(),
        timestampKind:
          index === 2
            ? ("retrieval-only" as const)
            : ("http-cache-estimate" as const),
      },
    };
  });
  await ingest(rows);
  const quality = await getDataQuality(now);
  expect(quality.pools).toBe(4);
  expect(quality.fields.find((f) => f.field === "priceUsd")).toMatchObject({
    present: 3,
    missing: 1,
    total: 4,
    coveragePct: 75,
  });
  expect(
    quality.fields.find((f) => f.field === "liquidityUsd")?.coveragePct,
  ).toBe(75);
  expect(quality.freshness).toMatchObject({
    current: 2,
    stale: 1,
    unknown: 1,
    stalePct: 25,
    unknownPct: 25,
  });
  const audits = await db.query("SELECT report FROM risk_audits");
  expect(audits.rows.length).toBeGreaterThan(0);
  expect(
    audits.rows.every((r) => r.report.modelVersion === "nexus-risk/3"),
  ).toBe(true);
});

it("measures 24h audit events, failed-audit runs and the active sliding request window", async () => {
  const now = Date.now();
  for (const [index, ok] of [true, false, false, true, false].entries()) {
    await db.query(
      "INSERT INTO source_audits(provider,endpoint,ok,status,latency_ms,at) VALUES('dex','fixture',$1,$2,1,$3)",
      [
        ok,
        ok ? 200 : index === 2 ? 429 : 503,
        new Date(now - (10 - index) * 1000),
      ],
    );
  }
  await db.query(
    "INSERT INTO source_audits(provider,endpoint,ok,status,latency_ms,at) VALUES('dex','old-fixture',false,503,1,$1)",
    [new Date(now - 86401000)],
  );
  await db.query(
    "INSERT INTO provider_budget_claims(channel,at) VALUES('gecko',$1),('gecko',$2)",
    [new Date(now - 1000), new Date(now - 61000)],
  );
  await db.query(
    "INSERT INTO provider_states(provider,status,last_error,error) VALUES('solana','error',$1,'older failure')",
    [new Date(now - 86401000)],
  );
  const quality = await getDataQuality(now);
  expect(quality.providers.find((p) => p.provider === "dex")).toMatchObject({
    auditEvents24h: 5,
    failedAuditEvents24h: 3,
    rateLimitedAuditEvents24h: 1,
    failedAuditRuns24h: 2,
    failedAuditEventPct: 60,
  });
  expect(quality.providers.find((p) => p.provider === "solana")).toMatchObject({
    status: "error",
    auditEvents24h: 0,
    failedAuditEventPct: null,
  });
  expect(
    quality.requestBudgets.find((b) => b.channel === "gecko"),
  ).toMatchObject({ used: 1, remaining: 7 });
  expect(quality.costs.totalUsd).toBeNull();
});

it("keeps the default API full, offers compact pages and leaves token detail observations complete", async () => {
  const obs = observation();
  await ingest([obs]);
  const full = await (
    await handleApi(
      new Request("http://localhost/api/pools?page=1&pageSize=100"),
    )
  ).json();
  expect(full.rows[0].sources.length).toBeGreaterThan(0);
  expect(full.format).toBeUndefined();
  const compactResponse = await handleApi(
    new Request(
      "http://localhost/api/pools?page=1&pageSize=100&format=compact",
    ),
  );
  expect(compactResponse.status).toBe(200);
  const compact = await compactResponse.json();
  expect(isCompactPoolPage(compact)).toBe(true);
  const decoded = unpackPoolPage(compact);
  expect(decoded.rows[0].priceUsd).toBe(full.rows[0].priceUsd);
  expect(decoded.rows[0].fieldEvidence?.priceUsd.source).toBe(
    full.rows[0].fieldEvidence.priceUsd.source,
  );
  expect(decoded.rows[0].risk.modelVersion).toBe("nexus-risk/3");
  const detail = await (
    await handleApi(new Request(`http://localhost/api/tokens/${obs.mint}`))
  ).json();
  expect(detail.selected.sources).toEqual(full.rows[0].sources);
  const quality = await (
    await handleApi(new Request("http://localhost/api/quality"))
  ).json();
  expect(quality).toMatchObject({
    version: 1,
    pools: 1,
    costs: { status: "unknown", totalUsd: null },
  });
  const byIds = await handleApi(
    new Request("http://localhost/api/pools/query?format=compact", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        origin: "http://localhost:3000",
      },
      body: JSON.stringify({ ids: [obs.id] }),
    }),
  );
  expect(isCompactPoolPage(await byIds.json())).toBe(true);
});

it("labels a single HTTP200 RPC failure as two audit events, without claiming a request error rate", async () => {
  let transportedRequests = 0;
  const provider = new SolanaProvider(
    new HttpClient(
      async () => {
        transportedRequests++;
        return new Response(
          JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            error: { code: -32015, message: "Unsupported transaction version" },
          }),
          { status: 200 },
        );
      },
      { audit: auditRequest },
    ),
  );
  await expect(provider.rpc("getHealth")).rejects.toThrow();
  expect(transportedRequests).toBe(1);
  const quality = await getDataQuality();
  const solana = quality.providers.find((p) => p.provider === "solana");
  expect(solana).toMatchObject({
    auditEvents24h: 2,
    failedAuditEvents24h: 1,
    failedAuditEventPct: 50,
    failedAuditRuns24h: 1,
  });
  expect(solana).not.toHaveProperty("requests24h");
  expect(solana).not.toHaveProperty("failurePct");
  expect(quality.costs).toMatchObject({ status: "unknown", totalUsd: null });
});
