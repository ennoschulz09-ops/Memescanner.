import { it, expect, afterAll, beforeAll } from "vitest";
import { db, migrate } from "../../lib/db";
import { ingest, rescorePools, getHealth } from "../../lib/ingestion";
import { observation } from "../helpers";
beforeAll(async () => {
  await migrate();
});
afterAll(async () => {
  await db.end();
});
it("audits a risk model version change even when numerical signals are identical", async () => {
  await db.query("TRUNCATE tokens CASCADE");
  await ingest([observation()]);
  const old = (await db.query("SELECT id,risk FROM pools LIMIT 1")).rows[0];
  await db.query(
    "UPDATE pools SET risk=jsonb_set(risk,'{modelVersion}','\"nexus-risk/1\"') WHERE id=$1",
    [old.id],
  );
  const before = Number(
    (
      await db.query("SELECT count(*) FROM risk_audits WHERE pool_key=$1", [
        old.id,
      ])
    ).rows[0].count,
  );
  expect(await rescorePools()).toBe(1);
  const updated = (
    await db.query("SELECT risk FROM pools WHERE id=$1", [old.id])
  ).rows[0].risk;
  expect(updated.modelVersion).toBe("nexus-risk/3");
  expect(
    Number(
      (
        await db.query("SELECT count(*) FROM risk_audits WHERE pool_key=$1", [
          old.id,
        ])
      ).rows[0].count,
    ),
  ).toBe(before + 1);
});

it("health honors individual freshness budgets and keeps retrieval-only out of stale", async () => {
  await db.query("TRUNCATE tokens CASCADE");
  const row = observation();
  row.provenance = {
    ...row.provenance,
    sourceAt: new Date(Date.now() - 10000).toISOString(),
    freshnessBudgetSeconds: 1,
  };
  await ingest([row]);
  expect((await getHealth()).counts.stale).toBe(1);
  row.provenance = {
    ...row.provenance,
    timestampKind: "retrieval-only",
    sourceAt: new Date(Date.now() - 86400000).toISOString(),
  };
  await db.query("UPDATE pools SET selected=$1", [row]);
  expect((await getHealth()).counts.stale).toBe(0);
});
