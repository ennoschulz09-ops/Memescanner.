import { beforeAll, beforeEach, afterAll, it, expect } from "vitest";
import { db, migrate } from "../../lib/db";
import { ingest } from "../../lib/ingestion";
import { handleApi } from "../../lib/api";
import { observation } from "../helpers";
import { cached } from "../../lib/services";
beforeAll(async () => {
  await migrate();
});
beforeEach(async () => {
  await db.query(
    "TRUNCATE tokens,sessions,source_cache RESTART IDENTITY CASCADE",
  );
});
afterAll(async () => {
  await db.end();
});
function request(path: string, method = "GET", body?: unknown, cookie = "") {
  return handleApi(
    new Request("http://localhost:3000/api/" + path, {
      method,
      headers: {
        origin: "http://localhost:3000",
        cookie,
        "content-type": "application/json",
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    }),
    path.split("/"),
  );
}
it("serves persisted scanner rows with source age and honest unknown risk", async () => {
  await ingest([observation()]);
  const res = await request("pools");
  const data = await res.json();
  expect(res.status).toBe(200);
  expect(data.rows).toHaveLength(1);
  expect(data.rows[0].risk.overall).toBeNull();
  expect(data.rows[0].provenance.sourceAt).toBeTruthy();
  expect(res.headers.get("cache-control")).toContain("no-store");
});
it("keeps failed cache refreshes explicitly stale and records cache hits", async () => {
  let calls = 0;
  await cached("cache-test", 60, async () => ({ value: ++calls }));
  const hit = await cached("cache-test", 60, async () => ({ value: ++calls }));
  expect(hit.cache.hit).toBe(true);
  expect(calls).toBe(1);
  await db.query(
    "UPDATE source_cache SET updated_at='2020-01-01' WHERE key='cache-test'",
  );
  const stale = await cached<{ value: number }>("cache-test", 60, async () => {
    throw new Error("network down");
  });
  expect(stale.cache.stale).toBe(true);
  expect(stale.error).toBeTruthy();
  const health = await (await request("health")).json();
  expect(health.cache.requests).toBeGreaterThanOrEqual(3);
  expect(health.cache.hits).toBeGreaterThanOrEqual(1);
});
it("rejects request bodies above the byte limit before parsing JSON", async () => {
  const res = await request("watchlists", "POST", { name: "x".repeat(33000) });
  expect(res.status).toBe(413);
});
it("persists watchlist items and isolates browser sessions", async () => {
  const o = observation();
  await ingest([o]);
  const session = await request("session");
  const cookie = session.headers.get("set-cookie")!.split(";")[0];
  const add = await request(
    "watchlists/items",
    "POST",
    { mint: o.mint },
    cookie,
  );
  expect(add.status).toBe(200);
  const own = await (
    await request("watchlists", "GET", undefined, cookie)
  ).json();
  expect(own.lists[0].items[0].mint).toBe(o.mint);
  const other = await (await request("watchlists")).json();
  expect(other.lists).toHaveLength(0);
  const del = await request(
    "watchlists/items",
    "DELETE",
    { mint: o.mint, listId: own.lists[0].id },
    cookie,
  );
  expect(del.status).toBe(200);
  expect(
    (await (await request("watchlists", "GET", undefined, cookie)).json())
      .lists[0].items,
  ).toHaveLength(0);
});
it("rejects cross-origin mutation, malformed addresses and oversized inputs", async () => {
  const cross = await handleApi(
    new Request("http://localhost:3000/api/watchlists", {
      method: "POST",
      headers: {
        origin: "https://evil.test",
        "content-type": "application/json",
      },
      body: '{"name":"test"}',
    }),
    ["watchlists"],
  );
  expect(cross.status).toBe(403);
  expect((await request("wallet/bad")).status).toBe(400);
  expect(
    (await request("search", "POST", { query: "x".repeat(10000) })).status,
  ).toBe(400);
});
it("stores presets and validated preferences", async () => {
  const s = await request("session"),
    cookie = s.headers.get("set-cookie")!.split(";")[0];
  expect(
    (
      await request(
        "presets",
        "POST",
        { name: "Liquid", filters: { minLiquidity: 10000 } },
        cookie,
      )
    ).status,
  ).toBe(200);
  expect(
    (await (await request("presets", "GET", undefined, cookie)).json())
      .presets[0].filters.minLiquidity,
  ).toBe(10000);
  await request(
    "settings",
    "PATCH",
    { compact: true, timezone: "UTC" },
    cookie,
  );
  expect(
    (await (await request("settings", "GET", undefined, cookie)).json())
      .settings.compact,
  ).toBe(true);
  expect(
    (
      await request(
        "settings",
        "PATCH",
        { SOLANA_RPC_URL: "https://evil.test" },
        cookie,
      )
    ).status,
  ).toBe(400);
});
it("exports only allowlisted fields and neutralizes spreadsheet formulas", async () => {
  await ingest([observation({ name: '=IMPORTXML("evil")' })]);
  const csv = await (await request("export?format=csv")).text();
  expect(csv).toContain("'=IMPORTXML");
  expect(csv).not.toContain("DATABASE_URL");
});
it("stores alert rules and separately acknowledges in-app delivery", async () => {
  const s = await request("session"),
    cookie = s.headers.get("set-cookie")!.split(";")[0];
  const body = {
    name: "Liquiditätsänderung",
    kind: "liquidity_change",
    threshold: 30,
    cooldownSeconds: 300,
    quotaPerHour: 3,
    quietStart: 22,
    quietEnd: 7,
    enabled: true,
    mint: null,
    watchlistId: null,
  };
  const res = await request("alerts", "POST", body, cookie);
  expect(res.status).toBe(200);
  const data = await (await request("alerts", "GET", undefined, cookie)).json();
  expect(data.rules).toHaveLength(1);
  expect(
    (
      await request(
        "alerts/" + data.rules[0].id,
        "PATCH",
        { enabled: false },
        cookie,
      )
    ).status,
  ).toBe(200);
  expect(
    (await (await request("alerts", "GET", undefined, cookie)).json()).rules[0]
      .data.enabled,
  ).toBe(false);
});
it("acknowledges only explicitly displayed alert IDs owned by the current session", async () => {
  const s = await request("session"),
    cookie = s.headers.get("set-cookie")!.split(";")[0];
  const owner = (await db.query("SELECT id FROM sessions")).rows[0].id;
  await db.query(
    "INSERT INTO alert_rules(id,owner,name,data) VALUES('ack-rule',$1,'ack','{}')",
    [owner],
  );
  for (const id of ["seen", "unseen"])
    await db.query(
      "INSERT INTO alert_events(id,rule_id,owner,mint,event_key,data) VALUES($1,'ack-rule',$2,'public',$1,'{}')",
      [id, owner],
    );
  expect(
    (await request("alerts/ack", "POST", { ids: ["seen"] }, cookie)).status,
  ).toBe(200);
  const states = Object.fromEntries(
    (await db.query("SELECT id,delivery_state FROM alert_events")).rows.map(
      (r) => [r.id, r.delivery_state],
    ),
  );
  expect(states).toEqual({ seen: "delivered", unseen: "pending" });
});
it("separates pending and decoded DOM receipts with one correlation ID and rejects impossible clocks", async () => {
  const signature = "3".repeat(88);
  await db.query("DELETE FROM chain_ui_receipts WHERE signature=$1", [
    signature,
  ]);
  await db.query(
    "INSERT INTO chain_candidates(signature,slot,status) VALUES($1,123,'pending') ON CONFLICT(signature) DO UPDATE SET status='pending'",
    [signature],
  );
  const session = await request("session");
  const cookie = session.headers.get("set-cookie")!.split(";")[0];
  const at = new Date().toISOString();
  const input = { eventIds: [signature], publishedAt: at, renderedAt: at };
  expect(
    (
      await request(
        "chain-receipts",
        "POST",
        { ...input, stage: "candidate" },
        cookie,
      )
    ).status,
  ).toBe(200);
  expect(
    (
      await request(
        "chain-receipts",
        "POST",
        { ...input, stage: "decoded" },
        cookie,
      )
    ).status,
  ).toBe(200);
  expect(
    (
      await db.query(
        "SELECT rendered_state FROM chain_ui_receipts WHERE signature=$1",
        [signature],
      )
    ).rows,
  ).toEqual([{ rendered_state: "candidate" }]);
  await db.query(
    "UPDATE chain_candidates SET status='decoded' WHERE signature=$1",
    [signature],
  );
  expect(
    (
      await request(
        "chain-receipts",
        "POST",
        { ...input, stage: "decoded" },
        cookie,
      )
    ).status,
  ).toBe(200);
  expect(
    (
      await db.query(
        "SELECT count(*)::int AS n FROM chain_ui_receipts WHERE signature=$1",
        [signature],
      )
    ).rows[0].n,
  ).toBe(2);
  expect(
    (
      await request(
        "chain-receipts",
        "POST",
        { ...input, stage: "decoded", renderedAt: "2000-01-01T00:00:00.000Z" },
        cookie,
      )
    ).status,
  ).toBe(400);
  await db.query("DELETE FROM chain_ui_receipts WHERE signature=$1", [
    signature,
  ]);
  await db.query("DELETE FROM chain_candidates WHERE signature=$1", [
    signature,
  ]);
});
