import { beforeAll, afterAll, it, expect } from "vitest";
import { db, migrate } from "../../lib/db";
import { openStream, streamStats } from "../../lib/stream";
import { ingest } from "../../lib/ingestion";
import { observation } from "../helpers";
import { poolKey } from "../../lib/domain";
beforeAll(async () => {
  await migrate();
});
afterAll(async () => {
  await db.end();
});
it("publishes real connection state and releases a disconnected stream", async () => {
  const abort = new AbortController();
  const response = await openStream(
    new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
  );
  expect(response.headers.get("content-type")).toContain("text/event-stream");
  const reader = response.body!.getReader();
  const first = new TextDecoder().decode((await reader.read()).value);
  expect(first).toContain("event: status");
  expect(first).toContain("polling");
  expect(streamStats().connections).toBe(1);
  abort.abort();
  await reader.cancel();
  expect(streamStats().connections).toBe(0);
});
it("does not repeatedly publish the same submillisecond database update", async () => {
  await db.query("TRUNCATE tokens RESTART IDENTITY CASCADE");
  await ingest([observation()]);
  await db.query(
    "UPDATE pools SET updated_at=date_trunc('milliseconds',clock_timestamp())+interval '100 microseconds'",
  );
  const abort = new AbortController(),
    response = await openStream(
      new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
    );
  const reader = response.body!.getReader(),
    decoder = new TextDecoder();
  await reader.read();
  expect(decoder.decode((await reader.read()).value)).toContain(
    "event: update",
  );
  const next = reader.read();
  const value = await Promise.race([
    next.then((v) => decoder.decode(v.value)),
    new Promise<string>((r) => setTimeout(() => r("no-change"), 3200)),
  ]);
  abort.abort();
  await reader.cancel();
  expect(value).toBe("no-change");
});
it("publishes a later-committed row whose update timestamp precedes an already published transaction", async () => {
  await db.query("TRUNCATE tokens RESTART IDENTITY CASCADE");
  const a = observation(),
    mint = "So11111111111111111111111111111111111111112";
  const b = { ...a, mint, id: poolKey(mint, a.poolId) };
  await ingest([a, b]);
  const abort = new AbortController(),
    res = await openStream(
      new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
    );
  const reader = res.body!.getReader(),
    decode = new TextDecoder();
  await reader.read();
  await reader.read();
  const slow = await db.connect();
  try {
    await slow.query("BEGIN");
    await slow.query(
      "UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1",
      [a.id],
    );
    await db.query(
      "UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1",
      [b.id],
    );
    expect(decode.decode((await reader.read()).value)).toContain(b.id);
    await slow.query("COMMIT");
    expect(decode.decode((await reader.read()).value)).toContain(a.id);
  } finally {
    await slow.query("ROLLBACK");
    slow.release();
    abort.abort();
    await reader.cancel();
  }
});
it("publishes a committed change within 700 ms instead of waiting for the polling interval", async () => {
  await db.query("TRUNCATE tokens RESTART IDENTITY CASCADE");
  const row = observation();
  await ingest([row]);
  const abort = new AbortController();
  const res = await openStream(
    new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
  );
  const reader = res.body!.getReader();
  await reader.read();
  await reader.read();
  await db.query("UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1", [
    row.id,
  ]);
  const value = await Promise.race([
    reader.read().then((r) => new TextDecoder().decode(r.value)),
    new Promise<string>((r) => setTimeout(() => r("timed-out"), 700)),
  ]);
  abort.abort();
  await reader.cancel();
  expect(value).toContain(row.id);
  expect(value).toContain('"revisions"');
});
it("disconnects a slow consumer before the outgoing queue can grow without bound", async () => {
  const row = observation();
  await ingest([row]);
  const abort = new AbortController();
  const response = await openStream(
    new Request("http://localhost:3000/api/stream", { signal: abort.signal }),
  );
  const reader = response.body!.getReader();
  await reader.read();
  await reader.read();
  try {
    for (let i = 0; i < 38; i++) {
      await db.query(
        "UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1",
        [row.id],
      );
      await new Promise((r) => setTimeout(r, 75));
    }
    expect(streamStats().connections).toBe(0);
  } finally {
    abort.abort();
    await reader.cancel();
  }
});

it.each([1, 5, 20])(
  "reconciles %i independent clients and a reconnect without losing the final revision",
  async (count) => {
    await db.query("TRUNCATE tokens RESTART IDENTITY CASCADE");
    const row = observation();
    await ingest([row]);
    const clients: {
      abort: AbortController;
      reader: ReadableStreamDefaultReader<Uint8Array>;
      cookie: string;
      lastId?: string;
    }[] = [];
    try {
      for (let i = 0; i < count; i++) {
        const abort = new AbortController();
        const response = await openStream(
          new Request("http://localhost:3000/api/stream", {
            signal: abort.signal,
          }),
        );
        expect(response.status).toBe(200);
        const reader = response.body!.getReader();
        clients.push({
          abort,
          reader,
          cookie: response.headers.get("set-cookie")!.split(";")[0],
        });
        await reader.read();
        const baseline = new TextDecoder().decode((await reader.read()).value);
        expect(baseline).toContain(row.id);
      }
      await db.query(
        "UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1",
        [row.id],
      );
      const revision = (
        await db.query("SELECT revision::text FROM pools WHERE id=$1", [row.id])
      ).rows[0].revision;
      await Promise.all(
        clients.map(async (c) => {
          const message = new TextDecoder().decode(
            (await c.reader.read()).value,
          );
          expect(message).toContain(`"${row.id}":"${revision}"`);
          c.lastId = /^id: (.+)$/m.exec(message)?.[1];
          expect(c.lastId).toBeTruthy();
        }),
      );
      const previous = clients[0];
      previous.abort.abort();
      await previous.reader.cancel();
      await db.query(
        "UPDATE pools SET updated_at=clock_timestamp() WHERE id=$1",
        [row.id],
      );
      const abort = new AbortController();
      const response = await openStream(
        new Request("http://localhost:3000/api/stream", {
          signal: abort.signal,
          headers: {
            cookie: previous.cookie,
            "last-event-id": previous.lastId!,
          },
        }),
      );
      const reader = response.body!.getReader();
      clients.push({ abort, reader, cookie: previous.cookie });
      expect(new TextDecoder().decode((await reader.read()).value)).toContain(
        '"resumed":true',
      );
      expect(new TextDecoder().decode((await reader.read()).value)).toContain(
        row.id,
      );
    } finally {
      for (const c of clients) {
        c.abort.abort();
        await c.reader.cancel();
      }
    }
    expect(streamStats().connections).toBe(0);
  },
);
