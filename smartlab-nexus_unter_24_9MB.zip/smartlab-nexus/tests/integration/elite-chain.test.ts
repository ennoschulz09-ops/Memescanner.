import { beforeAll, beforeEach, afterAll, it, expect } from "vitest";
import { db, migrate } from "../../lib/db";
import { ProgramFeed } from "../../worker/chain-feed";
import { SolanaProvider } from "../../lib/providers/solana";
import { HttpClient } from "../../lib/providers/http";
import { CPMM_PROGRAM } from "../../lib/providers/pool-init";
import bs58 from "bs58";
import { createHash } from "node:crypto";
const sig = (n: number) => bs58.encode(Buffer.alloc(64, n));
const accounts = Array.from({ length: 20 }, (_, i) =>
  bs58.encode(Buffer.alloc(32, i + 1)),
);
const tx = {
  slot: 123,
  blockTime: 1780000000,
  meta: { err: null },
  transaction: {
    message: {
      instructions: [
        {
          programId: CPMM_PROGRAM,
          accounts,
          data: bs58.encode(
            Buffer.concat([
              createHash("sha256")
                .update("global:initialize")
                .digest()
                .subarray(0, 8),
              Buffer.alloc(24),
            ]),
          ),
        },
      ],
    },
  },
};
function feed(response: (signature: string) => unknown) {
  return new ProgramFeed(
    new SolanaProvider(
      new HttpClient(
        async (_url, init) =>
          new Response(
            JSON.stringify(response(JSON.parse(String(init?.body)).params[0])),
          ),
      ),
    ),
  );
}
async function add(n: number, replay = false) {
  await db.query(
    "INSERT INTO chain_candidates(signature,slot,from_replay,observed_at,next_attempt_at) VALUES($1,123,$2,clock_timestamp()-($3*interval '1 minute'),clock_timestamp()-($3*interval '1 minute'))",
    [sig(n), replay, 60 - n],
  );
}
beforeAll(() => migrate());
beforeEach(() =>
  db.query(
    "TRUNCATE chain_candidates,chain_candidate_attempts,chain_feed_cursors,discoveries",
  ),
);
afterAll(async () => {
  await db.query(
    "TRUNCATE chain_candidates,chain_candidate_attempts,chain_feed_cursors,discoveries",
  );
  await db.end();
});
it("dead-letters an unsupported transaction without blocking the following valid candidate", async () => {
  await add(1);
  await add(2);
  const worker = feed((s) =>
    s === sig(1)
      ? { error: { code: -32015, message: "Unsupported transaction version" } }
      : { result: tx },
  );
  try {
    await expect(worker.processCandidate()).resolves.toBeUndefined();
    await worker.processCandidate();
    const rows = (
      await db.query(
        "SELECT status,terminal_reason,attempt_count FROM chain_candidates ORDER BY observed_at",
      )
    ).rows;
    expect(rows).toMatchObject([
      {
        status: "dead-letter",
        terminal_reason: "unsupported_transaction_version",
        attempt_count: 1,
      },
      { status: "decoded", attempt_count: 1 },
    ]);
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(2);
  } finally {
    await worker.stop();
  }
});
it("does not starve old replay behind newly observed live candidates", async () => {
  await add(1, true);
  await add(2, false);
  const worker = feed(() => ({ result: tx }));
  try {
    await worker.processCandidate();
    expect(
      (
        await db.query(
          "SELECT processed_at FROM chain_candidates WHERE signature=$1",
          [sig(1)],
        )
      ).rows[0].processed_at,
    ).toBeTruthy();
  } finally {
    await worker.stop();
  }
});
it("persists null-result retry reasons and bounds poison candidates across process instances", async () => {
  await add(1);
  for (let attempt = 0; attempt < 5; attempt++) {
    const worker = feed(() => ({ result: null }));
    try {
      await worker.processCandidate();
    } finally {
      await worker.stop();
    }
    await db.query(
      "UPDATE chain_candidates SET next_attempt_at=clock_timestamp()-interval '1 second'",
    );
  }
  const row = (
    await db.query(
      "SELECT status,attempt_count,terminal_reason,retry_reason FROM chain_candidates",
    )
  ).rows[0];
  expect(row).toMatchObject({
    status: "dead-letter",
    attempt_count: 5,
    terminal_reason: "retry_exhausted:transaction_not_available",
    retry_reason: "transaction_not_available",
  });
});
it("claims each candidate once under concurrent dequeue and publishes idempotently after restart", async () => {
  await add(1);
  const workers = [feed(() => ({ result: tx })), feed(() => ({ result: tx }))];
  try {
    await Promise.all(workers.map((w) => w.processCandidate()));
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(2);
    const row = (
      await db.query(
        "SELECT attempt_count,decoder_version,observed_at,fetched_at,event_at FROM chain_candidates",
      )
    ).rows[0];
    expect(row.attempt_count).toBe(1);
    expect(row.decoder_version).toBe("raydium-cpmm-initialize-v1");
    expect(row.observed_at.getTime()).toBeLessThan(row.fetched_at.getTime());
    expect(row.event_at.toISOString()).toBe("2026-05-28T20:26:40.000Z");
    await db.query(
      "UPDATE chain_candidates SET processed_at=NULL,status='pending',next_attempt_at=clock_timestamp()",
    );
    await workers[0].processCandidate();
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(2);
  } finally {
    await Promise.all(workers.map((w) => w.stop()));
  }
});
it("reclaims an expired crash lease without allowing the stale attempt to complete", async () => {
  await add(1);
  const worker = feed(() => ({ result: tx }));
  try {
    await db.query(
      "UPDATE chain_candidates SET lease_until=clock_timestamp()-interval '1 second',lease_token='old',status='processing',attempt_count=1",
    );
    await worker.processCandidate();
    expect(
      (
        await db.query(
          "SELECT status,attempt_count,lease_token FROM chain_candidates",
        )
      ).rows[0],
    ).toMatchObject({ status: "decoded", attempt_count: 2, lease_token: null });
  } finally {
    await worker.stop();
  }
});
it("keeps provider Retry-After without exhausting candidate failures and allows other due work", async () => {
  await add(1);
  await add(2);
  const limited = new ProgramFeed(
    new SolanaProvider(
      new HttpClient(
        async () =>
          new Response("limited", {
            status: 429,
            headers: { "Retry-After": "600" },
          }),
      ),
    ),
  );
  const valid = feed(() => ({ result: tx }));
  try {
    const before = Date.now();
    await limited.processCandidate();
    const row = (
      await db.query(
        "SELECT status,failure_count,retry_reason,next_attempt_at FROM chain_candidates WHERE signature=$1",
        [sig(1)],
      )
    ).rows[0];
    expect(row).toMatchObject({
      status: "retry",
      failure_count: 0,
      retry_reason: "provider_rate_limited",
    });
    expect(row.next_attempt_at.getTime() - before).toBeGreaterThanOrEqual(
      600000,
    );
    await valid.processCandidate();
    expect(
      (
        await db.query(
          "SELECT status FROM chain_candidates WHERE signature=$1",
          [sig(2)],
        )
      ).rows[0].status,
    ).toBe("decoded");
  } finally {
    await limited.stop();
    await valid.stop();
  }
});
it("rejects invalid decoder fixtures without publishing invented discoveries", async () => {
  await add(1);
  const worker = feed(() => ({
    result: {
      ...tx,
      transaction: {
        message: {
          instructions: [
            {
              ...tx.transaction.message.instructions[0],
              accounts: accounts.slice(0, 6),
            },
          ],
        },
      },
    },
  }));
  try {
    await worker.processCandidate();
    expect(
      (await db.query("SELECT status,terminal_reason FROM chain_candidates"))
        .rows[0],
    ).toMatchObject({
      status: "rejected",
      terminal_reason: "no_supported_initialization",
    });
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(0);
  } finally {
    await worker.stop();
  }
});
it("keeps admission bounded, deduplicates a full queue, and persists cursor and drop evidence", async () => {
  const { observeChainLog, getChainQueueHealth } =
    await import("../../lib/chain-queue");
  for (let n = 1; n <= 256; n++)
    await observeChainLog(
      `test-candidate-${n}`,
      n,
      "2026-10-23T12:00:00.000Z",
      true,
    );
  await observeChainLog(
    "test-candidate-1",
    1,
    "2026-10-23T12:01:00.000Z",
    true,
  );
  await observeChainLog("test-overflow", 257, "2026-10-23T12:02:00.000Z", true);
  await observeChainLog(
    "old-replay",
    12,
    "2026-10-23T11:00:00.000Z",
    false,
    true,
  );
  const health = await getChainQueueHealth();
  expect(health).toMatchObject({
    version: 1,
    pending: 256,
    deadLetter: 0,
    dropped: 1,
    cursor: {
      signature: "test-overflow",
      slot: 257,
      observedAt: "2026-10-23T12:02:00.000Z",
      coverageGaps: 1,
    },
  });
  expect(health.oldestAgeSeconds).toBeGreaterThan(0);
});
it("reports measured dequeue and the last versioned discovery with preserved observation time", async () => {
  await add(1);
  const worker = feed(() => ({ result: { ...tx, version: 1 } }));
  try {
    await worker.processCandidate();
    const { getChainQueueHealth } = await import("../../lib/chain-queue");
    const health = await getChainQueueHealth();
    expect(health).toMatchObject({
      pending: 0,
      deadLetter: 0,
      dequeueRate: { windowSeconds: 300, attempts: 1, perMinute: 0.2 },
      oldestAgeSeconds: null,
      lastRealDiscovery: {
        signature: sig(1),
        slot: 123,
        decoderVersion: "raydium-cpmm-initialize-v1",
      },
    });
    const provenance = (
      await db.query("SELECT provenance FROM discoveries LIMIT 1")
    ).rows[0].provenance;
    expect(provenance.latencyMs).toBeGreaterThan(0);
    const persistence = (
      await db.query(
        "SELECT duration_ms FROM metrics WHERE stage='discovery_persist' ORDER BY at DESC LIMIT 1",
      )
    ).rows[0];
    expect(persistence.duration_ms).toBeLessThan(60000);
    const candidate = (
      await db.query("SELECT observed_at FROM chain_candidates")
    ).rows[0];
    const discoveries = (await db.query("SELECT observed_at FROM discoveries"))
      .rows;
    expect(discoveries.map((r) => r.observed_at.toISOString())).toEqual([
      candidate.observed_at.toISOString(),
      candidate.observed_at.toISOString(),
    ]);
  } finally {
    await worker.stop();
  }
});
it("prevents an expired worker from overwriting a newer successful lease", async () => {
  await add(1);
  let release: () => void = () => {};
  let entered: () => void = () => {};
  const started = new Promise<void>((resolve) => {
    entered = resolve;
  });
  const hold = new Promise<void>((resolve) => {
    release = resolve;
  });
  const stale = new ProgramFeed(
    new SolanaProvider(
      new HttpClient(async () => {
        entered();
        await hold;
        return new Response(JSON.stringify({ result: null }));
      }),
    ),
  );
  const current = feed(() => ({ result: tx }));
  try {
    const pending = stale.processCandidate();
    await started;
    await db.query(
      "UPDATE chain_candidates SET lease_until=clock_timestamp()-interval '1 second'",
    );
    await current.processCandidate();
    release();
    await pending;
    expect(
      (await db.query("SELECT status,attempt_count FROM chain_candidates"))
        .rows[0],
    ).toMatchObject({ status: "decoded", attempt_count: 2 });
    expect(
      (
        await db.query(
          "SELECT outcome FROM chain_candidate_attempts ORDER BY started_at",
        )
      ).rows.map((r) => r.outcome),
    ).toEqual(["lease-expired", "decoded"]);
  } finally {
    release();
    await stale.stop();
    await current.stop();
  }
});
it("coalesces non-initialize log bursts into a durable cursor without dropping pool candidates", async () => {
  const worker = feed(() => ({ result: tx }));
  for (let n = 1; n <= 100; n++)
    worker.observe({
      method: "logsNotification",
      params: {
        result: {
          context: { slot: n },
          value: { signature: sig(n), err: null, logs: [] },
        },
      },
    });
  await worker.stop();
  const { getChainQueueHealth } = await import("../../lib/chain-queue");
  expect(await getChainQueueHealth()).toMatchObject({
    pending: 0,
    dropped: 0,
    cursor: { slot: 100, signature: sig(100) },
  });
});
it("sends bounded replay as a two-parameter read-only RPC request", async () => {
  const worker = new ProgramFeed(
    new SolanaProvider(
      new HttpClient(async (_url, init) => {
        expect(JSON.parse(String(init?.body))).toMatchObject({
          method: "getSignaturesForAddress",
          params: [
            CPMM_PROGRAM,
            { commitment: "confirmed", limit: 20, until: null },
          ],
        });
        return new Response(JSON.stringify({ result: [] }));
      }),
    ),
  );
  try {
    await worker["replay"]();
  } finally {
    await worker.stop();
  }
});
it("ignores queued websocket notifications after shutdown", async () => {
  const worker = feed(() => ({ result: tx }));
  try {
    await worker.stop();
    worker.observe({
      method: "logsNotification",
      params: {
        result: {
          context: { slot: 999 },
          value: { signature: sig(1), err: null, logs: [] },
        },
      },
    });
    expect(worker.snapshot().lastSignature).toBeNull();
  } finally {
    await worker.stop();
  }
});
it("does not checkpoint past an initialization whose candidate admission rolled back", async () => {
  const { observeChainLog } = await import("../../lib/chain-queue");
  await observeChainLog(sig(90), 90, "2026-10-23T12:00:00.000Z", false);
  await db.query(
    "CREATE OR REPLACE FUNCTION nexus_test_fail_chain_admission() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Injected admission rollback'; END $$",
  );
  await db.query(
    "CREATE TRIGGER nexus_test_fail_chain_admission BEFORE INSERT ON chain_candidates FOR EACH ROW EXECUTE FUNCTION nexus_test_fail_chain_admission()",
  );
  const worker = feed(() => ({ result: tx }));
  try {
    worker.observe({
      method: "logsNotification",
      params: {
        result: {
          context: { slot: 91 },
          value: {
            signature: sig(91),
            err: null,
            logs: [
              `Program ${CPMM_PROGRAM} invoke [1]`,
              "Program log: Instruction: Initialize",
            ],
          },
        },
      },
    });
    worker.observe({
      method: "logsNotification",
      params: {
        result: {
          context: { slot: 92 },
          value: { signature: sig(92), err: null, logs: [] },
        },
      },
    });
    await worker.stop();
    const cursor = (
      await db.query(
        "SELECT signature,coverage_gaps FROM chain_feed_cursors WHERE program_id=$1",
        [CPMM_PROGRAM],
      )
    ).rows[0];
    expect(cursor.signature).toBe(sig(90));
    expect(Number(cursor.coverage_gaps)).toBeGreaterThanOrEqual(1);
    expect(
      (await db.query("SELECT count(*)::int AS n FROM chain_candidates"))
        .rows[0].n,
    ).toBe(0);
    expect(worker.snapshot().lastSignature).not.toBe(sig(91));
    expect(worker.snapshot().lastSignature).not.toBe(sig(92));
  } finally {
    await worker.stop();
    await db.query(
      "DROP TRIGGER IF EXISTS nexus_test_fail_chain_admission ON chain_candidates",
    );
    await db.query("DROP FUNCTION IF EXISTS nexus_test_fail_chain_admission()");
  }
});

it("rolls discovery publication back when fenced completion fails, then recovers idempotently", async () => {
  await add(1);
  await db.query(`CREATE OR REPLACE FUNCTION nexus_test_completion_failure() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN IF NEW.status='decoded' THEN RAISE EXCEPTION 'injected completion failure'; END IF; RETURN NEW; END $$`);
  await db.query(
    "CREATE TRIGGER nexus_test_completion_failure BEFORE UPDATE ON chain_candidates FOR EACH ROW EXECUTE FUNCTION nexus_test_completion_failure()",
  );
  const worker = feed(() => ({ result: tx }));
  try {
    await worker.processCandidate();
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(0);
    expect(
      (await db.query("SELECT status FROM chain_candidates")).rows[0].status,
    ).toBe("retry");
    await db.query(
      "DROP TRIGGER nexus_test_completion_failure ON chain_candidates",
    );
    await db.query(
      "UPDATE chain_candidates SET next_attempt_at=clock_timestamp()",
    );
    await worker.processCandidate();
    expect(
      (await db.query("SELECT count(*)::int AS n FROM discoveries")).rows[0].n,
    ).toBe(2);
    expect(
      (await db.query("SELECT status FROM chain_candidates")).rows[0].status,
    ).toBe("decoded");
  } finally {
    await worker.stop();
    await db.query(
      "DROP TRIGGER IF EXISTS nexus_test_completion_failure ON chain_candidates",
    );
    await db.query("DROP FUNCTION IF EXISTS nexus_test_completion_failure()");
  }
});
it("absorbs fifty initialize logs and duplicates without the old four-admission burst loss", async () => {
  const worker = feed(() => ({ result: tx }));
  for (let n = 1; n <= 50; n++)
    for (let duplicate = 0; duplicate < 2; duplicate++)
      worker.observe({
        method: "logsNotification",
        params: {
          result: {
            context: { slot: n },
            value: {
              signature: sig(n),
              err: null,
              logs: [
                `Program ${CPMM_PROGRAM} invoke [1]`,
                "Program log: Instruction: Initialize",
              ],
            },
          },
        },
      });
  await worker.stop();
  expect(
    (await db.query("SELECT count(*)::int AS n FROM chain_candidates")).rows[0]
      .n,
  ).toBe(50);
  const { getChainQueueHealth } = await import("../../lib/chain-queue");
  expect(await getChainQueueHealth()).toMatchObject({
    pending: 50,
    dropped: 0,
    cursor: { slot: 50 },
  });
});
