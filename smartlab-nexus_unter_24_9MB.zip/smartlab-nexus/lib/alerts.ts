export type AlertKind =
  | "new_token"
  | "new_pool"
  | "liquidity_change"
  | "concentration_increase"
  | "feed_outage"
  | "risk_flag"
  | "watchlist_activity";
export interface AlertRule {
  kind: AlertKind;
  threshold: number;
  cooldownSeconds: number;
  quotaPerHour: number;
  quietStart: number | null;
  quietEnd: number | null;
  enabled: boolean;
  mint: string | null;
  debounceSeconds?: number;
}
export interface ResearchEvent {
  kind: AlertKind;
  mint: string | null;
  key: string;
  value: number;
  at: string;
  [key: string]: unknown;
}
export interface AlertHistory {
  key: string;
  at: string;
}
export function isQuiet(now: Date, start: number | null, end: number | null) {
  if (start === null || end === null || start === end) return false;
  const h = now.getUTCHours();
  return start < end ? h >= start && h < end : h >= start || h < end;
}
export function shouldAlert(
  rule: AlertRule,
  event: ResearchEvent,
  history: AlertHistory[],
  now = new Date(),
): boolean {
  if (
    !rule.enabled ||
    rule.kind !== event.kind ||
    (rule.mint && rule.mint !== event.mint)
  )
    return false;
  const occurred = new Date(event.at);
  if (
    !Number.isFinite(occurred.getTime()) ||
    isQuiet(occurred, rule.quietStart, rule.quietEnd) ||
    isQuiet(now, rule.quietStart, rule.quietEnd)
  )
    return false;
  if (history.some((x) => x.key === event.key)) return false;
  if (
    history.some(
      (x) => now.getTime() - Date.parse(x.at) < rule.cooldownSeconds * 1000,
    )
  )
    return false;
  if (
    history.filter((x) => now.getTime() - Date.parse(x.at) < 3600000).length >=
    rule.quotaPerHour
  )
    return false;
  if (
    ["liquidity_change", "concentration_increase"].includes(rule.kind) &&
    Math.abs(event.value) < rule.threshold
  )
    return false;
  if (rule.kind === "watchlist_activity" && event.value < rule.threshold)
    return false;
  return true;
}
