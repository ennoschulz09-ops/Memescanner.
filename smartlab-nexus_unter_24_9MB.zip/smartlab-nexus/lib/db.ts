import pg from "pg";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { ProviderError } from "./providers/http";
import type { Provider } from "./domain";

const globalDb = globalThis as unknown as { nexusDb?: pg.Pool };
export const db =
  globalDb.nexusDb ??
  new pg.Pool({
    connectionString:
      process.env.DATABASE_URL ||
      "postgresql://nexus:nexus_local_only@localhost:5432/nexus",
    max: 12,
    connectionTimeoutMillis: 3000,
    idleTimeoutMillis: 30000,
    statement_timeout: 10000,
  });
globalDb.nexusDb = db;
db.on("error", () => {
  console.error(
    JSON.stringify({
      level: "error",
      event: "db_connection_error",
      at: new Date().toISOString(),
    }),
  );
});
export async function migrate() {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(823714)");
    for (const file of (await readdir(path.join(process.cwd(), "db")))
      .filter((x) => /^\d+_.*\.sql$/.test(x))
      .sort()) {
      await client.query(
        await readFile(path.join(process.cwd(), "db", file), "utf8"),
      );
      await client.query(
        "INSERT INTO migrations(name) VALUES($1) ON CONFLICT DO NOTHING",
        [file.replace(/\.sql$/, "")],
      );
    }
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}
export const budgetLimits: Record<string, number> = {
  gecko: 8,
  "dex-profiles": 6,
  "dex-market": 30,
  solana: 30,
};
export async function claimBudget(provider: Provider, channel: string) {
  const limit = budgetLimits[channel];
  if (!limit) throw new Error("Unbekannter Budgetkanal");
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      "SELECT pg_advisory_xact_lock(hashtextextended('budget:'||$1,0))",
      [channel],
    );
    const state = (
      await client.query(
        "SELECT retry_at FROM provider_states WHERE provider=$1",
        [provider],
      )
    ).rows[0];
    if (state?.retry_at && new Date(state.retry_at).getTime() > Date.now())
      throw new ProviderError(
        provider,
        429,
        new Date(state.retry_at).getTime() - Date.now(),
        "Anbieter-Backoff aktiv",
      );
    await client.query(
      "DELETE FROM provider_budget_claims WHERE channel=$1 AND at<clock_timestamp()-interval '60 seconds'",
      [channel],
    );
    const window = (
      await client.query(
        "SELECT count(*)::int as used,min(at) as oldest FROM provider_budget_claims WHERE channel=$1",
        [channel],
      )
    ).rows[0];
    if (window.used >= limit)
      throw new ProviderError(
        provider,
        429,
        Math.max(1, new Date(window.oldest).getTime() + 60000 - Date.now()),
        "Lokales Anbieterbudget ausgeschöpft",
      );
    await client.query(
      "INSERT INTO provider_budget_claims(channel) VALUES($1)",
      [channel],
    );
    await client.query(
      "INSERT INTO provider_budgets(channel,used) VALUES($1,$2) ON CONFLICT(channel) DO UPDATE SET used=$2,window_start=clock_timestamp()",
      [channel, window.used + 1],
    );
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}
export async function auditRequest(e: {
  provider: Provider;
  endpoint: string;
  ok: boolean;
  status: number;
  latencyMs: number;
  error: string | null;
  retryAfterMs: number;
}) {
  await db.query(
    "INSERT INTO source_audits(provider,endpoint,ok,status,latency_ms,error) VALUES($1,$2,$3,$4,$5,$6)",
    [e.provider, e.endpoint, e.ok, e.status, e.latencyMs, e.error],
  );
  if (e.ok) {
    await db.query(
      `INSERT INTO provider_states(provider,status,last_success,latency_ms) VALUES($1,'ok',clock_timestamp(),$2)
      ON CONFLICT(provider) DO UPDATE SET status=CASE WHEN provider_states.retry_at>clock_timestamp() THEN provider_states.status ELSE 'ok' END,
      last_success=clock_timestamp(),latency_ms=$2,
      error=CASE WHEN provider_states.retry_at>clock_timestamp() THEN provider_states.error ELSE null END,
      consecutive_errors=CASE WHEN provider_states.retry_at>clock_timestamp() THEN provider_states.consecutive_errors ELSE 0 END,
      retry_at=CASE WHEN provider_states.retry_at>clock_timestamp() THEN provider_states.retry_at ELSE null END`,
      [e.provider, e.latencyMs],
    );
  } else {
    await db.query(
      `INSERT INTO provider_states(provider,status,last_error,error,latency_ms,consecutive_errors,retry_at) VALUES($1,$2,clock_timestamp(),$3,$4,1,clock_timestamp()+($5*interval '1 millisecond'))
      ON CONFLICT(provider) DO UPDATE SET status=$2,last_error=clock_timestamp(),error=$3,latency_ms=$4,consecutive_errors=provider_states.consecutive_errors+1,
      retry_at=GREATEST(provider_states.retry_at,clock_timestamp()+(GREATEST($5,LEAST(300000,5000*POWER(2,LEAST(provider_states.consecutive_errors,6)))+random()*3000)*interval '1 millisecond'))`,
      [
        e.provider,
        e.status === 429 ? "limited" : "error",
        e.error,
        e.latencyMs,
        Math.max(e.retryAfterMs, e.status === 429 ? 60000 : 5000),
      ],
    );
  }
}
export async function metric(stage: string, durationMs: number) {
  if (Number.isFinite(durationMs) && durationMs >= 0)
    await db.query("INSERT INTO metrics(stage,duration_ms) VALUES($1,$2)", [
      stage,
      Math.min(durationMs, 86400000),
    ]);
}
export async function countService(name: string) {
  await db.query(
    "INSERT INTO service_counters(name,value) VALUES($1,1) ON CONFLICT(name) DO UPDATE SET value=service_counters.value+1",
    [name],
  );
}
