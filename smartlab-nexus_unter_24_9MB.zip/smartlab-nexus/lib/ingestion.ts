import { randomUUID } from "node:crypto";
import { db, metric } from "./db";
import {
  isAddress,
  poolKey,
  type Observation,
  type PoolRow,
  type ChainEvidence,
  type ProviderState,
} from "./domain";
import { scoreRisk } from "./risk";
import { shouldAlert, type AlertRule, type ResearchEvent } from "./alerts";
import { withFieldEvidence } from "./value-evidence";
import { flushDebouncedAlerts } from "./alert-debounce";
import { freshnessBudgets } from "./freshness-config";
import { getChainQueueHealth } from "./chain-queue";

export async function ingest(
  observations: Observation[],
): Promise<{ updated: number; events: ResearchEvent[]; ids: string[] }> {
  const start = performance.now();
  const client = await db.connect();
  const events: ResearchEvent[] = [];
  const ids = new Set<string>();
  try {
    await client.query("BEGIN");
    for (const raw of [...observations].sort((a, b) =>
      a.id.localeCompare(b.id),
    )) {
      const o = withFieldEvidence(raw);
      if (
        !isAddress(o.mint) ||
        !isAddress(o.poolId) ||
        o.id !== poolKey(o.mint, o.poolId)
      )
        throw new Error("Ungültige normalisierte Beobachtung");
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtextextended($1,0))",
        [o.id],
      );
      const token = await client.query(
        "INSERT INTO tokens(mint,name,symbol) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING mint",
        [o.mint, o.name, o.symbol],
      );
      const initial = scoreRisk(o, null, [o]);
      const newPool = await client.query(
        "INSERT INTO pools(id,mint,pool_id,selected,risk) VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING",
        [o.id, o.mint, o.poolId, o, initial],
      );
      const previous = (
        await client.query("SELECT selected,risk FROM pools WHERE id=$1", [
          o.id,
        ])
      ).rows[0];
      const old = (
        await client.query(
          "SELECT payload FROM observations WHERE pool_key=$1 AND provider=$2",
          [o.id, o.provenance.provider],
        )
      ).rows[0]?.payload as Observation | undefined;
      const saved = await client.query(
        `INSERT INTO observations(pool_key,provider,source_at,fetched_at,payload) VALUES($1,$2,$3,$4,$5)
        ON CONFLICT(pool_key,provider) DO UPDATE SET source_at=$3,fetched_at=$4,payload=$5 WHERE observations.source_at<$3 RETURNING pool_key`,
        [
          o.id,
          o.provenance.provider,
          o.provenance.sourceAt,
          o.provenance.fetchedAt,
          o,
        ],
      );
      if (!saved.rowCount) continue;
      await client.query(
        "INSERT INTO samples(pool_key,provider,source_at,payload) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING",
        [o.id, o.provenance.provider, o.provenance.sourceAt, o],
      );
      const sources = (
        await client.query(
          "SELECT payload FROM observations WHERE pool_key=$1 ORDER BY source_at DESC,provider",
          [o.id],
        )
      ).rows.map((x) => x.payload as Observation);
      const selected = withFieldEvidence(sources[0], sources);
      const chain = (
        await client.query("SELECT data FROM chain_evidence WHERE mint=$1", [
          o.mint,
        ])
      ).rows[0]?.data as ChainEvidence | undefined;
      const risk = scoreRisk(selected, chain ?? null, sources);
      const activitySamples = (
        await client.query(
          "SELECT payload FROM samples WHERE pool_key=$1 AND provider=$2 ORDER BY source_at DESC LIMIT 2",
          [o.id, selected.provenance.provider],
        )
      ).rows.map((r) => r.payload as Observation);
      await client.query(
        "UPDATE pools SET activity_increase_pct=$2 WHERE id=$1",
        [o.id, activityIncrease(activitySamples)],
      );
      await client.query(
        "UPDATE pools SET selected=$2,risk=$3,updated_at=clock_timestamp() WHERE id=$1",
        [o.id, selected, risk],
      );
      await client.query("UPDATE tokens SET name=$2,symbol=$3 WHERE mint=$1", [
        o.mint,
        selected.name,
        selected.symbol,
      ]);
      const changed =
        !old ||
        previous.risk.modelVersion !== risk.modelVersion ||
        JSON.stringify(
          previous.risk.signals.map((s: any) => [s.key, s.value, s.state]),
        ) !==
          JSON.stringify(risk.signals.map((s) => [s.key, s.value, s.state]));
      if (changed)
        await client.query(
          "INSERT INTO risk_audits(pool_key,report) VALUES($1,$2)",
          [o.id, risk],
        );
      const at = new Date().toISOString();
      if (newPool.rowCount)
        events.push({
          kind: "new_pool",
          mint: o.mint,
          key: `pool:${o.id}`,
          value: 1,
          at,
          poolId: o.poolId,
          source: o.provenance.provider,
          before: null,
          after: o.poolId,
          measuredAt: o.createdAt,
          limits:
            "Erstes Erfassen dieses Pools; keine bestätigte Mint-Erstellung.",
        });
      if (token.rowCount)
        events.push({
          kind: "new_token",
          mint: o.mint,
          key: `new:${o.mint}`,
          value: 1,
          at,
          poolId: o.poolId,
          symbol: o.symbol,
          source: o.provenance.provider,
          before: null,
          after: o.mint,
          measuredAt: o.provenance.measuredAt,
          observedAt: o.provenance.fetchedAt,
          limits:
            "Erstes Erfassen im eigenen Bestand; kein Nachweis der Mint-Erstellzeit.",
        });
      if (old?.liquidityUsd && o.liquidityUsd !== null) {
        const delta =
          ((o.liquidityUsd - old.liquidityUsd) / old.liquidityUsd) * 100;
        if (Math.abs(delta) >= 10)
          events.push({
            kind: "liquidity_change",
            mint: o.mint,
            key: `liq:${o.id}:${o.provenance.sourceAt}:${o.provenance.provider}`,
            value: delta,
            at,
            poolId: o.poolId,
            source: o.provenance.provider,
            before: old.liquidityUsd,
            after: o.liquidityUsd,
            measuredAt: o.provenance.measuredAt,
            observedAt: o.provenance.fetchedAt,
            limits:
              "Änderung zweier Provider-Beobachtungen; keine Aussage über die Ursache oder ausführbare Liquidität.",
          });
      }
      const newFlags = old
        ? risk.flags.filter(
            (x) => !previous.risk.flags.includes(x) && !x.includes("unbekannt"),
          )
        : [];
      if (newFlags.length)
        events.push({
          kind: "risk_flag",
          mint: o.mint,
          key: `risk:${o.id}:${o.provenance.sourceAt}`,
          value: newFlags.length,
          at,
          flags: newFlags,
          source: o.provenance.provider + " / Risikomodell",
          before: previous.risk.flags,
          after: risk.flags,
          measuredAt: o.provenance.measuredAt,
          observedAt: o.provenance.fetchedAt,
          limits:
            "Indikatoränderung aus Markt- und gegebenenfalls RPC-Evidenz; kein Betrugsnachweis. Einzelquellen und Alter stehen im Risiko-Audit.",
        });
      if (old && o.buys5m !== null && o.sells5m !== null)
        events.push({
          kind: "watchlist_activity",
          mint: o.mint,
          key: `activity:${o.id}:${o.provenance.sourceAt}`,
          value: o.buys5m + o.sells5m,
          at,
          source: o.provenance.provider,
          before:
            old.buys5m !== null && old.sells5m !== null
              ? old.buys5m + old.sells5m
              : null,
          after: o.buys5m + o.sells5m,
          measuredAt: o.provenance.measuredAt,
          observedAt: o.provenance.fetchedAt,
          limits:
            "Gemeldete rollierende 5-Minuten-Tradezahl; keine eindeutigen Wallets und kein Beweis neuer Einzeltransaktionen.",
        });
      ids.add(o.id);
      await client.query(
        "UPDATE discoveries SET hydrated_at=clock_timestamp(),error=NULL WHERE mint=$1 AND hydrated_at IS NULL",
        [o.mint],
      );
    }
    for (const e of events)
      await client.query(
        "INSERT INTO events(kind,mint,pool_key,payload,at) VALUES($1,$2,$3,$4,$5)",
        [e.kind, e.mint, null, e, e.at],
      );
    if (ids.size) {
      await client.query("SELECT pg_notify('nexus_update',$1)", [
        JSON.stringify({ at: new Date().toISOString(), count: ids.size }),
      ]);
    }
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
  if (ids.size)
    await metric("ingest_commit", performance.now() - start).catch(() => {});
  if (events.length)
    await processPendingAlerts().catch(() =>
      console.error(
        JSON.stringify({
          event: "alert_outbox_deferred",
          at: new Date().toISOString(),
        }),
      ),
    );
  return { updated: ids.size, events, ids: [...ids] };
}
export async function processAlerts(events: ResearchEvent[]) {
  if (!events.length) return;
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    const rules = (
      await client.query("SELECT * FROM alert_rules ORDER BY id FOR UPDATE")
    ).rows;
    for (const r of rules) {
      const rule = r.data as AlertRule & { watchlistId?: string | null };
      if (!rule.enabled) continue;
      const history = (
        await client.query(
          "SELECT event_key,at FROM alert_events WHERE rule_id=$1 ORDER BY at DESC LIMIT 1000",
          [r.id],
        )
      ).rows.map((x) => ({
        key: x.event_key,
        at: new Date(x.at).toISOString(),
      }));
      let allowedMints: Set<string> | null = null;
      if (rule.watchlistId) {
        allowedMints = new Set(
          (
            await client.query(
              "SELECT i.mint FROM watchlist_items i JOIN watchlists w ON w.id=i.list_id WHERE w.id=$1 AND w.owner=$2",
              [rule.watchlistId, r.owner],
            )
          ).rows.map((x) => x.mint),
        );
      }
      for (const e of events) {
        if (Date.parse(e.at) < new Date(r.created_at).getTime()) continue;
        if (allowedMints && (!e.mint || !allowedMints.has(e.mint))) continue;
        if (
          rule.kind === "watchlist_activity" &&
          !rule.watchlistId &&
          !rule.mint
        )
          continue;
        if (!shouldAlert(rule, e, history, new Date())) {
          if (rule.kind === e.kind)
            await client.query(
              "DELETE FROM alert_candidates WHERE rule_id=$1 AND topic=$2",
              [r.id, e.mint ?? String(e.source ?? "global")],
            );
          continue;
        }
        if (rule.debounceSeconds) {
          await client.query(
            "INSERT INTO alert_candidates(rule_id,topic,data,not_before) VALUES($1,$2,$3,clock_timestamp()+($4*interval '1 second')) ON CONFLICT(rule_id,topic) DO UPDATE SET data=$3,not_before=clock_timestamp()+($4*interval '1 second')",
            [
              r.id,
              e.mint ?? String(e.source ?? "global"),
              e,
              rule.debounceSeconds,
            ],
          );
          continue;
        }
        const saved = await client.query(
          "INSERT INTO alert_events(id,rule_id,owner,mint,event_key,data) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING id",
          [
            randomUUID(),
            r.id,
            r.owner,
            e.mint,
            e.key,
            { ...e, ruleName: r.name },
          ],
        );
        if (saved.rowCount)
          history.unshift({ key: e.key, at: new Date().toISOString() });
      }
    }
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}
export async function processPendingAlerts() {
  await flushDebouncedAlerts();
  const pending = (
    await db.query(
      "SELECT id,payload FROM events WHERE alerts_processed_at IS NULL ORDER BY id LIMIT 500",
    )
  ).rows;
  if (!pending.length) return 0;
  await processAlerts(pending.map((x) => x.payload as ResearchEvent));
  await db.query(
    "UPDATE events SET alerts_processed_at=clock_timestamp() WHERE id=ANY($1::bigint[])",
    [pending.map((x) => x.id)],
  );
  return pending.length;
}
export async function getPools(
  options: {
    since?: string;
    mint?: string;
    limit?: number;
    ids?: string[];
  } = {},
): Promise<PoolRow[]> {
  const params: unknown[] = [];
  const clauses: string[] = [];
  if (options.ids) {
    params.push(options.ids);
    clauses.push(`p.id=ANY($${params.length}::text[])`);
  }
  if (options.since) {
    params.push(options.since);
    clauses.push(`p.updated_at >= $${params.length}::timestamptz`);
  }
  if (options.mint) {
    params.push(options.mint);
    clauses.push(`p.mint = $${params.length}`);
  }
  params.push(Math.min(options.limit ?? 10000, 10000));
  const rows = (
    await db.query(
      `SELECT p.*,c.data as chain,
    (SELECT jsonb_agg(o.payload ORDER BY o.source_at DESC) FROM observations o WHERE o.pool_key=p.id) as sources,
    (SELECT jsonb_agg(h.item ORDER BY h.source_at) FROM (SELECT s.source_at,jsonb_build_object('at',s.source_at,'value',(s.payload->>'priceUsd')::double precision) as item FROM samples s WHERE s.pool_key=p.id AND s.provider=p.selected->'provenance'->>'provider' ORDER BY s.source_at DESC LIMIT 32) h) as sparkline,
    (SELECT jsonb_agg(h.payload ORDER BY h.source_at DESC) FROM (SELECT s.source_at,s.payload FROM samples s WHERE s.pool_key=p.id AND s.provider=p.selected->'provenance'->>'provider' ORDER BY s.source_at DESC LIMIT 2) h) as activity_samples
    FROM pools p LEFT JOIN chain_evidence c ON c.mint=p.mint ${clauses.length ? "WHERE " + clauses.join(" AND ") : ""} ORDER BY p.updated_at DESC LIMIT $${params.length}`,
      params,
    )
  ).rows;
  return rows.map((r) => ({
    ...withFieldEvidence(r.selected, r.sources ?? []),
    revision: String(r.revision),
    activityIncreasePct: activityIncrease(r.activity_samples ?? []),
    firstSeenAt: new Date(r.first_seen_at).toISOString(),
    updatedAt: new Date(r.updated_at).toISOString(),
    sources: r.sources ?? [],
    risk: scoreRisk(r.selected, r.chain ?? null, r.sources ?? []),
    sparkline: r.sparkline ?? [],
  }));
}
function activityIncrease(samples: Observation[]): number | null {
  if (
    samples.length < 2 ||
    samples.some((s) => s.buys5m === null || s.sells5m === null)
  )
    return null;
  const current = samples[0].buys5m! + samples[0].sells5m!,
    previous = samples[1].buys5m! + samples[1].sells5m!;
  return previous > 0 ? ((current - previous) / previous) * 100 : null;
}
export async function getHealth() {
  const counters = Object.fromEntries(
    (await db.query("SELECT name,value::int FROM service_counters")).rows.map(
      (x) => [x.name, x.value],
    ),
  );
  const [providers, counts, worker, budgets, metrics] = await Promise.all([
    db.query("SELECT * FROM provider_states"),
    db.query(
      `SELECT (SELECT count(DISTINCT pool_id)::int FROM pools) as pools,(SELECT count(*)::int FROM tokens) as tokens,
      (SELECT max(updated_at) FROM pools) as last_update,
      (SELECT count(*)::int FROM tokens WHERE first_seen_at>now()-interval '1 minute') as new1,
      (SELECT count(*)::int FROM tokens WHERE first_seen_at>now()-interval '5 minutes') as new5,
      (SELECT count(*)::int FROM tokens WHERE first_seen_at>now()-interval '15 minutes') as new15,
      (SELECT count(*)::int FROM pools WHERE selected->'provenance'->>'timestampKind' IS DISTINCT FROM 'retrieval-only' AND selected->'provenance'->>'sourceAt' IS NOT NULL AND NOT ((selected->'provenance'->>'sourceAt')::timestamptz BETWEEN now()-(COALESCE((selected->'provenance'->>'freshnessBudgetSeconds')::double precision,$1)*interval '1 second') AND now()+interval '60 seconds')) as stale`,
      [freshnessBudgets().market],
    ),
    db.query("SELECT * FROM worker_state WHERE id=1"),
    db.query(
      "SELECT channel,count(*)::int as used,min(at) as window_start FROM provider_budget_claims WHERE at>clock_timestamp()-interval '60 seconds' GROUP BY channel",
    ),
    db.query(
      "SELECT stage,count(*)::int as n,percentile_cont(0.5) WITHIN GROUP(ORDER BY duration_ms) as p50,percentile_cont(0.95) WITHIN GROUP(ORDER BY duration_ms) as p95,percentile_cont(0.99) WITHIN GROUP(ORDER BY duration_ms) as p99 FROM metrics WHERE at>now()-interval '1 hour' GROUP BY stage",
    ),
  ]);
  const toIso = (d: Date | null) => (d ? new Date(d).toISOString() : null);
  const states: ProviderState[] = (["gecko", "dex", "solana"] as const).map(
    (provider) => {
      const r = providers.rows.find((x) => x.provider === provider);
      return r
        ? {
            provider,
            status: r.status,
            lastSuccess: toIso(r.last_success),
            lastError: toIso(r.last_error),
            error: r.error,
            latencyMs: r.latency_ms,
            consecutiveErrors: r.consecutive_errors,
            retryAt: toIso(r.retry_at),
          }
        : {
            provider,
            status: "unknown",
            lastSuccess: null,
            lastError: null,
            error: null,
            latencyMs: null,
            consecutiveErrors: 0,
            retryAt: null,
          };
    },
  );
  const w = worker.rows[0];
  const discoveryCoverage = (
    await db.query(
      "SELECT provider,count(*)::int as discovered_mints,count(*) FILTER(WHERE hydrated_at IS NULL)::int as pending,count(event_at)::int as event_time_samples,percentile_cont(.5) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM (first_seen_at-event_at))*1000) FILTER(WHERE event_at<=first_seen_at) as first_seen_p50_ms,percentile_cont(.95) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM (first_seen_at-event_at))*1000) FILTER(WHERE event_at<=first_seen_at) as first_seen_p95_ms,percentile_cont(.99) WITHIN GROUP(ORDER BY EXTRACT(EPOCH FROM (first_seen_at-event_at))*1000) FILTER(WHERE event_at<=first_seen_at) as first_seen_p99_ms,max(EXTRACT(EPOCH FROM (clock_timestamp()-first_seen_at))) FILTER(WHERE hydrated_at IS NULL) as oldest_pending_seconds FROM discoveries GROUP BY provider",
    )
  ).rows;
  const workerFresh =
    !!w &&
    Date.now() - new Date(w.heartbeat).getTime() < 150000 &&
    !["error", "stopped"].includes(w.data.status);
  const marketFresh = states
    .filter((x) => x.provider !== "solana")
    .some(
      (x) =>
        x.status === "ok" &&
        x.lastSuccess &&
        Date.now() - Date.parse(x.lastSuccess) < 180000,
    );
  return {
    mode:
      workerFresh &&
      w.data.status !== "degraded" &&
      marketFresh &&
      states.every((x) => x.status === "ok")
        ? ("current" as const)
        : ("degraded" as const),
    database: "ok",
    dataMode:
      process.env.NEXUS_TEST_MODE === "true" ? "test-only" : "public-read-only",
    freshnessBudgets: freshnessBudgets(),
    chainQueue: await getChainQueueHealth(),
    discoveryCoverage,
    cache: {
      requests: counters.cache_requests ?? 0,
      hits: counters.cache_hits ?? 0,
      staleFallbacks: counters.cache_stale_fallbacks ?? 0,
      hitRate: counters.cache_requests
        ? (counters.cache_hits ?? 0) / counters.cache_requests
        : null,
    },
    providers: states,
    counts: counts.rows[0],
    worker: w
      ? { ...w.data, heartbeat: toIso(w.heartbeat), active: workerFresh }
      : null,
    budgets: budgets.rows.map((x) => ({
      channel: x.channel,
      used:
        Date.now() - new Date(x.window_start).getTime() < 60000 ? x.used : 0,
      windowStart: toIso(x.window_start),
    })),
    metrics: metrics.rows,
    at: new Date().toISOString(),
    coverage:
      "Ausgewählte neue Pools, Trend-Pools und Tokenprofile; keine vollständige Solana-Abdeckung. HTTP-Cache-Zeit ist keine garantierte Messzeit.",
  };
}
export async function saveEvidence(mint: string, evidence: ChainEvidence) {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    const previous = (
      await client.query(
        "SELECT data FROM chain_evidence WHERE mint=$1 FOR UPDATE",
        [mint],
      )
    ).rows[0]?.data as ChainEvidence | undefined;
    await client.query(
      "INSERT INTO chain_evidence(mint,data,checked_at) VALUES($1,$2,clock_timestamp()) ON CONFLICT(mint) DO UPDATE SET data=$2,checked_at=clock_timestamp()",
      [mint, evidence],
    );
    const before = previous?.concentration?.top1Pct,
      after = evidence.concentration?.top1Pct;
    if (
      before !== null &&
      before !== undefined &&
      after !== null &&
      after !== undefined &&
      after > before
    ) {
      const at = new Date().toISOString();
      const event: ResearchEvent = {
        kind: "concentration_increase",
        mint,
        key: `concentration:${mint}:${evidence.checkedAt}`,
        value: after - before,
        at,
        before,
        after,
        source: "solana",
        measuredAt: null,
        observedAt: evidence.checkedAt,
        beforeObservedAt: previous?.checkedAt,
        slot: evidence.slot,
        limits:
          "Anteil des größten Tokenkontos in Prozentpunkten; keine Owner-/Wallet-Zuordnung.",
      };
      await client.query(
        "INSERT INTO events(kind,mint,payload) VALUES($1,$2,$3)",
        [event.kind, mint, event],
      );
    }
    const pools = (
      await client.query(
        "SELECT p.*, (SELECT jsonb_agg(o.payload) FROM observations o WHERE o.pool_key=p.id) as sources FROM pools p WHERE mint=$1 ORDER BY p.id FOR UPDATE OF p",
        [mint],
      )
    ).rows;
    for (const p of pools) {
      const risk = scoreRisk(p.selected, evidence, p.sources ?? []);
      const flags = risk.flags.filter(
        (f) => !p.risk.flags.includes(f) && !f.includes("unbekannt"),
      );
      if (flags.length) {
        const event: ResearchEvent = {
          kind: "risk_flag",
          mint,
          key: `inspection:${p.id}:${evidence.checkedAt}`,
          value: flags.length,
          at: new Date().toISOString(),
          flags,
        };
        await client.query(
          "INSERT INTO events(kind,mint,pool_key,payload) VALUES($1,$2,$3,$4)",
          [event.kind, mint, p.id, event],
        );
      }
      await client.query(
        "UPDATE pools SET risk=$2,updated_at=clock_timestamp() WHERE id=$1",
        [p.id, risk],
      );
      await client.query(
        "INSERT INTO risk_audits(pool_key,report) VALUES($1,$2)",
        [p.id, risk],
      );
    }
    await client.query("SELECT pg_notify('nexus_update',$1)", [
      JSON.stringify({ at: new Date().toISOString(), count: pools.length }),
    ]);
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
  await processPendingAlerts().catch(() => {});
}
export async function rescorePools(now = Date.now()) {
  const client = await db.connect();
  let changed = 0;
  try {
    await client.query("BEGIN");
    const rows = (
      await client.query(
        "SELECT p.*,c.data as chain,(SELECT jsonb_agg(o.payload) FROM observations o WHERE o.pool_key=p.id) as sources FROM pools p LEFT JOIN chain_evidence c ON c.mint=p.mint ORDER BY p.id FOR UPDATE OF p",
      )
    ).rows;
    const signature = (r: PoolRow["risk"]) =>
      JSON.stringify([
        r.modelVersion ?? null,
        r.dataQuality,
        r.overall,
        r.coverage,
        r.flags,
        r.signals.map((s) => [s.key, s.value, s.state, s.weight, s.formula]),
      ]);
    for (const p of rows) {
      const risk = scoreRisk(p.selected, p.chain ?? null, p.sources ?? [], now);
      if (signature(risk) === signature(p.risk)) continue;
      await client.query(
        "UPDATE pools SET risk=$2,updated_at=clock_timestamp() WHERE id=$1",
        [p.id, risk],
      );
      await client.query(
        "INSERT INTO risk_audits(pool_key,report) VALUES($1,$2)",
        [p.id, risk],
      );
      changed++;
    }
    await client.query("COMMIT");
    return changed;
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}
