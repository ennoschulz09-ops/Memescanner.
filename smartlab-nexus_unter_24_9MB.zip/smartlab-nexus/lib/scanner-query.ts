import { db } from "./db";
import { getPools } from "./ingestion";
import type { Filters } from "./filters";
export const scannerSortKeys = [
  "firstSeenAt",
  "createdAt",
  "token",
  "symbol",
  "name",
  "mint",
  "dex",
  "chain",
  "priceUsd",
  "liquidityUsd",
  "volume5m",
  "volume1h",
  "volume24h",
  "change5m",
  "fdvUsd",
  "marketCapUsd",
  "trades",
  "ratio",
  "quality",
  "risk",
  "momentum",
  "sparkline",
] as const;
export async function scannerPage(input: {
  page: number;
  pageSize: number;
  sort: string;
  direction: "asc" | "desc";
  filters: Filters;
}) {
  const f = input.filters,
    params: unknown[] = [],
    where: string[] = [];
  const bind = (v: unknown) => {
    params.push(v);
    return `$${params.length}`;
  };
  const number = (field: string) =>
    `(p.selected->>'${field}')::double precision`;
  const relative = `${number("volume5m")}/NULLIF(${number("volume1h")}/12,0)`;
  const trades = `(${number("buys5m")}+${number("sells5m")})`;
  const concentration =
    "(jsonb_path_query_first(p.risk,'$.signals[*] ? (@.key == \"concentration\").value') #>> '{}')::double precision";
  const age = `EXTRACT(EPOCH FROM (clock_timestamp()-(p.selected->>'createdAt')::timestamptz))/60`;
  if (f.query)
    where.push(
      `position(lower(${bind(f.query.trim())}) in lower(concat_ws(' ',p.mint,p.pool_id,p.selected->>'name',p.selected->>'symbol')))>0`,
    );
  if (f.minLiquidity !== undefined)
    where.push(`${number("liquidityUsd")}>=${bind(f.minLiquidity)}`);
  if (f.maxPoolAgeMins !== undefined)
    where.push(`${age}<=${bind(f.maxPoolAgeMins)}`);
  if (f.minRelativeVolume !== undefined)
    where.push(`${relative}>=${bind(f.minRelativeVolume)}`);
  if (f.minActivity !== undefined)
    where.push(`${trades}>=${bind(f.minActivity)}`);
  if (f.maxConcentration !== undefined)
    where.push(`${concentration}<=${bind(f.maxConcentration)}`);
  if (f.minQuality !== undefined)
    where.push(
      `(p.risk->>'dataQuality')::double precision>=${bind(f.minQuality)}`,
    );
  if (f.dex) where.push(`p.selected->>'dex'=${bind(f.dex)}`);
  if (f.security) where.push(`p.risk->>'state'=${bind(f.security)}`);
  if (f.minActivityIncrease !== undefined)
    where.push(`p.activity_increase_pct>=${bind(f.minActivityIncrease)}`);
  if (f.preset === "new") where.push(`${age}<=60`);
  if (f.preset === "rising") where.push(`${relative}>=2`);
  if (f.preset === "liquidity") where.push(`${number("liquidityUsd")}>=100000`);
  if (f.preset === "quality")
    where.push(`(p.risk->>'dataQuality')::double precision<60`);
  if (f.preset === "critical") where.push(`p.risk->>'state'='critical'`);
  if (f.preset === "unusual")
    where.push(
      `p.risk @? '$.signals[*] ? (@.key == "activity" && (@.state == "notable" || @.state == "critical"))'`,
    );
  let sort: string;
  if (input.sort === "firstSeenAt") sort = "p.first_seen_at";
  else if (input.sort === "createdAt")
    sort = "(p.selected->>'createdAt')::timestamptz";
  else if (input.sort === "quality")
    sort = "(p.risk->>'dataQuality')::double precision";
  else if (input.sort === "risk")
    sort = "(p.risk->>'overall')::double precision";
  else if (input.sort === "trades") sort = trades;
  else if (input.sort === "ratio")
    sort = `${number("buys5m")}/NULLIF(${number("sells5m")},0)`;
  else if (input.sort === "token" || input.sort === "symbol")
    sort = "p.selected->>'symbol'";
  else if (["name", "mint", "dex", "chain"].includes(input.sort))
    sort = `p.selected->>'${input.sort}'`;
  else if (
    [
      "priceUsd",
      "liquidityUsd",
      "volume5m",
      "volume1h",
      "volume24h",
      "change5m",
      "fdvUsd",
      "marketCapUsd",
    ].includes(input.sort)
  )
    sort = number(input.sort);
  else if (input.sort === "momentum") sort = number("change5m");
  else if (input.sort === "sparkline") sort = number("priceUsd");
  else throw new Error("Ungültige Sortierung");
  const limit = bind(input.pageSize),
    offset = bind((input.page - 1) * input.pageSize);
  const result = (
    await db.query(
      `WITH filtered AS MATERIALIZED (SELECT p.id,${sort} as rank FROM pools p ${where.length ? "WHERE " + where.join(" AND ") : ""}), ordered AS (SELECT id FROM filtered ORDER BY rank ${input.direction === "asc" ? "ASC" : "DESC"} NULLS LAST,id LIMIT ${limit} OFFSET ${offset}) SELECT (SELECT count(*)::int FROM filtered) as total,COALESCE((SELECT jsonb_agg(id) FROM ordered),'[]'::jsonb) as ids`,
      params,
    )
  ).rows[0];
  const ids = result.ids as string[];
  const rows = ids.length ? await getPools({ ids, limit: input.pageSize }) : [];
  const byId = new Map(rows.map((r) => [r.id, r]));
  return {
    rows: ids.map((id) => byId.get(id)!).filter(Boolean),
    total: result.total,
    page: input.page,
    pageSize: input.pageSize,
    at: new Date().toISOString(),
    filterSemantics:
      "Risikofilter: zuletzt gespeicherte Bewertung; dargestellte Werte prüfen Frische erneut.",
  };
}
