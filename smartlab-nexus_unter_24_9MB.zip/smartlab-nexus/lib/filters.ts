import type { PoolRow } from "./domain";
export interface Filters {
  query?: string;
  preset?: string;
  minLiquidity?: number;
  maxPoolAgeMins?: number;
  minRelativeVolume?: number;
  minActivity?: number;
  minActivityIncrease?: number;
  maxConcentration?: number;
  minQuality?: number;
  dex?: string;
  security?: "critical" | "unknown" | "observed" | "";
}
export function relativeVolume(row: PoolRow): number | null {
  return row.volume5m !== null && row.volume1h !== null && row.volume1h > 0
    ? row.volume5m / (row.volume1h / 12)
    : null;
}
export function filterPools(
  rows: PoolRow[],
  f: Filters,
  now = Date.now(),
): PoolRow[] {
  const q = (f.query ?? "").trim().toLowerCase();
  return rows.filter((r) => {
    if (
      q &&
      ![r.name, r.symbol, r.mint, r.poolId].some((v) =>
        v.toLowerCase().includes(q),
      )
    )
      return false;
    if (
      f.minLiquidity !== undefined &&
      (r.liquidityUsd === null || r.liquidityUsd < f.minLiquidity)
    )
      return false;
    const age = r.createdAt
      ? Math.max(0, (now - Date.parse(r.createdAt)) / 60000)
      : null;
    if (
      f.maxPoolAgeMins !== undefined &&
      (age === null || age > f.maxPoolAgeMins)
    )
      return false;
    const rel = relativeVolume(r);
    if (
      f.minRelativeVolume !== undefined &&
      (rel === null || rel < f.minRelativeVolume)
    )
      return false;
    const trades =
      r.buys5m === null || r.sells5m === null ? null : r.buys5m + r.sells5m;
    if (
      f.minActivity !== undefined &&
      (trades === null || trades < f.minActivity)
    )
      return false;
    const con = r.risk.signals.find((x) => x.key === "concentration")?.value;
    if (
      f.minActivityIncrease !== undefined &&
      (r.activityIncreasePct === null ||
        r.activityIncreasePct === undefined ||
        r.activityIncreasePct < f.minActivityIncrease)
    )
      return false;
    if (
      f.maxConcentration !== undefined &&
      (con === null || con === undefined || con > f.maxConcentration)
    )
      return false;
    if (f.minQuality !== undefined && r.risk.dataQuality < f.minQuality)
      return false;
    if (f.dex && r.dex !== f.dex) return false;
    if (f.security && r.risk.state !== f.security) return false;
    switch (f.preset) {
      case "new":
        return age !== null && age <= 60;
      case "rising":
        return rel !== null && rel >= 2;
      case "liquidity":
        return r.liquidityUsd !== null && r.liquidityUsd >= 100000;
      case "unusual":
        return r.risk.signals.some(
          (x) =>
            x.key === "activity" &&
            (x.state === "notable" || x.state === "critical"),
        );
      case "quality":
        return r.risk.dataQuality < 60;
      case "critical":
        return r.risk.state === "critical";
      default:
        return true;
    }
  });
}
export function sortPools(
  rows: PoolRow[],
  key: string,
  direction: "asc" | "desc",
): PoolRow[] {
  const field = (r: PoolRow): string | number | null => {
    if (key === "trades")
      return r.buys5m === null || r.sells5m === null
        ? null
        : r.buys5m + r.sells5m;
    if (key === "ratio")
      return r.buys5m === null ||
        r.sells5m === null ||
        r.buys5m + r.sells5m === 0
        ? null
        : r.sells5m === 0
          ? Number.MAX_VALUE
          : r.buys5m / r.sells5m;
    if (key === "momentum") return r.change5m;
    if (key === "sparkline") return r.sparkline.at(-1)?.value ?? null;
    return key === "quality"
      ? r.risk.dataQuality
      : key === "risk"
        ? r.risk.overall
        : ((r as unknown as Record<string, string | number | null>)[key] ??
          null);
  };
  return [...rows].sort((a, b) => {
    const x = field(a),
      y = field(b);
    if (x === null) return y === null ? 0 : 1;
    if (y === null) return -1;
    const cmp =
      typeof x === "number" && typeof y === "number"
        ? x - y
        : String(x).localeCompare(String(y));
    return (direction === "desc" ? -1 : 1) * cmp;
  });
}
