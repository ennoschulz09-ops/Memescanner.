"use client";
import type { PoolRow } from "./domain";
import { isCompactPoolPage, unpackPoolPage } from "./scanner-wire";
export class ClientError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function api<T = any>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const res = await fetch("/api/" + path, {
    method,
    credentials: "same-origin",
    headers: body === undefined ? {} : { "Content-Type": "application/json" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    cache: "no-store",
  });
  const data = await res.json();
  if (!res.ok)
    throw new ClientError(data.error ?? "Anfrage fehlgeschlagen.", res.status);
  return (isCompactPoolPage(data) ? unpackPoolPage(data) : data) as T;
}
export function mergeRows(old: PoolRow[], incoming: PoolRow[]): PoolRow[] {
  const map = new Map(old.map((r) => [r.id, r]));
  for (const r of incoming) {
    const prev = map.get(r.id);
    const newer =
      prev && r.revision && prev.revision
        ? BigInt(r.revision) > BigInt(prev.revision)
        : !!prev && r.updatedAt > prev.updatedAt;
    const same =
      prev && r.revision && prev.revision
        ? r.revision === prev.revision
        : !!prev && r.updatedAt === prev.updatedAt;
    if (
      !prev ||
      newer ||
      (same &&
        (r.risk.dataQuality !== prev.risk.dataQuality ||
          r.risk.overall !== prev.risk.overall ||
          r.risk.state !== prev.risk.state))
    )
      map.set(r.id, r);
  }
  const rows = [...map.values()];
  return rows.length > 10000
    ? rows
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
        .slice(0, 10000)
    : rows;
}
export const sourceName = (p: string) =>
  ({ gecko: "GeckoTerminal", dex: "DexScreener", solana: "Solana RPC" })[p] ??
  p;
const numericFormats = {
  compact: new Intl.NumberFormat("de-DE", {
    notation: "compact",
    maximumFractionDigits: 2,
  }),
  standard: new Intl.NumberFormat("de-DE", {
    notation: "standard",
    maximumFractionDigits: 4,
  }),
  usdCompact: new Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 2,
  }),
  usdStandard: new Intl.NumberFormat("en-US", {
    notation: "standard",
    maximumFractionDigits: 2,
  }),
  usdPrice: new Intl.NumberFormat("en-US", {
    notation: "standard",
    maximumFractionDigits: 6,
  }),
};
export function formatNumber(
  n: number | null | undefined,
  compact = true,
): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "Unbekannt";
  return numericFormats[compact ? "compact" : "standard"].format(n);
}
export function usd(n: number | null | undefined, price = false): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "—";
  if (price && n > 0 && n < 0.01) return "$" + n.toPrecision(4);
  return (
    "$" +
    numericFormats[
      price ? "usdPrice" : Math.abs(n) >= 10000 ? "usdCompact" : "usdStandard"
    ].format(n)
  );
}
export const short = (s: string, n = 4) =>
  s.length > n * 2 + 3 ? s.slice(0, n) + "…" + s.slice(-n) : s;
export function ago(at: string | null | undefined, now = Date.now()) {
  if (!at) return "unbekannt";
  const n = Math.max(0, (now - Date.parse(at)) / 1000);
  if (!Number.isFinite(n)) return "unbekannt";
  return n < 60
    ? `${Math.floor(n)}s`
    : n < 3600
      ? `${Math.floor(n / 60)}m`
      : n < 86400
        ? `${Math.floor(n / 3600)}h`
        : `${Math.floor(n / 86400)}d`;
}
export function dateTime(at: string | null | undefined, timezone = "local") {
  if (!at) return "Unbekannt";
  return (
    new Date(at).toLocaleString("de-DE", {
      ...(timezone === "UTC" ? { timeZone: "UTC" } : {}),
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }) + (timezone === "UTC" ? " UTC" : "")
  );
}
const metricQueue: { stage: string; durationMs: number }[] = [];
let metricTimer: ReturnType<typeof setTimeout> | undefined;
export function reportMetric(
  stage:
    | "receipt_to_ui"
    | "db_to_ui"
    | "publish_to_ui"
    | "fcp"
    | "filter"
    | "search"
    | "tti",
  durationMs: number,
) {
  if (durationMs >= 0 && durationMs <= 300000) {
    metricQueue.push({ stage, durationMs });
    if (metricQueue.length > 100) metricQueue.shift();
    if (!metricTimer)
      metricTimer = setTimeout(() => {
        metricTimer = undefined;
        const samples = metricQueue.splice(0);
        void api("metrics", "POST", { samples }).catch(() => {});
      }, 2000);
  }
}
