export interface SyncTask {
  full: boolean;
  ids: string[];
}
export class PendingUpdates {
  private full = false;
  private ids = new Set<string>();
  get hasPending() {
    return this.full || this.ids.size > 0;
  }
  add(event: { resync?: boolean; ids?: string[] }) {
    if (event.resync) {
      this.full = true;
      this.ids.clear();
    } else if (!this.full) for (const id of event.ids ?? []) this.ids.add(id);
  }
  take(): SyncTask | null {
    if (!this.full && !this.ids.size) return null;
    const value = { full: this.full, ids: [...this.ids] };
    this.full = false;
    this.ids.clear();
    return value;
  }
  failed(task: SyncTask) {
    this.add({ resync: task.full, ids: task.ids });
  }
}
