import type { PoolClient } from "pg";
import { db, metric } from "./db";
import { isAddress, type Provenance } from "./domain";
import { freshnessBudgets } from "./freshness-config";

export async function recordDiscoveries(
  items: { mint: string; eventAt?: string | null }[],
  provenance: Provenance,
  observationTime?: string,
  transaction?: PoolClient,
) {
  const persistStarted = performance.now();
  const observedAt = observationTime ?? new Date().toISOString();
  const client = transaction ?? (await db.connect());
  let added = 0;
  try {
    if (!transaction) await client.query("BEGIN");
    for (const item of items) {
      if (!isAddress(item.mint)) throw new Error("Ungültige entdeckte Mint");
      const result = await client.query(
        "INSERT INTO discoveries(mint,provider,provenance,observed_at,event_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(mint,provider) DO NOTHING RETURNING first_seen_at",
        [
          item.mint,
          provenance.provider,
          provenance,
          observedAt,
          item.eventAt ?? null,
        ],
      );
      added += result.rowCount ?? 0;
    }
    if (!transaction) await client.query("COMMIT");
  } catch (error) {
    if (!transaction) await client.query("ROLLBACK");
    throw error;
  } finally {
    if (!transaction) client.release();
  }
  if (added && !transaction)
    await metric("discovery_persist", performance.now() - persistStarted).catch(
      () => {},
    );
  return added;
}
export async function getDiscoveries() {
  const budget = freshnessBudgets().discovery;
  return (
    await db.query(
      "SELECT mint,array_agg(DISTINCT provider) as providers,(jsonb_agg(provenance ORDER BY observed_at DESC)->0) as provenance,min(first_seen_at) as first_seen_at,min(event_at) as event_at,max(hydrated_at) as hydrated_at,max(error) as error FROM discoveries GROUP BY mint ORDER BY min(first_seen_at) DESC,mint LIMIT 60",
    )
  ).rows.map((r) => ({
    mint: r.mint,
    provider: r.providers.join(", "),
    provenance: r.provenance,
    firstSeenAt: new Date(r.first_seen_at).toISOString(),
    discoveryFreshness:
      Date.now() - new Date(r.first_seen_at).getTime() <= budget * 1000
        ? "recent"
        : "historical",
    freshnessBudgetSeconds: budget,
    eventAt: r.event_at ? new Date(r.event_at).toISOString() : null,
    status: r.hydrated_at ? "hydrated" : "incomplete",
    error: r.error,
  }));
}

/** Candidates are NOT proven pools until decode. New pools are NOT new mint claims. */
export async function getChainEvents() {
  const rows = (
    await db.query(`SELECT signature,slot,status,observed_at,admitted_at,
    attempted_at,fetched_at,decoded_at,processed_at,event_at,decoded,decoder_version,
    retry_reason,terminal_reason,from_replay FROM chain_candidates
    ORDER BY observed_at DESC,signature LIMIT 30`)
  ).rows;
  return rows.map((r) => ({
    eventId: r.signature,
    slot: Number(r.slot),
    status: r.status,
    observedAt: r.observed_at.toISOString(),
    admittedAt: r.admitted_at?.toISOString() ?? null,
    rpcStartedAt: r.attempted_at?.toISOString() ?? null,
    fetchedAt: r.fetched_at?.toISOString() ?? null,
    decodedAt: r.decoded_at?.toISOString() ?? null,
    committedAt: r.processed_at?.toISOString() ?? null,
    eventAt: r.event_at?.toISOString() ?? null,
    blockTimeUncertaintyMs: 1000,
    clockOffsetMs: null,
    pools: Array.isArray(r.decoded) ? r.decoded : [],
    decoderVersion: r.decoder_version,
    replay: r.from_replay,
    reason: r.terminal_reason ?? r.retry_reason,
  }));
}
