import type {
  PoolRow,
  Provenance,
  RiskReport,
  RiskSignal,
  ValueEvidence,
} from "./domain";
import { marketFields } from "./value-evidence";
type MarketField = (typeof marketFields)[number];
type WireEvidence = [
  source: ValueEvidence["source"],
  sourceTimestamp: number | null,
  sourceResponseAt: number,
  fetchedAt: number,
  computedAt: number,
  freshness: ValueEvidence["freshness"],
  confidence: ValueEvidence["confidenceLevel"],
  missing: boolean,
  conflicts: string[],
];

export const POOL_WIRE_FORMAT = "nexus-pools/1" as const;
type SignalDefinition = Omit<
  RiskSignal,
  "value" | "state" | "updatedAt" | "coverage" | "explanation"
>;
type WireSignal = [
  definition: number,
  value: number | null,
  state: RiskSignal["state"],
  updatedAt: number | null,
  coverage: number,
  explanation: number,
];
type WireRow = Omit<
  PoolRow,
  | "fieldEvidence"
  | "risk"
  | "sources"
  | "provenance"
  | "sourceSummaries"
  | "sparkline"
  | "sourceDetail"
  | MarketField
> & {
  values: (number | null)[];
  provenance: number;
  sourceSummaries: number[];
  sparkline: [at: number, value: number | null][];
  evidence?: (number | null)[];
  risk: Omit<RiskReport, "signals"> & { signals: WireSignal[] };
};
export interface CompactPoolPage {
  format: typeof POOL_WIRE_FORMAT;
  rows: WireRow[];
  evidence: WireEvidence[];
  evidenceFields: string[];
  signalDefinitions: SignalDefinition[];
  explanations: string[];
  provenance: Provenance[];
  timestamps: string[];
  [key: string]: unknown;
}

/** Lossless for list values/evidence; complete source payloads stay on token detail. */
export function packPoolPage<T extends { rows: PoolRow[] }>(
  page: T,
): Omit<T, "rows"> & CompactPoolPage {
  const evidence: WireEvidence[] = [],
    evidenceFields: string[] = [],
    signalDefinitions: SignalDefinition[] = [],
    explanations: string[] = [],
    provenance: Provenance[] = [],
    timestamps: string[] = [];
  const evidenceKeys = new Map<string, number>(),
    definitionKeys = new Map<string, number>(),
    explanationKeys = new Map<string, number>(),
    provenanceKeys = new Map<string, number>(),
    timestampKeys = new Map<string, number>(),
    evidenceFieldKeys = new Map<string, number>();
  const intern = <V>(value: V, values: V[], keys: Map<string, number>) => {
    const key = JSON.stringify(value);
    let index = keys.get(key);
    if (index === undefined) {
      index = values.length;
      keys.set(key, index);
      values.push(value);
    }
    return index;
  };
  const time = (at: string) => intern(at, timestamps, timestampKeys);
  const origin = (source: Provenance) =>
    intern(source, provenance, provenanceKeys);
  const rows: WireRow[] = page.rows.map((row) => {
    const {
      fieldEvidence,
      sources,
      risk,
      provenance: selectedOrigin,
      sourceSummaries,
      sparkline,
      sourceDetail: _sourceDetail,
      ...base
    } = row;
    const values = marketFields.map((field) => row[field]);
    for (const field of marketFields) delete (base as Partial<PoolRow>)[field];
    const references: (number | null)[] = [];
    if (fieldEvidence)
      for (const [field, entry] of Object.entries(fieldEvidence)) {
        const fieldIndex = intern(field, evidenceFields, evidenceFieldKeys);
        while (references.length <= fieldIndex) references.push(null);
        references[fieldIndex] = intern(
          [
            entry.source,
            entry.sourceTimestamp === null ? null : time(entry.sourceTimestamp),
            time(entry.sourceResponseAt),
            time(entry.fetchedAt),
            time(entry.computedAt),
            entry.freshness,
            entry.confidenceLevel,
            entry.missing,
            entry.conflicts,
          ] as WireEvidence,
          evidence,
          evidenceKeys,
        );
      }
    return {
      ...base,
      provenance: origin(selectedOrigin),
      values,
      sourceSummaries: (
        sourceSummaries ?? sources.map((s) => s.provenance)
      ).map(origin),
      sparkline: sparkline.map((point) => [time(point.at), point.value]),
      ...(fieldEvidence ? { evidence: references } : {}),
      risk: {
        ...risk,
        signals: risk.signals.map((signal): WireSignal => {
          const {
            value,
            state,
            updatedAt,
            coverage,
            explanation,
            ...definition
          } = signal;
          return [
            intern(definition, signalDefinitions, definitionKeys),
            value,
            state,
            updatedAt === null ? null : time(updatedAt),
            coverage,
            intern(explanation, explanations, explanationKeys),
          ];
        }),
      },
    };
  });
  return {
    ...page,
    format: POOL_WIRE_FORMAT,
    rows,
    evidence,
    evidenceFields,
    signalDefinitions,
    explanations,
    provenance,
    timestamps,
  };
}

export function isCompactPoolPage(value: unknown): value is CompactPoolPage {
  return (
    !!value &&
    typeof value === "object" &&
    (value as { format?: unknown }).format === POOL_WIRE_FORMAT
  );
}

export function unpackPoolPage<T extends CompactPoolPage>(
  page: T,
): Omit<
  T,
  | "format"
  | "rows"
  | "evidence"
  | "evidenceFields"
  | "signalDefinitions"
  | "explanations"
  | "provenance"
  | "timestamps"
> & { rows: PoolRow[] } {
  const {
    format: _format,
    evidence,
    evidenceFields,
    signalDefinitions,
    explanations,
    provenance,
    timestamps,
    rows: compactRows,
    ...metadata
  } = page;
  const rows: PoolRow[] = compactRows.map((row) => {
    const {
      evidence: references,
      risk,
      provenance: selectedOrigin,
      sourceSummaries,
      sparkline,
      values,
      ...base
    } = row;
    const numeric = Object.fromEntries(
      marketFields.map((field, index) => [field, values[index]]),
    ) as Pick<PoolRow, MarketField>;
    return {
      ...numeric,
      sourceDetail: "deferred",
      ...base,
      provenance: { ...provenance[selectedOrigin] },
      sourceSummaries: sourceSummaries.map((index) => ({
        ...provenance[index],
      })),
      sparkline: sparkline.map(([at, value]) => ({
        at: timestamps[at],
        value,
      })),
      sources: [],
      ...(references
        ? {
            fieldEvidence: Object.fromEntries(
              references.flatMap((index, fieldIndex) => {
                if (index === null) return [];
                const [
                  source,
                  sourceTimestamp,
                  sourceResponseAt,
                  fetchedAt,
                  computedAt,
                  freshness,
                  confidenceLevel,
                  missing,
                  conflicts,
                ] = evidence[index];
                return [
                  [
                    evidenceFields[fieldIndex],
                    {
                      source,
                      sourceTimestamp:
                        sourceTimestamp === null
                          ? null
                          : timestamps[sourceTimestamp],
                      sourceResponseAt: timestamps[sourceResponseAt],
                      fetchedAt: timestamps[fetchedAt],
                      computedAt: timestamps[computedAt],
                      freshness,
                      confidenceLevel,
                      missing,
                      conflicts: [...conflicts],
                    },
                  ],
                ];
              }),
            ),
          }
        : {}),
      risk: {
        ...risk,
        signals: risk.signals.map(
          ([definition, value, state, updatedAt, coverage, explanation]) => ({
            ...signalDefinitions[definition],
            value,
            state,
            updatedAt: updatedAt === null ? null : timestamps[updatedAt],
            coverage,
            explanation: explanations[explanation],
          }),
        ),
      },
    };
  });
  return { ...metadata, rows };
}
