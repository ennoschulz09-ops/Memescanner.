import type { Observation, ValueEvidence } from "./domain";
import { freshness } from "./domain";
import { sourceConflicts } from "./risk";
export const marketFields = [
  "priceUsd",
  "liquidityUsd",
  "volume5m",
  "volume1h",
  "volume24h",
  "buys5m",
  "sells5m",
  "change5m",
  "change1h",
  "change24h",
  "fdvUsd",
  "marketCapUsd",
] as const;
export function withFieldEvidence(
  row: Observation,
  sources: Observation[] = [row],
  now = Date.now(),
): Observation {
  const conflicts = sourceConflicts(sources),
    fieldEvidence: Record<string, ValueEvidence> = {};
  for (const field of marketFields) {
    const missing =
      row[field] === null ||
      row[field] === undefined ||
      !Number.isFinite(row[field]);
    fieldEvidence[field] = {
      source: row.provenance.provider,
      sourceTimestamp: row.provenance.measuredAt,
      sourceResponseAt: row.provenance.sourceAt,
      fetchedAt: row.provenance.fetchedAt,
      computedAt: new Date(now).toISOString(),
      freshness: missing
        ? "UNAVAILABLE"
        : freshness(row, now) === "stale"
          ? "STALE"
          : row.provenance.measuredAt
            ? "LIVE"
            : "CACHED",
      confidenceLevel: missing
        ? "unknown"
        : row.provenance.measuredAt
          ? "complete"
          : "partial",
      missing,
      conflicts: conflicts
        .filter((c) => c.field === field)
        .flatMap((c) => c.sources),
    };
  }
  return {
    ...row,
    normalizedAt: row.normalizedAt ?? new Date(now).toISOString(),
    fieldEvidence,
  };
}
export function evidenceLabel(row: Observation, field: string) {
  const key =
    field === "trades" || field === "ratio"
      ? "buys5m"
      : field === "momentum"
        ? "change5m"
        : field;
  const e =
    row.fieldEvidence?.[key] ??
    (marketFields.includes(key as (typeof marketFields)[number])
      ? withFieldEvidence(row).fieldEvidence?.[key]
      : undefined);
  if (!e) return `${row.provenance.provider} · ${row.provenance.sourceAt}`;
  const { missing, freshness: state } = evidenceState(row, field);
  return `${state} · Quelle: ${e.source} · Messzeit: ${e.sourceTimestamp ?? "unbekannt"} · HTTP-Stand: ${e.sourceResponseAt} · Abruf: ${e.fetchedAt} · ${missing ? "Wert unbekannt" : "Abdeckung: " + e.confidenceLevel}${e.conflicts.length ? " · Quellenkonflikt" : ""}`;
}
export function evidenceState(row: Observation, field: string) {
  const key = field === "momentum" ? "change5m" : field;
  const value = (row as unknown as Record<string, unknown>)[key];
  const missing = ["trades", "ratio"].includes(field)
    ? row.buys5m === null ||
      row.sells5m === null ||
      (field === "ratio" && row.buys5m + row.sells5m === 0)
    : field === "sparkline"
      ? !(row as unknown as { sparkline?: unknown[] }).sparkline?.length
      : value === null || value === undefined;
  return {
    missing,
    freshness: missing
      ? "UNAVAILABLE"
      : freshness(row) === "stale"
        ? "STALE"
        : row.provenance.measuredAt
          ? "LIVE"
          : "CACHED",
  };
}
