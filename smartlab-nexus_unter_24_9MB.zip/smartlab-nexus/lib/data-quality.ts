import { budgetLimits, db } from "./db";
import type { Provider, ProviderState } from "./domain";
import { freshnessBudgets } from "./freshness-config";
import { marketFields } from "./value-evidence";

export interface DataQualityReport {
  version: 1;
  at: string;
  window: { from: string; to: string; hours: 24 };
  pools: number;
  fields: {
    field: string;
    present: number;
    missing: number;
    total: number;
    coveragePct: number | null;
  }[];
  freshness: {
    current: number;
    stale: number;
    unknown: number;
    total: number;
    stalePct: number | null;
    unknownPct: number | null;
    budgetsSeconds: ReturnType<typeof freshnessBudgets>;
  };
  providers: {
    provider: Provider;
    status: ProviderState["status"];
    auditEvents24h: number;
    failedAuditEvents24h: number;
    rateLimitedAuditEvents24h: number;
    failedAuditEventPct: number | null;
    failedAuditRuns24h: number;
    lastSuccess: string | null;
    lastError: string | null;
    retryAt: string | null;
  }[];
  cache: {
    scope: "retained-service-counters";
    requests: number;
    hits: number;
    staleFallbacks: number;
    hitRatePct: number | null;
  };
  requestBudgets: {
    channel: string;
    limit: number;
    used: number;
    remaining: number;
    windowSeconds: 60;
  }[];
  costs: { status: "unknown"; totalUsd: null; reason: string };
  limits: string[];
}
const pct = (part: number, total: number) =>
  total > 0 ? Math.round((part / total) * 10000) / 100 : null;
const iso = (value: Date | string | null | undefined) =>
  value ? new Date(value).toISOString() : null;

/** Aggregates local observations and audit events, not correlated transport requests. */
export async function getDataQuality(
  now = Date.now(),
): Promise<DataQualityReport> {
  const at = new Date(now).toISOString(),
    from = new Date(now - 86400000).toISOString(),
    budgetsSeconds = freshnessBudgets();
  const [fields, freshness, providers, cache, budgets] = await Promise.all([
    db.query(
      `/* quality:fields */ WITH present AS (SELECT e.key AS field,count(*)::int AS present FROM pools p CROSS JOIN LATERAL jsonb_each(p.selected) e WHERE e.key=ANY($1::text[]) AND jsonb_typeof(e.value)='number' GROUP BY e.key), total AS (SELECT count(*)::int AS total FROM pools) SELECT field,total.total,COALESCE(present.present,0)::int AS present FROM unnest($1::text[]) AS field LEFT JOIN present USING(field) CROSS JOIN total`,
      [[...marketFields]],
    ),
    db.query(
      `/* quality:freshness */ WITH provenance AS MATERIALIZED (SELECT selected->'provenance' AS source FROM pools), classified AS (SELECT CASE WHEN source->>'timestampKind'='retrieval-only' OR source->>'sourceAt' IS NULL THEN 'unknown' WHEN (source->>'sourceAt')::timestamptz BETWEEN $1::timestamptz-COALESCE((source->>'freshnessBudgetSeconds')::double precision,$2)*interval '1 second' AND $1::timestamptz+interval '60 seconds' THEN 'current' ELSE 'stale' END AS state FROM provenance) SELECT count(*)::int AS total,count(*) FILTER(WHERE state='current')::int AS current,count(*) FILTER(WHERE state='stale')::int AS stale,count(*) FILTER(WHERE state='unknown')::int AS unknown FROM classified`,
      [at, budgetsSeconds.market],
    ),
    db.query(
      `/* quality:providers */ WITH recent AS (SELECT provider,ok,status,lag(ok) OVER(PARTITION BY provider ORDER BY at,id) AS previous_ok FROM source_audits WHERE at >= $1::timestamptz AND at <= $2::timestamptz), totals AS (SELECT provider,count(*)::int AS audit_events,count(*) FILTER(WHERE NOT ok)::int AS failed_audit_events,count(*) FILTER(WHERE status=429)::int AS rate_limited_audit_events,count(*) FILTER(WHERE NOT ok AND previous_ok IS DISTINCT FROM false)::int AS failed_audit_runs FROM recent GROUP BY provider) SELECT COALESCE(t.provider,p.provider) AS provider,t.audit_events,t.failed_audit_events,t.rate_limited_audit_events,t.failed_audit_runs,p.status,p.last_success,p.last_error,p.retry_at FROM totals t FULL JOIN provider_states p USING(provider)`,
      [from, at],
    ),
    db.query(
      "/* quality:cache */ SELECT name,value FROM service_counters WHERE name IN ('cache_requests','cache_hits','cache_stale_fallbacks')",
    ),
    db.query(
      "/* quality:budgets */ SELECT channel,count(*)::int AS used FROM provider_budget_claims WHERE at > $1::timestamptz-interval '60 seconds' AND at <= $1::timestamptz GROUP BY channel",
      [at],
    ),
  ]);
  const counts = freshness.rows[0] ?? {},
    total = Number(counts.total ?? 0),
    stale = Number(counts.stale ?? 0),
    unknown = Number(counts.unknown ?? 0);
  const counters = Object.fromEntries(
    cache.rows.map((r) => [r.name, Number(r.value)]),
  );
  const requests = counters.cache_requests ?? 0,
    hits = counters.cache_hits ?? 0;
  return {
    version: 1,
    at,
    window: { from, to: at, hours: 24 },
    pools: total,
    fields: marketFields.map((field) => {
      const row = fields.rows.find((r) => r.field === field),
        fieldTotal = Number(row?.total ?? total),
        present = Number(row?.present ?? 0);
      return {
        field,
        present,
        missing: fieldTotal - present,
        total: fieldTotal,
        coveragePct: pct(present, fieldTotal),
      };
    }),
    freshness: {
      current: Number(counts.current ?? 0),
      stale,
      unknown,
      total,
      stalePct: pct(stale, total),
      unknownPct: pct(unknown, total),
      budgetsSeconds,
    },
    providers: (["dex", "gecko", "solana"] as const).map((provider) => {
      const row = providers.rows.find((r) => r.provider === provider),
        auditEvents24h = Number(row?.audit_events ?? 0),
        failedAuditEvents24h = Number(row?.failed_audit_events ?? 0);
      return {
        provider,
        status: row?.status ?? "unknown",
        auditEvents24h,
        failedAuditEvents24h,
        rateLimitedAuditEvents24h: Number(row?.rate_limited_audit_events ?? 0),
        failedAuditEventPct: pct(failedAuditEvents24h, auditEvents24h),
        failedAuditRuns24h: Number(row?.failed_audit_runs ?? 0),
        lastSuccess: iso(row?.last_success),
        lastError: iso(row?.last_error),
        retryAt: iso(row?.retry_at),
      };
    }),
    cache: {
      scope: "retained-service-counters",
      requests,
      hits,
      staleFallbacks: counters.cache_stale_fallbacks ?? 0,
      hitRatePct: pct(hits, requests),
    },
    requestBudgets: Object.entries(budgetLimits).map(([channel, limit]) => {
      const used = Number(
        budgets.rows.find((r) => r.channel === channel)?.used ?? 0,
      );
      return {
        channel,
        limit,
        used,
        remaining: Math.max(0, limit - used),
        windowSeconds: 60,
      };
    }),
    costs: {
      status: "unknown",
      totalUsd: null,
      reason:
        "Keine verifizierten Provider-Tarife oder Abrechnungsdaten konfiguriert; Auditereignisse und Budgetclaims sind keine Kostenmessung.",
    },
    limits: [
      "Abdeckung bezieht sich auf gespeicherte Pools und numerische Provider-Felder; sie belegt weder Richtigkeit noch vollständige Solana-Abdeckung.",
      "HTTP-Cache-Zeit ist keine garantierte Messzeit; retrieval-only zählt als unbekannte Frische.",
      "Providerzählungen und Fehleranteile beziehen sich auf Auditereignisse, nicht auf Requests: Ein HTTP200 mit RPC-/Schemafehler kann zwei Ereignisse erzeugen. Fehlerfolgen innerhalb 24h messen keine Provider-Uptime; Budgetblockaden vor Transport sind nicht enthalten.",
      "Cache-Zähler gelten über ihre lokale Aufbewahrung, nicht für das 24h-Auditfenster. Externe Requests anderer Anwendungen fehlen.",
    ],
  };
}
