import {
  freshness,
  num,
  type Observation,
  type ChainEvidence,
  type RiskReport,
  type RiskSignal,
  type SignalState,
} from "./domain";
import { freshnessBudgets } from "./freshness-config";

export const RISK_MODEL_VERSION = "nexus-risk/3";

export function sourceConflicts(
  sources: Observation[],
): { field: string; differencePct: number; sources: string[] }[] {
  const conflicts: {
    field: string;
    differencePct: number;
    sources: string[];
  }[] = [];
  for (let i = 0; i < sources.length; i++)
    for (let j = i + 1; j < sources.length; j++) {
      const a = sources[i],
        b = sources[j];
      if (
        a.poolId !== b.poolId ||
        a.mint !== b.mint ||
        a.provenance.provider === b.provenance.provider
      )
        continue;
      for (const field of ["priceUsd", "fdvUsd", "liquidityUsd"] as const) {
        const x = a[field],
          y = b[field];
        if (
          x === null ||
          y === null ||
          !Number.isFinite(x) ||
          !Number.isFinite(y) ||
          Math.min(x, y) < 0 ||
          x === y
        )
          continue;
        // Relative to the larger reported value: bounded 0..100, including zero/positive disagreements.
        const differencePct = (Math.abs(x - y) / Math.max(x, y)) * 100;
        if (differencePct > (field === "priceUsd" ? 10 : 20))
          conflicts.push({
            field,
            differencePct,
            sources: [a.provenance.provider, b.provenance.provider],
          });
      }
    }
  return conflicts;
}
export function scoreRisk(
  obs: Observation,
  evidence: ChainEvidence | null,
  sources: Observation[],
  now = Date.now(),
): RiskReport {
  // Invalid upstream numbers contribute unknown evidence, never a default low risk.
  obs = { ...obs };
  for (const field of [
    "priceUsd",
    "liquidityUsd",
    "volume5m",
    "volume1h",
    "volume24h",
    "buys5m",
    "sells5m",
    "change5m",
    "change1h",
    "change24h",
    "fdvUsd",
    "marketCapUsd",
  ] as const)
    obs[field] = num(obs[field], field.startsWith("change"));
  const currentTime = (at: string) =>
    Number.isFinite(Date.parse(at)) &&
    now - Date.parse(at) >= -60000 &&
    now - Date.parse(at) < freshnessBudgets().onchain * 1000;
  const componentValid = (key: "contract" | "holders") =>
    !!evidence &&
    (evidence.components
      ? evidence.components[key].status === "ok" &&
        currentTime(evidence.components[key].checkedAt)
      : !evidence.error && currentTime(evidence.checkedAt));
  const c = componentValid("contract") ? evidence!.controls : null;
  const con = componentValid("holders") ? evidence!.concentration : null;
  const fresh = freshness(obs, now) === "current";
  const liq = obs.liquidityUsd;
  const liquidity =
    !fresh || liq === null
      ? null
      : liq < 10000
        ? 100
        : liq < 50000
          ? 70
          : liq < 250000
            ? 35
            : 10;
  const positiveSupply = !!c && /^\d+$/.test(c.supply) && BigInt(c.supply) > 0n;
  const concentration =
    positiveSupply &&
    con?.top1Pct !== null &&
    con?.top1Pct !== undefined &&
    Number.isFinite(con.top1Pct) &&
    con.top1Pct >= 0 &&
    con.top1Pct <= 100
      ? con.top1Pct
      : null;
  const authorityKnown =
    c &&
    positiveSupply &&
    c.mintAuthority !== "unknown" &&
    c.freezeAuthority !== "unknown";
  const riskyExtensions =
    c?.extensions.filter((x) =>
      /permanentDelegate|transferHook|nonTransferable|defaultAccountState|transferFeeConfig/i.test(
        x,
      ),
    ) ?? [];
  const controls = authorityKnown
    ? Math.min(
        100,
        (c.mintAuthority === null ? 0 : 60) +
          (c.freezeAuthority === null ? 0 : 40) +
          (riskyExtensions.length ? 50 : 0),
      )
    : null;
  const ratio =
    fresh && liq !== null && liq > 0 && obs.volume5m !== null
      ? obs.volume5m / liq
      : null;
  const activity =
    ratio === null ? null : ratio > 1.5 ? 90 : ratio > 0.5 ? 55 : 10;
  const marketInputs = [
    obs.priceUsd,
    liq,
    obs.volume5m,
    obs.volume1h,
    obs.volume24h,
    obs.buys5m,
    obs.sells5m,
    obs.change5m,
    obs.fdvUsd ?? obs.marketCapUsd,
    obs.createdAt,
  ];
  const completeness =
    marketInputs.filter((x) => x !== null).length / marketInputs.length;
  const dataQuality = Math.round(
    (60 * completeness +
      20 * (authorityKnown ? 1 : 0) +
      10 * (concentration !== null ? 1 : 0) +
      10 *
        (sources.filter((x) => freshness(x, now) === "current").length >= 2
          ? 1
          : 0)) *
      (fresh ? 1 : 0.5),
  );
  const state = (value: number | null): SignalState =>
    value === null
      ? "unknown"
      : value >= 70
        ? "critical"
        : value >= 35
          ? "notable"
          : "observed";
  const mk = (
    key: string,
    label: string,
    value: number | null,
    unit: string,
    threshold: string,
    explanation: string,
    formula: string,
    weight: number,
    source = obs.provenance.provider as string,
    updatedAt: string | null = obs.provenance.sourceAt,
  ): RiskSignal => ({
    key,
    label,
    value,
    unit,
    threshold,
    state: state(value),
    source,
    updatedAt,
    coverage: value === null ? 0 : 1,
    explanation,
    formula,
    weight,
  });
  const signals: RiskSignal[] = [
    mk(
      "quality",
      "Datenqualität",
      dataQuality,
      "/ 100",
      "< 60: eingeschränkt",
      "Vollständigkeit der Marktfelder, frische Quellen und verfügbare Onchain-Prüfungen. Kein Sicherheitsnachweis.",
      "(60 × Markt-Vollständigkeit + 20 × Controls + 10 × Konzentrationsdaten + 10 × zweite frische Quelle) × Frischefaktor; stale/unbekannt = 0,5",
      0,
    ),
    mk(
      "liquidity",
      "Liquiditätsrisiko",
      liquidity,
      "/ 100",
      "< 10k USD: kritisch; < 50k: auffällig",
      `Pool-Liquidität: ${liq === null ? "unbekannt" : liq.toFixed(2) + " USD"}. Gemeldete Reserven sind keine Garantie für ausführbare Liquidität.`,
      "L < 10.000 → 100; < 50.000 → 70; < 250.000 → 35; sonst 10; fehlend → unbekannt",
      0.3,
    ),
    mk(
      "concentration",
      "Konzentrationsrisiko",
      concentration,
      "%",
      "Top-Tokenkonto ≥ 70 %: kritisch",
      "Anteil des größten Tokenkontos an der Supply. Tokenkonten sind keine eindeutigen Holder/Wallets; Poolkonten können enthalten sein. Vollständige Owner-Konzentration unbekannt.",
      "100 × größtes Tokenkonto / Mint-Supply (Integer-Berechnung); fehlend → unbekannt",
      0.25,
      "Solana RPC",
      evidence?.components?.holders.checkedAt ??
        (componentValid("holders") ? evidence!.checkedAt : null),
    ),
    mk(
      "contract",
      "Contract-Kontrollen",
      controls,
      "/ 100",
      "Mint aktiv: +60; Freeze aktiv: +40",
      c
        ? `Mint: ${c.mintAuthority === null ? "deaktiviert" : c.mintAuthority === "unknown" ? "unbekannt" : "aktiv"}; Freeze: ${c.freezeAuthority === null ? "deaktiviert" : c.freezeAuthority === "unknown" ? "unbekannt" : "aktiv"}. Erweiterungen: ${c.extensions.join(", ") || "keine gemeldet"}.`
        : "Mint-/Freeze-Authority und Tokenprogramm wurden nicht erfolgreich geprüft.",
      "min(100, 60 × Mint aktiv + 40 × Freeze aktiv + 50 × relevante Token-2022-Erweiterung); fehlend → unbekannt",
      0.3,
      "Solana RPC",
      evidence?.components?.contract.checkedAt ??
        (componentValid("contract") ? evidence!.checkedAt : null),
    ),
    mk(
      "activity",
      "Auffällige Aktivität",
      activity,
      "/ 100",
      "Volumen 5m / Liquidität > 0,5: auffällig",
      "Verhältnis von gemeldetem 5-Minuten-Volumen zur Liquidität. Dies belegt weder Manipulation noch Wallet-Cluster.",
      "V5m / L > 1,5 → 90; > 0,5 → 55; sonst 10; L ≤ 0 oder fehlend → unbekannt",
      0.15,
    ),
    {
      ...mk(
        "momentum",
        "Momentum-Kontext",
        fresh ? obs.change5m : null,
        "%",
        "|5m-Änderung| > 30 %: auffällig",
        "Beobachtete Preisänderung über 5 Minuten, ohne Prognose oder Handlungsaufforderung.",
        "Vom Provider gemeldete Preisänderung 5m; keine Gewichtung im Risikoscore",
        0,
      ),
      state:
        !fresh || obs.change5m === null
          ? "unknown"
          : Math.abs(obs.change5m) > 30
            ? "notable"
            : "observed",
    },
    mk(
      "lp-lock",
      "LP-Lock / LP-Eigentümer",
      null,
      "",
      "Keine verifizierte Quelle",
      "Lock-Status und LP-Eigentümer werden ohne verifizierbare Daten nicht behauptet.",
      "Nicht verfügbar → unbekannt; niemals als Nullrisiko eingesetzt",
      0,
      "keine",
    ),
    mk(
      "clusters",
      "Transaktionscluster",
      null,
      "",
      "Keine belastbare Cluster-Evidenz",
      "Die Aggregatdaten enthalten keine vollständigen Transaktionsgraphen. Keine Cluster- oder Eigentümerbehauptung.",
      "Nicht verfügbar → unbekannt",
      0,
      "keine",
    ),
  ];
  signals[0].state =
    dataQuality < 40 ? "critical" : dataQuality < 70 ? "notable" : "observed";
  const required = signals.filter((x) => x.weight > 0);
  const coverage = required.reduce(
    (n, x) => n + (x.value === null ? 0 : x.weight),
    0,
  );
  const overall =
    fresh && required.every((x) => x.value !== null)
      ? Math.round(required.reduce((n, x) => n + x.value! * x.weight, 0))
      : null;
  const conflicts = sourceConflicts(sources);
  const flags = required
    .filter(
      (x) =>
        x.state === "critical" ||
        x.state === "notable" ||
        x.state === "unknown",
    )
    .map((x) =>
      x.state === "unknown"
        ? `${x.label} unbekannt`
        : `${x.label}: ${x.state === "critical" ? "kritisch" : "auffällig"}`,
    );
  if (!fresh) flags.push("Datenfrische eingeschränkt");
  if (conflicts.length) flags.push("Widersprüchliche Quelldaten");
  return {
    modelVersion: RISK_MODEL_VERSION,
    evidenceStatus: required.every((x) => x.value !== null)
      ? "COMPLETE"
      : required.some((x) => x.value !== null)
        ? "DEGRADED"
        : "UNKNOWN",
    dataQuality,
    overall,
    coverage: Math.round(coverage * 100) / 100,
    state: required.some((x) => x.state === "critical")
      ? "critical"
      : overall === null
        ? "unknown"
        : state(overall),
    signals,
    flags,
    computedAt: new Date(now).toISOString(),
  };
}
