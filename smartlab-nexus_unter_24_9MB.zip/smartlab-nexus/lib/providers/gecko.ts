import { z } from "zod";
import { isAddress } from "../domain";
import { HttpClient } from "./http";
import { normalizeGecko } from "./normalize";
export class GeckoProvider {
  constructor(private http = new HttpClient()) {}
  async discover(kind: "new_pools" | "trending_pools" = "new_pools") {
    const r = await this.http.get(
      "gecko",
      kind,
      `https://api.geckoterminal.com/api/v2/networks/solana/${kind}?include=base_token,quote_token,dex`,
    );
    return this.http.validate("gecko", kind, () =>
      normalizeGecko(r.data, r.provenance),
    );
  }
  async pools(addresses: string[]) {
    if (!addresses.length) return [];
    if (addresses.length > 30 || addresses.some((x) => !isAddress(x)))
      throw new Error("Ungültige Pool-Liste");
    const r = await this.http.get(
      "gecko",
      "pools/multi",
      `https://api.geckoterminal.com/api/v2/networks/solana/pools/multi/${addresses.join(",")}?include=base_token,quote_token,dex`,
    );
    return this.http.validate("gecko", "pools/multi", () =>
      normalizeGecko(r.data, r.provenance),
    );
  }
  async ohlcv(pool: string, window: "1h" | "24h" | "7d") {
    if (!isAddress(pool)) throw new Error("Ungültige Pooladresse");
    const params =
      window === "1h"
        ? ["minute", "1", "60"]
        : window === "24h"
          ? ["minute", "15", "96"]
          : ["hour", "1", "168"];
    const r = await this.http.get(
      "gecko",
      "ohlcv",
      `https://api.geckoterminal.com/api/v2/networks/solana/pools/${pool}/ohlcv/${params[0]}?aggregate=${params[1]}&limit=${params[2]}&currency=usd&token=base&include_empty_intervals=false`,
    );
    const root = await this.http.validate("gecko", "ohlcv", () =>
      z
        .object({
          data: z.object({
            attributes: z.object({
              ohlcv_list: z.array(
                z.tuple([
                  z.number(),
                  z.number(),
                  z.number(),
                  z.number(),
                  z.number(),
                  z.number(),
                ]),
              ),
            }),
          }),
        })
        .parse(r.data),
    );
    return {
      candles: root.data.attributes.ohlcv_list
        .filter((x) => x.every(Number.isFinite))
        .reverse()
        .map((x) => ({
          at: new Date(x[0] * 1000).toISOString(),
          open: x[1],
          high: x[2],
          low: x[3],
          close: x[4],
          volume: x[5],
        })),
      provenance: r.provenance,
    };
  }
}
