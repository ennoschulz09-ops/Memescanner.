import { createHash } from "node:crypto";
import bs58 from "bs58";
import { z } from "zod";
import { isAddress } from "../domain";
// Official raydium-io/raydium-cp-swap mainnet program; see docs/chain-decoder-source.md.
export const CPMM_PROGRAM = "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C";
export const CPMM_DECODER_VERSION = "raydium-cpmm-initialize-v1";
const discriminator = createHash("sha256")
  .update("global:initialize")
  .digest()
  .subarray(0, 8);
export function isOwnInitializeLog(logs: string[]) {
  const stack: string[] = [];
  for (const line of logs.slice(0, 2000)) {
    const invoke = /^Program ([1-9A-HJ-NP-Za-km-z]+) invoke \[\d+\]$/.exec(
      line,
    );
    if (invoke) {
      stack.push(invoke[1]);
      continue;
    }
    if (/^Program [1-9A-HJ-NP-Za-km-z]+ (success|failed)/.test(line)) {
      stack.pop();
      continue;
    }
    if (
      stack.at(-1) === CPMM_PROGRAM &&
      line === "Program log: Instruction: Initialize"
    )
      return true;
  }
  return false;
}
export function decodePoolInitializations(input: unknown) {
  if (
    input &&
    typeof input === "object" &&
    "version" in input &&
    !["legacy", 0, 1].includes((input as { version: any }).version)
  )
    return [];
  const root = z
    .object({
      slot: z.number().int().nonnegative(),
      blockTime: z.number().nullable().optional(),
      meta: z.object({
        err: z.unknown().nullable(),
        innerInstructions: z
          .array(z.object({ instructions: z.array(z.unknown()) }))
          .optional(),
      }),
      transaction: z.object({
        message: z.object({ instructions: z.array(z.unknown()) }),
      }),
    })
    .parse(input);
  if (root.meta.err !== null) return [];
  const result: {
    poolAddress: string;
    mints: string[];
    slot: number;
    eventAt: string | null;
    decoderVersion: string;
  }[] = [];
  for (const value of [
    ...root.transaction.message.instructions,
    ...(root.meta.innerInstructions ?? []).flatMap((i) => i.instructions),
  ]) {
    const parsed = z
      .object({
        programId: z.literal(CPMM_PROGRAM),
        accounts: z.array(z.string().refine(isAddress)).min(20).max(256),
        data: z.string(),
      })
      .safeParse(value);
    if (!parsed.success) continue;
    let data: Uint8Array;
    try {
      data = bs58.decode(parsed.data.data);
    } catch {
      continue;
    }
    if (
      data.length !== 32 ||
      !Buffer.from(data.subarray(0, 8)).equals(discriminator)
    )
      continue;
    const a = parsed.data.accounts;
    if (a[4] === a[5] || a[3] === a[4] || a[3] === a[5]) continue;
    result.push({
      poolAddress: a[3],
      mints: [a[4], a[5]],
      slot: root.slot,
      eventAt:
        root.blockTime != null
          ? new Date(root.blockTime * 1000).toISOString()
          : null,
      decoderVersion: CPMM_DECODER_VERSION,
    });
  }
  return result;
}
