import { z } from "zod";
import {
  isAddress,
  safeText,
  type Controls,
  type Concentration,
  type ChainEvidence,
} from "../domain";
import { HttpClient, ProviderError } from "./http";
export const MAX_SUPPORTED_TRANSACTION_VERSION = 1;
export class SolanaRpcError extends ProviderError {
  readonly reason: string;
  readonly permanent: boolean;
  constructor(public rpcCode: number) {
    const reason =
      rpcCode === -32015
        ? "unsupported_transaction_version"
        : [-32600, -32601, -32602].includes(rpcCode)
          ? "rpc_request_rejected"
          : [-32007, -32009].includes(rpcCode)
            ? "transaction_history_unavailable"
            : rpcCode === -32429
              ? "provider_rate_limited"
              : "rpc_unavailable";
    super(
      "solana",
      rpcCode === -32429 ? 429 : 502,
      rpcCode === -32429 ? 60000 : 0,
      `Solana RPC ${rpcCode}: ${reason}`,
    );
    this.name = "SolanaRpcError";
    this.reason = reason;
    this.permanent = [-32015, -32600, -32601, -32602, -32007, -32009].includes(
      rpcCode,
    );
  }
}
export const TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
export const TOKEN_2022 = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb";
export function parseMint(value: unknown, slot: number): Controls {
  const root = z
    .object({
      owner: z.enum([TOKEN_PROGRAM, TOKEN_2022]),
      data: z.object({
        parsed: z.object({
          type: z.literal("mint"),
          info: z.object({
            supply: z.string().regex(/^\d+$/),
            decimals: z.number().int().min(0).max(255),
            mintAuthority: z.string().refine(isAddress).nullable().optional(),
            freezeAuthority: z.string().refine(isAddress).nullable().optional(),
            extensions: z
              .array(z.object({ extension: z.string() }).passthrough())
              .optional(),
          }),
        }),
      }),
    })
    .parse(value);
  const i = root.data.parsed.info;
  return {
    mintAuthority: i.mintAuthority === undefined ? "unknown" : i.mintAuthority,
    freezeAuthority:
      i.freezeAuthority === undefined ? "unknown" : i.freezeAuthority,
    program: root.owner,
    supply: i.supply,
    decimals: i.decimals,
    slot,
    extensions: (i.extensions ?? []).map((x) => safeText(x.extension, 64)),
  };
}
export function concentration(
  accounts: { address: string; amount: string }[],
  supply: string,
): Concentration {
  const s = /^\d+$/.test(supply) ? BigInt(supply) : 0n;
  const coherent =
    accounts.length <= 20 &&
    new Set(accounts.map((a) => a.address)).size === accounts.length &&
    accounts.every((a) => isAddress(a.address) && /^\d+$/.test(a.amount));
  const valid = accounts
    .filter((x) => /^\d+$/.test(x.amount))
    .sort((a, b) =>
      BigInt(a.amount) > BigInt(b.amount)
        ? -1
        : BigInt(a.amount) < BigInt(b.amount)
          ? 1
          : 0,
    )
    .slice(0, 20);
  const total = valid.reduce((n, x) => n + BigInt(x.amount), 0n);
  const percent = (a: bigint) =>
    coherent && s > 0 && a <= s && total <= s
      ? Number((a * 1_000_000n) / s) / 10000
      : null;
  return {
    scope: "token-accounts",
    top1Pct: valid.length ? percent(BigInt(valid[0].amount)) : null,
    top20Pct: valid.length
      ? percent(valid.reduce((n, x) => n + BigInt(x.amount), 0n))
      : null,
    accounts: valid.map((x) => ({ ...x, pct: percent(BigInt(x.amount)) })),
  };
}
export class SolanaProvider {
  constructor(
    private http = new HttpClient(),
    private url = process.env.SOLANA_RPC_URL ||
      "https://api.mainnet.solana.com",
  ) {}
  async rpc(method: string, params: unknown[] = []): Promise<any> {
    const allowed = [
      "getHealth",
      "getAccountInfo",
      "getTokenLargestAccounts",
      "getBalance",
      "getTokenAccountsByOwner",
      "getSignaturesForAddress",
      "getTransaction",
    ];
    if (!allowed.includes(method))
      throw new Error("RPC-Methode nicht freigegeben");
    const r = await this.http.request("solana", method, this.url, "solana", {
      jsonrpc: "2.0",
      id: 1,
      method,
      params,
    });
    return this.http.validate("solana", method, () => {
      const result = z
        .object({
          result: z.unknown().optional(),
          error: z.unknown().optional(),
        })
        .parse(r.data);
      if (result.error) {
        const error = z.object({ code: z.number().int() }).parse(result.error);
        throw new SolanaRpcError(error.code);
      }
      if (result.result === undefined)
        throw new Error(`Solana RPC: ${method} nicht verfügbar`);
      const context = z
        .object({ slot: z.number().int().nonnegative() })
        .passthrough();
      if (method === "getHealth") return z.literal("ok").parse(result.result);
      if (method === "getTransaction") {
        if (
          result.result &&
          typeof result.result === "object" &&
          "version" in result.result &&
          !["legacy", 0, 1].includes(
            (result.result as { version: any }).version,
          )
        )
          throw new SolanaRpcError(-32015);
        return z
          .object({
            slot: z.number().int().nonnegative(),
            blockTime: z.number().nullable().optional(),
            meta: z
              .object({
                err: z.unknown().nullable(),
                innerInstructions: z
                  .array(z.object({ instructions: z.array(z.unknown()) }))
                  .optional(),
              })
              .passthrough(),
            transaction: z
              .object({
                message: z
                  .object({ instructions: z.array(z.unknown()) })
                  .passthrough(),
              })
              .passthrough(),
          })
          .passthrough()
          .nullable()
          .parse(result.result);
      }
      if (method === "getBalance")
        return z
          .object({ context, value: z.number().nonnegative() })
          .parse(result.result);
      if (method === "getAccountInfo")
        return z.object({ context, value: z.unknown() }).parse(result.result);
      if (method === "getTokenLargestAccounts")
        return z
          .object({
            context,
            value: z
              .array(
                z
                  .object({
                    address: z.string(),
                    amount: z.string().regex(/^\d+$/),
                  })
                  .passthrough(),
              )
              .max(20),
          })
          .parse(result.result);
      if (method === "getTokenAccountsByOwner")
        return z
          .object({
            context,
            value: z.array(
              z
                .object({
                  pubkey: z.string(),
                  account: z
                    .object({
                      owner: z.string(),
                      data: z
                        .object({
                          parsed: z
                            .object({
                              info: z
                                .object({
                                  mint: z.string(),
                                  tokenAmount: z.object({
                                    uiAmountString: z.string(),
                                  }),
                                })
                                .passthrough(),
                            })
                            .passthrough(),
                        })
                        .passthrough(),
                    })
                    .passthrough(),
                })
                .passthrough(),
            ),
          })
          .parse(result.result);
      return z
        .array(
          z
            .object({
              signature: z.string().min(32).max(100),
              slot: z.number().int().nonnegative(),
              err: z.unknown().nullable(),
              blockTime: z.number().nullable().optional(),
            })
            .passthrough(),
        )
        .max(20)
        .parse(result.result);
    });
  }
  async health() {
    return this.rpc("getHealth");
  }
  async inspect(mint: string): Promise<
    ChainEvidence & {
      requestFailure: { status: number; retryAfterMs: number } | null;
    }
  > {
    if (!isAddress(mint)) throw new Error("Ungültige Mint-Adresse");
    const checkedAt = new Date().toISOString();
    const components: NonNullable<ChainEvidence["components"]> = {
      contract: { status: "unknown", checkedAt, slot: null },
      holders: { status: "unknown", checkedAt, slot: null },
    };
    let controls: Controls | null = null;
    let c: Concentration | null = null;
    let error: string | null = null;
    let requestFailure: { status: number; retryAfterMs: number } | null = null;
    const failure = (e: unknown) => ({
      status: e instanceof ProviderError ? e.status : 503,
      retryAfterMs: Math.max(
        60000,
        e instanceof ProviderError ? e.retryAfterMs : 0,
      ),
    });
    try {
      const a = await this.rpc("getAccountInfo", [
        mint,
        { encoding: "jsonParsed", commitment: "confirmed" },
      ]);
      controls = parseMint(a.value, a.context.slot);
      components.contract = {
        status: "ok",
        checkedAt: new Date().toISOString(),
        slot: a.context.slot,
      };
    } catch (e) {
      error = "Contract-Kontrollen nicht verfügbar";
      requestFailure = failure(e);
    }
    if (controls) {
      try {
        const largest = await this.rpc("getTokenLargestAccounts", [
          mint,
          { commitment: "confirmed", minContextSlot: controls.slot },
        ]);
        if (largest.context.slot < controls.slot)
          throw new Error("Holder context predates mint");
        const entries = z
          .array(
            z.object({
              address: z.string(),
              amount: z.string().regex(/^\d+$/),
            }),
          )
          .parse(largest.value);
        c = concentration(entries, controls.supply);
        if (c.top20Pct === null)
          throw new Error("Inconsistent holder evidence");
        components.holders = {
          status: "ok",
          checkedAt: new Date().toISOString(),
          slot: largest.context.slot,
        };
      } catch (e) {
        error = "Größte Tokenkonten nicht verfügbar";
        requestFailure = failure(e);
      }
    }
    return {
      components,
      controls,
      concentration: c,
      checkedAt,
      error,
      requestFailure,
      slot: controls?.slot ?? null,
    };
  }
  async wallet(address: string) {
    if (!isAddress(address)) throw new Error("Ungültige öffentliche Adresse");
    const checkedAt = new Date().toISOString();
    const queries = await Promise.allSettled([
      this.rpc("getBalance", [address, { commitment: "confirmed" }]),
      this.rpc("getTokenAccountsByOwner", [
        address,
        { programId: TOKEN_PROGRAM },
        { encoding: "jsonParsed", commitment: "confirmed" },
      ]),
      this.rpc("getTokenAccountsByOwner", [
        address,
        { programId: TOKEN_2022 },
        { encoding: "jsonParsed", commitment: "confirmed" },
      ]),
      this.rpc("getSignaturesForAddress", [
        address,
        { limit: 20, commitment: "confirmed" },
      ]),
    ]);
    const val = (n: number) =>
      queries[n].status === "fulfilled" ? queries[n].value : null;
    const accounts = [...(val(1)?.value ?? []), ...(val(2)?.value ?? [])]
      .slice(0, 500)
      .flatMap((x: any) => {
        const i = x.account?.data?.parsed?.info;
        return i && isAddress(i.mint)
          ? [
              {
                account: safeText(x.pubkey, 44),
                mint: i.mint,
                amount: safeText(i.tokenAmount?.uiAmountString, 80),
                program: x.account.owner,
              },
            ]
          : [];
      });
    const signatures = (val(3) ?? []).map((x: any) => ({
      signature: safeText(x.signature, 100),
      at: x.blockTime ? new Date(x.blockTime * 1000).toISOString() : null,
      slot: x.slot,
      failed: !!x.err,
    }));
    return {
      address,
      checkedAt,
      source: "Solana RPC",
      balanceSol: typeof val(0)?.value === "number" ? val(0).value / 1e9 : null,
      slot: val(0)?.context?.slot ?? null,
      accounts,
      signatures,
      errors: queries
        .map((r, i) =>
          r.status === "rejected"
            ? [
                "SOL-Saldo",
                "SPL-Tokenkonten",
                "Token-2022-Konten",
                "Signaturen",
              ][i]
            : null,
        )
        .filter(Boolean),
      coverage: queries.filter((x) => x.status === "fulfilled").length / 4,
      limitations: [
        "Maximal 20 Signaturen; keine vollständige Transaktionshistorie.",
        "Tokenkonten sind öffentliche Konten, keine Personen- oder Eigentümerzuordnung.",
        "Interaktionspartner und Cluster werden ohne Transaktionsdecodierung nicht behauptet.",
      ],
    };
  }
}
