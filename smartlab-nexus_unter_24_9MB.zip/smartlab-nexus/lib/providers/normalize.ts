import { z } from "zod";
import {
  isAddress,
  iso,
  num,
  poolKey,
  safeText,
  type Observation,
  type Provenance,
} from "../domain";

const object = z.record(z.string(), z.unknown());
function record(x: unknown): Record<string, any> {
  return object.safeParse(x).success ? (x as Record<string, any>) : {};
}
function normalized(
  input: Omit<Observation, "id" | "chain">,
): Observation | null {
  if (!isAddress(input.mint) || !isAddress(input.poolId)) return null;
  return { ...input, id: poolKey(input.mint, input.poolId), chain: "solana" };
}
export function normalizeDex(data: unknown, p: Provenance): Observation[] {
  const rows = z.array(z.unknown()).parse(data);
  const out: Observation[] = [];
  for (const raw of rows) {
    const x = record(raw);
    if (x.chainId !== "solana") continue;
    const b = record(x.baseToken),
      q = record(x.quoteToken),
      tx = record(record(x.txns).m5),
      v = record(x.volume),
      c = record(x.priceChange);
    const row = normalized({
      mint: b.address,
      poolId: x.pairAddress,
      name: safeText(b.name) || "Unbekannt",
      symbol: safeText(b.symbol, 20) || "?",
      dex: safeText(x.dexId, 40) || "unbekannt",
      quoteMint: isAddress(q.address) ? q.address : null,
      createdAt: iso(x.pairCreatedAt),
      priceUsd: num(x.priceUsd),
      liquidityUsd: num(record(x.liquidity).usd),
      volume5m: num(v.m5),
      volume1h: num(v.h1),
      volume24h: num(v.h24),
      buys5m: num(tx.buys),
      sells5m: num(tx.sells),
      change5m: num(c.m5, true),
      change1h: num(c.h1, true),
      change24h: num(c.h24, true),
      fdvUsd: num(x.fdv),
      marketCapUsd: num(x.marketCap),
      provenance: { ...p, provider: "dex" },
    });
    if (row) out.push(row);
  }
  return out;
}
export function normalizeGecko(data: unknown, p: Provenance): Observation[] {
  const root = z
    .object({
      data: z.array(z.unknown()),
      included: z.array(z.unknown()).optional(),
    })
    .parse(data);
  const included = new Map(
    (root.included ?? []).map((x) => {
      const r = record(x);
      return [r.id, record(r.attributes)];
    }),
  );
  const out: Observation[] = [];
  for (const raw of root.data) {
    const x = record(raw),
      a = record(x.attributes),
      r = record(x.relationships);
    if (typeof x.id !== "string" || !x.id.startsWith("solana_")) continue;
    const base = record(record(r.base_token).data),
      quote = record(record(r.quote_token).data),
      dex = record(record(r.dex).data);
    const b = included.get(base.id) ?? {},
      q = included.get(quote.id) ?? {};
    const tx = record(record(a.transactions).m5),
      v = record(a.volume_usd),
      c = record(a.price_change_percentage);
    const row = normalized({
      mint: b.address ?? String(base.id ?? "").replace(/^solana_/, ""),
      poolId: a.address,
      name: safeText(b.name) || safeText(a.name) || "Unbekannt",
      symbol:
        safeText(b.symbol, 20) ||
        safeText(String(a.name ?? "").split(" / ")[0], 20) ||
        "?",
      dex: safeText(dex.id, 40) || "unbekannt",
      quoteMint: isAddress(q.address)
        ? q.address
        : isAddress(String(quote.id ?? "").replace(/^solana_/, ""))
          ? String(quote.id).replace(/^solana_/, "")
          : null,
      createdAt: iso(a.pool_created_at),
      priceUsd: num(a.base_token_price_usd),
      liquidityUsd: num(a.reserve_in_usd),
      volume5m: num(v.m5),
      volume1h: num(v.h1),
      volume24h: num(v.h24),
      buys5m: num(tx.buys),
      sells5m: num(tx.sells),
      change5m: num(c.m5, true),
      change1h: num(c.h1, true),
      change24h: num(c.h24, true),
      fdvUsd: num(a.fdv_usd),
      marketCapUsd: num(a.market_cap_usd),
      provenance: { ...p, provider: "gecko" },
    });
    if (row) out.push(row);
  }
  return out;
}
