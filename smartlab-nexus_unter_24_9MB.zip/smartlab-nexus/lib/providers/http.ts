import { fetch as undiciFetch, EnvHttpProxyAgent } from "undici";
import type { Provider, Provenance } from "../domain";
import { TokenBucket } from "../../worker/scheduler";
import { freshnessBudgets } from "../freshness-config";

export type Transport = (url: string, init?: RequestInit) => Promise<Response>;
export interface HttpHooks {
  claim?: (provider: Provider, channel: string) => Promise<void>;
  audit?: (event: {
    provider: Provider;
    endpoint: string;
    ok: boolean;
    status: number;
    latencyMs: number;
    error: string | null;
    retryAfterMs: number;
  }) => Promise<void>;
}
export class ProviderError extends Error {
  constructor(
    public provider: Provider,
    public status: number,
    public retryAfterMs = 0,
    message?: string,
  ) {
    super(message ?? `${provider}: HTTP ${status}`);
    this.name = "ProviderError";
  }
}
export function provenance(
  provider: Provider,
  endpoint: string,
  headers: Headers,
  at: Date,
  latencyMs: number,
): Provenance {
  const date = Date.parse(headers.get("date") ?? "");
  const age = Number(headers.get("age") ?? 0);
  const cacheAgeSeconds = Math.max(
    Number.isFinite(age) ? Math.max(0, age) : 0,
    Number.isFinite(date) ? Math.max(0, (at.getTime() - date) / 1000) : 0,
  );
  const hasClock = Number.isFinite(date) || headers.has("age");
  return {
    freshnessBudgetSeconds: freshnessBudgets().market,
    provider,
    endpoint,
    fetchedAt: at.toISOString(),
    sourceAt: new Date(at.getTime() - cacheAgeSeconds * 1000).toISOString(),
    measuredAt: null,
    timestampKind: hasClock ? "http-cache-estimate" : "retrieval-only",
    cacheAgeSeconds,
    latencyMs,
  };
}
let dispatcher: EnvHttpProxyAgent | undefined;
const transport: Transport = async (url, init) => {
  dispatcher ??= new EnvHttpProxyAgent();
  return (await undiciFetch(url, { ...init, dispatcher } as Parameters<
    typeof undiciFetch
  >[1])) as unknown as Response;
};
export class HttpClient {
  private buckets = new Map<string, TokenBucket>();
  constructor(
    private fetcher: Transport = transport,
    private hooks: HttpHooks = {},
  ) {}
  async validate<T>(
    provider: Provider,
    endpoint: string,
    parse: () => T,
  ): Promise<T> {
    try {
      return parse();
    } catch (cause) {
      const error =
        cause instanceof ProviderError
          ? cause
          : new ProviderError(
              provider,
              502,
              0,
              "Provider-Schema oder RPC-Ergebnis ungültig",
            );
      await this.hooks.audit?.({
        provider,
        endpoint,
        ok: false,
        status: error.status,
        latencyMs: 0,
        error: error.message,
        retryAfterMs: error.retryAfterMs,
      });
      throw error;
    }
  }
  async get(
    provider: Provider,
    endpoint: string,
    url: string,
    channel = provider as string,
  ) {
    return this.request(provider, endpoint, url, channel);
  }
  async request(
    provider: Provider,
    endpoint: string,
    url: string,
    channel: string,
    body?: unknown,
  ): Promise<{ data: unknown; provenance: Provenance }> {
    if (
      process.env.CI_NETWORK_ISOLATION === "true" &&
      process.env.NEXUS_TEST_MODE === "true"
    )
      throw new ProviderError(
        provider,
        503,
        0,
        "Externe Abrufe im isolierten Test deaktiviert",
      );
    const capacity = (
      { gecko: 8, "dex-profiles": 6, "dex-market": 30, solana: 30 } as Record<
        string,
        number
      >
    )[channel];
    if (capacity) {
      let bucket = this.buckets.get(channel);
      if (!bucket) {
        bucket = new TokenBucket(capacity, capacity);
        this.buckets.set(channel, bucket);
      }
      if (!bucket.take())
        throw new ProviderError(
          provider,
          429,
          bucket.retryAfterMs(),
          "Lokales Token-Bucket-Budget ausgeschöpft",
        );
    }
    await this.hooks.claim?.(provider, channel);
    const start = performance.now();
    let status = 0;
    try {
      const response = await this.fetcher(url, {
        method: body === undefined ? "GET" : "POST",
        signal: AbortSignal.timeout(12000),
        headers: {
          Accept:
            provider === "gecko"
              ? "application/json;version=20230203"
              : "application/json",
          ...(body === undefined ? {} : { "Content-Type": "application/json" }),
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      });
      status = response.status;
      if (!response.ok) {
        const h = response.headers.get("retry-after");
        const retry = h
          ? /^\d+(\.\d+)?$/.test(h)
            ? Number(h) * 1000
            : Math.max(0, Date.parse(h) - Date.now())
          : 0;
        throw new ProviderError(
          provider,
          status,
          Number.isFinite(retry) ? retry : 0,
        );
      }
      const text = await response.text();
      if (text.length > 8_000_000)
        throw new ProviderError(
          provider,
          502,
          0,
          "Provider-Antwort überschreitet Größenlimit",
        );
      let data: unknown;
      try {
        data = JSON.parse(text);
      } catch {
        throw new ProviderError(provider, 502, 0, "Ungültige JSON-Antwort");
      }
      const p = provenance(
        provider,
        endpoint,
        response.headers,
        new Date(),
        performance.now() - start,
      );
      await this.hooks.audit?.({
        provider,
        endpoint,
        ok: true,
        status,
        latencyMs: p.latencyMs,
        error: null,
        retryAfterMs: 0,
      });
      return { data, provenance: p };
    } catch (error) {
      const e =
        error instanceof ProviderError
          ? error
          : new ProviderError(
              provider,
              status || 503,
              0,
              "Provider nicht erreichbar oder Zeitlimit überschritten",
            );
      await this.hooks.audit?.({
        provider,
        endpoint,
        ok: false,
        status: e.status,
        latencyMs: performance.now() - start,
        error: e.message,
        retryAfterMs: e.retryAfterMs,
      });
      throw e;
    }
  }
}
