import { z } from "zod";
import { isAddress } from "../domain";
import { HttpClient } from "./http";
import { normalizeDex } from "./normalize";
export class DexProvider {
  constructor(private http = new HttpClient()) {}
  async profileFeed() {
    const r = await this.http.get(
      "dex",
      "token-profiles/latest",
      "https://api.dexscreener.com/token-profiles/latest/v1",
      "dex-profiles",
    );
    const rows = await this.http.validate("dex", "token-profiles/latest", () =>
      z
        .array(
          z
            .object({ chainId: z.string(), tokenAddress: z.string() })
            .passthrough(),
        )
        .parse(r.data),
    );
    return {
      provenance: r.provenance,
      mints: rows
        .filter((x) => x.chainId === "solana" && isAddress(x.tokenAddress))
        .map((x) => x.tokenAddress)
        .slice(0, 30),
    };
  }
  async profiles() {
    return (await this.profileFeed()).mints;
  }
  async tokens(mints: string[]) {
    if (!mints.length) return [];
    if (mints.length > 30 || mints.some((m) => !isAddress(m)))
      throw new Error("Ungültige Mint-Liste");
    const r = await this.http.get(
      "dex",
      "tokens/solana",
      "https://api.dexscreener.com/tokens/v1/solana/" + mints.join(","),
      "dex-market",
    );
    return this.http.validate("dex", "tokens/solana", () =>
      normalizeDex(r.data, r.provenance),
    );
  }
  async search(query: string) {
    const q = query.trim().slice(0, 96);
    if (q.length < 2) return [];
    const r = await this.http.get(
      "dex",
      "search",
      "https://api.dexscreener.com/latest/dex/search?q=" +
        encodeURIComponent(q),
      "dex-market",
    );
    const root = await this.http.validate("dex", "search", () =>
      z
        .object({ pairs: z.array(z.unknown()).nullable().optional() })
        .parse(r.data),
    );
    return normalizeDex(root.pairs ?? [], r.provenance);
  }
}
