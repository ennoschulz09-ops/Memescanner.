export interface ChartPoint {
  at: string;
  value: number | null;
}
export interface MeasuredPoint {
  at: string;
  value: number;
}
/** Never interpolate nulls, invalid values or unobserved intervals. Last duplicate wins. */
export function segmentSeries(
  points: ChartPoint[],
  maxGapMs = 180000,
): MeasuredPoint[][] {
  const ordered = [
    ...new Map(
      points
        .filter((p) => Number.isFinite(Date.parse(p.at)))
        .map((p) => [Date.parse(p.at), p]),
    ).values(),
  ].sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  const segments: MeasuredPoint[][] = [];
  let current: MeasuredPoint[] = [];
  const flush = () => {
    if (current.length) segments.push(current);
    current = [];
  };
  for (const point of ordered) {
    if (point.value === null || !Number.isFinite(point.value)) {
      flush();
      continue;
    }
    if (
      current.length &&
      Date.parse(point.at) - Date.parse(current.at(-1)!.at) > maxGapMs
    )
      flush();
    current.push({ at: point.at, value: point.value });
  }
  flush();
  return segments;
}

/** Normalized geometry avoids overflow for valid values near Number.MAX_VALUE. */
export function chartScale(values: number[], nonnegative = false) {
  const low = Math.min(...values),
    high = Math.max(...values);
  const magnitude = Math.max(Math.abs(low), Math.abs(high)) || 1;
  const lo = low / magnitude,
    hi = high / magnitude;
  const range = hi - lo || 0.01;
  const floor = nonnegative && low >= 0 ? 0 : -Number.MAX_VALUE / magnitude;
  const min = Math.max(floor, lo - range * 0.1),
    max = Math.min(Number.MAX_VALUE / magnitude, hi + range * 0.1);
  return {
    fraction: (value: number) => (value / magnitude - min) / (max - min),
    valueAt: (fraction: number) =>
      Math.max(
        -Number.MAX_VALUE,
        Math.min(Number.MAX_VALUE, (min + (max - min) * fraction) * magnitude),
      ),
  };
}
