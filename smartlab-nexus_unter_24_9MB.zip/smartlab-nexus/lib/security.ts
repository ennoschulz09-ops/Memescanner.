import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { db } from "./db";
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
const buckets = new Map<string, { at: number; count: number }>();
export function rateLimit(key: string, limit = 120) {
  const now = Date.now();
  let v = buckets.get(key);
  if (!v || now - v.at > 60000) {
    v = { at: now, count: 0 };
    buckets.set(key, v);
  }
  if (++v.count > limit)
    throw new ApiError(
      429,
      "Anfragelimit erreicht. Bitte in einer Minute erneut versuchen.",
    );
  if (buckets.size > 10000)
    for (const [k, v] of buckets) if (now - v.at > 60000) buckets.delete(k);
}
function hash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}
function cookies(req: Request) {
  return Object.fromEntries(
    (req.headers.get("cookie") ?? "").split(";").map((x) => {
      const [key, ...rest] = x.trim().split("=");
      return [key, rest.join("=")];
    }),
  );
}
export function checkOrigin(req: Request) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const origin = req.headers.get("origin");
  const configured = process.env.APP_ORIGIN || "http://localhost:3000";
  const allowed = new Set([configured]);
  const u = new URL(configured);
  if (["localhost", "127.0.0.1", "0.0.0.0"].includes(u.hostname))
    for (const h of ["localhost", "127.0.0.1", "0.0.0.0"])
      allowed.add(`${u.protocol}//${h}:${u.port || "3000"}`);
  if (!origin || !allowed.has(origin))
    throw new ApiError(403, "Anfrageursprung nicht zugelassen.");
}
export function isAuthorized(req: Request) {
  const token = process.env.ACCESS_TOKEN;
  return !token || cookies(req).nexus_access === hash("nexus-access:" + token);
}
export function login(req: Request, token: string) {
  rateLimit("access-login", 10);
  const expected = process.env.ACCESS_TOKEN;
  if (!expected) return "";
  const a = Buffer.from(hash(token)),
    b = Buffer.from(hash(expected));
  if (!timingSafeEqual(a, b)) throw new ApiError(401, "Zugangscode ungültig.");
  return `nexus_access=${hash("nexus-access:" + expected)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=86400${req.url.startsWith("https:") ? "; Secure" : ""}`;
}
export async function session(req: Request) {
  const old = cookies(req).nexus_session;
  const token =
    old && /^[a-f0-9]{64}$/.test(old) ? old : randomBytes(32).toString("hex");
  const owner = hash(token);
  await db.query("INSERT INTO sessions(id) VALUES($1) ON CONFLICT DO NOTHING", [
    owner,
  ]);
  return {
    owner,
    cookie:
      old === token
        ? null
        : `nexus_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${req.url.startsWith("https:") ? "; Secure" : ""}`,
  };
}
export function csvCell(value: unknown) {
  if (value === null || value === undefined) return "";
  if (typeof value === "number")
    return Number.isFinite(value) ? String(value) : "";
  let s = String(value);
  if (/^[=+\-@\t\r\n]/.test(s)) s = "'" + s;
  return '"' + s.replaceAll('"', '""') + '"';
}
