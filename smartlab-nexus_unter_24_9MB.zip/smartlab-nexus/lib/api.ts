import { randomUUID } from "node:crypto";
import { z, ZodError } from "zod";
import { db, metric } from "./db";
import { getPools, getHealth, ingest } from "./ingestion";
import {
  providers,
  cached,
  inspectToken,
  tokenDetail,
  watchlists,
  analytics,
} from "./services";
import { isAddress, safeText, type PoolRow } from "./domain";
import { packPoolPage } from "./scanner-wire";
import { getDataQuality } from "./data-quality";
import {
  ApiError,
  checkOrigin,
  isAuthorized,
  login,
  session,
  rateLimit,
  csvCell,
} from "./security";
import { ProviderError } from "./providers/http";
import { streamStats } from "./stream";
import { getDiscoveries, getChainEvents } from "./discovery";
import { scannerPage, scannerSortKeys } from "./scanner-query";

const address = z.string().refine(isAddress, "Ungültige Solana-Adresse");
const name = z
  .string()
  .trim()
  .min(1)
  .max(64)
  .transform((s) => safeText(s, 64))
  .refine(Boolean);
const filterSchema = z
  .object({
    query: z.string().max(96).optional(),
    preset: z.string().max(32).optional(),
    minLiquidity: z.number().min(0).optional(),
    maxPoolAgeMins: z.number().min(0).optional(),
    minRelativeVolume: z.number().min(0).optional(),
    minActivity: z.number().min(0).optional(),
    minActivityIncrease: z.number().min(0).optional(),
    maxConcentration: z.number().min(0).max(100).optional(),
    minQuality: z.number().min(0).max(100).optional(),
    dex: z.string().max(40).optional(),
    security: z.enum(["critical", "unknown", "observed", ""]).optional(),
  })
  .strict();
const settingsSchema = z
  .object({
    compact: z.boolean().optional(),
    timezone: z.enum(["local", "UTC"]).optional(),
    reducedMotion: z.boolean().optional(),
    columns: z.array(z.string().max(40)).max(24).optional(),
    recentMints: z.array(address).max(10).optional(),
    defaultWindow: z.enum(["1h", "24h", "7d"]).optional(),
  })
  .strict();
const ruleSchema = z
  .object({
    name,
    kind: z.enum([
      "new_token",
      "new_pool",
      "concentration_increase",
      "feed_outage",
      "liquidity_change",
      "risk_flag",
      "watchlist_activity",
    ]),
    threshold: z.number().min(0).max(1000000),
    cooldownSeconds: z.number().int().min(60).max(86400),
    debounceSeconds: z.number().int().min(0).max(3600).optional().default(0),
    quotaPerHour: z.number().int().min(1).max(100),
    quietStart: z.number().int().min(0).max(23).nullable(),
    quietEnd: z.number().int().min(0).max(23).nullable(),
    enabled: z.boolean(),
    mint: address.nullable(),
    watchlistId: z.string().max(64).nullable(),
  })
  .strict();
async function body(req: Request) {
  if (Number(req.headers.get("content-length") ?? 0) > 32768)
    throw new ApiError(413, "Anfrage zu groß.");
  const reader = req.body?.getReader();
  if (!reader) throw new ApiError(400, "JSON-Eingabe erforderlich.");
  let bytes = 0,
    text = "";
  const decoder = new TextDecoder();
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    bytes += part.value.byteLength;
    if (bytes > 32768) {
      await reader.cancel();
      throw new ApiError(413, "Anfrage zu groß.");
    }
    text += decoder.decode(part.value, { stream: true });
  }
  text += decoder.decode();
  try {
    return JSON.parse(text);
  } catch {
    throw new ApiError(400, "Ungültiges JSON.");
  }
}
async function preferences(owner: string) {
  return (
    (await db.query("SELECT preferences FROM sessions WHERE id=$1", [owner]))
      .rows[0]?.preferences ?? {}
  );
}
export async function handleApi(
  req: Request,
  _segments?: string[],
): Promise<Response> {
  let cookie: string | null = null;
  const send = (
    data: unknown,
    status = 200,
    headers: Record<string, string> = {},
  ) =>
    new Response(JSON.stringify(data), {
      status,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
        ...(cookie ? { "Set-Cookie": cookie } : {}),
        ...headers,
      },
    });
  try {
    checkOrigin(req);
    const url = new URL(req.url),
      parts = url.pathname
        .replace(/^\/api\/?/, "")
        .split("/")
        .filter(Boolean),
      [root, id, action] = parts;
    const readLike =
      req.method === "GET" ||
      (root === "pools" && id === "query") ||
      ["metrics", "chain-receipts"].includes(root);
    rateLimit("global:" + (readLike ? "read" : "write"), readLike ? 2400 : 300);
    if (root === "access" && req.method === "POST") {
      const p = z
        .object({ token: z.string().min(1).max(256) })
        .parse(await body(req));
      return send({ ok: true }, 200, { "Set-Cookie": login(req, p.token) });
    }
    if (!isAuthorized(req))
      return send({ error: "Zugangscode erforderlich." }, 401);
    const s = await session(req);
    cookie = s.cookie;
    const owner = s.owner;
    rateLimit(`${owner}:${readLike ? "read" : "write"}`, readLike ? 1200 : 60);
    if (root === "session" && req.method === "GET")
      return send({ authorized: true, settings: await preferences(owner) });
    if (root === "discoveries" && req.method === "GET")
      return send({
        tokens: await getDiscoveries(),
        chainEvents: await getChainEvents(),
        publishedAt: new Date().toISOString(),
        coverage:
          "Profil- und Poolfeeds; keine vollständige Mint-Erkennung. Entdeckt bedeutet zuerst hier beobachtet.",
      });
    if (root === "chain-receipts" && req.method === "POST") {
      const input = z
        .object({
          eventIds: z
            .array(z.string().regex(/^[1-9A-HJ-NP-Za-km-z]{64,100}$/))
            .min(1)
            .max(30),
          publishedAt: z.iso.datetime(),
          renderedAt: z.iso.datetime(),
          stage: z.enum(["candidate", "decoded"]),
        })
        .strict()
        .parse(await body(req));
      const published = Date.parse(input.publishedAt),
        rendered = Date.parse(input.renderedAt);
      if (
        rendered < published ||
        rendered - published > 300000 ||
        Math.abs(Date.now() - rendered) > 60000
      )
        throw new ApiError(400, "Ungültiges Messfenster");
      await db.query(
        `INSERT INTO chain_ui_receipts(signature,owner,published_at,rendered_at,rendered_state)
        SELECT signature,$2,$3,$4,$5 FROM chain_candidates WHERE signature=ANY($1::text[]) AND ($5='candidate' OR status='decoded')
        ON CONFLICT(signature,owner,rendered_state) DO NOTHING`,
        [
          input.eventIds,
          owner,
          input.publishedAt,
          input.renderedAt,
          input.stage,
        ],
      );
      return send({
        ok: true,
        measurement: "browser-reported; clock offset unknown",
      });
    }
    const sendPools = <T extends { rows: PoolRow[] }>(page: T) =>
      send(
        url.searchParams.get("format") === "compact"
          ? packPoolPage(page)
          : page,
      );
    if (root === "quality" && req.method === "GET")
      return send(await getDataQuality());
    if (root === "pools" && req.method === "GET") {
      if (url.searchParams.has("page")) {
        const page = z.coerce
          .number()
          .int()
          .min(1)
          .max(100000)
          .parse(url.searchParams.get("page"));
        const pageSize = z.coerce
          .number()
          .int()
          .min(1)
          .max(200)
          .parse(url.searchParams.get("pageSize") ?? 100);
        const sort = z
          .enum(scannerSortKeys)
          .parse(url.searchParams.get("sort") ?? "firstSeenAt");
        const direction = z
          .enum(["asc", "desc"])
          .parse(url.searchParams.get("direction") ?? "desc");
        const raw = url.searchParams.get("filters") ?? "{}";
        if (raw.length > 4096) throw new ApiError(400, "Filter zu lang.");
        let parsed: unknown;
        try {
          parsed = JSON.parse(raw);
        } catch {
          throw new ApiError(400, "Filter ungültig.");
        }
        return sendPools(
          await scannerPage({
            page,
            pageSize,
            sort,
            direction,
            filters: filterSchema.parse(parsed),
          }),
        );
      }
      const since = url.searchParams.get("since");
      if (since && !z.iso.datetime().safeParse(since).success)
        throw new ApiError(400, "Ungültiger Zeitstempel.");
      const rows = await getPools({ since: since ?? undefined, limit: 200 });
      return sendPools({
        rows,
        limit: 200,
        at: new Date().toISOString(),
        coverage:
          "Ausschnitt öffentlicher Solana-Pools. Poolalter ist kein Tokenalter.",
      });
    }
    if (root === "pools" && id === "query" && req.method === "POST") {
      const { ids } = z
        .object({
          ids: z
            .array(
              z
                .string()
                .refine(
                  (s) =>
                    s.split(":").length === 2 && s.split(":").every(isAddress),
                ),
            )
            .min(1)
            .max(300),
        })
        .strict()
        .parse(await body(req));
      return sendPools({
        rows: await getPools({ ids }),
        at: new Date().toISOString(),
      });
    }
    if (root === "health" && req.method === "GET")
      return send({ ...(await getHealth()), stream: streamStats() });
    if (root === "search" && req.method === "POST") {
      const { query } = z
        .object({ query: z.string().trim().min(2).max(96) })
        .strict()
        .parse(await body(req));
      const rows = await providers.dex.search(query);
      await ingest(rows);
      const keys = new Set(rows.map((x) => x.id));
      return send({
        rows: (await getPools()).filter((x) => keys.has(x.id)),
        at: new Date().toISOString(),
      });
    }
    if (root === "tokens" && id) {
      address.parse(id);
      if (req.method === "GET") {
        const result = await tokenDetail(
          id,
          url.searchParams.get("pool") ?? undefined,
          owner,
        );
        if (!result) throw new ApiError(404, "Token noch nicht erfasst.");
        return send(result);
      }
      if (req.method === "POST" && action === "inspect") {
        if (!(await getPools({ mint: id })).length)
          throw new ApiError(404, "Token noch nicht erfasst.");
        return send(await inspectToken(id));
      }
    }
    if (root === "candles" && req.method === "GET") {
      address.parse(id);
      const window = z.enum(["1h", "24h", "7d"]).parse(action);
      return send(
        await cached(`candles:${id}:${window}`, 60, () =>
          providers.gecko.ohlcv(id, window),
        ),
      );
    }
    if (root === "wallet" && req.method === "GET") {
      address.parse(id);
      return send(
        await cached("wallet:" + id, 60, () => providers.solana.wallet(id)),
      );
    }
    if (root === "watchlists") {
      if (req.method === "GET") return send(await watchlists(owner));
      if (!id && req.method === "POST") {
        const p = z
          .object({ name })
          .strict()
          .parse(await body(req));
        const r = await db.query(
          "INSERT INTO watchlists(id,owner,name) SELECT $1,$2,$3 WHERE (SELECT count(*) FROM watchlists WHERE owner=$2)<20 ON CONFLICT(owner,name) DO UPDATE SET name=$3 RETURNING id,name",
          [randomUUID(), owner, p.name],
        );
        if (!r.rowCount) throw new ApiError(409, "Maximal 20 Watchlists.");
        return send(r.rows[0]);
      }
      if (id === "items" && ["POST", "DELETE"].includes(req.method)) {
        const p = z
          .object({ mint: address, listId: z.string().max(64).optional() })
          .strict()
          .parse(await body(req));
        let listId = p.listId;
        if (!listId) {
          const r = await db.query(
            "INSERT INTO watchlists(id,owner,name) VALUES($1,$2,$3) ON CONFLICT(owner,name) DO UPDATE SET name=$3 RETURNING id",
            [randomUUID(), owner, "Meine Watchlist"],
          );
          listId = r.rows[0].id;
        }
        if (
          !(
            await db.query(
              "SELECT id FROM watchlists WHERE id=$1 AND owner=$2",
              [listId, owner],
            )
          ).rowCount
        )
          throw new ApiError(404, "Watchlist nicht gefunden.");
        if (req.method === "POST") {
          if (
            !(await db.query("SELECT mint FROM tokens WHERE mint=$1", [p.mint]))
              .rowCount
          )
            throw new ApiError(404, "Token noch nicht erfasst.");
          const count = await db.query(
            "SELECT count(*)::int as n FROM watchlist_items WHERE list_id=$1",
            [listId],
          );
          if (count.rows[0].n >= 500)
            throw new ApiError(409, "Maximal 500 Einträge je Liste.");
          await db.query(
            "INSERT INTO watchlist_items(list_id,mint) VALUES($1,$2) ON CONFLICT DO NOTHING",
            [listId, p.mint],
          );
        } else
          await db.query(
            "DELETE FROM watchlist_items WHERE list_id=$1 AND mint=$2",
            [listId, p.mint],
          );
        return send({ ok: true, listId });
      }
      if (id && req.method === "DELETE") {
        await db.query("DELETE FROM watchlists WHERE id=$1 AND owner=$2", [
          id,
          owner,
        ]);
        return send({ ok: true });
      }
    }
    if (root === "presets") {
      if (req.method === "GET")
        return send({
          presets: (
            await db.query(
              "SELECT id,name,filters FROM presets WHERE owner=$1 ORDER BY name",
              [owner],
            )
          ).rows,
        });
      if (req.method === "POST") {
        const p = z
          .object({ name, filters: filterSchema })
          .strict()
          .parse(await body(req));
        const count = (
          await db.query(
            "SELECT count(*)::int as n FROM presets WHERE owner=$1",
            [owner],
          )
        ).rows[0].n;
        if (count >= 50) throw new ApiError(409, "Maximal 50 Filter-Presets.");
        return send(
          (
            await db.query(
              "INSERT INTO presets(id,owner,name,filters) VALUES($1,$2,$3,$4) ON CONFLICT(owner,name) DO UPDATE SET filters=$4 RETURNING *",
              [randomUUID(), owner, p.name, p.filters],
            )
          ).rows[0],
        );
      }
      if (id && req.method === "DELETE") {
        await db.query("DELETE FROM presets WHERE id=$1 AND owner=$2", [
          id,
          owner,
        ]);
        return send({ ok: true });
      }
    }
    if (root === "alerts") {
      if (req.method === "GET") {
        const [rules, events] = await Promise.all([
          db.query(
            "SELECT id,name,data FROM alert_rules WHERE owner=$1 ORDER BY created_at DESC",
            [owner],
          ),
          db.query(
            "SELECT id,mint,trigger_state,delivery_state,data,at,delivered_at FROM alert_events WHERE owner=$1 ORDER BY at DESC LIMIT 200",
            [owner],
          ),
        ]);
        return send({
          rules: rules.rows,
          events: events.rows,
          channel: "in-app",
        });
      }
      if (id === "ack" && req.method === "POST") {
        const { ids } = z
          .object({ ids: z.array(z.string().max(64)).max(200) })
          .strict()
          .parse(await body(req));
        await db.query(
          "UPDATE alert_events SET delivery_state='delivered',delivered_at=clock_timestamp() WHERE owner=$1 AND id=ANY($2::text[]) AND delivery_state='pending'",
          [owner, ids],
        );
        return send({ ok: true });
      }
      if (!id && req.method === "POST") {
        const p = ruleSchema.parse(await body(req));
        if (
          p.watchlistId &&
          !(
            await db.query(
              "SELECT id FROM watchlists WHERE id=$1 AND owner=$2",
              [p.watchlistId, owner],
            )
          ).rowCount
        )
          throw new ApiError(404, "Watchlist nicht gefunden.");
        if (p.kind === "watchlist_activity" && !p.watchlistId && !p.mint)
          throw new ApiError(
            400,
            "Für Watchlist-Ereignisse eine Liste oder Mint-Adresse angeben.",
          );
        const count = (
          await db.query(
            "SELECT count(*)::int as n FROM alert_rules WHERE owner=$1",
            [owner],
          )
        ).rows[0].n;
        if (count >= 50) throw new ApiError(409, "Maximal 50 Alert-Regeln.");
        return send(
          (
            await db.query(
              "INSERT INTO alert_rules(id,owner,name,data) VALUES($1,$2,$3,$4) RETURNING id",
              [randomUUID(), owner, p.name, p],
            )
          ).rows[0],
        );
      }
      if (id && req.method === "PATCH") {
        const patch = z
          .object({ enabled: z.boolean() })
          .strict()
          .parse(await body(req));
        await db.query(
          "UPDATE alert_rules SET data=data||$3::jsonb WHERE id=$1 AND owner=$2",
          [id, owner, patch],
        );
        return send({ ok: true });
      }
      if (id && req.method === "DELETE") {
        await db.query("DELETE FROM alert_rules WHERE id=$1 AND owner=$2", [
          id,
          owner,
        ]);
        return send({ ok: true });
      }
    }
    if (root === "settings") {
      if (req.method === "GET")
        return send({
          settings: await preferences(owner),
          runtime: {
            pollIntervalSeconds: Math.max(
              60,
              (Number(process.env.POLL_INTERVAL_MS) || 60000) / 1000,
            ),
            retentionDays: Number(process.env.RETENTION_DAYS) || 30,
            authentication: !!process.env.ACCESS_TOKEN,
            providerMode: "Öffentliche Read-only-APIs",
          },
        });
      if (req.method === "PATCH") {
        const p = settingsSchema.parse(await body(req));
        await db.query(
          "UPDATE sessions SET preferences=preferences||$2::jsonb WHERE id=$1",
          [owner, p],
        );
        return send({ ok: true, settings: await preferences(owner) });
      }
    }
    if (root === "analytics" && req.method === "GET")
      return send(await analytics());
    if (root === "events" && req.method === "GET") {
      const q = (url.searchParams.get("q") ?? "").slice(0, 96);
      return send({
        events: (
          await db.query(
            "SELECT id,kind,mint,payload,at FROM events WHERE $1='' OR mint ILIKE $2 OR kind ILIKE $2 ORDER BY at DESC LIMIT 300",
            [q, "%" + q + "%"],
          )
        ).rows,
      });
    }
    if (root === "metrics" && req.method === "POST") {
      const sample = z
        .object({
          stage: z.enum([
            "receipt_to_ui",
            "db_to_ui",
            "publish_to_ui",
            "fcp",
            "filter",
            "search",
            "tti",
          ]),
          durationMs: z.number().min(0).max(300000),
        })
        .strict();
      const input = await body(req);
      const samples = Array.isArray((input as { samples?: unknown })?.samples)
        ? z
            .object({ samples: z.array(sample).min(1).max(100) })
            .strict()
            .parse(input).samples
        : [sample.parse(input)];
      await db.query(
        'INSERT INTO metrics(stage,duration_ms) SELECT x.stage,x."durationMs" FROM jsonb_to_recordset($1::jsonb) x(stage text,"durationMs" double precision)',
        [JSON.stringify(samples)],
      );
      return send({ ok: true });
    }
    if (root === "export" && req.method === "GET") {
      const format = z
        .enum(["csv", "json"])
        .parse(url.searchParams.get("format") ?? "json");
      const scope = z
        .enum(["pools", "events", "alerts"])
        .parse(url.searchParams.get("scope") ?? "pools");
      let rows: Record<string, unknown>[];
      if (scope === "events")
        rows = (
          await db.query(
            "SELECT kind,mint,at,payload FROM events ORDER BY at DESC LIMIT 10000",
          )
        ).rows.map((x) => ({
          kind: x.kind,
          mint: x.mint,
          at: x.at,
          value: x.payload.value ?? null,
        }));
      else if (scope === "alerts")
        rows = (
          await db.query(
            "SELECT mint,trigger_state,delivery_state,at,data FROM alert_events WHERE owner=$1 ORDER BY at DESC LIMIT 10000",
            [owner],
          )
        ).rows.map((x) => ({
          mint: x.mint,
          triggerState: x.trigger_state,
          deliveryState: x.delivery_state,
          at: x.at,
          ruleName: x.data.ruleName,
        }));
      else
        rows = (await getPools()).map((p) => ({
          mint: p.mint,
          pool: p.poolId,
          name: p.name,
          symbol: p.symbol,
          dex: p.dex,
          priceUsd: p.priceUsd,
          liquidityUsd: p.liquidityUsd,
          volume24h: p.volume24h,
          fdvUsd: p.fdvUsd,
          marketCapUsd: p.marketCapUsd,
          dataQuality: p.risk.dataQuality,
          risk: p.risk.overall,
          source: p.provenance.provider,
          sourceAt: p.provenance.sourceAt,
          fetchedAt: p.provenance.fetchedAt,
          timestampKind: p.provenance.timestampKind,
        }));
      const headers = {
        "Cache-Control": "no-store",
        "Content-Disposition": `attachment; filename="nexus-${scope}.${format}"`,
        ...(cookie ? { "Set-Cookie": cookie } : {}),
      };
      if (format === "json")
        return send(
          { exportedAt: new Date().toISOString(), scope, rows },
          200,
          headers,
        );
      const keys = rows.length ? Object.keys(rows[0]) : ["Keine Daten"];
      return new Response(
        "\ufeff" +
          [
            keys.map(csvCell).join(","),
            ...rows.map((r) => keys.map((k) => csvCell(r[k])).join(",")),
          ].join("\r\n"),
        { headers: { ...headers, "Content-Type": "text/csv; charset=utf-8" } },
      );
    }
    throw new ApiError(404, "Endpunkt nicht gefunden.");
  } catch (e) {
    if (e instanceof ZodError)
      return send(
        {
          error: "Eingabe ungültig.",
          issues: e.issues.map((i) => ({
            path: i.path.join("."),
            message: i.message,
          })),
        },
        400,
      );
    if (e instanceof ApiError) return send({ error: e.message }, e.status);
    if (e instanceof ProviderError)
      return send(
        {
          error: e.message,
          retryAfterSeconds: Math.ceil(e.retryAfterMs / 1000),
          mode: "degraded",
        },
        e.status === 429 ? 429 : 502,
        {
          "Retry-After": String(Math.max(1, Math.ceil(e.retryAfterMs / 1000))),
        },
      );
    console.error(
      JSON.stringify({
        event: "api_error",
        at: new Date().toISOString(),
        code:
          typeof e === "object" && e && "code" in e
            ? String(e.code)
            : "internal",
      }),
    );
    return send(
      {
        error: "Dienst oder Datenbank vorübergehend nicht verfügbar.",
        mode: "offline",
        database: "unavailable",
      },
      503,
    );
  }
}
