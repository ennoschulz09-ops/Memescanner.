import { db, claimBudget, auditRequest, countService } from "./db";
import { HttpClient, ProviderError } from "./providers/http";
import { DexProvider } from "./providers/dex";
import { GeckoProvider } from "./providers/gecko";
import { SolanaProvider } from "./providers/solana";
import { getPools, saveEvidence } from "./ingestion";
import { sourceConflicts } from "./risk";
const http = new HttpClient(undefined, {
  claim: claimBudget,
  audit: auditRequest,
});
export const providers = {
  dex: new DexProvider(http),
  gecko: new GeckoProvider(http),
  solana: new SolanaProvider(http),
};
export async function cached<T>(
  key: string,
  ttlSeconds: number,
  load: () => Promise<T>,
): Promise<
  T & {
    cache: { hit: boolean; ageSeconds: number; stale: boolean };
    error?: string;
  }
> {
  await countService("cache_requests");
  const row = (
    await db.query("SELECT data,updated_at FROM source_cache WHERE key=$1", [
      key,
    ])
  ).rows[0];
  const age = row
    ? (Date.now() - new Date(row.updated_at).getTime()) / 1000
    : Infinity;
  if (row && age < ttlSeconds) {
    await countService("cache_hits");
    return { ...row.data, cache: { hit: true, ageSeconds: age, stale: false } };
  }
  try {
    const data = await load();
    await db.query(
      "INSERT INTO source_cache(key,data) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET data=$2,updated_at=clock_timestamp()",
      [key, data],
    );
    return { ...data, cache: { hit: false, ageSeconds: 0, stale: false } };
  } catch (e) {
    if (row) {
      await countService("cache_stale_fallbacks");
      return {
        ...row.data,
        error:
          e instanceof ProviderError
            ? e.message
            : "Quelle vorübergehend nicht verfügbar",
        cache: { hit: true, ageSeconds: age, stale: true },
      };
    }
    throw e;
  }
}
export async function inspectToken(mint: string) {
  return cached("inspect:" + mint, 60, async () => {
    const evidence = await providers.solana.inspect(mint);
    await saveEvidence(mint, evidence);
    return { evidence };
  });
}
export async function tokenDetail(mint: string, poolId?: string, owner = "") {
  const pools = await getPools({ mint });
  const selected =
    pools.find((x) => x.poolId === poolId) ??
    [...pools].sort(
      (a, b) => (b.liquidityUsd ?? -1) - (a.liquidityUsd ?? -1),
    )[0];
  if (!selected) return null;
  const [history, audits, events, chain, alerts] = await Promise.all([
    db.query(
      "SELECT payload FROM samples WHERE pool_key=$1 AND provider=$2 ORDER BY source_at DESC LIMIT 1000",
      [selected.id, selected.provenance.provider],
    ),
    db.query(
      "SELECT report,at FROM risk_audits WHERE pool_key=$1 ORDER BY at DESC LIMIT 50",
      [selected.id],
    ),
    db.query(
      "SELECT kind,payload,at FROM events WHERE mint=$1 ORDER BY at DESC LIMIT 50",
      [mint],
    ),
    db.query("SELECT data FROM chain_evidence WHERE mint=$1", [mint]),
    db.query(
      "SELECT id,data,at,trigger_state,delivery_state FROM alert_events WHERE mint=$1 AND owner=$2 ORDER BY at DESC LIMIT 50",
      [mint, owner],
    ),
  ]);
  return {
    selected,
    alerts: alerts.rows,
    pools,
    history: history.rows.reverse().map((x) => ({
      at: x.payload.provenance.sourceAt,
      priceUsd: x.payload.priceUsd,
      liquidityUsd: x.payload.liquidityUsd,
      volume5m: x.payload.volume5m,
      trades5m:
        x.payload.buys5m === null || x.payload.sells5m === null
          ? null
          : x.payload.buys5m + x.payload.sells5m,
      provider: x.payload.provenance.provider,
    })),
    audits: audits.rows,
    evidence: chain.rows[0]?.data ?? null,
    events: events.rows,
    conflicts: sourceConflicts(selected.sources),
  };
}
export async function watchlists(owner: string) {
  const lists = (
    await db.query(
      "SELECT id,name,created_at FROM watchlists WHERE owner=$1 ORDER BY created_at",
      [owner],
    )
  ).rows;
  const items = (
    await db.query(
      "SELECT i.*,t.name,t.symbol FROM watchlist_items i JOIN watchlists w ON w.id=i.list_id JOIN tokens t ON t.mint=i.mint WHERE w.owner=$1 ORDER BY i.created_at DESC",
      [owner],
    )
  ).rows;
  return {
    lists: lists.map((l) => ({
      ...l,
      items: items.filter((i) => i.list_id === l.id),
    })),
  };
}
export async function analytics() {
  const observations = await getPools();
  const seen = new Set<string>();
  const pools = observations.filter((p) => {
    if (seen.has(p.poolId)) return false;
    seen.add(p.poolId);
    return true;
  });
  const dex: Record<string, { pools: number; liquidity: number }> = {};
  let liquidity = 0,
    volume = 0,
    knownLiquidity = 0,
    knownVolume = 0;
  for (const p of pools) {
    dex[p.dex] ??= { pools: 0, liquidity: 0 };
    dex[p.dex].pools++;
    if (p.liquidityUsd !== null) {
      liquidity += p.liquidityUsd;
      knownLiquidity++;
      dex[p.dex].liquidity += p.liquidityUsd;
    }
    if (p.volume24h !== null) {
      volume += p.volume24h;
      knownVolume++;
    }
  }
  const [events, audits] = await Promise.all([
    db.query(
      "SELECT date_trunc('hour',at) as hour,kind,count(*)::int as count FROM events WHERE at>now()-interval '24 hours' GROUP BY hour,kind ORDER BY hour",
    ),
    db.query(
      "SELECT provider,endpoint,ok,status,latency_ms,error,at FROM source_audits ORDER BY at DESC LIMIT 40",
    ),
  ]);
  return {
    pools: pools.length,
    tokens: new Set(pools.map((x) => x.mint)).size,
    liquidity: knownLiquidity ? liquidity : null,
    volume24h: knownVolume ? volume : null,
    liquidityCoverage: pools.length ? knownLiquidity / pools.length : 0,
    volumeCoverage: pools.length ? knownVolume / pools.length : 0,
    quality: pools.length
      ? pools.reduce((n, p) => n + p.risk.dataQuality, 0) / pools.length
      : null,
    riskCounts: Object.fromEntries(
      ["critical", "notable", "unknown", "observed"].map((s) => [
        s,
        pools.filter((x) => x.risk.state === s).length,
      ]),
    ),
    dex: Object.entries(dex)
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.liquidity - a.liquidity),
    events: events.rows,
    audits: audits.rows,
    at: new Date().toISOString(),
    scope:
      "Zuletzt aktualisierte Auswahl von maximal 10.000 Pool/Asset-Zeilen, dedupliziert nach Pool. Summen nur bekannter Werte; Abdeckung separat. Keine Hochrechnung auf den Gesamtmarkt.",
  };
}
