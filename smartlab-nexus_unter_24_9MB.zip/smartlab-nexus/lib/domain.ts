import bs58 from "bs58";
import { freshnessBudgets } from "./freshness-config";

export type Provider = "dex" | "gecko" | "solana";
export type NullableNumber = number | null;
export interface Provenance {
  freshnessBudgetSeconds?: number;
  provider: Provider;
  endpoint: string;
  fetchedAt: string;
  sourceAt: string;
  measuredAt: string | null;
  timestampKind: "http-cache-estimate" | "retrieval-only" | "rpc-slot";
  cacheAgeSeconds: number;
  latencyMs: number;
}
export interface Observation {
  normalizedAt?: string;
  fieldEvidence?: Record<string, ValueEvidence>;
  id: string;
  mint: string;
  poolId: string;
  chain: "solana";
  name: string;
  symbol: string;
  dex: string;
  quoteMint: string | null;
  createdAt: string | null;
  priceUsd: NullableNumber;
  liquidityUsd: NullableNumber;
  volume5m: NullableNumber;
  volume1h: NullableNumber;
  volume24h: NullableNumber;
  buys5m: NullableNumber;
  sells5m: NullableNumber;
  change5m: NullableNumber;
  change1h: NullableNumber;
  change24h: NullableNumber;
  fdvUsd: NullableNumber;
  marketCapUsd: NullableNumber;
  provenance: Provenance;
}
export interface ValueEvidence {
  source: Provider;
  sourceTimestamp: string | null;
  sourceResponseAt: string;
  fetchedAt: string;
  computedAt: string;
  freshness: "LIVE" | "CACHED" | "STALE" | "UNAVAILABLE";
  confidenceLevel: "complete" | "partial" | "unknown";
  missing: boolean;
  conflicts: string[];
}
export interface Controls {
  mintAuthority: string | null;
  freezeAuthority: string | null;
  program: string;
  supply: string;
  decimals: number;
  slot: number;
  extensions: string[];
}
export interface Concentration {
  top1Pct: NullableNumber;
  top20Pct: NullableNumber;
  scope: "token-accounts";
  accounts: { address: string; amount: string; pct: NullableNumber }[];
}
export interface ChainEvidence {
  components?: {
    contract: {
      status: "ok" | "unknown";
      checkedAt: string;
      slot: number | null;
    };
    holders: {
      status: "ok" | "unknown";
      checkedAt: string;
      slot: number | null;
    };
  };
  controls: Controls | null;
  concentration: Concentration | null;
  checkedAt: string;
  error: string | null;
  slot: number | null;
}
export type SignalState = "observed" | "notable" | "critical" | "unknown";
export interface RiskSignal {
  key: string;
  label: string;
  value: NullableNumber;
  unit: string;
  threshold: string;
  state: SignalState;
  source: string;
  updatedAt: string | null;
  coverage: number;
  explanation: string;
  formula: string;
  weight: number;
}
export interface RiskReport {
  evidenceStatus?: "COMPLETE" | "DEGRADED" | "UNKNOWN";
  modelVersion: string;
  dataQuality: number;
  overall: NullableNumber;
  coverage: number;
  state: SignalState;
  signals: RiskSignal[];
  flags: string[];
  computedAt: string;
}
export interface PoolRow extends Observation {
  revision?: string;
  activityIncreasePct?: number | null;
  firstSeenAt: string;
  updatedAt: string;
  risk: RiskReport;
  sources: Observation[];
  /** Compact lists expose provenance summaries; detail keeps full observations. */
  sourceDetail?: "full" | "deferred";
  sourceSummaries?: Provenance[];
  sparkline: { at: string; value: number | null }[];
}
export interface Sample {
  at: string;
  priceUsd: NullableNumber;
  liquidityUsd: NullableNumber;
  volume5m: NullableNumber;
  trades5m: NullableNumber;
  provider: Provider;
}
export interface ProviderState {
  provider: Provider;
  status: "ok" | "error" | "limited" | "unknown";
  lastSuccess: string | null;
  lastError: string | null;
  error: string | null;
  latencyMs: number | null;
  consecutiveErrors: number;
  retryAt: string | null;
}
export function safeText(value: unknown, max = 96): string {
  return typeof value === "string"
    ? value
        .replace(
          /[<>\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g,
          "",
        )
        .trim()
        .slice(0, max)
    : "";
}
export function isAddress(value: unknown): value is string {
  if (typeof value !== "string" || !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value))
    return false;
  try {
    return bs58.decode(value).length === 32;
  } catch {
    return false;
  }
}
export function num(value: unknown, signed = false): NullableNumber {
  if (
    typeof value === "string" &&
    !/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(value.trim())
  )
    return null;
  if (
    value === null ||
    value === undefined ||
    value === "" ||
    typeof value === "boolean" ||
    (typeof value !== "number" && typeof value !== "string")
  )
    return null;
  const n = Number(value);
  return Number.isFinite(n) && (signed || n >= 0) ? n : null;
}
export function iso(value: unknown): string | null {
  if (typeof value !== "number" && typeof value !== "string") return null;
  const n = new Date(value).getTime();
  return Number.isFinite(n) && n > 0 && n <= Date.now() + 60000
    ? new Date(n).toISOString()
    : null;
}
export function poolKey(mint: string, poolId: string) {
  return `${mint}:${poolId}`;
}
export function freshness(
  row: Pick<Observation, "provenance">,
  now = Date.now(),
  staleSeconds = row.provenance.freshnessBudgetSeconds ??
    freshnessBudgets().market,
): "current" | "stale" | "unknown" {
  if (row.provenance.timestampKind === "retrieval-only") return "unknown";
  const age = now - Date.parse(row.provenance.sourceAt);
  return age >= -60000 && age <= staleSeconds * 1000 ? "current" : "stale";
}
