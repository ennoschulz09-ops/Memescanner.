import { randomUUID } from "node:crypto";
import { db } from "./db";
import { getHealth } from "./ingestion";
import { session, isAuthorized, ApiError, rateLimit } from "./security";
import {
  subscribeChanges,
  ensureNotifications,
  notificationStats,
} from "./notifications";
const active = new Map<string, number>();
interface Version {
  id: string;
  revision: string;
  at: string;
  input_at: string;
}
const epoch = randomUUID();
let sequence = 0,
  generation = 0;
const checkpoints = new Map<
  string,
  { at: number; known: Map<string, string> }
>();
let cached: { at: number; generation: number; rows: Version[] } | null = null;
let loading: Promise<Version[]> | null = null;
async function versions() {
  if (
    cached &&
    cached.generation === generation &&
    Date.now() - cached.at < 100
  )
    return cached.rows;
  if (loading) {
    await loading;
    return versions();
  }
  const startGeneration = generation;
  loading = db
    .query(
      `SELECT id,revision::text,to_char(updated_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') as at,selected->'provenance'->>'fetchedAt' as input_at FROM pools ORDER BY id`,
    )
    .then((r) => {
      if (startGeneration === generation)
        cached = { at: Date.now(), generation, rows: r.rows };
      return r.rows as Version[];
    })
    .finally(() => {
      loading = null;
    });
  return loading;
}
export function streamStats() {
  return {
    connections: [...active.values()].reduce((a, b) => a + b, 0),
    transport: "SSE",
    protocolVersion: 2,
    sourceMode: "budgeted-polling",
    notifications: notificationStats(),
    checkpoints: checkpoints.size,
    replay: "bounded latest-state reconciliation; 32 checkpoints / 5 minutes",
  };
}
export async function openStream(req: Request): Promise<Response> {
  if (!isAuthorized(req))
    return Response.json(
      { error: "Zugangscode erforderlich." },
      { status: 401 },
    );
  try {
    const s = await session(req);
    rateLimit(s.owner + ":stream", 15);
    if ((active.get(s.owner) ?? 0) >= 3 || streamStats().connections >= 30)
      throw new ApiError(429, "Maximale Zahl offener Verbindungen erreicht.");
    const initial = await getHealth();
    generation++;
    cached = null;
    for (const [key, value] of checkpoints)
      if (Date.now() - value.at > 300000) checkpoints.delete(key);
    const previous = checkpoints.get(req.headers.get("last-event-id") ?? "");
    let known = previous?.known ?? new Map<string, string>(),
      hasSnapshot = !!previous,
      closed = false,
      busy = false,
      dirty = false;
    let timer: ReturnType<typeof setInterval> | undefined,
      lifetime: ReturnType<typeof setTimeout> | undefined,
      debounce: ReturnType<typeof setTimeout> | undefined;
    let closeController: (() => void) | undefined,
      unsubscribe: (() => void) | undefined;
    let lastHealth = Date.now();
    const cleanup = () => {
      if (closed) return;
      closed = true;
      clearInterval(timer);
      clearTimeout(lifetime);
      clearTimeout(debounce);
      unsubscribe?.();
      const n = Math.max(0, (active.get(s.owner) ?? 1) - 1);
      if (n) active.set(s.owner, n);
      else active.delete(s.owner);
      req.signal.removeEventListener("abort", onAbort);
    };
    const onAbort = () => {
      cleanup();
      closeController?.();
    };
    active.set(s.owner, (active.get(s.owner) ?? 0) + 1);
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        closeController = () => {
          try {
            controller.close();
          } catch {}
        };
        const send = (event: string, data: unknown, id?: string) => {
          if (!closed && (controller.desiredSize ?? 0) < -32) {
            cleanup();
            closeController?.();
            return;
          }
          if (!closed)
            controller.enqueue(
              new TextEncoder().encode(
                `${id ? "id: " + id + "\n" : ""}event: ${event}\ndata: ${JSON.stringify(data)}\n\n`,
              ),
            );
        };
        const schedule = () => {
          if (closed) return;
          if (busy) {
            dirty = true;
            return;
          }
          if (!debounce)
            debounce = setTimeout(() => {
              debounce = undefined;
              void check();
            }, 50);
        };
        const check = async () => {
          if (closed || busy) return;
          busy = true;
          try {
            await ensureNotifications();
            const rows = await versions();
            if (closed) return;
            const changed = rows.filter((r) => known.get(r.id) !== r.revision),
              next = new Map(rows.map((r) => [r.id, r.revision]));
            const removedIds = [...known.keys()].filter((id) => !next.has(id));
            const baseline = !hasSnapshot;
            hasSnapshot = true;
            known = next;
            if (changed.length || removedIds.length || baseline) {
              const latest = [...changed].sort((a, b) =>
                b.at.localeCompare(a.at),
              )[0];
              const id = `${epoch}:${++sequence}`;
              checkpoints.set(id, { at: Date.now(), known });
              while (checkpoints.size > 32)
                checkpoints.delete(checkpoints.keys().next().value!);
              send(
                "update",
                {
                  protocolVersion: 2,
                  ...(changed.length > 300
                    ? { resync: true }
                    : {
                        ids: changed.map((r) => r.id),
                        revisions: Object.fromEntries(
                          changed.map((r) => [r.id, r.revision]),
                        ),
                      }),
                  removedIds,
                  baseline,
                  at: latest?.at ?? new Date().toISOString(),
                  inputAt: latest?.input_at ?? null,
                  publishedAt: new Date().toISOString(),
                },
                id,
              );
            }
            if (Date.now() - lastHealth >= 10000) {
              lastHealth = Date.now();
              const health = await getHealth();
              send("status", {
                protocolVersion: 2,
                transport: notificationStats().connected
                  ? "connected"
                  : "degraded",
                sourceMode: "budgeted-polling",
                mode: health.mode,
                at: new Date().toISOString(),
              });
            }
          } catch {
            send("status", {
              protocolVersion: 2,
              transport: "degraded",
              mode: "offline",
              database: "unavailable",
              at: new Date().toISOString(),
            });
          } finally {
            busy = false;
            if (dirty) {
              dirty = false;
              schedule();
            }
          }
        };
        send("status", {
          protocolVersion: 2,
          transport: "connected",
          sourceMode: "budgeted-polling",
          mode: initial.mode,
          resync: !previous,
          resumed: !!previous,
          baseline: true,
          at: new Date().toISOString(),
        });
        unsubscribe = subscribeChanges((scope) => {
          generation++;
          cached = null;
          if (scope === "discoveries" || scope === "chain_candidates")
            send("discovery", { at: new Date().toISOString() });
          schedule();
        });
        req.signal.addEventListener("abort", onAbort, { once: true });
        timer = setInterval(() => void check(), 2000);
        void check();
        lifetime = setTimeout(() => {
          send("reconnect", { at: new Date().toISOString() });
          cleanup();
          closeController?.();
        }, 300000);
        if (req.signal.aborted) onAbort();
      },
      cancel() {
        cleanup();
      },
    });
    return new Response(body, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
        ...(s.cookie ? { "Set-Cookie": s.cookie } : {}),
      },
    });
  } catch (e) {
    return Response.json(
      {
        error: e instanceof ApiError ? e.message : "Datenbank nicht verfügbar.",
        mode: "offline",
      },
      { status: e instanceof ApiError ? e.status : 503 },
    );
  }
}
