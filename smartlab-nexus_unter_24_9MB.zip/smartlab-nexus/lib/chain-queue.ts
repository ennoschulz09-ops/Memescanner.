import { randomUUID } from "node:crypto";
import { db } from "./db";
import { CPMM_PROGRAM } from "./providers/pool-init";
import { ProviderError } from "./providers/http";
import { SolanaRpcError } from "./providers/solana";

export const CHAIN_LEASE_SECONDS = 90;
export interface ChainClaim {
  signature: string;
  slot: string;
  observed_at: Date;
  lease_token: string;
  attempt_count: number;
  failure_count: number;
}
export async function claimChainCandidate(): Promise<ChainClaim | null> {
  const token = randomUUID();
  const c = await db.connect();
  try {
    await c.query("BEGIN");
    const row = (
      await c.query(
        `WITH due AS (
      SELECT signature FROM chain_candidates WHERE processed_at IS NULL AND dead_letter_at IS NULL
      AND next_attempt_at<=clock_timestamp() AND (lease_until IS NULL OR lease_until<=clock_timestamp())
      ORDER BY next_attempt_at,observed_at,signature FOR UPDATE SKIP LOCKED LIMIT 1)
      UPDATE chain_candidates q SET status='processing',attempt_count=attempt_count+1,
      attempted_at=clock_timestamp(),lease_until=clock_timestamp()+($2*interval '1 second'),lease_token=$1
      FROM due WHERE q.signature=due.signature RETURNING q.*`,
        [token, CHAIN_LEASE_SECONDS],
      )
    ).rows[0];
    if (row) {
      await c.query(
        "UPDATE chain_candidate_attempts SET outcome='lease-expired',completed_at=clock_timestamp(),reason='worker_interrupted' WHERE signature=$1 AND outcome='processing'",
        [row.signature],
      );
      await c.query(
        "INSERT INTO chain_candidate_attempts(token,signature) VALUES($1,$2)",
        [token, row.signature],
      );
    }
    await c.query("COMMIT");
    return row ?? null;
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}

export function chainFailure(error: unknown) {
  if (error instanceof SolanaRpcError)
    return {
      reason: error.reason,
      permanent: error.permanent,
      limited: error.status === 429,
      delayMs: error.retryAfterMs,
      rpcCode: error.rpcCode,
    };
  if (error instanceof ProviderError)
    return {
      reason:
        error.status === 429
          ? "provider_rate_limited"
          : error.status === 502
            ? "rpc_schema_invalid"
            : "provider_unavailable",
      permanent: false,
      limited: error.status === 429,
      delayMs: error.retryAfterMs,
      rpcCode: null,
    };
  if (
    (error as { chainReason?: string })?.chainReason ===
    "transaction_not_available"
  )
    return {
      reason: "transaction_not_available",
      permanent: false,
      limited: false,
      delayMs: 0,
      rpcCode: null,
    };
  return {
    reason: "internal_processing_error",
    permanent: false,
    limited: false,
    delayMs: 0,
    rpcCode: null,
  };
}
export async function failChainCandidate(row: ChainClaim, error: unknown) {
  const failure = chainFailure(error);
  const failures = row.failure_count + (failure.limited ? 0 : 1);
  const terminal = failure.permanent || failures >= 5;
  const delay = Math.max(
    failure.delayMs,
    failure.limited
      ? 60000
      : Math.min(900000, 15000 * 2 ** Math.min(failures, 6)),
  );
  const terminalReason = terminal
    ? failure.permanent
      ? failure.reason
      : `retry_exhausted:${failure.reason}`
    : null;
  const c = await db.connect();
  try {
    await c.query("BEGIN");
    const updated = await c.query(
      `UPDATE chain_candidates SET status=$3,failure_count=$4,retry_reason=$5,rpc_code=$6,
      terminal_reason=$7,dead_letter_at=CASE WHEN $8 THEN clock_timestamp() ELSE NULL END,
      processed_at=CASE WHEN $8 THEN clock_timestamp() ELSE NULL END,
      lease_until=NULL,lease_token=NULL,next_attempt_at=clock_timestamp()+($9*interval '1 millisecond')
      WHERE signature=$1 AND lease_token=$2`,
      [
        row.signature,
        row.lease_token,
        terminal ? "dead-letter" : "retry",
        failures,
        failure.reason,
        failure.rpcCode,
        terminalReason,
        terminal,
        delay,
      ],
    );
    if (updated.rowCount)
      await c.query(
        "UPDATE chain_candidate_attempts SET completed_at=clock_timestamp(),outcome=$2,reason=$3,rpc_code=$4 WHERE token=$1",
        [
          row.lease_token,
          terminal ? "dead-letter" : "retry",
          failure.reason,
          failure.rpcCode,
        ],
      );
    await c.query("COMMIT");
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}

export async function observeChainLog(
  sig: string,
  slot: number,
  observedAt: string,
  candidate: boolean,
  replay = false,
  checkpoint = true,
) {
  const c = await db.connect();
  try {
    await c.query("BEGIN");
    await c.query("SELECT pg_advisory_xact_lock(7864333)");
    let dropped = false;
    if (candidate) {
      const found = await c.query(
        "SELECT 1 FROM chain_candidates WHERE signature=$1",
        [sig],
      );
      if (!found.rowCount) {
        const inserted = await c.query(
          "INSERT INTO chain_candidates(signature,slot,from_replay,observed_at) SELECT $1,$2,$3,$4 WHERE (SELECT count(*) FROM chain_candidates WHERE processed_at IS NULL AND dead_letter_at IS NULL)<256 RETURNING signature",
          [sig, slot, replay, observedAt],
        );
        dropped = !inserted.rowCount;
      }
    }
    // Replay cannot move the WebSocket checkpoint backwards or replace it.
    if (!replay && checkpoint)
      await c.query(
        `INSERT INTO chain_feed_cursors(program_id,signature,slot,observed_at) VALUES($1,$2,$3,$4)
      ON CONFLICT(program_id) DO UPDATE SET signature=$2,slot=$3,observed_at=$4,updated_at=clock_timestamp()
      WHERE chain_feed_cursors.observed_at IS NULL OR chain_feed_cursors.observed_at<=$4`,
        [CPMM_PROGRAM, sig, slot, observedAt],
      );
    if (dropped)
      await c.query(
        "INSERT INTO chain_feed_cursors(program_id,dropped,coverage_gaps) VALUES($1,1,1) ON CONFLICT(program_id) DO UPDATE SET dropped=chain_feed_cursors.dropped+1,coverage_gaps=chain_feed_cursors.coverage_gaps+1",
        [CPMM_PROGRAM],
      );
    await c.query("COMMIT");
    return !dropped;
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}
export async function recordChainGap(reason: string, dropped = 0) {
  await db.query(
    "INSERT INTO chain_feed_cursors(program_id,replay_status,coverage_gaps,dropped) VALUES($1,$2,1,$3) ON CONFLICT(program_id) DO UPDATE SET replay_status=$2,coverage_gaps=chain_feed_cursors.coverage_gaps+1,dropped=chain_feed_cursors.dropped+$3,updated_at=clock_timestamp()",
    [CPMM_PROGRAM, reason, dropped],
  );
}

/** JSON v1: ages are seconds, dequeue rate is claims/min over the last 300s.
 * pending includes leased/retry rows; retryReasons counts current pending reasons.
 * lastRealDiscovery requires a versioned decoded transaction, never an HTTP feed.
 * Cursor gaps/drops are cumulative since migration; historical uninstrumented counts are unknown.
 */
export async function getChainQueueHealth() {
  const [stats, reasons, rate, last, cursor] = await Promise.all([
    db.query(
      "SELECT count(*) FILTER(WHERE processed_at IS NULL AND dead_letter_at IS NULL)::int AS pending,count(*) FILTER(WHERE dead_letter_at IS NOT NULL)::int AS dead_letter,max(EXTRACT(EPOCH FROM (clock_timestamp()-observed_at))) FILTER(WHERE processed_at IS NULL AND dead_letter_at IS NULL)::float AS oldest FROM chain_candidates",
    ),
    db.query(
      "SELECT retry_reason,count(*)::int AS n FROM chain_candidates WHERE processed_at IS NULL AND dead_letter_at IS NULL AND retry_reason IS NOT NULL GROUP BY retry_reason",
    ),
    db.query(
      "SELECT count(*)::int AS n FROM chain_candidate_attempts WHERE started_at>clock_timestamp()-interval '300 seconds'",
    ),
    db.query(
      "SELECT signature,slot,event_at,observed_at,processed_at,decoder_version FROM chain_candidates WHERE status='decoded' AND decoder_version IS NOT NULL AND discovered_at IS NOT NULL ORDER BY discovered_at DESC LIMIT 1",
    ),
    db.query("SELECT * FROM chain_feed_cursors WHERE program_id=$1", [
      CPMM_PROGRAM,
    ]),
  ]);
  const s = stats.rows[0],
    l = last.rows[0],
    c = cursor.rows[0];
  const at = (v: unknown) => (v ? new Date(v as string).toISOString() : null);
  return {
    version: 1 as const,
    pending: s.pending,
    deadLetter: s.dead_letter,
    dequeueRate: {
      windowSeconds: 300,
      attempts: rate.rows[0].n,
      perMinute: rate.rows[0].n / 5,
    },
    oldestAgeSeconds: s.oldest === null ? null : Math.max(0, s.oldest),
    retryReasons: Object.fromEntries(
      reasons.rows.map((r) => [r.retry_reason, r.n]),
    ) as Record<string, number>,
    dropped: Number(c?.dropped ?? 0),
    lastRealDiscovery: l
      ? {
          signature: l.signature,
          slot: Number(l.slot),
          eventAt: at(l.event_at),
          observedAt: at(l.observed_at)!,
          processedAt: at(l.processed_at)!,
          decoderVersion: l.decoder_version,
        }
      : null,
    cursor: {
      programId: CPMM_PROGRAM,
      signature: c?.signature ?? null,
      slot: c?.slot == null ? null : Number(c.slot),
      observedAt: at(c?.observed_at),
      replayStatus: c?.replay_status ?? null,
      coverageGaps: Number(c?.coverage_gaps ?? 0),
    },
  };
}
