import type { PoolClient } from "pg";
import { db } from "./db";
const subscribers = new Set<(scope: string) => void>();
let client: PoolClient | null = null,
  connecting: Promise<void> | null = null;
let reconnects = 0;
export function notificationStats() {
  return { connected: !!client, reconnects };
}
export async function ensureNotifications() {
  if (client || connecting || !subscribers.size) return connecting;
  connecting = (async () => {
    const next = await db.connect();
    const failure = () => {
      if (client === next) {
        client = null;
        reconnects++;
        next.release(true);
        for (const fn of subscribers) fn("reconnect");
      }
    };
    next.on("error", failure);
    try {
      await next.query("LISTEN nexus_update");
    } catch (error) {
      next.removeListener("error", failure);
      next.release(true);
      throw error;
    }
    if (!subscribers.size) {
      next.release(true);
      return;
    }
    client = next;
    next.on("notification", (event) => {
      let scope = "pools";
      try {
        scope = JSON.parse(event.payload ?? "{}").scope ?? "pools";
      } catch {}
      for (const fn of subscribers) fn(scope);
    });
  })().finally(() => {
    connecting = null;
  });
  return connecting;
}
export function subscribeChanges(fn: (scope: string) => void) {
  subscribers.add(fn);
  void ensureNotifications().catch(() => {});
  return () => {
    subscribers.delete(fn);
    if (!subscribers.size && client) {
      const old = client;
      client = null;
      old.removeAllListeners("notification");
      old.release(true);
    }
  };
}
