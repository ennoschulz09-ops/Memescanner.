import { randomUUID } from "node:crypto";
import { db } from "./db";
import { shouldAlert, type AlertRule, type ResearchEvent } from "./alerts";
export async function flushDebouncedAlerts() {
  const client = await db.connect();
  let count = 0;
  try {
    await client.query("BEGIN");
    const rules = (
      await client.query("SELECT * FROM alert_rules ORDER BY id FOR UPDATE")
    ).rows;
    const candidates = (
      await client.query(
        "SELECT * FROM alert_candidates WHERE not_before<=clock_timestamp() ORDER BY not_before LIMIT 100 FOR UPDATE SKIP LOCKED",
      )
    ).rows;
    for (const candidate of candidates) {
      const r = rules.find((r) => r.id === candidate.rule_id),
        event = candidate.data as ResearchEvent;
      if (r) {
        const rule = r.data as AlertRule & { watchlistId?: string | null };
        const history = (
          await client.query(
            "SELECT event_key as key,at FROM alert_events WHERE rule_id=$1 ORDER BY at DESC LIMIT 1000",
            [r.id],
          )
        ).rows.map((h) => ({ key: h.key, at: new Date(h.at).toISOString() }));
        const allowed =
          !rule.watchlistId ||
          !!(
            await client.query(
              "SELECT 1 FROM watchlist_items i JOIN watchlists w ON w.id=i.list_id WHERE i.list_id=$1 AND i.mint=$2 AND w.owner=$3",
              [rule.watchlistId, event.mint, r.owner],
            )
          ).rowCount;
        const recovered =
          event.kind === "feed_outage" &&
          (
            await client.query(
              "SELECT status FROM provider_states WHERE provider=$1",
              [event.source],
            )
          ).rows[0]?.status === "ok";
        if (allowed && !recovered && shouldAlert(rule, event, history)) {
          const saved = await client.query(
            "INSERT INTO alert_events(id,rule_id,owner,mint,event_key,data) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING",
            [
              randomUUID(),
              r.id,
              r.owner,
              event.mint,
              event.key,
              { ...event, ruleName: r.name },
            ],
          );
          count += saved.rowCount ?? 0;
        }
      }
      await client.query(
        "DELETE FROM alert_candidates WHERE rule_id=$1 AND topic=$2",
        [candidate.rule_id, candidate.topic],
      );
    }
    await client.query("COMMIT");
    return count;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
