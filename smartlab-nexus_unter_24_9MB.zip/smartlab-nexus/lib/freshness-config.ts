const seconds = (value: string | undefined, fallback: number) => {
  const n = Number(value);
  return Number.isFinite(n) && n >= 10 && n <= 86400 ? Math.floor(n) : fallback;
};
export function freshnessBudgets() {
  return {
    discovery: seconds(process.env.DISCOVERY_FRESHNESS_SECONDS, 180),
    market: seconds(process.env.MARKET_FRESHNESS_SECONDS, 180),
    onchain: seconds(process.env.ONCHAIN_FRESHNESS_SECONDS, 3600),
  };
}
