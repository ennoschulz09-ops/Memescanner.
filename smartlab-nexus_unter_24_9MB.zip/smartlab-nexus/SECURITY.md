# Sicherheitsgrenzen

Stand: 23.10.2026. SMARTLAB NEXUS ist ein lesendes Solana-Recherchewerkzeug. Schreibzugriffe in PostgreSQL betreffen eigene Beobachtungen, Watchlists, Einstellungen und Alerts. Es gibt keine Wallet-Anbindung, privaten Schlüssel, Signierung, Swap-, Order- oder Handelsfunktion.

## Erzwungene Grenzen

- Solana-HTTP-RPC erlaubt ausschließlich `getHealth`, `getAccountInfo`, `getTokenLargestAccounts`, `getBalance`, `getTokenAccountsByOwner`, `getSignaturesForAddress`, `getTransaction`. Unbekannte Methoden werden vor Netzwerkzugriff abgelehnt. Die WebSocket-Verbindung verwendet ausschließlich dokumentiertes `logsSubscribe` für ein festes Programm.
- Anbieter-URLs sind fest beziehungsweise ausschließlich serverseitig konfiguriert. Benutzereingaben werden nicht zu frei wählbaren HTTP-Zielen. `SOLANA_WS_URL` verlangt wss; Zielauswahl ist eine Betreiberberechtigung.
- Zod validiert externe Antworten und API-Eingaben; kanonische Base58-Adressen und Pool-IDs werden geprüft. Scannerfilter nutzen gebundene SQL-Parameter und eine feste Sortierspaltenliste. Keine frei interpolierten Benutzerspalten.
- React rendert Token-Metadaten als Text. CSV-Formelanfänge werden entschärft. JSON-Körper sind auf 32 KiB begrenzt, Exporte und Scannerseiten gedeckelt.
- HttpOnly-/SameSite-Sitzungscookies; Origin-Prüfung bei Mutationen, optionale Zugangscode-Sperre mit `ACCESS_TOKEN`. Quoten unterscheiden Datenabfragen/gebündelte Telemetrie von echten Änderungen. SSE maximal drei Verbindungen pro Sitzung und 30 pro App-Prozess, begrenzte Lebensdauer, Cursor und langsame Verbraucher.
- Secretwerte bleiben serverseitig. API-Fehler geben keine RPC-URLs oder Datenbankpasswörter aus; strukturierte Providerfehler werden bereinigt. `.env` und Runtime-Dateien sind ignoriert.
- CSP, Frame-, Referrer- und Content-Type-Schutz sind gesetzt. Die Next-Bootstrap-Skripte benötigen derzeit `unsafe-inline`; dies ist keine noncebasierte Strict-CSP.

## Betrieb

PostgreSQL ist lokal nur an Loopback gebunden. GitHub Codespaces veröffentlicht ausschließlich Port 3000 mit privater Sichtbarkeit; der DB-Port wird nicht weitergeleitet. Der korrekte Codespaces-Ursprung wird beim Start gesetzt. Öffentliches Hosting benötigt TLS, korrektes `APP_ORIGIN`, einen starken Zugangscode, Backups und Überwachung. Ein Codespace stoppt seine Worker beim Pausieren und ist kein unbegrenzter 24/7-Dienst.

Es gibt keinen vollständigen Account-Login, keine Rollenverwaltung und keine Ende-zu-Ende-Verschlüsselung persönlicher Listen. Löschen des Sitzungscookies verliert den Zugang zu den zugehörigen Daten. Für Mehrbenutzerbetrieb ist zusätzliche Authentifizierung nötig. Ein öffentliches GitHub-Repository ist nicht gleichbedeutend mit einer öffentlichen App; der Nutzer hat ein privates Repository beauftragt. Zugangsdaten gehören weder in Git noch in GitHub Actions-Logs.

Worker-Lock, Idempotenz, gebundene Queues, persistierte Kandidaten und gemeinsame Providerbudgets verhindern unbegrenzte Duplikate/Parallelität. Diese Maßnahmen ersetzen keine Perimeter-Firewall und keine DDoS-Abwehr. SSE-Verbindungsgrenzen gelten pro App-Prozess, nicht global über alle Replikate.

## Elite-Ergänzungen

Die persistente Chain-Queue ist auf 256 offene Kandidaten begrenzt. Leases mit Fencing-Token verhindern, dass ein nach einem Crash verspätet abschließender Worker eine neu vergebene Verarbeitung überschreibt. Unbekannte Transaktionsversionen oder ungültige Decoderformate werden ausdrücklich verworfen. Das erweitert die Leseberechtigung nicht.

`CI_NETWORK_ISOLATION=true` zusammen mit `NEXUS_TEST_MODE=true` lehnt externe Provideranfragen vor Budgetbuchung und Netzwerkzugriff ab. Test- und Benchmarkwerkzeuge erzwingen separate Datenbanken mit geprüftem Suffix; der Benchmark verweigert zusätzlich denselben Datenbanknamen wie die App. Browserfixtures tragen ein sichtbares Testdatenbanner. Dieser Testmodus ist keine Produktionsauthentifizierung. Der neue Workflow führt alle Browserprojekte aus; der tatsächliche GitHub-Actions-Lauf bleibt bis zum privaten Upload ungeprüft.

## Nachweise und Grenzen

`npm run test:security` prüft verbotene Features/Bibliotheken, vorhandene RPC-Allowlist und Servergrenzen. Aktueller Bericht: [reports/security.json](reports/security.json), null Funde in 49 gescannten Quelldateien beim Elite-Abschlusslauf am 24.10.2026. `npm audit --omit=dev` ergab am 23.10.2026 null bekannte Produktionslücken: [reports/elite-dependency-audit.json](reports/elite-dependency-audit.json). Diese zeitgebundenen Such-/Abhängigkeitsprüfungen sind kein externer Penetrationstest und beweisen keine Abwesenheit aller Schwachstellen.

Unit-/Integrationstests prüfen unter anderem verbotene RPC-Methoden, beschädigte Providerdaten, Origin-/Payload-Grenzen, Sitzungsisolation, Quoten, CSV-Escaping und Outputbereinigung. Browserprüfungen prüfen beobachtbare API-Ausfälle. Der lokale Chaos-Test unterbricht PostgreSQL tatsächlich und verifiziert Recovery. Einzelheiten und offene Prüfungen: [QA_REPORT.md](QA_REPORT.md).

Sicherheitsprobleme mit reproduzierbaren Schritten und bereinigten Logs privat an den Repository-Betreiber melden. Keine Schlüssel oder Zugangsdaten in öffentlichen Issues posten. Es gibt kein eingerichtetes Security-Bounty-Programm.

## Final Precision Security Check

`npm run test:security` prüft Quelltext, direkte und transitive Wallet-/Order-Abhängigkeiten im Lockfile, bekannte eingebettete Secretformate und die exakt erwartete RPC-Allowlist (Zusatzmethoden lassen den Check scheitern). `npm audit --audit-level=moderate` ist CI-Gate; Vitest wurde wegen nachgewiesener kritischer Transitiver auf 5.0.5 aktualisiert. Das sind bekannte Musterprüfungen, keine vollständige Secret-History- oder Penetrationsprüfung. Das ZIP enthält keine Git-History und gewährt keinen Zugriff auf das private Remote.

DOM-Quittungen sind sitzungsgebundene, validierte und begrenzte Telemetrie. Sie autorisieren keinerlei Blockchain-Aktion. Browser-Zeitangaben sind Selbstberichte und keine vertrauenswürdigen Marktzeitstempel. CSP enthält weiter unsafe-inline; vollständige Mehrbenutzer-Accounts und externer Pentest bleiben offen.
