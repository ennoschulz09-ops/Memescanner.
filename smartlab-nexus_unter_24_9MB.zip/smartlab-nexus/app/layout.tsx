import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "SMARTLAB NEXUS · Solana Token Intelligence",
  description:
    "Öffentliche Solana-Pooldaten entdecken, beobachten und Risiken nachvollziehbar analysieren.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
