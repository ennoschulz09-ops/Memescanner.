import { handleApi } from "../../../lib/api";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  return handleApi(req);
}
export async function POST(req: Request) {
  return handleApi(req);
}
export async function PATCH(req: Request) {
  return handleApi(req);
}
export async function DELETE(req: Request) {
  return handleApi(req);
}
