import { NexusShell } from "../components/nexus-shell";
export default function Home() {
  return <NexusShell />;
}
