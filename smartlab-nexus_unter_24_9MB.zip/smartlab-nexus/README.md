# SMARTLAB NEXUS

Deutschsprachiges Solana-Research-Terminal mit echten öffentlichen Daten, getrenntem Erfassungsworker und PostgreSQL. Keine Handels-, Ausführungs-, Signatur- oder Wallet-Verbindungsfunktionen.

FINAL PRECISION (24.10.2026): atomar gefencete Chain-Publikation, gepufferte Admission statt vier paralleler Drops, ereignisgesteuertes Decoder-Wakeup, korrelierte Pending-/Decode-Renderquittungen, Risk-Modell v3 mit getrennten Teilprüfungen, segmentierte Charts und operativer Research-Blotter. Mobil werden 25 statt 100 Zeilen je echter Serverseite geladen; alle Filter und Folgeseiten bleiben verfügbar. **Aktuelle Abnahme und offene Gates:** [FINAL_SCORECARD.md](FINAL_SCORECARD.md), [docs/FINAL_GAP_MATRIX.md](docs/FINAL_GAP_MATRIX.md), [DATA_FIELD_INVENTORY.md](DATA_FIELD_INVENTORY.md), [docs/FINAL_OBSERVATION_PLAN.md](docs/FINAL_OBSERVATION_PLAN.md). Ältere Elite-Berichte sind historische Belege, keine Verifikation dieses Builds.

Elite-Upgrade vom 23.10.2026: ATLAS-Designsystem, Command Dashboard, mobile Tokenkarten und Analyse-Sheet, Data Quality Dashboard, kompakter Scannervertrag, persistente Chain-Queue und versioniertes Risikomodell. Aktuelle Abnahme: [QA_REPORT.md](QA_REPORT.md), [PERFORMANCE.md](PERFORMANCE.md), [SOURCE_COVERAGE.md](SOURCE_COVERAGE.md), [RISK_MODEL.md](RISK_MODEL.md), [SECURITY.md](SECURITY.md). Öffentliche Quellen haben Lücken und Limits; es wird keine pauschale 9,5/10-Qualität behauptet.

Der Code und die Startkonfiguration sind lokal vorbereitet. Das Ziel wurde laut Nutzer auf privat umgestellt. Seitdem liefern beide verbundenen GitHub-Zugänge HTTP404 und haben keine Berechtigung für dieses private Repository. Der Upload wartet auf die Repository-Freigabe in der ChatGPT/Codex-GitHub-Verbindung. Erst nach dem Upload startet der Codespaces-Link. [Statusbeleg](reports/elite-github-status.json).

## Direkt aus GitHub im Browser starten

[GitHub Codespaces öffnen](https://codespaces.new/ennoschulz09-ops/smartlab-nexus)

1. Im privaten Repository **Code → Codespaces → Create codespace on main** wählen, alternativ den Link oben öffnen.
2. Die Einrichtung abwarten. Abhängigkeiten, PostgreSQL, Schema, App und Worker werden automatisch eingerichtet beziehungsweise gestartet.
3. Im Reiter **PORTS** bei **3000 / SMARTLAB NEXUS** auf **Open in Browser** klicken. Der Port bleibt standardmäßig privat und benötigt deine GitHub-Anmeldung.

Es sind keine API-Schlüssel nötig. Die App beginnt mit einem leeren eigenen Datenbestand und ruft echte Quellen ab; nach dem ersten erfolgreichen Abruf erscheinen Pools. Der dynamische HTTPS-Ursprung des Codespace wird automatisch gesetzt, damit Watchlists, Alerts und andere Mutationen funktionieren. Datenbankport 5432 wird nicht veröffentlicht.

Codespaces ist eine laufende Entwicklungsumgebung: Stoppt der Codespace, pausieren App und Erfassung. GitHub kann nach Verbrauch deines Kontingents Kosten berechnen; Nutzung und Budget in deinen GitHub-Einstellungen prüfen. Für dauerhaften 24/7-Betrieb ist ein eigener Hostingdienst erforderlich. GitHub Pages kann die API, PostgreSQL und den dauerhaften Worker nicht betreiben.

Logs und manueller Neustart im Codespaces-Terminal:

```bash
tail -f .runtime/codespace.log
# Bei Bedarf, jeweils als eigener Befehl:
npm run codespace:stop
npm run codespace:start
```

Die Einrichtung steht in `.devcontainer/`. Ein Workflow unter `.github/workflows/ci.yml` prüft bei Push/PR Unit- und Integrationstests, Typecheck, Sicherheitscheck, Produktionsbuild sowie Chromium-, Firefox- und WebKit-Browserprüfungen einschließlich Axe. Browserfixtures liegen ausschließlich in einer separaten Testdatenbank; externer Providerzugriff ist im CI-Testmodus gesperrt. Echte Providerproben bleiben separate Prüfungen. Der neue Remote-Workflow ist vor dem privaten Upload noch nicht ausgeführt. Weitere Hinweise: [docs/github.md](docs/github.md).

## Lokal starten

Voraussetzungen: Node.js ≥ 22.9 (getestet mit 22.16 im Codespaces-Container und lokal mit 24.19), npm, Docker Compose oder ein vorhandener PostgreSQL-17-Server.

```bash
cd smartlab-nexus
npm ci
cp .env.example .env
docker compose up -d postgres
npm run dev:all
```

App: **http://localhost:3000**. `dev:all` migriert das Schema und startet Next.js und den separaten Worker. Bei langsamer Datenbankinitialisierung den Start erneut ausführen. Es werden keine Demo-Tokens eingesät; der erste erfolgreiche Abruf liefert echte Pools. API-Budgets und Nichterreichbarkeit können diesen Abruf verzögern.

Alternativ in getrennten Terminals:

```bash
npm run db:migrate
npm run dev
```

```bash
npm run worker
```

Der Worker schreibt strukturierte JSON-Logs, hält eine exklusive PostgreSQL-Advisory-Sperre und verbindet sich nach DB-Verlust erneut. `npm run worker:once` führt einen einzelnen Durchlauf aus; anschließend zeigt System Health den Worker als gestoppt.

## Ansichten und Bedienung

| Ansicht           | Funktion                                                                                                                                                                                           |
| ----------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Command Dashboard | Quellenzustand, Queue/Alter, Frische, beobachtete Marktänderungen und Drilldown zur Datenqualität                                                                                                  |
| Datenqualität     | Prozentuale Feldabdeckung, Stale-/Unknown-Anteile, Providerfehler, Anfragebudgets und ausdrücklich unbekannte API-Kosten                                                                           |
| Discovery         | Frühe Mint-Funde vor der Hydration, unvollständige Daten ausdrücklich markiert; anschließend tatsächlich erfasste Pools                                                                            |
| Live Scanner      | Virtualisierte Tabelle, Suche nach Name/Symbol/Mint, Quelle durchsuchen, Schnellfilter, kombinierbare Filter, gespeicherte Presets, Spaltenwahl/Sortierung                                         |
| Token-Analyse     | Poolwahl, Chartfenster, Preis/Volumen/Liquidität/Trades, Quellenvergleich, Contract-Prüfung, Kontoverteilung, Risiko- und Ereignis-Audit, persönliche Alert-Historie                               |
| Risk Lab          | Einzelindikatoren mit Werten, Formeln, Schwellen, Gewichten und Quellen                                                                                                                            |
| Wallet Explorer   | Öffentlicher SOL-Saldo, SPL-/Token-2022-Konten, bis zu 20 Signaturen und beobachtete Aktivitätsverteilung                                                                                          |
| Watchlists        | Sitzungsgebundene Listen mit Suche; Stern im Scanner speichert mit einem Klick                                                                                                                     |
| Alerts            | Neuer Pool, Liquiditäts-/Konzentrations-/Risikoänderung und Feed-Ausfall; Cooldown, Debounce, Quota, UTC-Ruhezeiten, persistierte Outbox, getrennte Auslösung/Zustellung, Ereignissuche und Export |
| Analytics         | Aggregationen über erfasste unterschiedliche Pools, Abdeckungsgrade und Ereignisse                                                                                                                 |
| System Health     | Anbieterzustand, Backoff, Budgets, Worker/Queue, Cache-Trefferrate, SSE-Verbindungen, gemessene Perzentile, Quell-Audits                                                                           |
| Einstellungen     | Kompakte Tabellenansicht (mobile Touch-Karten behalten128 px Höhe), reduzierte Bewegung, lokale Zeit/UTC und Runtime-Informationen                                                                 |

Ein Klick auf eine Desktop-Zeile öffnet die rechte Analyseansicht, ein weiterer Klick die vollständige Analyse. Mobil öffnet eine Karte eine Schnellanalyse als Bottom Sheet; von dort führt „Vollständige Analyse“ zum Detailbildschirm. Escape schließt das Sheet und stellt den Zeilenfokus wieder her. Die Bottom-Navigation verbindet die fünf Hauptansichten. „Updates pausieren“ friert automatische Scanneränderungen ein; Fortsetzen synchronisiert die aktuelle Seite. `Ctrl/Cmd K` fokussiert die Suche. Suche, Sortierung und Filter werden auf dem Server über den erfassten Bestand ausgeführt; der Scanner lädt am Desktop 100, mobil 25 Zeilen je Seite, höchstens 200 über die API. Enter kann zusätzlich die budgetierte DexScreener-Suche auslösen. Mobile Filter öffnen ein Sheet mit Escape-/Fokus-Unterstützung.

## Datenpfad und Herkunft

```mermaid
flowchart LR
  HTTP[Budgetierte HTTP-Feeds] --> DISC[Frühe Discovery]
  WS[Begrenzte CPMM-Logs] --> C[Persistierte Kandidaten]
  C --> RPC[Read-only Transaktionsdecoder]
  RPC --> DISC
  DISC --> H[Getrennte Markt-Hydration]
  H --> DB[(PostgreSQL)]
  R[Getrennte Risk-Anreicherung] --> DB
  DISC --> DB
  DB --> A[Alert-Outbox und Debounce]
  DB --> N[LISTEN / NOTIFY]
  N --> SSE[SSE v2 / Checkpoints]
  SSE --> UI[Gebündelte Seiten-Deltas / virtuelle Tabelle]
  DB --> F[Serverfilter und Seiten]
  F --> UI
```

HTTP-Marktdaten werden budgetiert gepollt. Gecko-New-Pools behält wegen des dokumentierten Einminuten-Caches mindestens 60 Sekunden; Profile, Marktpflege, Hydration, Risk und Alerts laufen unabhängig. Ein zusätzlicher WebSocket-Pfad prüft genau eine dokumentierte Raydium-CPMM-Initialize-Variante; Details und Lücken stehen in SOURCE_COVERAGE.md. SSE wird durch transaktionales PostgreSQL-NOTIFY geweckt und führt alle zwei Sekunden einen Abgleich durch. Nach fünf Minuten erneuert sich die Verbindung. Maximal drei Streams je Sitzung und 30 je App-Prozess, 32 Checkpoints für fünf Minuten; Replay synchronisiert den neuesten Zustand, nicht jede Zwischenrevision. Bei Ausfall erfolgt ein sichtbarer HTTP-Fallback nach 15 Sekunden.

Jede Beobachtung hat `provider`, Endpunktkennung, `fetchedAt`, `sourceAt`, `cacheAgeSeconds`, `timestampKind` und HTTP-Latenz. Zwölf skalare Marktfelder erhalten zusätzlich `fieldEvidence` mit Quelle, Mess-/Abruf-/Berechnungszeit, Freshness, Abdeckungs-Konfidenz, Konflikten und Missing-State. `measuredAt` bleibt **null**, wenn die Quelle keine tatsächliche Messzeit veröffentlicht. HTTP-Date/Age ist keine Chain-Ereigniszeit. Discovery-, Markt- und Onchain-Budgets sind getrennt konfigurierbar; Standards 180/180/3.600 Sekunden. Unbekannt bleibt unbekannt.

Aktuelle offizielle APIs, Grenzen und Quellen: [docs/providers.md](docs/providers.md). Die API-Referenz von GeckoTerminal ist als OpenAPI-Snapshot archiviert. Standardbudgets: GeckoTerminal 8, DexScreener Profile 6 / Markt 30, Solana RPC 30 Anfragen in einer **rollierenden Minute**, gemeinsam für App und Worker. Ein 429 ohne Retry-After verursacht mindestens 60 Sekunden Backoff. Ein späterer Erfolg einer vorher schon laufenden Anfrage hebt einen aktiven Backoff nicht auf.

Neue Listings und Watchlists erhalten Priorität. Unabhängige Aufgaben rotieren bis 30 Mints alle 15 Sekunden beziehungsweise 20 Pools alle 20 Sekunden; tatsächliche Anfragen hängen von Budget und Backoff ab. Höchstens vier Aufgaben laufen gleichzeitig. Queue-Zulassung, Jitter und Circuit-Breaker begrenzen Last. Die kostenlose Kapazität reicht bei großem Bestand nicht zur Auffrischung aller Pools: Stale-Zustände und Abdeckungsgrenzen bleiben sichtbar.

Ein Pool von zwei Anbietern bleibt ein Pool. Preis, Volumen und Liquidität verschiedener Anbieter werden nicht für denselben Pool addiert. Provider-Beobachtungen bleiben für den Vergleich getrennt erhalten. Poolalter und erster Entdeckungszeitpunkt sind kein nachgewiesenes Mint-Alter.

## Methodik und bekannte Grenzen

- Datenqualität: 60 % Markt-Vollständigkeit, 20 % Controls, 10 % Konzentrationsdaten, 10 % zweite frische Quelle; Frischefaktor 0,5 bei veralteten/unbestätigten Werten.
- Gesamtrisiko nur bei allen vier verfügbaren Pflichtkomponenten: Liquidität 30 %, Tokenkonto-Konzentration 25 %, Contract-Kontrollen 30 %, auffällige aggregierte Aktivität 15 %. Fehlend bedeutet unbekannt, niemals Nullrisiko. Exakte Formeln und Schwellen stehen in jeder Signalkarte und [lib/risk.ts](lib/risk.ts).
- Momentum ist beobachtete 5-Minuten-Preisänderung ohne Gewicht im Risikoindikator. Keine Prognose.
- Der Aktivitätsanstiegsfilter vergleicht die rollierende 5-Minuten-Tradezahl mit dem vorherigen eigenen Sample desselben Providers. Ohne zwei Samples oder bei Null-Baseline bleibt der Anstieg unbekannt; die Mindestanzahl von Trades ist ein eigener Filter.
- Größte Tokenkonten sind **keine eindeutigen Wallet-Holder**. Verwahr-/Poolkonten können enthalten sein. Owner-Konzentration, verifizierte LP-Locks, vollständige Transaktionsgraphen, große individuelle Wallet-Flüsse und belastbare Cluster bleiben ohne geeignete Evidenz unbekannt.
- Die Discovery ist ein Ausschnitt aus New-Pool-, Trend-Pool-, Tokenprofil-Feeds und einer begrenzten CPMM-Programmsubscription. Profile sind selektiv; Poolinitialisierung bedeutet nicht Mint-Erstellung. Keine vollständige Solana-Abdeckung.
- Öffentliche Solana-Endpunkte können einzelne Methoden begrenzen oder ablehnen. Contract-Kontrollen sind dann teilweise verfügbar, Konzentration unbekannt. `SOLANA_RPC_URL` kann einen geeigneten dedizierten Read-only-RPC-Anbieter konfigurieren; keine automatische Buchung kostenpflichtiger Angebote.
- Preis-/Volumenhistorie aus GeckoTerminal, sofern vorhanden. Liquiditäts-/Trade-Historie aus eigenen gespeicherten Samples. Keine rückwirkend erfundene Historie und keine aufgefüllten leeren Intervalle.
- Alerts werden ausschließlich **in der App** zugestellt. Neue Regeln gelten ab Erstellzeit. Ruhezeiten unterdrücken Ereignisse ohne Nachversand. Die Outbox wiederholt DB-bedingt fehlgeschlagene Verarbeitung; Deduplizierung/Cooldown gelten persistent. „Zugestellt“ bedeutet Öffnen des Posteingangs und erfolgreiche Bestätigung. Ein fehlgeschlagener API-Zugriff wird als Fehler angezeigt, ohne eine Zustellung zu behaupten. Externer Versand ist nicht eingerichtet.
- Der kompakte Scannervertrag bewahrt Feld-Evidenz und Konflikte; vollständige Quellenbeobachtungen werden beim Öffnen der Analyse geladen (`sourceDetail: deferred`). Scanner-Antworten enthalten höchstens 200 Pools, Standardseite 100; Ereignisanzeige bis 300, Exporte bis 10.000. Samples/Audits/Discovery/abgeschlossene Chain-Kandidaten standardmäßig 30 Tage; offene Kandidaten bleiben begrenzt persistiert. Wallet-Ansicht bis 500 Tokenkonten (Anzeige 100) und 20 Signaturen.
- Sitzungen sind zufällige HttpOnly-Cookies. Es gibt keinen vollständigen Mehrbenutzer-Login oder Rollenverwaltung. Entfernte Cookies verlieren den Zugriff auf die zugehörigen Listen. PostgreSQL-Backups liegen beim Betreiber.

## Konfiguration und Schutz

`.env.example` enthält ausschließlich lokale Beispielwerte. `DATABASE_URL`, `SOLANA_RPC_URL`, `POLL_INTERVAL_MS` und `RETENTION_DAYS` bleiben serverseitig. Zugangsdaten werden weder im UI noch in Exporten ausgegeben. `APP_ORIGIN` muss dem tatsächlichen Browser-Ursprung entsprechen, besonders bei Reverse-Proxy-/Preview-URLs.

Der optionale `ACCESS_TOKEN` schützt App-APIs mit einem Zugangscode und HttpOnly-Zugangscookie; für einen gemeinsamen Betrieb mindestens 32 zufällige Zeichen verwenden. PostgreSQL ist im Compose-Setup nur an Loopback gebunden. Die App lauscht für lokale Vorschauen an `0.0.0.0`; Netzwerkfreigabe entsprechend dem eigenen Betriebskontext konfigurieren.

Mutationen prüfen den Origin, JSON-Eingaben haben ein 32-KiB-Streamlimit und strikte Schemas. Anbieterziele sind fest beziehungsweise serverseitig konfiguriert, RPC-Methoden explizit freigegeben. React rendert Metadaten als Text; CSV-Formelanfänge werden entschärft. CSP, Frame-Schutz, Referrer- und Content-Type-Header sind gesetzt. Der lokale Next.js-Bootstrap nutzt Inline-Skripte; die CSP ist deshalb keine noncebasierte Strict-CSP. Statische Suche und Abhängigkeitsprüfung ersetzen keinen externen Penetrationstest.

## Tests und Messungen

```bash
npm test
npm run db:test
npm run test:integration
npm run typecheck
npm run build
```

Browserprüfungen verwenden entweder eine laufende App mit tatsächlich erfassten Pools oder den isolierten CI-Modus. Browser und Systemabhängigkeiten installieren: `npx playwright install --with-deps chromium firefox webkit`. Ein vorhandenes Chromium lässt sich mit `CHROMIUM_PATH` wählen. Für den CI-Modus zunächst `NEXUS_TEST_MODE=true CI_NETWORK_ISOLATION=true CI_TEST_DATABASE_URL=<separate_DB_mit_Suffix_test> npm run test:ci-fixtures`, danach dieselben Variablen plus `PLAYWRIGHT_START_SERVER=true npm run test:e2e` setzen; Port 3000 muss frei sein. Der Workflow enthält die vollständige Konfiguration.

```bash
npm run test:e2e
npm run test:security
npm run test:live
npm run bench
npm run test:runtime
npm run bench:realtime
npm run bench:elite
```

Der Elite-Benchmark verwendet echte paginierte APIs gegen eine eigene `_performance_test`-Datenbank für 1k/5k/10k, Desktop und gedrosseltes Mobilprofil. Realtime- und Elite-Benchmarks sequenziell ohne andere Browser-/Buildlast ausführen.

Integrationstests nutzen ausschließlich eine separate Datenbank mit Suffix `_test` und leeren dort Tabellen. Die Konfiguration verweigert einen anders benannten Datenbanknamen. `db:test` erstellt sie bei Bedarf; auf verwalteten Systemen kann die Berechtigung dafür fehlen.

`test:live` ist eine separate optionale echte Read-only-Probe, teilt Anbieterbudgets mit dem Worker und erzeugt `reports/live-check.json`. Teilweise Antworten werden als `partial`, eingeschränkte Quellen als `blocked` dokumentiert; der Befehl meldet dann einen Fehlercode. Keine Offline-Fixture wird als Live-Erfolg gewertet.

`npm run test:chaos` ist ein separater **unterbrechender lokaler Ausfalltest**: Er stoppt den Compose-PostgreSQL-Dienst, prüft HTTP 503/Offline, startet ihn wieder und überprüft Worker-Recovery sowie die Health-Isolation eines zweiten Workers. Nur mit lokalen Standardwerten und laufender App/Worker ausführen. `test:runtime` beobachtet bis zu 125 Sekunden echte Worker- und Browsermessungen und erzeugt Screenshots; kleine Stichproben bleiben ausdrücklich gekennzeichnet.

`BENCH_BUILD_MODE=production npm run bench` fängt ausschließlich Antworten in einem isolierten Testbrowser ab und misst 1.000/5.000/10.000 synthetische Zeilen mit sichtbarem TESTDATEN-Banner. Keine Test-Tokens gelangen in die App-Datenbank. Gemessen werden Paint-Zeitpunkte, Berechnungsperzentile, Suche bis Darstellung inklusive Debounce, virtuelle Zeilen, Skript-Scroll-FPS und JS-Heap. TTI ist eine aufgabenspezifische Näherung.

`bench:realtime` erstellt eine **separate** Datenbank mit Suffix `_performance_test`, leert ausschließlich diese Testdatenbank, startet einen eigenen Produktionsserver auf Port 3100 und prüft 5.000 Datensätze mit 500 Updates/Minute über echte DB-Commits, NOTIFY, SSE, HTTP-Deltas und DOM. Kein Provider wird mit Testlast abgefragt. Der Name wird vor destruktiven Testoperationen geprüft. Erfasst werden p50/p95/p99, Bootstrap-Konfidenzintervalle, CPU/RSS/Netzwerk und PostgreSQL-Zähler. Voraussetzungen: laufendes lokales PostgreSQL, Rechte zum Erstellen der Testdatenbank, Produktionsbuild und Chromium. Einzelheiten: PERFORMANCE.md.

System Health zeigt Eingang bis Commit-Bestätigung, Provider-Eingang bis UI, DB-Schreibzeit bis UI und Server-Publish bis UI getrennt; `updated_at` ist die Transaktions-Schreibzeit, kein exakter Commit-Wandzeitstempel. Provider-HTTP-Latenzen sind separat. Echte Chain-Ereignislatanz bleibt ohne Quellzeit unbekannt; Uhren müssen synchron sein. Wartung aktualisiert alterungsbedingte Risiko-Audits ungefähr einmal pro Minute.

## Produktionsbetrieb vorbereiten

```bash
npm ci
npm run db:migrate
npm run build
npm start
```

Den Worker als separaten dauerhaften Node-Prozess betreiben (`npm run worker`), etwa unter systemd oder dem Prozessmanager des Hosters. Eine reine kurzlebige Serverless-Funktion kann ihn nicht ersetzen. Gemeinsames PostgreSQL, TLS am Reverse Proxy, korrektes `APP_ORIGIN`, gesicherte Zugangswerte, Backups und Überwachung konfigurieren. Für SSE am Proxy Buffering deaktivieren und mindestens 360 Sekunden Read-Timeout zulassen. Horizontale Worker sind durch die DB-Sperre begrenzt; Rate-Limits/Budgets teilen den Datenbankzustand, Browser-Verbindungslimits gelten pro App-Prozess.

Kein Deployment wurde veröffentlicht und keine bezahlte API eingerichtet. Die Standard-Datenendpunkte sind kostenlos nutzbar und ohne SLA; Hosting, Datenbank und eventuelle spätere dedizierte RPC-Tarife sind separat. Dokumentierte lokale Tests belegen keine allgemeine Produktionsreife.

## Projektstruktur und Abnahme

`app/` Next.js-Routen, `components/` Terminalansichten, `lib/providers/` Adapter/Normalisierung, `lib/` Scoring/Filter/Alerts/API/Persistenz, `worker/` Erfassung/Prioritäten, `db/` Schema, `tests/` Unit/Integration/Browser, `scripts/` Prüfung/Messung, `reports/` Belege.

PDF-Texte: [ursprünglicher Auftrag](docs/masterprompt.txt), [Upgrade-Auftrag](docs/upgrade-masterprompt.txt), [Elite-Auftrag](docs/elite-masterprompt.txt). Design: [System](DESIGN_SYSTEM.md), [Audit und Screenshots](DESIGN_AUDIT.md), [Änderungen](CHANGELOG.md). Upgrade-Befund und Plan: [Audit](docs/upgrade-audit.md), [Plan](docs/upgrade-plan.md). Die aktuelle Abnahme ist QA_REPORT.md. `reports/acceptance.md`, `reports/verification.json` und ursprüngliche Design-/Plan-Dokumente sind historische Belege vor dem Upgrade und ersetzen die neue Abnahme nicht.
