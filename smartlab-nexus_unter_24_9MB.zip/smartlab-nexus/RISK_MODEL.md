# Risikomodell und Unbekannte

Stand: 23.10.2026. Gesamtstatus **PARTIAL**: versionierte und getestete Heuristiken sind vorhanden; wirtschaftliche Owner-Zuordnung, LP-Evidenz und vollständige Onchain-Abdeckung fehlen. Implementierung: [lib/risk.ts](lib/risk.ts). Indikatoren dienen der Recherche; sie beweisen weder Betrug noch Sicherheit und sind keine Handlungsempfehlung. Markt-, Contract-, Konzentrations- und Datenabdeckungswerte werden getrennt angezeigt. Jede Signalkarte zeigt Quelle, Alter, Rohwert, Schwelle, Formel und Grenzen.

| Komponente | Formel / Schwellen | Gewicht im Gesamtrisiko |
|---|---|---:|
| Liquidität | Gemeldete USD-Liquidität L: L < 10.000 → 100; < 50.000 → 70; < 250.000 → 35; sonst 10. Fehlend → unbekannt. | 30 % |
| Tokenkonto-Konzentration | 100 × größter Tokenkontobestand / Mint-Supply. Rohbeträge werden als Integer mit BigInt verarbeitet, nicht über fehleranfällige UI-Dezimalzahlen. | 25 % |
| Contract-Kontrollen | min(100, 60 × aktive Mint-Authority + 40 × aktive Freeze-Authority + 50 × mindestens eine relevante Token-2022-Erweiterung). Beide Authorities müssen bekannt sein. | 30 % |
| Auffällige Marktaktivität | Gemeldetes V5m / L > 1,5 → 90; > 0,5 → 55; sonst 10. L ≤ 0 oder fehlende Eingaben → unbekannt. | 15 % |
| Momentum | Gemeldete Preisänderung 5m; Betrag über 30 % wird hervorgehoben. | 0 % |
| LP-Lock / LP-Eigentümer | Ohne verifizierte Daten unbekannt. | 0 % |
| Transaktionscluster | Ohne öffentlich prüfbare Graph-Evidenz unbekannt. | 0 % |

Relevante Erweiterungen: permanentDelegate, transferHook, nonTransferable, defaultAccountState, transferFeeConfig. Aktive Berechtigungen oder Erweiterungen können legitime Zwecke haben. Fehlende/deaktivierte Berechtigungen beweisen keine Sicherheit. Fehlerhafte RPC-Schemas werden abgelehnt; veraltete Evidenz wird nach dem konfigurierten Onchain-Budget nicht weiter als aktuelle Prüfung gewertet.

## Modellversionen und konservative Auswertung

Neue Reports und Risiko-Audits tragen `modelVersion: "nexus-risk/3"`. Der Vorläufer wird hier als Legacy/v1 beschrieben; historische Reports ohne Versionsfeld werden nicht rückwirkend mit einer Version versehen. Die Oberfläche zeigt dafür „Legacy · Version unbekannt“. Ein Versionswechsel erzeugt auch bei unveränderten Zahlen einen neuen Audit-Eintrag; alte Einträge bleiben erhalten.

Der Gesamtscore von v2 ist nur definiert, wenn alle vier gewichteten Komponenten vorliegen **und** die ausgewählten Marktdaten nach ihrem Frischebudget aktuell sind. Dann ist er die gerundete gewichtete Summe. Sonst ist er null/„unbekannt“; bekannte Teilwerte werden nicht hochgerechnet. Ein bereits bekanntes kritisches Teilrisiko kann trotz unbekanntem Gesamtwert den Zustand „kritisch“ setzen. Einzelrisiko ≥ 70: kritisch, ≥ 35: auffällig, darunter: beobachtet. „Beobachtet“ bedeutet nicht „sicher“. Konzentration ist unmittelbar der Prozentanteil des größten Tokenkontos und keine versteckte Klassifikation.

Nicht endliche oder unzulässige negative Eingaben werden innerhalb der Risikoberechnung als fehlend behandelt; beobachtete Null bleibt Null. Null-Liquidität ist ein kritisches Liquiditätsrisiko, macht V5m/L aber unbekannt. Supply muss eine positive Integer-Zeichenfolge sein; Null-/ungültige Supply verifiziert weder Controls noch Konzentration. Onchain-Evidenz mit Fehler, außerhalb des konfigurierten Altersbudgets oder mehr als 60 Sekunden in der Zukunft gilt nicht als verifiziert. Retrieval-only-Marktdaten erlauben keinen Gesamtwert. Legacy/v1 hatte diese zusätzlichen Schranken nicht durchgängig; historische Scores sind daher nicht ohne Versionskontext mit v2 vergleichbar.

Quellenkonflikte werden bei gleichem Mint und Pool zwischen verschiedenen Providern geprüft: `100 × abs(a−b) / max(a,b)`, oberhalb 10 % für Preis und 20 % für FDV/Liquidität. Die Formel bleibt für nichtnegative endliche Werte zwischen 0 und 100; Null gegen positiv ergibt 100 %, zwei gleiche Werte ergeben keinen Konflikt. Auch extreme Werte erzeugen so weder Infinity noch einen durch JSON zu null gewordenen Konflikt. Eine Depeg-artige Abweichung ist ein Quellenkonflikt, keine Behauptung über einen verifizierten Peg.

Die Datenqualität ist separat:

`round((60 × Marktvollständigkeit + 20 × Controls bekannt + 10 × Konzentration bekannt + 10 × mindestens zwei frische Quellen) × Frischefaktor)`.

Marktvollständigkeit = Anteil vorhandener Werte aus Preis, Liquidität, V5m, V1h, V24h, Käufen 5m, Verkäufen 5m, Preisänderung 5m, FDV oder Market Cap und Pool-Erstellzeit. Frischefaktor 1 bei aktueller Antwort, sonst 0,5. Ein hoher Abdeckungswert ist kein Sicherheitsurteil.

## Evidenzgrenzen

Im finalen realen Beobachtungsfenster des Hauptworkers am 23.10.2026 von 18:59:53.642 bis 19:11:26.430 UTC antworteten sieben `getTokenLargestAccounts`-Aufrufe tatsächlich mit HTTP 429. Rohbeleg: [elite-chain-live-summary.json](reports/elite-chain-live-summary.json); Diagnose: [elite-pipeline-diagnosis.md](docs/elite-pipeline-diagnosis.md). Ein erfolgreicher Mint-Abruf daneben macht die gesamte fehlerbehaftete Chain-Prüfung im v2-Score nicht vollständig. Rohdaten können im Detail erhalten bleiben, während Controls/Konzentration als unverifiziert und der Gesamtwert als unbekannt gewertet werden. Der Worker persistiert die eingeschränkte Evidenz und gibt den typisierten Fehler mit Retry-After an seinen Scheduler weiter; eine Rate-Limit-Antwort wird nicht als erfolgreiche Risikoanreicherung ausgegeben. Gemeinsames Providerbudget und Backoff bleiben wirksam.

Größte Tokenkonten sind keine eindeutigen Wallet-Holder. Depot-, Pool- und technische Konten können enthalten sein; es werden ohne Beleg keine technischen Konten herausgerechnet. Die Kontokonzentration bleibt ausdrücklich von Owner-/Wallet-Konzentration getrennt. Die größten zwanzig Konten sind keine vollständige Holderliste. Dezimalstellen und Supply werden auf der Chain geprüft; Summe/Anteile mit unmöglichen Ergebnissen werden nicht als valide Evidenz übernommen.

Aggregiertes Volumen/Trades beweisen weder Wash Trading noch abgestimmte Wallets. Es gibt keinen belastbaren Funding-/Transfer-Cluster-Score. Fehlende Evidenz wird niemals als 0-Risiko eingesetzt. LP- und Clusterkarten bleiben unbekannt. Für belastbare Erweiterungen wären ein vollständigerer Datenbestand, verifizierte Kontenzuordnungen und separat geprüfte Methoden erforderlich.

Risiko-Audits werden bei geänderten Signalen oder Modellversionen persistiert. Alterungsbedingte Neubewertung erfolgt in der Wartung, spätestens im nächsten ungefähr einminütigen Wartungsdurchlauf; die API prüft Evidenzalter zusätzlich beim Lesen. Serverseitige Risikofilter verwenden den persistierten Snapshot und können bis dahin von frisch berechneten Detailwerten abweichen. Kein garantiert atomarer Live-Risikofilter.

## Datenqualität und Transport

`GET /api/quality` liefert Feldabdeckung, getrennte stale/unknown-Anteile, beobachtete Providerfehler über 24 Stunden, Cache-Zähler mit eigener Aufbewahrung und die aktiven 60-Sekunden-Requestbudgets. Leere Nenner ergeben null. Ohne verifizierte Tarife oder Abrechnungsdaten bleiben Kosten ausdrücklich unbekannt (`totalUsd: null`), nicht 0. Audit-Ereignisse sind keine exakten abrechenbaren Requests: Transport und anschließende Schemaablehnung können getrennte Audits erzeugen. Diese Übersicht misst gespeicherte Daten, nicht Sicherheit oder Provider-Uptime.

Die optionale kompakte Scannerantwort erhält alle ausgewählten Feldwerte, individuelle Herkunft/Missing-/Konfliktzustände und sämtliche Risikoanzeigen. Vollständige alternative Quellenbeobachtungen werden erst im Token-Detail übertragen; die Liste kennzeichnet sie ausdrücklich als nachzuladen. Vertrag und Grenzen: [elite-data-contract.md](docs/elite-data-contract.md). Die Transportreduktion verbessert keine fehlende Evidenz.

## Alerts

Neuer Token/Pool, Liquiditätsänderung, Konzentrationsanstieg, Feed-Ausfall, neue Risikohinweise und Watchlist-Aktivität sind beobachtete Ereignisse. Liquiditätsereignisse entstehen erst ab 10 % Änderung zweier eigener Beobachtungen; die Regel kann eine höhere absolute Schwelle verlangen. Konzentrationsregeln messen Prozentpunkte, keine relativen Prozent. Feed-Ausfall ist global und benötigt eine Regel ohne Mint-/Watchlist-Begrenzung.

Neue Ereignisse tragen Quelle, vorher/nachher, Beobachtungs-/gegebenenfalls Messzeit und Grenzen. Ältere gespeicherte Ereignisse können diese Angaben nicht nachträglich erhalten und zeigen sie als unbekannt. Neue Regeln greifen ab Erstellung. Cooldown, persistierte Deduplizierung, Quota, UTC-Ruhezeiten und optionales nachlaufendes Debounce begrenzen Meldungen. Während Debounce erneute passende Ereignisse verschieben die Fälligkeit; ein erholter Feed wird beim Flush erneut geprüft. Auslösung in der Outbox und bestätigte In-App-Zustellung sind getrennt. Es wird nichts per Mail/Push/Chat versendet.

## Belege und verbleibende Grenzen

[tests/unit/elite-data.test.ts](tests/unit/elite-data.test.ts) prüft unter anderem zero/invalid Supply, fehlerhafte/zukünftige Chain-Prüfungen, fehlende/veraltete Marktdaten, Null-Liquidität und extreme Quellenunterschiede. 150 generierte JSON-DTO-Roundtrips und 100 generierte Extremwertvergleiche verwenden den reproduzierbaren Seed `20261023`. [tests/integration/elite-data.test.ts](tests/integration/elite-data.test.ts) prüft echte PostgreSQL-Abdeckung, Auditversion, Providerfehler/Budgets und die vollständigen Detailquellen. Rot-/Grün-Rohausgaben stehen in [elite-data-test-evidence.txt](reports/elite-data-test-evidence.txt). Weitere Unit-/Integrationsprüfungen betreffen Token-2022, Konzentrationsnormalisierung, Alertregeln, Auditänderungen, Debounce und die deduplizierte Outbox.

Diese Prüfungen validieren Implementierung und Transparenz der Heuristiken, nicht deren Prognosegüte am Markt. Die 692,788 Sekunden reale Pipelinebeobachtung enthalten nur ein versioniertes CPMM-Ereignis; daraus folgen weder allgemeine Risikoabdeckung noch belastbare Latenzperzentile oder eine SLA. Owner-/Wallet-Konzentration, LP-Lock/-Eigentümer, Cluster und vollständige Holderdaten bleiben **PARTIAL/UNKNOWN**; unbekannt wird nicht als Nullrisiko eingesetzt.

## Final Precision v3

V3 erhält erfolgreich geprüfte Mint-Kontrollen bei separatem Holder-RPC-Fehler. `components.contract/holders` tragen eigenen Status, checkedAt und Slot. Holder-RPC fordert minContextSlot des Mints an; ein älterer Context, doppelte Tokenkonten, ungültige Adressen, Supply oder unmögliche Summen liefern keine Konzentrationsbewertung. Das bleibt eine Tokenkonto- und keine wirtschaftliche Holderanalyse; spätere Slots sind kein atomarer Supply-Snapshot. Legacy-Evidenz ohne Komponentenstatus bleibt beim gemeinsamen Error vollständig UNKNOWN.

`risk.evidenceStatus`: COMPLETE wenn alle gewichteten Signale bekannt, DEGRADED bei Teilabdeckung, UNKNOWN ohne verwertbare gewichtete Evidenz. Veraltete Marktbeobachtungen liefern für Liquidität, Aktivität und Momentum UNKNOWN; sie bleiben als historische Werte sichtbar. Alle bisherigen Schwellen und Gewichte bleiben nachvollziehbar. Signals `contract`, `concentration`, `liquidity`, `clusters` und `quality` bilden getrennte Perspektiven; Wallet-Cluster/LP bleiben ohne Belege UNKNOWN. `quality` bewertet Abdeckung, keine Sicherheit.

Das historische Register `tests/fixtures/risk-evaluation/v1.json` enthält derzeit keine unabhängig bestätigten Risikolabels. Precision/Recall/False-Positive-Rate bleiben null, Label-Coverage=0. Unit-Regeln und Propertytests sind kein Scam-Detektionsbenchmark.
