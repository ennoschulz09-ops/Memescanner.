import { defineConfig } from "vitest/config";
import "dotenv/config";
process.env.DATABASE_URL =
  process.env.TEST_DATABASE_URL ||
  "postgresql://nexus:nexus_local_only@localhost:5432/nexus_test";
if(!/^[a-zA-Z0-9_]+_test$/.test(new URL(process.env.DATABASE_URL).pathname.slice(1)))throw new Error('Integrationstests benötigen eine getrennte Datenbank mit Suffix _test.');
export default defineConfig({
  test: {
    include: ["tests/integration/**/*.test.ts"],
    testTimeout: 30000,
    fileParallelism: false,
  },
});
