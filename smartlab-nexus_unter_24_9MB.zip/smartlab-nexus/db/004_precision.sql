-- Additive event tracing; signature is the stable transaction event ID.
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS admitted_at timestamptz;
ALTER TABLE chain_candidates ALTER COLUMN admitted_at SET DEFAULT clock_timestamp();
CREATE TABLE IF NOT EXISTS chain_ui_receipts (
  signature text NOT NULL, owner text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  published_at timestamptz NOT NULL, rendered_at timestamptz NOT NULL,
  PRIMARY KEY(signature,owner)
);
CREATE INDEX IF NOT EXISTS chain_ui_receipts_recent ON chain_ui_receipts(received_at);

CREATE OR REPLACE TRIGGER nexus_chain_notify AFTER INSERT OR UPDATE OR DELETE ON chain_candidates FOR EACH ROW EXECUTE FUNCTION nexus_notify_change();

-- Preserve early candidate receipts separately from confirmed decode renders.
ALTER TABLE chain_ui_receipts ADD COLUMN IF NOT EXISTS rendered_state text NOT NULL DEFAULT 'legacy';
ALTER TABLE chain_ui_receipts DROP CONSTRAINT IF EXISTS chain_ui_receipts_pkey;
ALTER TABLE chain_ui_receipts ADD PRIMARY KEY(signature,owner,rendered_state);
