CREATE TABLE IF NOT EXISTS discoveries (
  mint text NOT NULL, provider text NOT NULL, provenance jsonb NOT NULL,
  first_seen_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  observed_at timestamptz NOT NULL, event_at timestamptz,
  hydrated_at timestamptz, attempted_at timestamptz, next_attempt_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  error text, PRIMARY KEY(mint,provider)
);
CREATE INDEX IF NOT EXISTS discoveries_pending ON discoveries(next_attempt_at,first_seen_at) WHERE hydrated_at IS NULL;
CREATE INDEX IF NOT EXISTS discoveries_recent ON discoveries(first_seen_at DESC);
CREATE TABLE IF NOT EXISTS chain_candidates(signature text PRIMARY KEY,slot bigint NOT NULL,from_replay boolean NOT NULL DEFAULT false,observed_at timestamptz NOT NULL DEFAULT clock_timestamp(),next_attempt_at timestamptz NOT NULL DEFAULT clock_timestamp(),processed_at timestamptz,decoded jsonb);
CREATE INDEX IF NOT EXISTS chain_candidates_pending ON chain_candidates(from_replay,observed_at) WHERE processed_at IS NULL;
CREATE INDEX IF NOT EXISTS pools_seen_page ON pools(first_seen_at DESC,id);
CREATE INDEX IF NOT EXISTS pools_liquidity_page ON pools(((selected->>'liquidityUsd')::double precision) DESC NULLS LAST,id);
CREATE INDEX IF NOT EXISTS pools_dex ON pools((selected->>'dex'));
ALTER TABLE pools ADD COLUMN IF NOT EXISTS activity_increase_pct double precision;
CREATE OR REPLACE FUNCTION nexus_notify_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_TABLE_NAME='pools' THEN
    IF TG_OP='UPDATE' THEN
      IF NEW.revision=OLD.revision THEN RETURN NEW; END IF;
    END IF;
  END IF;
  PERFORM pg_notify('nexus_update',json_build_object('scope',TG_TABLE_NAME)::text);
  RETURN NULL;
END $$;
CREATE OR REPLACE TRIGGER nexus_pool_notify AFTER INSERT OR UPDATE OR DELETE ON pools FOR EACH ROW EXECUTE FUNCTION nexus_notify_change();
CREATE OR REPLACE TRIGGER nexus_discovery_notify AFTER INSERT OR UPDATE OR DELETE ON discoveries FOR EACH ROW EXECUTE FUNCTION nexus_notify_change();
ALTER TABLE events ALTER COLUMN mint DROP NOT NULL;
ALTER TABLE alert_events ALTER COLUMN mint DROP NOT NULL;
CREATE TABLE IF NOT EXISTS alert_candidates (
  rule_id text NOT NULL REFERENCES alert_rules(id) ON DELETE CASCADE, topic text NOT NULL,
  data jsonb NOT NULL, not_before timestamptz NOT NULL, PRIMARY KEY(rule_id,topic)
);
CREATE INDEX IF NOT EXISTS alert_candidates_due ON alert_candidates(not_before);
CREATE OR REPLACE FUNCTION nexus_feed_incident() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status='ok' AND NEW.status IN ('error','limited') THEN
    INSERT INTO events(kind,mint,payload) VALUES('feed_outage',NULL,jsonb_build_object(
      'kind','feed_outage','mint',NULL,'key','feed:'||NEW.provider||':'||clock_timestamp()::text,
      'value',1,'at',to_char(clock_timestamp() AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
      'source',NEW.provider,'before',OLD.status,'after',NEW.status,
      'reason',NEW.error,'limits','Anbieterzustand; keine Aussage über Marktbewegungen.'));
  END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE TRIGGER nexus_feed_incident AFTER UPDATE ON provider_states FOR EACH ROW EXECUTE FUNCTION nexus_feed_incident();
