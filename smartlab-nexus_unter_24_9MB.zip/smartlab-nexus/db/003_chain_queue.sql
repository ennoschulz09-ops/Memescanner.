-- Additive queue evidence; legacy observations and successful rows are retained.
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending';
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS attempt_count integer NOT NULL DEFAULT 0;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS failure_count integer NOT NULL DEFAULT 0;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS attempted_at timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS lease_until timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS lease_token text;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS retry_reason text;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS rpc_code integer;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS terminal_reason text;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS dead_letter_at timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS decoder_version text;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS event_at timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS fetched_at timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS decoded_at timestamptz;
ALTER TABLE chain_candidates ADD COLUMN IF NOT EXISTS discovered_at timestamptz;
UPDATE chain_candidates SET status=CASE WHEN jsonb_typeof(decoded)='array' AND jsonb_array_length(decoded)>0 THEN 'decoded' ELSE 'rejected' END WHERE processed_at IS NOT NULL AND status='pending';
CREATE INDEX IF NOT EXISTS chain_candidates_due ON chain_candidates(next_attempt_at,observed_at) WHERE processed_at IS NULL AND dead_letter_at IS NULL;
CREATE TABLE IF NOT EXISTS chain_candidate_attempts (
  token text PRIMARY KEY, signature text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT clock_timestamp(), completed_at timestamptz,
  outcome text NOT NULL DEFAULT 'processing', reason text, rpc_code integer
);
CREATE INDEX IF NOT EXISTS chain_candidate_attempts_recent ON chain_candidate_attempts(started_at DESC);
CREATE TABLE IF NOT EXISTS chain_feed_cursors (
  program_id text PRIMARY KEY, signature text, slot bigint, observed_at timestamptz,
  replay_status text, coverage_gaps bigint NOT NULL DEFAULT 0, dropped bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

-- Attempts have independent retention so existing candidate truncation/retention stays compatible.
ALTER TABLE chain_candidate_attempts DROP CONSTRAINT IF EXISTS chain_candidate_attempts_signature_fkey;
